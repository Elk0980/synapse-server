"""New TG writer only. A separately reviewed Root READ-ONLY adapter supplies facts.

No old apply/save/finish/cleanup or five-table migration is imported. The adapter
is a mandatory, pinned runtime input, never a synthetic replacement for native
facts. This module implements the actual build/up/CAS/backup/schema operations.
"""
import copy,importlib.util,json,os,re,stat,subprocess,time
from pathlib import Path
from safe_files import need,sha,encoded,read,exact,write_new,cas
import database

ROOT=Path('/opt/synapse/releases/palitra-app-20261015')
LOCK=Path('/opt/synapse/.palitra-app-release.lock')
FLAG='PALITRA_TELEGRAM_MINIAPP_ENABLED'
ADAPTER_API='palitra-tg-root-readonly/v1'

class Ticket:
    def __init__(self,path,digest,package_sha,mode,clock=time.time,lease_check=None):
        self.path=exact(path);need(self.path.parent==ROOT or ROOT in self.path.parents,'ROOT_ACTION_PATH_REQUIRED');self.digest=digest;self.package_sha=package_sha;self.mode=mode;self.clock=clock;self.initial=None;self.lease_check=lease_check or self.native_lease
    def document(self,ref):
        p=exact(ref['path']);need(p.parent==ROOT or ROOT in p.parents,'ROOT_REFERENCE_REQUIRED');s=p.stat()
        need(s.st_uid==s.st_gid==0 and stat.S_IMODE(s.st_mode)==0o600,'PRIVATE_ROOT_REFERENCE_REQUIRED');raw=read(p,native=True);need(sha(raw)==ref['sha256'],'REFERENCE_SHA_CHANGED');return json.loads(raw)
    @staticmethod
    def native_lease(value):
        pid=value['pid'];need(type(pid) is int and pid>1 and value['path']==str(LOCK),'OWN_ROOT_LEASE_REQUIRED')
        raw=Path('/proc/'+str(pid)+'/stat').read_text();ticks=raw[raw.rfind(')')+2:].split()[19];need(ticks==value['startTicks'],'LEASE_PID_REUSED')
        inode=exact(LOCK).stat().st_ino;device=LOCK.stat().st_dev;found=False
        for line in Path('/proc/locks').read_text().splitlines():
            fields=line.split()
            if len(fields)>5 and fields[1]=='FLOCK' and fields[3]=='WRITE' and fields[4]==str(pid):
                major,minor,ino=fields[5].split(':')
                if (int(major,16),int(minor,16),int(ino))==(os.major(device),os.minor(device),inode):found=True
        need(found,'ACTUAL_EXCLUSIVE_ROOT_LEASE_MISSING')
    def check(self,mode):
        need(mode==self.mode,'ACTION_MODE_CHANGED');need(sha(read(self.path,native=True))==self.digest,'ACTION_SHA_CHANGED');s=self.path.stat();need(s.st_uid==s.st_gid==0 and stat.S_IMODE(s.st_mode)==0o600,'ROOT600_ACTION_REQUIRED')
        value=json.loads(read(self.path));required={'schema','mode','status','runtimeAuthorization','packageSha256','namespace','created','expires','lease','queue','bindings'};need(set(value)==required,'CLOSED_ROOT_ACTION_REQUIRED')
        need(value['schema']=='palitra-tg-root-action/v1' and value['mode']==mode and value['packageSha256']==self.package_sha,'ACTION_PACKAGE_MODE_CHANGED')
        need(value['status']==('ROOT_AUTHORIZED_READ_ONLY' if mode=='inspect' else 'ROOT_AUTHORIZED_ONE_ATTEMPT') and value['runtimeAuthorization'] is (mode!='inspect'),'EXPLICIT_ROOT_AUTHORIZATION_REQUIRED')
        need(re.fullmatch('palitra-tg-r7-[a-f0-9]{32}',value['namespace']) is not None,'NEW_NAMESPACE_REQUIRED');need(type(value['created']) in (int,float) and type(value['expires']) in (int,float) and 0<value['expires']-value['created']<=1800 and value['created']<=self.clock()<value['expires'],'ACTION_EXPIRED')
        need(value['queue']=={'resource':'synapse-content-production','owner':'Root','clear':True},'SINGLE_WRITER_QUEUE_REQUIRED');self.lease_check(value['lease'])
        need(set(value['bindings'])=={'installerAcceptance','readonlyAdapterManifest','nativeBase','containerNames','contentContainer'}|({'installedReceipt'} if mode=='rollback' else set()),'CLOSED_NATIVE_BINDINGS_REQUIRED')
        need(self.initial is None or self.initial==value,'ACTION_MUTATED');self.initial=copy.deepcopy(value);return value
    def fast(self):self.check(self.mode)

class Native:
    def __init__(self,ticket,package,directory,journal):
        need(os.name=='posix' and os.geteuid()==0,'LINUX_ROOT_NATIVE_ONLY');self.ticket=ticket;self.package=package;self.directory=Path(directory);self.journal=journal;auth=ticket.check(ticket.mode);self.bindings=auth['bindings'];self.namespace=auth['namespace'];self.child=None;self.forward_plan=None;self.published=set();self.rollback_mode=False
        accepted=ticket.document(self.bindings['installerAcceptance']);need(accepted=={'schema':'palitra-tg-installer-acceptance/v1','status':'ROOT_ACCEPTED_EXACT_INSTALLER_CODE','manifestSha256':ticket.package_sha,'readonlyAdapterManifestSha256':self.bindings['readonlyAdapterManifest']['sha256']},'INSTALLER_AND_READ_ADAPTER_NOT_ACCEPTED')
        contract=ticket.document(self.bindings['readonlyAdapterManifest']);need(contract['schema']==ADAPTER_API and contract['readOnly'] is True and set(contract)=={'schema','readOnly','entry','files','readScriptSha256','readScriptScopes'},'ROOT_READONLY_ADAPTER_CONTRACT_REQUIRED')
        entry=exact(contract['entry']);need(entry.parent.parent==ROOT,'ROOT_READ_ADAPTER_DIRECTORY_REQUIRED')
        actual=set()
        for p in entry.parent.rglob('*'):
            need(not p.is_symlink(),'READ_ADAPTER_DIRECTORY_ALIAS')
            if p.is_file():actual.add(p.relative_to(entry.parent).as_posix())
        need(actual==set(contract['files']),'READ_ADAPTER_CLOSURE_CHANGED')
        for name,pin in contract['files'].items():
            need(not Path(name).is_absolute() and '..' not in Path(name).parts,'READ_ADAPTER_PATH');need(sha(read(entry.parent/name,native=True))==pin,'READ_ADAPTER_SHA_CHANGED')
        self.adapter_files={str(entry.parent/name):pin for name,pin in contract['files'].items()}
        self.read_scripts=set(contract['readScriptSha256']);self.read_scopes=contract['readScriptScopes']
        need(set(self.read_scopes)==self.read_scripts and len(self.read_scripts)==4,'EXACT_SCOPED_READ_SCRIPTS')
        for pin,scope in self.read_scopes.items():
            need(set(scope)=={'containers','images'} and type(scope['images']) is bool and type(scope['containers']) is list and scope['containers'] and len(scope['containers'])==len(set(scope['containers'])) and set(scope['containers'])<=set(self.bindings['containerNames']) and set(scope['containers'])<={'synapse-content-1','synapse-chat-1'},'CLOSED_READ_SCRIPT_SCOPE')
            need(pin in {v for k,v in contract['files'].items() if k.endswith('.js')},'READ_SCRIPT_FILE_PIN_REQUIRED')
        self.allowed_images={package['parentImage']};spec=importlib.util.spec_from_file_location('root_reviewed_readonly',entry);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        need(module.API==ADAPTER_API and module.READ_ONLY is True,'EXACT_READ_ADAPTER_API_REQUIRED')
        self.before=ticket.document(self.bindings['nativeBase']);self.verify_before_contract();self.reader=module.create(self.read_command);self.expected=copy.deepcopy(self.before);self.static_backups=[]
    def command(self,args,timeout=90):
        need(type(args) is list and all(type(v) is str for v in args),'NO_SHELL_ARGUMENTS_REQUIRED');r=subprocess.run(args,stdin=subprocess.DEVNULL,capture_output=True,timeout=timeout,check=True)
        need(len(r.stdout)<=32*1024*1024 and len(r.stderr)<=8*1024*1024,'NATIVE_OUTPUT_BOUND');return r.stdout
    def read_command(self,args):
        ok=args in (['docker','ps','--all','--no-trunc','--format','{{.ID}}'],['docker','ps','--all','--no-trunc','--format','{{.Names}}'])
        if args[:3]==['docker','image','inspect']:ok=(len(args)==4 and args[3] in self.allowed_images) or (len(args)==6 and args[3:5]==['--platform','linux/amd64'] and args[5] in self.allowed_images)
        if args[:2]==['docker','inspect']:ok=len(args)==3 and args[2] in self.bindings['containerNames']
        if args[:2]==['docker','exec']:ok=len(args)==6 and args[3:5]==['node','-e'] and args[2] in self.read_scopes.get(sha(args[5].encode()),{}).get('containers',[])
        prefix=['docker','run','--rm','--network=none','--read-only','--cap-drop=ALL','--security-opt=no-new-privileges','--entrypoint=node']
        if args[:len(prefix)]==prefix:ok=len(args)==len(prefix)+3 and args[-3] in self.allowed_images and args[-2]=='-e' and self.read_scopes.get(sha(args[-1].encode()),{}).get('images') is True
        if args[:2]==['docker','compose'] and hasattr(self,'before'):
            plans=[self.before['compose']['files']]
            if self.forward_plan:plans.append(self.forward_plan['compose']['files'])
            allowed=[self.compose_args(files)+tail for files in plans for tail in (['config','--format','json'],['config','--hash','content'])]
            ok=args in allowed
        need(ok,'READ_ADAPTER_COMMAND_REFUSED');return self.command(args)
    def verify_before_contract(self):
        b=self.before;p=self.package;need(set(b)=={'schema','image','source','appTree','static','env','compose','invariants','database'},'FULL_NORMALIZED_ROOT_CAPTURE_REQUIRED');need(b['schema']=='palitra-tg-native-base/v1','ROOT_CAPTURE_SCHEMA')
        need(b['image']==p['parentImage'] and b['source']==p['sourceBefore'] and b['appTree']==p['appTreeBefore'],'EXACT_CURRENT_R8_CODE_REQUIRED')
        need({k:v['sha256'] for k,v in b['static'].items()}==p['staticBefore'],'EXACT_ALL49_STATIC_REQUIRED');need(b['env'].get(FLAG,'false')=='false','FEATURE_ALREADY_ENABLED')
        need(set(b['invariants'])=={'foreignContainers','runtimeMounts','networks','workerConfig','selection','managedSite','otherEnvironment','authCode','pushCode'},'FULL_NATIVE_INVARIANTS_REQUIRED')
        db=exact(b['database']['path']);volume=exact(b['database']['volumeRoot']);need(volume in db.parents and (db.stat().st_dev,db.stat().st_ino)==tuple(b['database']['identity']),'MOUNTED_CURRENT_DATABASE_REQUIRED')
        c=b['compose'];need(set(c)=={'project','directory','files','resolved'} and c['project']=='synapse' and len(c['files'])==len({f['path'] for f in c['files']}),'CURRENT_COMPOSE_CHAIN_REQUIRED')
        for f in c['files']:need(sha(read(f['path'],native=True))==f['sha256'],'COMPOSE_BASE_CHANGED')
        need(self.bindings['contentContainer'] in self.bindings['containerNames'],'CURRENT_CONTENT_CONTAINER_REQUIRED')
        need(self.bindings['contentContainer']=='synapse-content-1' and len(self.bindings['containerNames'])==len(set(self.bindings['containerNames'])),'EXACT_CURRENT_CONTENT_AND_CONTAINER_CLOSURE')
        need(set(b['invariants']['foreignContainers'])==set(self.bindings['containerNames'])-{'synapse-content-1'},'ALL_FOREIGN_CONTAINERS_REQUIRED')
    def guard(self,phase):
        self.ticket.fast();self.verify_package();names=self.command(['docker','ps','--all','--no-trunc','--format','{{.Names}}']).decode().splitlines();need(set(names)==set(self.bindings['containerNames']) and len(names)==len(set(names)),'DOCKER_CONTAINER_CLOSURE_CHANGED');actual=self.reader.snapshot();want=copy.deepcopy(self.before)
        active=phase in ('running','installed','rollback-running','rolled-back');forward=active and phase not in ('rollback-running','rolled-back')
        if forward:
            need(self.child and self.forward_plan,'CHILD_AND_PLAN_REQUIRED');want.update(image=self.child['image'],source=self.package['sourceAfter'],appTree=self.package['appTreeAfter']);want['env'][FLAG]='true';want['compose']=self.forward_plan['compose']
        for index in self.published:
            row=self.package['staticMirrors'][index];want['static'][row['target']]['sha256']=row['beforeSha256'] if self.rollback_mode else row['afterSha256']
        # During rollback before individual static restores, un-restored mirrors
        # still contain the installed bytes while original runtime is active.
        if self.rollback_mode:
            for index,row in enumerate(self.package['staticMirrors']):want['static'][row['target']]['sha256']=row['beforeSha256'] if index in self.published else row['afterSha256']
        need(actual==want,'FULL_NATIVE_BASE_OR_POST_STATE_CHANGED');return {'phase':phase,'snapshotSha256':sha(encoded(actual))}
    def verify_package(self):
        need(sha(read(self.directory/'code-manifest.json',native=True))==self.ticket.package_sha,'PACKAGE_MANIFEST_CHANGED')
        for name,pin in self.package['_closure'].items():need(sha(read(self.directory/name,native=True))==pin,'PACKAGE_CHANGED_AFTER_ADMISSION')
        for name,pin in self.adapter_files.items():need(sha(read(name,native=True))==pin,'READ_ADAPTER_CHANGED_AFTER_ADMISSION')
        for name in ('installerAcceptance','nativeBase','readonlyAdapterManifest'):self.ticket.document(self.bindings[name])
    def payload(self,target):
        row=next(r for r in self.package['files'] if r['target']==target);raw=read(self.directory/row['file'],native=True);need(sha(raw)==row['sha256'] and len(raw)==row['bytes'],'EXACT_PAYLOAD_REQUIRED');return raw
    def backup(self):
        self.guard('before');result={'content':database.backup(self.before['database']['path'],self.journal.root/'content.sqlite',self.ticket.fast),'static':[],'nativeBase':self.bindings['nativeBase']}
        for index,row in enumerate(self.package['staticMirrors']):
            p=exact(row['target']);raw=read(p,native=True);need(sha(raw)==row['beforeSha256'],'STATIC_BACKUP_CAS');dest=self.journal.root/('static-'+str(index));write_new(dest,raw);result['static'].append({'path':str(dest),'sha256':sha(raw),'target':row['target'],'mode':stat.S_IMODE(p.stat().st_mode)})
        self.static_backups=result['static'];return result
    def build(self):
        self.guard('before');context=self.journal.root/'context';context.mkdir(mode=0o700);app=context/'app';app.mkdir(mode=0o755)
        for row in self.package['files']:
            dest=app/row['target'];dest.parent.mkdir(mode=0o755,parents=True,exist_ok=True);write_new(dest,self.payload(row['target']),0o644)
        alias='synapse-'+self.namespace+'-base:local';tag='synapse-'+self.namespace+':local'
        need(self.command(['docker','image','ls','--quiet',alias]).strip()==self.command(['docker','image','ls','--quiet',tag]).strip()==b'','IMAGE_NAME_EXISTS_NO_REPLAY')
        dockerfile=('FROM '+alias+'\nCOPY app/ /app/\n').encode();write_new(context/'Dockerfile',dockerfile)
        def context_guard():
            wanted={'Dockerfile':sha(dockerfile),**{'app/'+r['target']:r['sha256'] for r in self.package['files']}}
            actual={}
            for p in context.rglob('*'):
                need(not p.is_symlink(),'BUILD_CONTEXT_ALIAS')
                if p.is_file():actual[p.relative_to(context).as_posix()]=sha(read(p,native=True))
            need(actual==wanted,'CLOSED_BUILD_CONTEXT_CHANGED')
        context_guard();self.ticket.fast();self.command(['docker','image','tag',self.package['parentImage'],alias]);context_guard();self.guard('before');self.command(['docker','build','--network=none','--pull=false','--tag',tag,'--iidfile',str(context/'image.id'),str(context)],180)
        image=read(context/'image.id').decode().strip();need(re.fullmatch('sha256:[a-f0-9]{64}',image) and image!=self.package['parentImage'],'NEW_CHILD_IMAGE_REQUIRED');self.allowed_images.add(image);self.child={'image':image};self.verify_child(self.child);return self.child
    def verify_child(self,child):
        self.child=child;self.allowed_images.add(child['image']);parent=self.reader.image(self.package['parentImage']);new=self.reader.image(child['image']);need(parent['id']==self.package['parentImage'] and new['id']==child['image'] and new['layers'][:-1]==parent['layers'] and len(new['layers'])==len(parent['layers'])+1 and new['config']==parent['config'] and new['appTree']==self.package['appTreeAfter'],'EXACT_ONE_COPY_CHILD_REQUIRED')
    def compose_args(self,files):
        c=self.before['compose'];return ['docker','compose','--project-name',c['project'],'--project-directory',c['directory']]+[v for f in files for v in ('--file',f['path'])]
    def plan(self,child,enable=True):
        self.guard('before');overlay=self.journal.root/'content-overlay.json';write_new(overlay,encoded({'services':{'content':{'image':child['image'],'environment':{FLAG:'true'}}}}));files=self.before['compose']['files']+[{'path':str(overlay),'sha256':sha(read(overlay))}];resolved=json.loads(self.command(self.compose_args(files)+['config','--format','json']));expected=copy.deepcopy(self.before['compose']['resolved']);expected['services']['content']['image']=child['image'];expected['services']['content'].setdefault('environment',{})[FLAG]='true';need(resolved==expected,'ONLY_CONTENT_IMAGE_AND_FEATURE_FLAG_MAY_CHANGE')
        plan={'compose':{**self.before['compose'],'files':files,'resolved':resolved}};self.forward_plan=plan;return plan
    def schema(self):
        raw=read(self.directory/'schema.sql',native=True);need(sha(raw)==self.package['_closure']['schema.sql'],'SINGLE_SCHEMA_SHA_CHANGED');return database.prepare(self.before['database']['path'],raw.decode(),self.ticket.fast)
    def ready(self,rollback=False):
        # Rollback disables our feature and restores the original environment;
        # an unhealthy bot must not prevent this explicit, separately admitted recovery.
        if rollback:return {'featureEnable':False,'schemaAndAllCurrentDataRetained':True}
        facts=self.reader.readiness();need(set(facts)=={'uniqueExistingBot','healthyExistingBridge','signedVerifier','currentStaffBinding','sameOrigin','csp','refKey','miniappSchema'} and all(v is True for v in facts.values()),'BOT_ENV_SCHEMA_READINESS_NOT_PROVEN');return facts
    def up(self,plan):
        self.ticket.fast();files=plan['compose']['files']
        for f in files:need(sha(read(f['path'],native=True))==f['sha256'],'LATE_COMPOSE_FILE_CAS')
        resolved=json.loads(self.command(self.compose_args(files)+['config','--format','json']));need(resolved==plan['compose']['resolved'],'LATE_COMPOSE_PLAN_CHANGED');self.ready(rollback=self.rollback_mode);self.guard('installed' if self.rollback_mode else 'before');self.ticket.fast();self.command(self.compose_args(files)+['up','--detach','--no-build','--pull','never','--no-deps','content'],180);return {'commandReturnedZero':True,'needsReadback':True}
    def publish(self,index):
        self.guard('running');row=self.package['staticMirrors'][index];mode=self.before['static'][row['target']]['mode'];cas(row['target'],row['beforeSha256'],self.payload(row['runtimeSource']),mode,self.ticket.fast);self.published.add(index);return {'target':row['target'],'sha256':row['afterSha256']}
    def bind_rollback(self,installed):
        self.child=installed['child'];self.allowed_images.add(self.child['image']);self.forward_plan=installed['plan'];self.published={0,1};self.installed=installed
    def rollback_plan(self):
        files=self.before['compose']['files'];resolved=json.loads(self.command(self.compose_args(files)+['config','--format','json']));need(resolved==self.before['compose']['resolved'],'ORIGINAL_COMPOSE_ENV_CHANGED');self.rollback_mode=True;self.published=set();return {'compose':self.before['compose']}
    def restore_static(self,index,installed):
        self.guard('rollback-running');row=self.package['staticMirrors'][index];saved=installed['backup']['static'][index];need(saved['target']==row['target'] and saved['sha256']==row['beforeSha256'],'EXACT_OWN_STATIC_BACKUP_REQUIRED');raw=read(saved['path'],native=True);need(sha(raw)==row['beforeSha256'],'STATIC_BACKUP_CHANGED');cas(row['target'],row['afterSha256'],raw,saved['mode'],self.ticket.fast);self.published.add(index);return {'target':row['target'],'sha256':row['beforeSha256']}
