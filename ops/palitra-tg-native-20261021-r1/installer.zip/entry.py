"""Fresh Root apply/explicit rollback/inspect. No automatic retry or old actions."""
import argparse,hashlib,json,os,re,stat,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('/opt/synapse/releases/palitra-app-20261015')
NAME='palitra-tg-r7-installer-readbinding-r1'

def need(ok,code):
    if not ok:raise ValueError(code)
def load_package(directory,manifest_sha,native=True):
    directory=Path(directory)
    if native:need(os.name=='posix' and os.geteuid()==0 and directory==ROOT/(NAME+'-code'),'EXACT_LINUX_ROOT_STAGED_CODE_REQUIRED')
    def read(p):
        for x in [p,*p.parents]:need(not x.is_symlink(),'PACKAGE_ALIAS')
        s=p.stat();need(stat.S_ISREG(s.st_mode) and s.st_nlink==1 and s.st_size<=32*1024*1024,'REGULAR_PACKAGE_FILE')
        if native:need(s.st_uid==s.st_gid==0 and stat.S_IMODE(s.st_mode)==0o600,'ROOT600_CODE_REQUIRED')
        raw=p.read_bytes();z=p.stat();need((s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)==(z.st_dev,z.st_ino,z.st_size,z.st_mtime_ns) and len(raw)==s.st_size,'PACKAGE_READ_RACE');return raw
    raw=read(directory/'code-manifest.json');need(hashlib.sha256(raw).hexdigest()==manifest_sha,'EXPLICIT_EXACT_MANIFEST_SHA_REQUIRED');manifest=json.loads(raw)
    need(set(manifest)=={'schema','runtimeAuthorization','files'} and manifest['schema']=='palitra-tg-installer-code/v1' and manifest['runtimeAuthorization'] is False,'CODE_ONLY_MANIFEST_REQUIRED')
    files=manifest['files'];need(type(files) is dict and 35<=len(files)<=80,'BOUNDED_CLOSED_PACKAGE')
    actual=set();dirs=set()
    for p in directory.rglob('*'):
        need(not p.is_symlink(),'PACKAGE_DIRECTORY_ALIAS')
        if p.is_file():actual.add(p.relative_to(directory).as_posix())
        elif p.is_dir():dirs.add(p.relative_to(directory).as_posix())
    need(actual==set(files)|{'code-manifest.json'},'CLOSED_FILE_SET_CHANGED')
    wanted_dirs={p.as_posix() for name in files for p in Path(name).parents if str(p)!='.'};need(dirs==wanted_dirs,'CLOSED_DIRECTORY_SET_CHANGED')
    for name,pin in files.items():
        need(type(name) is str and '\\' not in name and ':' not in name and all(v not in ('','.','..') for v in name.split('/')) and not name.startswith('/'),'PACKAGE_RELATIVE_PATH')
        need(hashlib.sha256(read(directory/name)).hexdigest()==pin,'CODE_PAYLOAD_SHA_CHANGED')
    package=json.loads(read(directory/'package.json'));need(package['schema']=='palitra-tg-installer-package/v1' and package['runtimeAuthorization'] is False,'PACKAGE_SCHEMA')
    need(len(package['files'])==29 and len(package['staticMirrors'])==2 and len(package['sourceBefore'])==244 and len(package['sourceAfter'])==264,'EXACT_TG_CLOSURE_REQUIRED')
    for row in package['files']:
        name=row['target'];need(not name.startswith('/') and '\\' not in name and ':' not in name and all(v not in ('','.','..') for v in name.split('/')),'PAYLOAD_TARGET_ESCAPE')
        need(row['file']=='payload/'+name and files[row['file']]==row['sha256'],'CLOSED_PAYLOAD_BINDING')
    package['_closure']=files;return package

def main(argv=None):
    parser=argparse.ArgumentParser();parser.add_argument('--mode',choices=('apply','rollback','inspect'),required=True);parser.add_argument('--manifest-sha',required=True);parser.add_argument('--action',required=True);parser.add_argument('--action-sha',required=True);args=parser.parse_args(argv)
    directory=Path(__file__).resolve().parent;package=load_package(directory,args.manifest_sha)
    # Only after code closure verification are project modules imported.
    from native import Ticket,Native
    from safe_files import Journal,encoded,write_new,sha
    import controller
    ticket=Ticket(args.action,args.action_sha,args.manifest_sha,args.mode);auth=ticket.check(args.mode)
    if args.mode=='inspect':
        backend=Native(ticket,package,directory,None);observed=backend.reader.snapshot();print(json.dumps({'status':'READ_ONLY_INSPECT_NO_REPLAY','snapshotSha256':sha(encoded(observed))}));return 0
    # Constructor validates all required Root read contracts before consuming an action.
    backend=Native(ticket,package,directory,None)
    journal=Journal(ROOT/(auth['namespace']+'-'+args.mode),{'actionSha256':args.action_sha,'manifestSha256':args.manifest_sha});backend.journal=journal
    if args.mode=='apply':result=controller.apply(ticket,backend,journal,package)
    else:result=controller.rollback(ticket,backend,journal,ticket.document(auth['bindings']['installedReceipt']))
    write_new(journal.root/'result.json',encoded(result));print(json.dumps({'status':result['status'],'resultSha256':sha(encoded(result))}));return 0
if __name__=='__main__':
    try:raise SystemExit(main())
    except Exception as error:
        # No secrets, business data or shell output are copied to the terminal.
        code=str(error);print(json.dumps({'status':'STOP_INSPECT_ONLY_NO_RETRY','error':type(error).__name__,'code':code if isinstance(error,ValueError) and re.fullmatch('[A-Z0-9_]{1,96}',code) else 'NATIVE_OPERATION_FAILED'}),file=sys.stderr);raise SystemExit(2)
