"""One explicit additive schema and consistent protected backup; never restore."""
import json,os,sqlite3,stat,time,collections
from contextlib import closing
from pathlib import Path
from safe_files import need,sha,encoded,exact,read,write_new

TABLE='palitra_miniapp_sessions'
def typed(v):
    if v is None:return ['null']
    if isinstance(v,bytes):return ['blob',v.hex()]
    if isinstance(v,int):return ['integer',str(v)]
    if isinstance(v,float):return ['real',v.hex()]
    return ['text',v]
def protected_seal(db):
    schema=db.execute("SELECT type,name,tbl_name,sql FROM sqlite_schema WHERE tbl_name!=? ORDER BY type,name",(TABLE,)).fetchall()
    tables=[];size=0
    for name, in db.execute("SELECT name FROM sqlite_schema WHERE type='table' AND name!=? ORDER BY name",(TABLE,)):
        quoted='"'+name.replace('"','""')+'"';rows=collections.Counter()
        for row in db.execute('SELECT * FROM '+quoted):
            value=encoded([typed(v) for v in row]);size+=len(value);need(size<=512*1024*1024,'PROTECTED_SEAL_LIMIT');rows[sha(value)]+=1
        tables.append([name,sorted(rows.items())])
    return sha(encoded({'schema':schema,'tables':tables}))
def assert_schema(db):
    row=db.execute("SELECT sql FROM sqlite_schema WHERE type='table' AND name=?",(TABLE,)).fetchone();need(row is not None,'MINIAPP_SCHEMA_ABSENT')
    cols=db.execute('PRAGMA table_info('+TABLE+')').fetchall();names=['token_hash','company_code','bot_key','bot_id','created_at','expires_at']
    need(len(cols)==6 and all(c[1]==names[i] and c[2]==('TEXT' if i<4 else 'INTEGER') and c[5]==(1 if i==0 else 0) and c[3]==(0 if i==0 else 1) for i,c in enumerate(cols)),'MINIAPP_SCHEMA_COLUMNS')
    fk=db.execute('PRAGMA foreign_key_list('+TABLE+')').fetchall();need(len(fk)==1 and fk[0][2:5]==('palitra_crm_sessions','token_hash','token_hash') and fk[0][6]=='CASCADE','MINIAPP_SCHEMA_FOREIGN_KEY')
    need("CHECK(company_code='palitra-love')" in row[0].replace(' ',''),'MINIAPP_SCHEMA_COMPANY')
def backup(source,destination,guard):
    source=exact(source);before=source.stat();need(stat.S_ISREG(before.st_mode) and before.st_nlink==1,'DATABASE_REGULAR_REQUIRED');guard()
    destination=exact(destination,True);write_new(destination,b'');uri=source.as_uri()+'?mode=ro'
    with closing(sqlite3.connect(uri,uri=True)) as src,closing(sqlite3.connect(destination)) as dst:
        started=time.monotonic()
        def progress(status,remaining,total):
            need(time.monotonic()-started<120,'BACKUP_DEADLINE');guard()
        src.execute('PRAGMA query_only=ON');src.backup(dst,pages=128,progress=progress);need(dst.execute('PRAGMA quick_check').fetchone()==('ok',),'BACKUP_QUICK_CHECK');seal=protected_seal(dst)
    guard();need((source.stat().st_dev,source.stat().st_ino)==(before.st_dev,before.st_ino),'DATABASE_REPLACED')
    return {'path':str(destination),'sha256':sha(read(destination,512*1024*1024)),'protectedSnapshot':seal,'restorableAutomatically':False}
def prepare(source,ddl,locked_guard,timeout_seconds=30):
    source=exact(source);before=source.stat();need(source.is_file() and before.st_nlink==1,'DATABASE_REGULAR_REQUIRED')
    need(ddl.count('CREATE TABLE')==1 and ('CREATE TABLE IF NOT EXISTS '+TABLE+' (') in ddl and ';' not in ddl.rstrip().rstrip(';'),'EXACT_SINGLE_DDL_REQUIRED')
    # mode=rw refuses a vanished database instead of silently creating an empty one.
    with closing(sqlite3.connect(source.as_uri()+'?mode=rw',uri=True,timeout=5,isolation_level=None)) as db:
        db.execute('PRAGMA foreign_keys=ON');db.execute('BEGIN IMMEDIATE');started=time.monotonic()
        try:
            locked_guard();need(db.execute("SELECT 1 FROM sqlite_schema WHERE type='table' AND name='palitra_crm_sessions'").fetchone() is not None,'CRM_SCHEMA_PREREQUISITE')
            before_seal=protected_seal(db);changes=db.total_changes
            existed=db.execute('SELECT 1 FROM sqlite_schema WHERE name=?',(TABLE,)).fetchone() is not None
            if existed:assert_schema(db)
            db.execute(ddl);assert_schema(db);need(db.total_changes==changes and protected_seal(db)==before_seal,'PROTECTED_CURRENT_ROWS_CHANGED')
            need(time.monotonic()-started<timeout_seconds,'SCHEMA_LOCK_DEADLINE');locked_guard();need((source.stat().st_dev,source.stat().st_ino)==(before.st_dev,before.st_ino),'DATABASE_REPLACED')
            db.execute('COMMIT');return {'created':not existed,'protectedCurrentSha256':before_seal,'businessRowsChanged':0,'schemaOnly':TABLE}
        except BaseException:
            db.execute('ROLLBACK');raise
