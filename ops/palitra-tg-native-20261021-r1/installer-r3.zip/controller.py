"""Executable one-attempt apply/rollback orchestration. Backend owns native IO."""
import copy,json,time
from safe_files import need,sha,encoded,read

def apply(ticket,backend,journal,package):
    need(journal.sequence==0,'ATTEMPT_EXISTS_INSPECT_ONLY')
    ticket.check('apply');backend.guard('before');journal.record('admission','PASSED')
    saved=journal.once('protected-backup',backend.backup)
    child=journal.once('one-copy-build',backend.build)
    backend.guard('before');backend.verify_child(child)
    plan=journal.once('compose-plan',lambda:backend.plan(child,enable=True))
    backend.guard('before');ticket.check('apply')
    schema=journal.once('single-miniapp-schema',backend.schema)
    backend.guard('before');backend.ready();ticket.check('apply')
    # Final full guard after planning/schema and immediately before the one up.
    backend.guard('before');up=journal.once('content-up',lambda:backend.up(plan))
    backend.guard('running')
    for index in range(2):journal.once('static-'+str(index),lambda index=index:backend.publish(index))
    observed=backend.guard('installed');backend.ready()
    result={'status':'INSTALLED_PENDING_ROOT_LIVE_ACCEPTANCE','backup':saved,'child':child,'plan':plan,'schema':schema,'up':up,'observed':observed,'packageSha256':ticket.package_sha,'databaseRestoreAllowed':False,'runtimeAcceptance':False}
    journal.record('installed','READBACK_NOT_WHOLE_APP_ACCEPTANCE',result);return result

def rollback(ticket,backend,journal,installed):
    need(journal.sequence==0,'ATTEMPT_EXISTS_INSPECT_ONLY')
    ticket.check('rollback');need(installed.get('status')=='INSTALLED_PENDING_ROOT_LIVE_ACCEPTANCE' and installed.get('packageSha256')==ticket.package_sha,'EXACT_KNOWN_INSTALLED_RECEIPT_REQUIRED')
    backend.bind_rollback(installed);backend.guard('installed');backend.ready(rollback=True)
    # Deliberately NO backup restoration, table deletion, managed save or replay.
    plan=journal.once('rollback-plan',backend.rollback_plan)
    backend.guard('installed');ticket.check('rollback');journal.once('rollback-up',lambda:backend.up(plan))
    backend.guard('rollback-running')
    for index in range(2):journal.once('rollback-static-'+str(index),lambda index=index:backend.restore_static(index,installed))
    observed=backend.guard('rolled-back');result={'status':'CODE_STATIC_ENV_ROLLED_BACK_DATA_AND_SCHEMA_RETAINED','observed':observed,'databaseRestored':False,'schemaDropped':False}
    journal.record('rollback','READBACK_NOT_CUSTOMER_ACCEPTANCE',result);return result
