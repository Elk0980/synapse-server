CREATE TABLE IF NOT EXISTS palitra_miniapp_sessions (
  token_hash TEXT PRIMARY KEY REFERENCES palitra_crm_sessions(token_hash) ON DELETE CASCADE,
  company_code TEXT NOT NULL CHECK(company_code='palitra-love'), bot_key TEXT NOT NULL, bot_id TEXT NOT NULL,
  created_at INTEGER NOT NULL, expires_at INTEGER NOT NULL
);