"""Private, bounded files and CAS. No shell, database restore or service calls."""
import hashlib,json,os,stat
from pathlib import Path

def need(ok,code):
    if not ok: raise ValueError(code)
def sha(raw): return hashlib.sha256(raw).hexdigest()
def encoded(value): return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def exact(path,missing=False):
    p=Path(path);need(p.is_absolute(),'ABSOLUTE_PATH_REQUIRED')
    for part in [p,*p.parents]:need(not part.is_symlink(),'PATH_ALIAS_REFUSED')
    need(missing or p.exists(),'PATH_MISSING');return p
def identity(s):return (s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns)
def read(path,limit=32*1024*1024,native=False):
    p=exact(path);a=p.lstat();need(stat.S_ISREG(a.st_mode) and a.st_nlink==1 and a.st_size<=limit,'BOUNDED_REGULAR_FILE_REQUIRED')
    if native:need(a.st_uid==a.st_gid==0,'ROOT_FILE_REQUIRED')
    fd=os.open(p,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0))
    try:
        raw=os.read(fd,limit+1);need(identity(a)==identity(os.fstat(fd))==identity(p.lstat()) and len(raw)==a.st_size,'READ_RACE')
        return raw
    finally:os.close(fd)
def sync_dir(p):
    if os.name!='posix':return
    fd=os.open(p,os.O_RDONLY|getattr(os,'O_DIRECTORY',0))
    try:os.fsync(fd)
    finally:os.close(fd)
def write_new(path,raw,mode=0o600):
    p=exact(path,True);fd=os.open(p,os.O_CREAT|os.O_EXCL|os.O_WRONLY|getattr(os,'O_NOFOLLOW',0),mode)
    try:
        if os.name=='posix':os.fchmod(fd,mode)
        with os.fdopen(fd,'wb',closefd=False) as f:f.write(raw);f.flush();os.fsync(fd)
    finally:os.close(fd)
    sync_dir(p.parent)
def cas(path,before,raw,mode,guard):
    p=exact(path);a=p.lstat();need(sha(read(p))==before,'STATIC_CAS_CHANGED');guard()
    tmp=p.with_name(p.name+'.tg-'+os.urandom(12).hex());write_new(tmp,raw,mode)
    # A concurrent writer is forbidden by the external Root lease; still recheck
    # bytes AND inode immediately before atomic rename, and fail closed on drift.
    need(identity(p.lstat())==identity(a) and sha(read(p))==before,'LATE_STATIC_CAS_CHANGED');guard();os.replace(tmp,p);sync_dir(p.parent)
    need(sha(read(p))==sha(raw),'STATIC_READBACK_FAILED')

class Journal:
    def __init__(self,directory,bindings):
        self.root=exact(directory,True);self.root.mkdir(mode=0o700);sync_dir(self.root.parent)
        self.bindings=bindings;self.sequence=0;self.previous=None;self.started=set()
    def record(self,phase,status,facts=None):
        value={'phase':phase,'status':status,'facts':facts,'bindings':self.bindings,'previous':self.previous,'automaticRetry':False,'databaseRestore':False,'runtimeAcceptance':False}
        raw=encoded(value);write_new(self.root/('%03d.json'%self.sequence),raw);self.previous=sha(raw);self.sequence+=1
    def once(self,name,call):
        need(name not in self.started,'ACTION_STARTED_NO_REPLAY');self.started.add(name)
        self.record(name,'STARTED_UNKNOWN_INSPECT_ONLY')
        value=call();self.record(name,'RETURNED_REQUIRES_READBACK',value);return value
