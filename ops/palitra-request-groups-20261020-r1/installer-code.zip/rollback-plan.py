"""Pure manual rollback descriptor; never invokes restore, publication or up."""
import hashlib,json
from pathlib import Path
NAME = 'palitra-request-groups-20261020-r1'
ROOT=Path('/opt/synapse/releases/palitra-app-20261015')
PARENT = 'sha256:c2ee8188f781150bd3b64159852e73cd41fe20eb7cdd3721e1ecd19bcf6545b5'
def plan(release,receipt_pin):
    release.inspect(receipt_pin)
    state=release.a.pinned(release.paths['journal'],receipt_pin,True)
    files=state['after']['containers']['content']['files']
    if state['name']!=NAME or state['binding']['parentImage']!=PARENT or len(files)!=len(set(files)) or len(files)!=47:raise ValueError('EXACT_COMPLETED_FORWARD47_REQUIRED')
    if state['written']!=release.static_targets or Path(state['written'][-1]).name!='cabinet.html':raise ValueError('EXACT_STATIC_CABINET_LAST_REQUIRED')
    release.n.code_backup_guard(state['codeBackups'])
    overlay=ROOT/(NAME+'-rollback-r1-overlay.json');raw=json.dumps({'services':{'content':{'image':PARENT}}},sort_keys=True,separators=(',',':')).encode()
    if str(overlay) in files:raise ValueError('FRESH_ROLLBACK_NAMESPACE_REQUIRED')
    prefix=['docker','compose']+[v for p in [*files,str(overlay)] for v in ('-f',p)]
    return {'schema':1,'status':'PLAN_ONLY_NOT_AUTHORIZATION','namespace':NAME+'-rollback-r1','receiptSha256':receipt_pin,
        'fromImage':state['childImage'],'toImage':PARENT,'currentCidRequired':state['after']['contentCid'],
        'overlayPath':str(overlay),'overlayUtf8':raw.decode(),'overlaySha256':hashlib.sha256(raw).hexdigest(),
        'composeBefore':files,'composeAfter':[*files,str(overlay)],'expectedSourceFiles':240,'expectedStaticFiles':43,'expectedChainFiles':48,
        'sourceReversals':[{'path':r['target'],'fromSha256':r['sha256'],'toSha256':r['beforeSha256']} for r in release.records],
        'staticRestoreOrder':release.static_targets,'staticBackups':state['codeBackups']['static'],'cabinetLast':True,
        'planArgv':prefix+['config','--hash','content'],'oneUpArgv':prefix+['up','-d','--no-deps','--no-build','--pull','never','content'],
        'mandatory':['New explicit Root rollback acceptance/fresh own PID/current full CAS',
            'New EXCL UNKNOWN journal; no replay of forward or failed namespaces',
            'Verify exact preserved parent image/code and current source240/static43/compose47/env/worker/managed259',
            'One final rollback plan THEN fresh current report/content/traffic consistent backups including committed WAL',
            'Preserve current all three DB schemas/auth/grants/observation/old and new rows; never restore old DB or absence',
            'Exact current SHA/mode/owner/link CAS for the four private static originals; cabinet.html last',
            'Late lease/time/context/code/data guards immediately before one approved up',
            'Postverify parent code/source240/static43/chain48 and unchanged protected runtime/current data'],
        'databaseRestore':False,'schemaChanges':0,'workerRecreated':False,'automaticRetry':False,'automaticRollback':False,
        'uiRollbackRisk':'Old client entry UI returns with parent code; newer business data is retained'}
