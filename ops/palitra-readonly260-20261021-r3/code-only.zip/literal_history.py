"""AST literal-only history traversal. No old module imports or constructors.

Only explicit read-and-hash / pinned(path, literalSha) relations are followed.
Unknown dynamic relations are not treated as verified. Full static closure is
required separately, so an incomplete traversal cannot silently grant success.
"""
import ast,hashlib,json,re
from pathlib import PurePosixPath

ROOT=PurePosixPath('/opt/synapse/releases/palitra-app-20261015')
# Sealed cart-total-copy payload contract: records.name is relative to product/.
STATIC_COPY_MANIFEST_SHA='e2e8f0364c9df75d580391e6aba79ac7b227c2eb81a2b194552576336ec6bf87'
def need(v,c):
    if not v:raise ValueError(c)
def digest(v):return type(v) is str and re.fullmatch('[a-f0-9]{64}',v) is not None
def constants(tree):
    out={}
    for node in tree.body:
        if isinstance(node,ast.Assign):
            try:value=ast.literal_eval(node.value)
            except Exception:continue
            for target in node.targets:
                if isinstance(target,ast.Name):out[target.id]=value
    return out
def relations(raw,filename):
    tree=ast.parse(raw,filename=filename);global_env=constants(tree);global_env.setdefault('ROOT',ROOT)
    found={}
    def value(node,env):
        if isinstance(node,ast.Constant):return node.value
        if isinstance(node,ast.Name):return env.get(node.id)
        if isinstance(node,ast.BinOp):
            a,b=value(node.left,env),value(node.right,env)
            if isinstance(node.op,ast.Div) and isinstance(a,(str,PurePosixPath)) and isinstance(b,str):return PurePosixPath(a)/b
            if isinstance(node.op,ast.Add) and isinstance(a,str) and isinstance(b,str):return a+b
        if isinstance(node,ast.Call):
            if isinstance(node.func,ast.Name) and node.func.id=='Path' and len(node.args)==1:
                v=value(node.args[0],env)
                if isinstance(v,(str,PurePosixPath)):return PurePosixPath(v)
            if isinstance(node.func,ast.Attribute) and node.func.attr=='read_bytes' and not node.args:
                p=value(node.func.value,env)
                if isinstance(p,PurePosixPath):return ('bytes',p)
            if isinstance(node.func,ast.Attribute) and node.func.attr=='read' and len(node.args)==1:
                p=value(node.args[0],env)
                if isinstance(p,PurePosixPath):return ('bytes',p)
        return None
    def add(path,pin):
        if not isinstance(path,PurePosixPath) or not digest(pin):return
        # Runtime/public paths in old methods are not historical release seals.
        # The new full snapshot checks their current values independently.
        if not path.is_absolute() or '..' in path.parts or not path.is_relative_to(ROOT):return
        need(str(path) not in found or found[str(path)]==pin,'CONFLICTING_HISTORICAL_LITERAL_PINS');found[str(path)]=pin
    def inspect(node,env):
        for call in ast.walk(node):
            if isinstance(call,ast.Call) and isinstance(call.func,ast.Attribute) and call.func.attr=='pinned' and len(call.args)>=2:add(value(call.args[0],env),value(call.args[1],env))
            if isinstance(call,ast.Compare) and len(call.ops)==1 and isinstance(call.ops[0],ast.Eq):
                pairs=[(call.left,call.comparators[0]),(call.comparators[0],call.left)]
                for left,right in pairs:
                    if isinstance(left,ast.Call) and isinstance(left.func,ast.Name) and left.func.id=='sha' and len(left.args)==1:
                        raw_value=value(left.args[0],env)
                        if isinstance(raw_value,tuple) and raw_value[0]=='bytes':add(raw_value[1],value(right,env))
    def body(nodes,env):
        for node in nodes:
            if isinstance(node,ast.Assign):
                v=value(node.value,env)
                for target in node.targets:
                    if isinstance(target,ast.Name) and v is not None:env[target.id]=v
                inspect(node,env)
            elif isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):body(node.body,dict(env))
            elif isinstance(node,ast.ClassDef):body(node.body,dict(env))
            else:
                inspect(node,env)
                # Statically inspect branch literals in isolated environments.
                for field in ('body','orelse','finalbody'):
                    children=getattr(node,field,None)
                    if isinstance(children,list):body(children,dict(env))
                for handler in getattr(node,'handlers',[]):body(handler.body,dict(env))
    body(tree.body,global_env)
    # Uniform modern completed-parent seam has literal namespace and pins.
    c=global_env;name=c.get('PARENT_NAME')
    if isinstance(name,str) and re.fullmatch('[a-z0-9][a-z0-9-]{0,120}',name):
        for key,suffix in [('JOURNAL_SHA','journal'),('PARENT_RECEIPT','journal'),('DECISION_SHA','decision'),('ACCEPTANCE_SHA','root-acceptance'),('PREFLIGHT_SHA','preflight')]:add(ROOT/(name+'-'+suffix+'.json'),c.get(key))
        for key,suffix in [('MANIFEST_SHA','manifest.json'),('ENTRY_SHA','company-app.py'),('NATIVE_SHA','native.py'),('CONTROLLER_SHA','controller.py'),('PARENT_HELPER','release-native.py'),('PARENT_ENTRY','company-app.py')]:add(ROOT/(name+'-code')/suffix,c.get(key))
    return found

def collect(seed_path,seed_pin,reader):
    todo=[(str(seed_path),seed_pin)];pins={};artifacts={};source={};total=0
    while todo:
        path,pin=todo.pop();need(len(pins)<1024,'HISTORICAL_GRAPH_BOUND')
        if path in pins:need(pins[path]==pin,'HISTORICAL_GRAPH_PIN_CONFLICT');continue
        p=PurePosixPath(path);need(p.is_absolute() and '..' not in p.parts and p.is_relative_to(ROOT) and digest(pin),'EXACT_HISTORICAL_GRAPH_NODE_REQUIRED')
        raw=reader(path);need(type(raw) is bytes and len(raw)<=16*1024*1024 and hashlib.sha256(raw).hexdigest()==pin,'HISTORICAL_GRAPH_FILE_CHANGED');pins[path]=pin
        total+=len(raw);need(total<=128*1024*1024,'HISTORICAL_GRAPH_BYTES_BOUND')
        if path.endswith('.py'):
            source[path]=raw;todo.extend(relations(raw,path).items())
        elif path.endswith('.json'):
            doc=json.loads(raw);artifacts[path]=doc
            if p.name.lower().endswith('manifest.json') and isinstance(doc,dict) and isinstance(doc.get('files'),list):
                seen=set()
                for row in doc['files']:
                    name=row.get('path');need(type(name) is str and PurePosixPath(name).as_posix()==name and not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts and name not in seen and digest(row.get('sha256')),'CLOSED_FROZEN_MANIFEST_NODE_REQUIRED');seen.add(name)
                    todo.append((str(p.parent/name),row['sha256']))
            if p.name=='MANIFEST.json' and isinstance(doc,dict) and isinstance(doc.get('records'),list):
                payload_root=p.parent
                if doc.get('scope')=='PALITRA_CART_TOTAL_COPY_ONLY':
                    need(pin==STATIC_COPY_MANIFEST_SHA and set(doc)=={'schema','scope','records'} and type(doc['schema']) is int and doc['schema']==1 and len(doc['records'])==2 and all(type(row) is dict for row in doc['records']) and {row.get('name') for row in doc['records']}=={'order.js','storefront.js'},'EXACT_SEALED_STATIC_COPY_MANIFEST_REQUIRED')
                    # cart_total_copy.accept() and the closed archive use product/<name>.
                    # Do not fall back to a flat file or ignore a missing pinned artifact.
                    payload_root=p.parent/'product'
                seen=set()
                for row in doc['records']:
                    name=row.get('name',row.get('path',row.get('payload')))
                    need(type(name) is str and PurePosixPath(name).as_posix()==name and not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts and name not in seen and digest(row.get('sha256')),'CLOSED_FROZEN_PAYLOAD_NODE_REQUIRED');seen.add(name)
                    todo.append((str(payload_root/name),row['sha256']))
    return {'pins':pins,'artifacts':artifacts,'source':source}
