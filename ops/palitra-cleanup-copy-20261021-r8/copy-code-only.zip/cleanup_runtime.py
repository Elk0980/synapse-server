"""Bounded Palitra cleanup candidate. CLI mutates PRIVATE COPIES only; live apply disabled.

No production path is selected implicitly. No transport, worker, decrypt or replay.
Full rows are hashed privately for CAS/preservation; public output contains no bodies.
"""
import argparse
import hashlib
import json
import os
import re
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
COPY_ROOT = HERE / 'private-copies'
ORDERS = tuple(range(18, 29))
THREADS = tuple(range(10, 21))
SITE = 'palitra'
COMPANY = 'palitra-love'
MARKER = 'palitra-love/order-cleanup/deleted-request/v1/'
UUID = re.compile(r'[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}')
PUSH = 'palitra-push-private/v1/job/'
# Only the last item of each family is an ID. No prefix-based DELETE exists.
DOCUMENT_FAMILIES = {
    'workflow': ('palitra-love/order-workflow/orders/', ORDERS),
    'orderAck': ('palitra-love/order-workflow/order-autoreply/', ORDERS),
    'threadAck': ('palitra-love/order-workflow/chat-autoreply/', THREADS),
    'contactFollowup': ('palitra-love/order-contact-followup/v1/', ORDERS),
}
DELETE_ORDER = (
    'chat_native_jobs', 'chat_message_deliveries', 'chat_manager_map',
    'chat_thread_requests', 'chat_widget_starts', 'chat_thread_contacts',
    'chat_thread_media_events', 'chat_thread_attachments', 'chat_web_uploads',
    'chat_thread_channels', 'chat_thread_links', 'chat_web_grants',
    'chat_thread_messages', 'chat_threads', 'client_dialog_owner_requests', 'client_bot_outbox',
    'client_dialog_versions', 'client_dialog_attachments', 'client_bot_map',
    'client_order_links', 'client_dialog_messages', 'client_dialogs',
    'site_order_checklist_events', 'site_order_checklist', 'site_order_work_events',
    'site_order_work', 'site_order_outbox', 'site_orders', 'documents',
)

def require(ok, code):
    if not ok:
        raise ValueError(code)

def packed(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False,
                      default=lambda x: {'blobSha256': hashlib.sha256(x).hexdigest()}).encode()

def sha(value):
    return hashlib.sha256(value if isinstance(value, bytes) else packed(value)).hexdigest()

def ident(value):
    require(re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', value) is not None, 'UNSUPPORTED_SQL_IDENTIFIER')
    return '"' + value + '"'

def records(db, sql, args=()):
    cur = db.execute(sql, args)
    columns = [c[0] for c in cur.description]
    values = cur.fetchmany(50001)
    require(len(values) <= 50000, 'BOUNDED_TABLE_LIMIT')
    return [dict(zip(columns, r)) for r in values]

def state(db):
    require(db.execute('PRAGMA foreign_keys').fetchone()[0] == 1, 'FOREIGN_KEYS_MUST_STAY_ON')
    schema = records(db, "SELECT type,name,tbl_name,sql FROM sqlite_schema WHERE sql IS NOT NULL ORDER BY type,name")
    require(len(schema) <= 600, 'SCHEMA_LIMIT')
    tables = [r['name'] for r in schema if r['type'] == 'table']
    require(len(tables) <= 200, 'TABLE_LIMIT')
    rows = {t: records(db, 'SELECT * FROM ' + ident(t)) for t in tables}
    require(sum(map(len, rows.values())) <= 250000, 'SNAPSHOT_LIMIT')
    require(not db.execute('PRAGMA foreign_key_check').fetchone(), 'FOREIGN_KEY_VIOLATION')
    require(db.execute('PRAGMA quick_check').fetchall() == [('ok',)], 'QUICK_CHECK_FAILED')
    return schema, rows

def row_seal(rows):
    return sha(sorted(sha(r) for r in rows))

def canonicalRowsForPreflight(table, rows):
    """Only these two observed volatile fields differ before action; never _all."""
    result = []
    counters = 0
    for original in rows:
        row = dict(original)
        if table == 'client_bot_bridge_state':
            require(type(row.get('bot_key')) is str and type(row.get('checked_at')) is str,
                    'EXACT_BRIDGE_KEY_AND_HEARTBEAT_COLUMN_REQUIRED')
            stamp = row['checked_at']
            require(re.fullmatch(r'\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{1,6})?Z', stamp) is not None,
                    'VALID_BRIDGE_HEARTBEAT_TIMESTAMP_REQUIRED')
            try:
                datetime.fromisoformat(stamp[:-1] + '+00:00')
            except ValueError:
                require(False, 'VALID_BRIDGE_HEARTBEAT_TIMESTAMP_REQUIRED')
            row['checked_at'] = '<preaction-volatile:checked_at>'
        elif table == 'sqlite_sequence' and row.get('name') == 'hugh_owner_alerts':
            counters += 1
            require(type(row.get('seq')) is int and row['seq'] >= 0, 'NONNEGATIVE_HUGH_OWNER_ALERT_COUNTER_REQUIRED')
            row['seq'] = '<preaction-volatile:hugh_owner_alerts.seq>'
        result.append(row)
    require(counters <= 1, 'UNIQUE_HUGH_OWNER_ALERT_COUNTER_REQUIRED')
    return result

def validateLiveCounters(current, backup):
    """Under BEGIN IMMEDIATE: only the named counter may advance, never decrease."""
    values = []
    for snapshot in (current, backup):
        rows = [r for r in snapshot.get('sqlite_sequence', []) if r['name'] == 'hugh_owner_alerts']
        require(len(rows) <= 1 and all(type(r['seq']) is int and r['seq'] >= 0 for r in rows),
                'EXACT_HUGH_OWNER_ALERT_COUNTER_REQUIRED')
        values.append(rows[0]['seq'] if rows else None)
    live, before = values
    require((live is None) == (before is None), 'HUGH_OWNER_ALERT_COUNTER_PRESENCE_CHANGED')
    require(live is None or live >= before, 'HUGH_OWNER_ALERT_COUNTER_DECREASED')

def plan(db, contact_prefix='palitra-love/order-contact-followup/v1/'):
    """Read only inside the caller's snapshot/transaction; hashes bind every row."""
    schema, all_rows = state(db)
    require(set(DELETE_ORDER).issubset(all_rows), 'MISSING_KNOWN_DEPENDENCY_SCHEMA')
    # Whole Palitra queue must be terminal, including NULL/unmapped audit rows.
    # Otherwise a retained notice could be picked up after its followup is gone.
    require(all(r['status'] in ('sent', 'failed', 'uncertain') for r in all_rows['client_bot_outbox']
                if r['company_code'] == COMPANY), 'GLOBAL_PALITRA_CLIENT_QUEUE_NOT_TERMINAL')
    require(all(r['status'] in ('sent', 'error', 'uncertain') for r in all_rows['site_order_outbox']
                if r['site'] == SITE and r['company_code'] == COMPANY), 'GLOBAL_PALITRA_SITE_QUEUE_NOT_TERMINAL')
    require('chat_web_sessions' in all_rows, 'CHAT_WEB_SESSIONS_TABLE_REQUIRED')
    require(all(not (r['type'] == 'trigger' and r['tbl_name'] in DELETE_ORDER) for r in schema),
            'TARGET_TRIGGER_REQUIRES_REVIEW')
    selected = {t: [] for t in DELETE_ORDER}
    by = lambda t, column, values: [r for r in all_rows[t] if r[column] in values]
    orders = by('site_orders', 'id', ORDERS)
    require(sorted(r['id'] for r in orders) == list(ORDERS), 'EXACT_11_ORDERS_REQUIRED')
    require(all(r['site'] == SITE and r['company_code'] == COMPANY for r in orders), 'ORDER_COMPANY_MISMATCH')
    require({r['id'] for r in all_rows['site_orders'] if r['site'] == SITE or r['company_code'] == COMPANY} == set(ORDERS),
            'GLOBAL_PALITRA_ORDER_SET_CHANGED')
    markers = []
    order_map = []
    for row in orders:
        request = row['request_id'].strip().lower()
        require(UUID.fullmatch(request) is not None, 'CANONICAL_V4_REQUEST_UUID_REQUIRED')
        fingerprint = sha(('palitra\n' + request).encode())
        markers.append(MARKER + fingerprint)
        order_map.append({'id': row['id'], 'requestUuidSha256': fingerprint})
    require(len(set(markers)) == len(ORDERS), 'DUPLICATE_REQUEST_UUID')
    threads = by('chat_threads', 'id', THREADS)
    require(sorted(r['id'] for r in threads) == list(THREADS)
            and sorted(r['order_id'] for r in threads) == list(ORDERS)
            and all(r['site'] == SITE and r['company_code'] == COMPANY for r in threads), 'EXACT_REAL_THREAD_ORDER_MAP_REQUIRED')
    require({r['id'] for r in by('chat_threads', 'order_id', ORDERS)} == set(THREADS), 'EXTRA_ORDER_THREAD')
    require({r['id'] for r in all_rows['chat_threads'] if r['site'] == SITE or r['company_code'] == COMPANY} == set(THREADS),
            'GLOBAL_PALITRA_THREAD_SET_CHANGED')
    dialogs = by('client_dialogs', 'id', (1,))
    require(len(dialogs) == 1 and dialogs[0]['company_code'] == COMPANY and dialogs[0]['order_id'] is None,
            'STANDALONE_LEGACY1_REQUIRED')
    require(not by('client_dialogs', 'order_id', ORDERS), 'ADDITIONAL_ORDER_LEGACY_DIALOG_REQUIRES_REVIEW')
    bot = dialogs[0]['bot_key']
    messages = by('chat_thread_messages', 'thread_id', THREADS)
    legacy_messages = by('client_dialog_messages', 'dialog_id', (1,))
    require(len(legacy_messages) == 10, 'EXACT_LEGACY_10_MESSAGES_REQUIRED')
    require(all(r['company_code'] == COMPANY and r['bot_key'] == bot for r in legacy_messages), 'LEGACY_CHILD_SCOPE_MISMATCH')
    mids = {r['id'] for r in messages}
    lmids = {r['id'] for r in legacy_messages}
    selected.update(site_orders=orders, chat_threads=threads, client_dialogs=dialogs,
                    chat_thread_messages=messages, client_dialog_messages=legacy_messages)
    for t in ('site_order_work', 'site_order_work_events', 'site_order_checklist', 'site_order_checklist_events'):
        selected[t] = by(t, 'order_id', ORDERS)
    selected['site_order_outbox'] = by('site_order_outbox', 'order_id', ORDERS)
    require(all(r['site'] == SITE and r['company_code'] == COMPANY and r['status'] in ('sent', 'error', 'uncertain')
                for r in selected['site_order_outbox']), 'SITE_OUTBOX_ACTIVE_OR_UNKNOWN_REFUSED')
    require(all(any(r['id'] == job and r['order_id'] == order and r['status'] == 'uncertain'
                    for r in selected['site_order_outbox']) for job, order in ((43,23),(48,28))),
            'KNOWN_UNCERTAIN_SITE_AUDIT_CHANGED')
    for t in ('chat_native_jobs', 'chat_thread_requests', 'chat_widget_starts', 'chat_thread_contacts',
              'chat_thread_channels', 'chat_thread_links', 'chat_web_grants', 'chat_manager_map', 'chat_thread_attachments'):
        selected[t] = by(t, 'thread_id', THREADS)
    selected['chat_message_deliveries'] = by('chat_message_deliveries', 'message_id', mids)
    require(all(r['status'] in ('sent', 'failed', 'not_queued', 'uncertain') for r in selected['chat_message_deliveries']),
            'UNRESOLVED_DELIVERY_REFUSED')
    selected['chat_thread_media_events'] = [r for r in all_rows['chat_thread_media_events']
                                          if r['message_id'] in mids or r['replaces_message_id'] in mids]
    # No filesystem deletion is implemented; unrelated companies' uploads survive.
    require(not selected['chat_thread_attachments'] and not by('client_dialog_attachments', 'dialog_id', (1,)), 'SELECTED_MEDIA_REFUSED')
    selected['chat_web_uploads'] = [r for r in all_rows['chat_web_uploads'] if r['thread_id'] in THREADS
        or r['dialog_id'] == 1 or r['thread_message_id'] in mids or r['legacy_message_id'] in lmids]
    require(not selected['chat_web_uploads'], 'SELECTED_UPLOADS_REQUIRE_DISK_REVIEW')
    for t in ('client_dialog_versions', 'client_dialog_attachments'):
        selected[t] = by(t, 'message_id', lmids)
    selected['client_dialog_owner_requests'] = by('client_dialog_owner_requests', 'dialog_id', (1,))
    selected['client_order_links'] = [r for r in all_rows['client_order_links']
                                     if r['order_id'] in ORDERS or r['dialog_id'] == 1]
    selected['client_bot_map'] = [r for r in all_rows['client_bot_map']
                                 if r['order_id'] in ORDERS or r['dialog_id'] == 1 or r['client_message_id'] in lmids]
    require(all((r['order_id'] is None or r['order_id'] in ORDERS)
                and (r['dialog_id'] is None or r['dialog_id'] == 1)
                and (r['client_message_id'] is None or r['client_message_id'] in lmids)
                for r in selected['client_bot_map']), 'EXACT_SELECTED_ROUTING_MAP_CLOSURE_REQUIRED')
    require(all(r['bot_key'] == bot for r in selected['client_bot_map'] + selected['client_order_links']
                + selected['chat_native_jobs']), 'BOT_CHILD_SCOPE_MISMATCH')
    require(all(r['site'] == SITE and r['order_id'] in ORDERS and r['dialog_id'] in (None,1)
                for r in selected['client_order_links']), 'ORDER_LINK_SITE_OR_CLOSURE_MISMATCH')
    native_jobs = {r['job_id'] for r in selected['chat_native_jobs']}
    jobs = [r for r in all_rows.get('client_bot_outbox', []) if r['id'] in native_jobs or r['dialog_id'] == 1 or r['message_id'] in lmids]
    require(native_jobs.issubset({r['id'] for r in jobs}) and all(r['company_code'] == COMPANY and r['bot_key'] == bot
            and r['status'] in ('sent', 'failed', 'uncertain') for r in jobs), 'ACTIVE_UNKNOWN_NATIVE_OR_LEGACY_QUEUE_REFUSED')
    require(all(r['company_code'] == COMPANY and r['bot_key'] == bot and r['target'] in ('manager','customer')
                and any(m['id'] == r['message_id'] and m['thread_id'] == r['thread_id'] for m in messages)
                for r in selected['chat_native_jobs']), 'NATIVE_MESSAGE_THREAD_IDENTITY_MISMATCH')
    require(all((r['dialog_id'] is None or r['dialog_id'] == 1)
                and (r['message_id'] is None or r['message_id'] in lmids) for r in jobs),
            'SELECTED_NATIVE_LEGACY_OUTBOX_CLOSURE_REQUIRED')
    require(all(any(j['id'] == r['job_id'] and j['dialog_id'] is None and j['message_id'] is None
                and j['kind'] == ('forward' if r['target'] == 'manager' else 'reply') for j in jobs)
                for r in selected['chat_native_jobs']), 'EXACT_NATIVE_OUTBOX_TARGET_BINDING_REQUIRED')
    selected['client_bot_outbox'] = jobs
    # Root's final review scope can explicitly include terminal business outbox
    # rows. Before-backup + old-ID/status/row-SHA audit preserve the past outcome;
    # immutable release journals and client_bot_receipts/audit are never touched.
    documents = all_rows['documents']
    require(all(not any(r['key'] == key for r in documents) for key in markers), 'EXISTING_TOMBSTONE_NO_RETRY')
    families = dict(DOCUMENT_FAMILIES)
    require(contact_prefix == families['contactFollowup'][0], 'EXACT_CONTACT_NAMESPACE_REQUIRED')
    keys = set()
    document_counts = {}
    for family, (prefix, parents) in families.items():
        family_keys = {prefix + str(i) for i in parents}
        found = [r for r in documents if r['key'] in family_keys]
        exact_ids = list(range(19,29)) if family == 'orderAck' else list(parents)
        found_keys = {r['key'] for r in found}
        required_keys = {prefix + str(i) for i in exact_ids}
        require(family == 'workflow' or (required_keys <= found_keys if family == 'orderAck' else found_keys == required_keys),
                'DOCUMENT_VERSION_INVENTORY_NOT_CLOSED_' + family)
        require(not (keys & {r['key'] for r in found}), 'OVERLAPPING_DOCUMENT_FAMILIES')
        keys.update(r['key'] for r in found)
        document_counts[family] = {'keys': len(found_keys), 'versions': len(found)}
    selected['documents'] = [r for r in documents if r['key'] in keys]
    require(not any(r['key'] in {'palitra-love/order-workflow/issued-followup/' + str(i) for i in ORDERS}
                    for r in documents), 'ISSUED_FOLLOWUP_REQUIRES_ADDITIONAL_SCOPE_REVIEW')
    # Read only the safe typed job link of latest contact records, without output.
    # An unlinked terminal job remains untouched; an active related job refuses.
    for oid in ORDERS:
        versions = [r for r in documents if r['key'] == contact_prefix + str(oid)]
        current = max(versions, key=lambda r: r['version'])
        try:
            value = json.loads(current['body'])
        except (ValueError, TypeError):
            value = None
        thread_id = next(r['id'] for r in threads if r['order_id'] == oid)
        require(isinstance(value, dict) and value.get('schema') == 1 and value.get('site') == SITE
                and value.get('companyCode') == COMPANY and value.get('orderId') == oid
                and value.get('threadId') == thread_id, 'FOLLOWUP_DOCUMENT_IDENTITY_INVALID')
        job_id = value.get('telegramJobId')
        if job_id is not None:
            require(type(job_id) is int and job_id > 0, 'FOLLOWUP_TYPED_JOB_ID_REQUIRED')
            linked = [r for r in all_rows['client_bot_outbox'] if r['id'] == job_id]
            require(len(linked) == 1 and linked[0]['company_code'] == COMPANY and linked[0]['bot_key'] == bot
                    and linked[0]['status'] in ('sent', 'failed', 'uncertain'), 'FOLLOWUP_QUEUE_UNRESOLVED')
    push = [r for r in documents if r['key'].startswith(PUSH)]
    latest = {}
    for row in push:
        if row['key'] not in latest or row['version'] > latest[row['key']]['version']:
            latest[row['key']] = row
    for row in latest.values():
        try:
            envelope = json.loads(row['body'])
        except (ValueError, TypeError):
            envelope = None
        require(isinstance(envelope, dict) and set(envelope) == {'schema', 'cipher', 'active', 'iv', 'tag', 'data'}
                and envelope['schema'] == 1 and envelope['cipher'] == 'aes-256-gcm' and envelope['active'] is False,
                'ACTIVE_INVALID_UNKNOWN_PUSH_REFUSED')
        require(all(type(envelope[k]) is str and envelope[k] for k in ('iv','tag','data')), 'OPAQUE_PUSH_ENVELOPE_INVALID')
    selected_seals = {t: sorted(sha(r) for r in rows) for t, rows in selected.items()}
    retained = {t: row_seal(canonicalRowsForPreflight(t, [r for r in rows if sha(r) not in set(selected_seals.get(t, []))]))
                for t, rows in all_rows.items()}
    scope = {'schemaSha256': sha(schema),
             'preactionFingerprint': {'schema': 2, 'volatileExceptions': [
                 {'table': 'client_bot_bridge_state', 'column': 'checked_at'},
                 {'table': 'sqlite_sequence', 'rowName': 'hugh_owner_alerts', 'column': 'seq',
                  'nonnegativeInteger': True, 'liveMustBeAtLeastBackup': True}], 'postMutationFullRowsExact': True},
             'snapshotSha256': sha({t: row_seal(canonicalRowsForPreflight(t, v)) for t, v in all_rows.items()}),
             'orderMap': sorted(order_map, key=lambda r: r['id']),
             'threadMap': sorted(({'id': r['id'], 'orderId': r['order_id']} for r in threads), key=lambda r: r['id']),
             'legacyDialogIds': [1], 'targets': selected_seals, 'retained': retained,
             'documents': document_counts, 'tombstoneKeys': sorted(markers),
             'businessOutboxBeforeAudit': sorted(({'table': t, 'id': r['id'], 'status': r['status'],
                 'orderId': r['order_id'] if t == 'site_order_outbox' else None, 'rowSha256': sha(r)}
                 for t in ('site_order_outbox', 'client_bot_outbox') for r in selected[t]), key=lambda r: (r['table'], r['id'])),
             'pushAuditRetained': {'keys': len(latest), 'versions': len(push), 'active': 0}, 'sequenceReset': False}
    return {'scopeSha256': sha(scope), 'scope': scope, '_rows': selected, '_all': all_rows, '_schema': schema}

def mutate(db, planned, timestamp):
    """Only called under BEGIN IMMEDIATE after CAS; never resets any sequence."""
    for key in planned['scope']['tombstoneKeys']:
        db.execute('INSERT INTO documents(key,version,created_at,author,body) VALUES(?,1,?,?,?)',
                   (key, timestamp, 'palitra-order-cleanup:v1', '{"schema":1,"kind":"deleted-request"}'))
    for table in DELETE_ORDER:
        for row in planned['_rows'][table]:
            # Exact full-row equality binds every affected byte, including nulls.
            columns = sorted(row)
            sql = 'DELETE FROM ' + ident(table) + ' WHERE ' + ' AND '.join(ident(c) + ' IS ?' for c in columns)
            require(db.execute(sql, [row[c] for c in columns]).rowcount == 1, 'TARGET_ROW_CAS_FAILED')
    after_schema, after = state(db)
    require(after_schema == planned['_schema'], 'SCHEMA_CHANGED')
    for table, before in planned['_all'].items():
        expected = [r for r in before if sha(r) not in set(planned['scope']['targets'].get(table, []))]
        actual = after[table]
        if table == 'documents':
            markers = [r for r in actual if r['key'] in planned['scope']['tombstoneKeys']]
            require(len(markers) == len(ORDERS) and all(r['version'] == 1 and r['author'] == 'palitra-order-cleanup:v1'
                and r['body'] == '{"schema":1,"kind":"deleted-request"}' and r['created_at'] == timestamp for r in markers), 'MARKER_POSTCHECK_FAILED')
            actual = [r for r in actual if r['key'] not in planned['scope']['tombstoneKeys']]
        if table == 'sqlite_sequence':
            oldseq = {r['name']: r['seq'] for r in expected}
            newseq = {r['name']: r['seq'] for r in actual}
            require(all(newseq.get(n) == v for n, v in oldseq.items() if n != 'documents')
                    and newseq.get('documents') == max(oldseq.get('documents', 0),
                       max((r['id'] for r in planned['_all']['documents']), default=0)) + len(ORDERS), 'SEQUENCE_PRESERVATION_FAILED')
        else:
            require(row_seal(actual) == row_seal(expected), 'RETAINED_DOMAIN_CHANGED_' + table)

def dryrun(db, contact_prefix):
    require(not db.in_transaction, 'OWN_TRANSACTION_REQUIRED')
    db.execute('BEGIN IMMEDIATE')
    try:
        planned = plan(db, contact_prefix)
        mutate(db, planned, '2000-01-01T00:00:00Z')
        return public(planned, 'SQLITE_COPY_DRYRUN_ROLLED_BACK_NOT_ACCEPTANCE')
    finally:
        db.rollback()

def public(planned, status):
    scope = planned['scope']
    safe_ids = {}
    for table, rows in planned['_rows'].items():
        if rows and 'id' in rows[0]:
            safe_ids[table] = sorted(r['id'] for r in rows)
        elif table == 'chat_native_jobs':
            safe_ids[table] = sorted(r['job_id'] for r in rows)
    return {'status': status, 'scopeSha256': planned['scopeSha256'], 'snapshotSha256': scope['snapshotSha256'],
            'preactionFingerprint': scope['preactionFingerprint'],
            'schemaSha256': scope['schemaSha256'], 'orderMap': scope['orderMap'], 'threadMap': scope['threadMap'],
            'legacyDialogIds': [1], 'targetCounts': {t: len(v) for t, v in scope['targets'].items()},
            'documentCounts': scope['documents'], 'pushAuditRetained': scope['pushAuditRetained'],
            'businessOutboxBeforeAudit': scope['businessOutboxBeforeAudit'],
            'targetInternalIds': safe_ids,
            'sessionsRetained': len(planned['_all']['chat_web_sessions']), 'cleanupAcceptance': False, 'liveApplyEnabled': False,
            'pending': ['FRESH_ROOT_GUARD_IMAGE_HTTP410_LEASE_DISK_PROBE', 'PRIVATE_VERIFIED_RUNTIME_BACKUP',
                        'ACTION_TIME_USER_CONFIRMATION', 'SEPARATE_RUNTIME_ADMISSION_AND_REVIEW']}

def backup_verified(db, path):
    path = Path(path)
    require(not path.exists() and not db.in_transaction, 'FRESH_PRIVATE_BACKUP_REQUIRED')
    # Exclusive create, explicit mode; private parent ACL still requires Root proof.
    fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    os.close(fd)
    copy = sqlite3.connect(path)
    try:
        db.backup(copy)
        copy.execute('PRAGMA foreign_keys=ON')
        source_schema, source_rows = state(db)
        copied_schema, copied_rows = state(copy)
        require(source_schema == copied_schema and sha(source_rows) == sha(copied_rows), 'BACKUP_COPY_MISMATCH')
    finally:
        copy.close()
    return sha(path.read_bytes())

def local_copy_guard(db, *outputs):
    allowed = (COPY_ROOT.resolve(), (HERE.parent / 'QA_CLEANUP').resolve())
    for _, name, filename in db.execute('PRAGMA database_list'):
        require(name in ('main', 'temp'), 'ATTACHED_DATABASE_REFUSED')
        if filename:
            target = Path(filename).resolve()
            require(any(target.is_relative_to(root) for root in allowed), 'COPY_EXECUTOR_LIVE_PATH_REFUSED')
    for output in outputs:
        target = Path(output).resolve()
        require(any(target.is_relative_to(root) for root in allowed), 'ONLY_PRIVATE_LOCAL_COPY_OUTPUTS_ALLOWED')

def execute_reviewed_transaction(db, contact_prefix, expected_scope_sha, backup_path, timestamp, before_mutation=None, before_commit=None):
    """One shared exact algorithm; caller owns private admission/journal/lease.

    No apply-copy path checks are bypassed: copy callers keep local_copy_guard.
    """
    require(not db.in_transaction, 'OWN_TRANSACTION_REQUIRED')
    db.execute('BEGIN IMMEDIATE')
    try:
        planned = plan(db, contact_prefix)
        require(planned['scopeSha256'] == expected_scope_sha, 'SCOPE_CHANGED_NO_APPLY')
        # Backup was taken before acquiring the lock: exact source seal must match
        # again under the lock, rejecting even a write outside selected targets.
        saved = sqlite3.connect(Path(backup_path).resolve().as_uri() + '?mode=ro', uri=True)
        try:
            saved.execute('PRAGMA foreign_keys=ON')
            backup_plan = plan(saved, contact_prefix)
            require(backup_plan['scopeSha256'] == expected_scope_sha, 'BACKUP_SCOPE_CAS_FAILED')
            validateLiveCounters(planned['_all'], backup_plan['_all'])
        finally:
            saved.close()
        if before_mutation is not None:
            before_mutation(planned)
        mutate(db, planned, timestamp)
        if before_commit is not None:
            before_commit()
        db.commit()
    except BaseException:
        db.rollback()
        raise
    return planned

def apply_copy_once(db, contact_prefix, expected_scope_sha, journal_path, backup_path, *, enable=False,
                    fixture_authorization=False):
    """Concrete one-attempt COPY executor. No live/runtime authorization path exists."""
    require(enable is True and fixture_authorization is True, 'APPLY_DISABLED_ROOT_RUNTIME_ADMISSION_ABSENT')
    local_copy_guard(db, journal_path, backup_path)
    require(not db.in_transaction, 'OWN_TRANSACTION_REQUIRED')
    # Journal precedes the first mutation and remains UNKNOWN on every exception.
    journal = Path(journal_path)
    if journal.exists():
        raise FileExistsError('ONE_ATTEMPT_JOURNAL_EXISTS_NO_RETRY')
    before = plan(db, contact_prefix)
    require(before['scopeSha256'] == expected_scope_sha, 'INITIAL_SCOPE_CHANGED_NO_APPLY')
    fd = os.open(journal, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    with os.fdopen(fd, 'w', encoding='utf-8') as out:
        json.dump({'phase': 'UNKNOWN_NO_RETRY', 'scopeSha256': expected_scope_sha, 'copyOnly': True,
                   'businessOutboxBeforeAudit': before['scope']['businessOutboxBeforeAudit']}, out)
        out.flush()
        os.fsync(out.fileno())
    backup_sha = backup_verified(db, backup_path)
    planned = execute_reviewed_transaction(db, contact_prefix, expected_scope_sha, backup_path,
                                          datetime.now(timezone.utc).isoformat())
    result = public(planned, 'APPLIED_TO_PRIVATE_COPY_ONLY_NOT_RUNTIME_ACCEPTANCE')
    result['backupSha256'] = backup_sha
    # If this final write fails the existing UNKNOWN file forbids another attempt.
    with journal.open('w', encoding='utf-8') as out:
        json.dump({'phase': 'PRIVATE_COPY_APPLIED', 'scopeSha256': expected_scope_sha, 'result': result}, out)
        out.flush()
        os.fsync(out.fileno())
    return result

def open_private_copy(path):
    path = Path(path).resolve(strict=True)
    require(path.is_relative_to(COPY_ROOT.resolve()) and path.suffix == '.sqlite' and not path.is_symlink(),
            'ONLY_EXPLICIT_LOCAL_PRIVATE_COPY_ALLOWED')
    db = sqlite3.connect(path.as_uri() + '?mode=rw', uri=True)
    db.execute('PRAGMA foreign_keys=ON')
    db.execute('PRAGMA busy_timeout=0')
    return db

def main():
    p = argparse.ArgumentParser()
    p.add_argument('mode', choices=('preview', 'dryrun', 'apply'))
    p.add_argument('--private-copy', required=True)
    p.add_argument('--contact-prefix', default='palitra-love/order-contact-followup/v1/')
    args = p.parse_args()
    require(args.mode != 'apply', 'APPLY_DISABLED_ROOT_RUNTIME_ADMISSION_ABSENT')
    refs = json.loads((HERE / 'LOCAL_REFERENCE_PINS.json').read_bytes())
    require(all(sha(Path(r['path']).read_bytes()) == r['sha256'] for r in refs['files']),
            'LOCAL_REFERENCE_CHANGED_REVIEW_REQUIRED')
    db = open_private_copy(args.private_copy)
    try:
        if args.mode == 'dryrun':
            value = dryrun(db, args.contact_prefix)
        else:
            db.execute('PRAGMA query_only=ON')
            db.execute('BEGIN')
            value = public(plan(db, args.contact_prefix), 'SQLITE_COPY_PREVIEW_NOT_ACCEPTANCE')
            db.rollback()
        print(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2))
    finally:
        db.close()

if __name__ == '__main__':
    try:
        main()
    except (ValueError, sqlite3.Error, OSError, KeyError, TypeError) as error:
        # Never echo SQL rows, paths, bodies or sqlite constraint values.
        code = str(error) if isinstance(error, ValueError) else type(error).__name__
        print(json.dumps({'status': 'REFUSED_NOT_CLEANUP_ACCEPTANCE', 'code': code, 'liveApplyEnabled': False}))
        raise SystemExit(2)
