"""Separate readonly-live preparation. No action-time admission or live SQL writes.

Default expected guard image is disabled. Root alone may stage and invoke this
after the guard is installed and pinned. Never monkeypatches copy path guards.
"""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import sqlite3
import stat
import sys
import types

sys.dont_write_bytecode = True
import live_entry as L

CODE = L.ROOT / 'palitra-order-cleanup-prepare-20261020-r6-code'
EXPECTED_GUARD_IMAGE = None

def stamp():
    return datetime.now(timezone.utc).isoformat().replace('+00:00','Z')

def new_json(path, value):
    raw = (json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
    L.need(len(raw)<=4*1024*1024,'BOUNDED_PROOF_REQUIRED')
    fd = os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'wb') as out:
        out.write(raw); out.flush(); os.fsync(out.fileno())
    return L.sha(raw)

def new_copy(source, path):
    fd = os.open(path,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600); os.close(fd)
    db = sqlite3.connect(Path(path).resolve().as_uri()+'?mode=rw',uri=True)
    try:
        source.backup(db)
        db.execute('PRAGMA foreign_keys=ON'); db.execute('PRAGMA busy_timeout=0')
        return db
    except BaseException:
        db.close()
        raise

def prepare_copy(source, destination, engine, *, image, database_path, identity, private_root=False,
                 selected_media_disk_count=None, current_check=lambda:None):
    """Synthetic-testable preparation only. Source connection MUST be readonly."""
    L.need(source.execute('PRAGMA query_only').fetchone()[0] == 1 and not source.in_transaction,
           'QUERY_ONLY_SOURCE_WITH_OWN_SNAPSHOT_REQUIRED')
    os.mkdir(destination,0o700)  # EXCL: never reuse a partial/UNKNOWN preparation.
    destination = Path(destination)
    backup_path = destination/'before.sqlite'
    dry_path = destination/'dryrun.sqlite'
    source.execute('BEGIN')
    before = None
    try:
        before = engine.plan(source)
        backup = new_copy(source,backup_path)
        try:
            L.need(engine.plan(backup)['scopeSha256'] == before['scopeSha256'], 'BACKUP_SNAPSHOT_MISMATCH')
            L.need(engine.plan(source)['scopeSha256'] == before['scopeSha256'], 'SOURCE_READ_SNAPSHOT_CHANGED')
        finally:
            backup.close()
    finally:
        source.rollback()
    # There is no source mutation, SQL UPDATE/DELETE/DDL or WAL checkpoint above.
    backup = sqlite3.connect(backup_path.resolve().as_uri()+'?mode=ro&immutable=1',uri=True)
    try:
        backup.execute('PRAGMA foreign_keys=ON'); backup.execute('PRAGMA query_only=ON')
        planned = engine.plan(backup)
        L.need(planned['scopeSha256'] == before['scopeSha256'], 'BACKUP_SCOPE_CHANGED')
        proof = {'schema':1,'status':'VERIFIED_PRIVATE_SQLITE_BACKUP','databasePath':str(database_path),
            'databaseIdentity':identity,'backupPath':str(backup_path.resolve()),'backupSha256':L.sqlite_file_sha(backup_path),
            'scopeSha256':planned['scopeSha256'],'snapshotSha256':planned['scope']['snapshotSha256'],
            'schemaSha256':planned['scope']['schemaSha256'],'guardImage':image,'consistentCommittedWal':True,
            'quickCheck':'ok','foreignKeyViolations':0,'privateRoot0600':private_root,
            'selectedMediaDiskCount':selected_media_disk_count,'createdAtUtc':stamp()}
        proof_sha = new_json(destination/'backup-proof.json',proof)
        preview = engine.public(planned,'SQLITE_COPY_PREVIEW_NOT_ACCEPTANCE')
        preview['createdAtUtc'] = stamp()
        preview_sha = new_json(destination/'preview.json',preview)
        dry = new_copy(backup,dry_path)
        try:
            dry_before = engine.plan(dry)
            result = engine.dryrun(dry,'palitra-love/order-contact-followup/v1/')
            L.need(engine.plan(dry)['scopeSha256'] == dry_before['scopeSha256'] == planned['scopeSha256'],
                   'DRYRUN_ROLLBACK_SCOPE_CHANGED')
        finally:
            dry.close()
        result['createdAtUtc'] = stamp()
        dry_sha = new_json(destination/'dryrun.json',result)
    finally:
        backup.close()
    current_check()  # Root lease/native guard still exact; only reads.
    receipt = {'schema':1,'status':'PRIVATE_COPY_PREPARED_NOT_ACTION_AUTHORIZATION',
        'scopeSha256':planned['scopeSha256'],'guardImage':image,'createdAtUtc':stamp(),
        'backupProof':{'path':str((destination/'backup-proof.json').resolve()),'sha256':proof_sha},
        'preview':{'path':str((destination/'preview.json').resolve()),'sha256':preview_sha},
        'dryrun':{'path':str((destination/'dryrun.json').resolve()),'sha256':dry_sha},
        'runtimeDatabaseWrites':0,'cleanupAcceptance':False,'liveApplyEnabled':False,
        'pending':['ROOT_SELECTED_MEDIA_DISK_PROOF','ACTION_TIME_USER_CONFIRMATION','SEPARATE_LIVE_ADMISSION']}
    new_json(destination/'PREPARED.json',receipt)
    return receipt

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--expected-guard-image',default=EXPECTED_GUARD_IMAGE)
    p.add_argument('--guard-receipt-sha',required=True)
    p.add_argument('--lease-pid',type=int,required=True);p.add_argument('--lease-start-ticks',required=True)
    p.add_argument('--nonce',required=True)
    args = p.parse_args()
    L.need(type(args.expected_guard_image) is str and re.fullmatch('sha256:[a-f0-9]{64}',args.expected_guard_image)
           and args.expected_guard_image != L.PARENT_IMAGE,'EXPECTED_INSTALLED_GUARD_IMAGE_DISABLED_OR_NOT_NEW')
    L.need(os.name=='posix' and os.geteuid()==0 and Path(__file__)==CODE/'prepare_preview.py','EXACT_STAGED_POSIX_PREPARE_ENTRY_REQUIRED')
    L.need(L.digest(args.guard_receipt_sha) and re.fullmatch('[a-f0-9]{32}',args.nonce)
           and args.lease_pid>1 and re.fullmatch('[1-9][0-9]*',args.lease_start_ticks),'EXACT_RECEIPT_LEASE_NONCE_REQUIRED')
    L.private_path(L.ROOT,True);L.private_path(CODE,True)
    # LOCAL_CODE_PINS and both entries must be independently pinned by Root's
    # staging manifest; this helper does not create an enabled runtime admission.
    pins = json.loads(L.private_read(CODE/'LOCAL_CODE_PINS.json'))
    raw = L.private_read(CODE/'cleanup_runtime.py',pins['engineSha256'])
    engine = types.ModuleType('exact_prepare_engine');engine.__file__=str(CODE/'cleanup_runtime.py')
    exec(compile(raw,engine.__file__,'exec'),engine.__dict__)
    row = {'path':str(L.ROOT/(L.GUARD+'-journal.json')),'sha256':args.guard_receipt_sha}
    receipt = json.loads(L.private_read(row['path'],row['sha256']))
    L.need(receipt.get('phase')=='APPLIED_NOT_CUSTOMER_ACCEPTANCE' and receipt.get('childImage')==args.expected_guard_image,
           'GUARD_NOT_EXACT_COMPLETED_INSTALLED_IMAGE')
    # Runtime.fast_snapshot must bind the exact CLI image before any DB open.
    a = {'guardImage': args.expected_guard_image,
         'lease': {'pid':args.lease_pid,'startTicks':args.lease_start_ticks,'lockPath':L.LOCK},
         'artifacts': {'guardReceipt':row}}
    runtime = L.Runtime(a,pins,CODE/'prepare_preview.py',None,None)
    runtime.full_guard_read()
    for part in (L.DATABASE,*L.DATABASE.parents):L.need(not part.is_symlink(),'DATABASE_ALIAS_REFUSED')
    s = L.DATABASE.lstat()
    L.need(stat.S_ISREG(s.st_mode) and s.st_nlink==1,'EXACT_LIVE_DB_FILE_REQUIRED')
    identity = {'dev':s.st_dev,'ino':s.st_ino,'uid':s.st_uid,'gid':s.st_gid,'mode':stat.S_IMODE(s.st_mode)}
    source = sqlite3.connect(L.DATABASE.as_uri()+'?mode=ro',uri=True)
    source.execute('PRAGMA foreign_keys=ON');source.execute('PRAGMA query_only=ON');source.execute('PRAGMA busy_timeout=0')
    try:
        result = prepare_copy(source,L.ROOT/('palitra-order-cleanup-prepare-'+args.nonce),engine,
            image=args.expected_guard_image,database_path=L.DATABASE,identity=identity,private_root=True,current_check=runtime.fast_guard_read)
    finally:
        source.close()
    print(json.dumps(result,ensure_ascii=False,sort_keys=True))

if __name__=='__main__':
    sys.dont_write_bytecode=True
    try:main()
    except BaseException as error:
        code=str(error) if type(error) is ValueError and re.fullmatch('[A-Z][A-Z0-9_]{0,120}',str(error)) else 'PREPARATION_REFUSED_NO_LIVE_WRITES'
        print(json.dumps({'status':'PREPARATION_REFUSED_NO_ACTION_AUTHORIZATION','code':code,'runtimeDatabaseWrites':0,'liveApplyEnabled':False}))
        raise SystemExit(2)
