"""Copy-only preparation. No live apply, full-guard acceptance or deletion admission.

The old full native inspect currently refuses legal managed-site version 260.
This tool does not suppress that refusal or claim it passed. It only makes new
private consistent copies and exercises the reviewed deletion algorithm there.
"""
import argparse,hashlib,json,os,re,sqlite3,stat,sys,types
from datetime import datetime,timezone
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('/opt/synapse/releases/palitra-app-20261015')
NAME='palitra-order-cleanup-copy-20261021-r8'
CODE=ROOT/(NAME+'-code')
DATABASE=Path('/var/lib/docker/volumes/synapse_content_data/_data/content.sqlite')
OWN_PID=3462715
IMAGE='sha256:951db09e9e6c4781350bbced7e7a9e4ef099077a368e38a6b1fac40e0a4a6a22'
RECEIPT='34ce6389ef04a5db158d5b1a27734e2d09c919df28b35a9dad4561af48d42892'
BASE_PINS={'cleanup_runtime.py':'6bd4b9f29ff1ffd4e553750d43df437444b5651485748e1eeca82163c8259861','live_entry.py':'16600560cef5f63f6e799113cebafff2164b3e765472bc4d46c1bdfc8c656935','prepare_preview.py':'69197d0c9e14cd794a9c5e4c45d81f20c49084cea5183cd8192b3a7ca9df5284','LOCAL_CODE_PINS.json':'556cff84fb6c8aff6ee00e3f77c903588f7cd29e217bc11d43ebde3a5c377b85'}
SOURCE_PINS={'palitra-orders-public/cabinet.html':'91277f53ec62bd700395d53f26a494c25ed8238f87b8973d647f96ab881a9187','palitra-orders-public/shell.js':'60502c40ecfb7a5f75972b7a841a197fb75b372fba76ade072cef9d3db5f9e4b','palitra-orders-public/shop.html':'862f294019ed0033c4daf70283654f6df895fe7cb203cbfb93d03de35e9f095b','server.js':'d1e0a83cfc23a5cf6558a1023438257240e78fc9c4c997c49f0ca23e36da093f','site-orders.js':'4826cc1d35bc0ac5216ab765f8dde31bb91ca96b935d5aee01537724eff6ef94'}
sha=lambda b:hashlib.sha256(b).hexdigest()
def need(ok,code):
 if not ok:raise ValueError(code)
def stamp():return datetime.now(timezone.utc).isoformat().replace('+00:00','Z')
def raw_private(path,pin=None):
 path=Path(path);need(path.is_absolute(),'ABSOLUTE_PRIVATE_PATH_REQUIRED')
 for p in (path,*path.parents):need(not p.is_symlink(),'PATH_ALIAS_REFUSED')
 s=path.lstat();need(stat.S_ISREG(s.st_mode) and s.st_nlink==1 and s.st_uid==s.st_gid==0 and stat.S_IMODE(s.st_mode)==0o600 and s.st_size<=4*1024*1024,'PRIVATE_SINGLE_FILE_REQUIRED')
 fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
 with os.fdopen(fd,'rb') as f:
  a=os.fstat(f.fileno());b=f.read(4*1024*1024+1);z=os.fstat(f.fileno())
 q=path.lstat();fields=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
 need(len(b)==s.st_size and all(getattr(s,k)==getattr(a,k)==getattr(z,k)==getattr(q,k) for k in fields),'PRIVATE_BYTES_RACED')
 need(pin is None or sha(b)==pin,'PRIVATE_PIN_CHANGED');return b
def directory(path,mode):
 for p in (path,*path.parents):need(not p.is_symlink(),'DIRECTORY_ALIAS_REFUSED')
 s=path.lstat();need(stat.S_ISDIR(s.st_mode) and s.st_uid==s.st_gid==0 and stat.S_IMODE(s.st_mode)==mode,'ROOT_DIRECTORY_MODE_REQUIRED')
def database_identity(path):
 for p in (path,*path.parents):need(not p.is_symlink(),'DATABASE_ALIAS_REFUSED')
 s=path.lstat();need(stat.S_ISREG(s.st_mode) and s.st_nlink==1 and s.st_uid==s.st_gid==0 and stat.S_IMODE(s.st_mode)==0o644,'ROOT_SINGLE_OBSERVED_DB_REQUIRED')
 return {'dev':s.st_dev,'ino':s.st_ino,'uid':s.st_uid,'gid':s.st_gid,'mode':stat.S_IMODE(s.st_mode)}
def load_modules(code):
 # Hash every inherited byte before importing; none is run as __main__.
 values={n:raw_private(code/n,pin) for n,pin in BASE_PINS.items()}
 def module(name,file,raw):
  m=types.ModuleType(name);m.__file__=str(file);exec(compile(raw,str(file),'exec'),m.__dict__);return m
 L=module('copy_r8_inherited_entry',code/'live_entry.py',values['live_entry.py'])
 previous=sys.modules.get('live_entry');sys.modules['live_entry']=L
 try:P=module('copy_r8_inherited_prepare',code/'prepare_preview.py',values['prepare_preview.py'])
 finally:
  if previous is None:sys.modules.pop('live_entry',None)
  else:sys.modules['live_entry']=previous
 E=module('copy_r8_inherited_engine',code/'cleanup_runtime.py',values['cleanup_runtime.py'])
 pins=json.loads(values['LOCAL_CODE_PINS.json']);need(pins['guardSourcePins']==SOURCE_PINS,'EXACT_FIVE_GUARD_PINS_REQUIRED')
 return L,P,E,pins
def source_readonly(source,database_path):
 need(source.execute('PRAGMA query_only').fetchone()[0]==1 and source.total_changes==0 and not source.in_transaction,'READONLY_SOURCE_BEFORE_AFTER_REQUIRED')
 rows=source.execute('PRAGMA database_list').fetchall()
 need(all(n in ('main','temp') for _,n,_ in rows) and len([r for r in rows if r[1]=='main'])==1,'NO_ATTACHED_SOURCE_DATABASE_ALLOWED')
 need(Path(next(r[2] for r in rows if r[1]=='main')).resolve()==Path(database_path).resolve(),'EXACT_SOURCE_DATABASE_REQUIRED')
def prepare_only(source,destination,E,P,*,image,database_path,identity,fast_check,fast_basis,private_root=False):
 """No live mutation methods are invoked. Tests use synthetic SQLite copies."""
 source_readonly(source,database_path);fast_check()
 before=E.plan(source)
 prepared=P.prepare_copy(source,destination,E,image=image,database_path=database_path,identity=identity,private_root=private_root,current_check=fast_check)
 source_readonly(source,database_path)
 after=E.plan(source)
 need(before['scopeSha256']==after['scopeSha256']==prepared['scopeSha256'],'LIVE_READONLY_SCOPE_CHANGED_REPREVIEW_REQUIRED')
 # Exact full-row and schema equality on the two private files after rollback.
 backup_path=Path(destination)/'before.sqlite';dry_path=Path(destination)/'dryrun.sqlite'
 for file in (backup_path,dry_path):need(not any(Path(str(file)+suffix).exists() for suffix in ('-wal','-shm','-journal')),'SELF_CONTAINED_COPY_REQUIRED')
 def read_copy(file):
  db=sqlite3.connect(file.resolve().as_uri()+'?mode=ro&immutable=1',uri=True)
  try:
   db.execute('PRAGMA query_only=ON');db.execute('PRAGMA foreign_keys=ON')
   schema,rows=E.state(db);return E.sha({'schema':schema,'rows':{name:E.row_seal(value) for name,value in rows.items()}})
  finally:db.close()
 # Use the unchanged engine's canonical full-row seals, including retained data.
 backup_rows=read_copy(backup_path);dry_rows=read_copy(dry_path)
 need(backup_rows==dry_rows,'PRIVATE_DRYRUN_FULL_ROWS_NOT_ROLLED_BACK')
 fast_check();source_readonly(source,database_path)
 result={'schema':1,'status':'COPY_ONLY_NOT_RUNTIME_AUTHORIZATION','namespace':NAME,'createdAtUtc':stamp(),'guardImage':image,'fastRuntimeFingerprint':fast_basis,'fiveGuardSourcePins':SOURCE_PINS,'scopeSha256':prepared['scopeSha256'],'snapshotSha256':after['scope']['snapshotSha256'],'databaseIdentity':identity,'runtimeDatabaseWrites':0,'sourceQueryOnlyBeforeAfter':True,'sourceConnectionTotalChanges':source.total_changes,'sourceScopeBeforeAfterEqual':True,'privateBackupDryrunFullRowsEqual':True,'privateCopyFullRowsSha256':backup_rows,'consistentCommittedWal':True,'quickCheck':'ok','foreignKeyViolations':0,'preview':prepared['preview'],'dryrun':prepared['dryrun'],'backupProof':prepared['backupProof'],'inheritedPrepared':{'path':str(Path(destination)/'PREPARED.json'),'status':prepared['status']},'fullGuardAccepted':False,'nativeInspectExecuted':False,'deletionAdmissionCompatible':False,'cleanupAcceptance':False,'liveApplyEnabled':False,'automaticRetry':False,'automaticRestore':False,'pending':['NEW_INDEPENDENT_FULL_NATIVE_GUARD_REVIEW_FOR_MANAGED260','ROOT_SELECTED_MEDIA_DISK_PROOF','ACTION_TIME_EXACT_SCOPE_CONFIRMATION','NEW_SEPARATE_LIVE_DELETE_ADMISSION_AND_ENTRY_REVIEW']}
 P.new_json(Path(destination)/'COPY_ONLY.json',result)
 return result
def main():
 parser=argparse.ArgumentParser(description='Copies only; there is no apply mode')
 parser.add_argument('--lease-pid',required=True,type=int);parser.add_argument('--lease-start-ticks',required=True);parser.add_argument('--nonce',required=True)
 args=parser.parse_args()
 need(os.name=='posix' and os.geteuid()==os.getegid()==0,'EXACT_POSIX_ROOT_REQUIRED')
 need(args.lease_pid==OWN_PID and re.fullmatch('[1-9][0-9]*',args.lease_start_ticks) and re.fullmatch('[a-f0-9]{32}',args.nonce),'EXACT_OWN_LEASE_NONCE_REQUIRED')
 need(Path(__file__)==CODE/'copy_prepare.py','EXACT_COPY_ONLY_ENTRY_REQUIRED');directory(ROOT,0o755);directory(CODE,0o700)
 manifest=json.loads(raw_private(CODE/'COPY_ONLY_MANIFEST.json'))
 need(manifest['namespace']==NAME and manifest['status']=='CODE_ONLY_NOT_RUNTIME_AUTHORIZATION' and manifest['runtimeAuthorization'] is False and manifest['fullGuardAccepted'] is False,'COPY_ONLY_MANIFEST_REQUIRED')
 expected={*BASE_PINS,'copy_prepare.py'}
 need(set(manifest['files'])==expected and {p.name for p in CODE.iterdir()}==expected|{'COPY_ONLY_MANIFEST.json'},'EXACT_SIX_CODE_FILES_REQUIRED')
 for name,row in manifest['files'].items():need(sha(raw_private(CODE/name))==row['sha256'],'EXACT_REVIEWED_COPY_ONLY_CODE_REQUIRED')
 L,P,E,pins=load_modules(CODE)
 a={'guardImage':IMAGE,'lease':{'pid':args.lease_pid,'startTicks':args.lease_start_ticks,'lockPath':L.LOCK},'artifacts':{'guardReceipt':{'path':str(ROOT/(L.GUARD+'-journal.json')),'sha256':RECEIPT}}}
 receipt=json.loads(L.private_read(a['artifacts']['guardReceipt']['path'],RECEIPT))
 need(receipt.get('phase')=='APPLIED_NOT_CUSTOMER_ACCEPTANCE' and receipt.get('childImage')==IMAGE,'EXACT_COMPLETED_GUARD_IMAGE_REQUIRED')
 runtime=L.Runtime(a,pins,CODE/'copy_prepare.py',None,None)
 runtime.lease();runtime.fast_basis=runtime.fast_snapshot();runtime.fast_guard_read()
 # Deliberately no full_guard_read/native_inspect: that limitation is explicit.
 identity=database_identity(DATABASE);destination=ROOT/(NAME+'-'+args.nonce)
 need(not os.path.lexists(destination),'NEW_COPY_NONCE_REQUIRED_NO_RETRY')
 source=sqlite3.connect(DATABASE.as_uri()+'?mode=ro',uri=True)
 try:
  source.execute('PRAGMA foreign_keys=ON');source.execute('PRAGMA query_only=ON');source.execute('PRAGMA busy_timeout=0')
  def fast_check():
   runtime.fast_guard_read();need(database_identity(DATABASE)==identity,'LIVE_DB_IDENTITY_CHANGED')
  result=prepare_only(source,destination,E,P,image=IMAGE,database_path=DATABASE,identity=identity,fast_check=fast_check,fast_basis=runtime.fast_basis,private_root=True)
 finally:source.close()
 directory(destination,0o700)
 for p in destination.iterdir():raw_private(p) if p.suffix!='.sqlite' else need(p.stat().st_uid==p.stat().st_gid==0 and stat.S_IMODE(p.stat().st_mode)==0o600,'PRIVATE_COPY_SQLITE_REQUIRED')
 # Output only identifiers/checks, never source rows, cookies, contact details.
 print(json.dumps({'status':result['status'],'directory':str(destination),'scopeSha256':result['scopeSha256'],'backupProof':result['backupProof'],'preview':result['preview'],'dryrun':result['dryrun'],'fullGuardAccepted':False,'deletionAdmissionCompatible':False,'runtimeDatabaseWrites':0,'liveApplyEnabled':False},sort_keys=True))
if __name__=='__main__':
 try:main()
 except BaseException as error:
  code=str(error) if type(error) is ValueError and re.fullmatch('[A-Z][A-Z0-9_]{0,120}',str(error)) else 'COPY_PREPARATION_REFUSED_NO_RETRY'
  print(json.dumps({'status':'COPY_PREPARATION_REFUSED_NO_RUNTIME_AUTHORIZATION','code':code,'runtimeDatabaseWrites':0,'liveApplyEnabled':False,'automaticRetry':False}));raise SystemExit(2)
