"""Staged code only. Disabled admission cannot open SQLite or invoke native code.

No enabled admission is supplied. Root must review, stage privately, capture the
new installed guard and backup/copy proofs, then obtain action-time confirmation.
"""
import argparse
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import re
import sqlite3
import stat
import subprocess
import sys
import time
import types
from datetime import datetime, timezone

ROOT = Path('/opt/synapse/releases/palitra-app-20261015')
DATABASE = Path('/var/lib/docker/volumes/synapse_content_data/_data/content.sqlite')
LOCK = '/opt/synapse/.palitra-app-release.lock'
GUARD = 'palitra-clear-orders-guard-20261020-r1'
GUARD_CODE = ROOT / (GUARD + '-code')
PARENT_IMAGE = 'sha256:5409d279f90c3b2a64315e16c11bf9f192094b9234980c1f0b066bb7774d1c58'
ARTIFACTS = frozenset(('guardReceipt', 'guardDecision', 'guardPreflight', 'guardAcceptance',
                      'ownInspect', 'productTests', 'backupProof', 'diskProbe', 'preview', 'dryrun', 'userApproval'))
sha = lambda raw: hashlib.sha256(raw).hexdigest()
digest = lambda s: type(s) is str and re.fullmatch('[a-f0-9]{64}', s) is not None
need = lambda ok, code: None if ok else refuse(code)

def refuse(code):
    raise ValueError(code)

def exact(obj, fields, code):
    need(type(obj) is dict and set(obj) == set(fields), code)

def epoch(value):
    need(type(value) is str and value.endswith('Z'), 'UTC_REQUIRED')
    try:
        result = datetime.fromisoformat(value[:-1] + '+00:00').timestamp()
    except ValueError:
        refuse('UTC_REQUIRED')
    return result

def fresh(value, now, bound=900):
    return 0 <= now - epoch(value) <= bound

def validate_admission(a, pins, now):
    need(type(a) is dict and a.get('enabled') is True, 'DISABLED_NO_RUNTIME_AUTHORIZATION')
    exact(a, ('schema','enabled','namespace','site','companyCode','serverId','account',
        'entrySha256','codePinsSha256','engineSha256','guardImage','scopeSha256','snapshotSha256',
        'artifacts','lease','nonce','issuedAtUtc','expiresAtUtc','oneApply','userActionTimeConfirmed'), 'CLOSED_ADMISSION_REQUIRED')
    need(a['schema'] == 1 and a['site'] == 'palitra' and a['companyCode'] == 'palitra-love'
         and a['serverId'] == 8936001 and a['account'] == 'sa133295', 'EXACT_COMPANY_SERVER_REQUIRED')
    need(type(a['namespace']) is str and re.fullmatch('palitra-order-cleanup-20261020-[a-z0-9-]{8,60}', a['namespace']), 'NEW_CLEANUP_NAMESPACE_REQUIRED')
    need(all(digest(a[k]) for k in ('entrySha256','codePinsSha256','engineSha256','scopeSha256','snapshotSha256'))
         and a['engineSha256'] == pins['engineSha256'], 'EXACT_REVIEWED_CODE_AND_SCOPE_REQUIRED')
    need(type(a['guardImage']) is str and re.fullmatch('sha256:[a-f0-9]{64}', a['guardImage'])
         and a['guardImage'] != PARENT_IMAGE, 'INSTALLED_NEW_GUARD_IMAGE_REQUIRED')
    need(a['oneApply'] is True and a['userActionTimeConfirmed'] is True, 'PERMANENT_ACTION_TIME_CONFIRMATION_REQUIRED')
    need(type(a['nonce']) is str and re.fullmatch('[a-f0-9]{32}', a['nonce']), 'FRESH_NONCE_REQUIRED')
    issued, expiry = epoch(a['issuedAtUtc']), epoch(a['expiresAtUtc'])
    need(0 <= now-issued <= 600 and now < expiry <= issued+600, 'EXPIRED_OR_FUTURE_ADMISSION')
    exact(a['artifacts'], ARTIFACTS, 'CLOSED_PRIVATE_ARTIFACT_SET_REQUIRED')
    for row in a['artifacts'].values():
        exact(row, ('path','sha256'), 'PINNED_PRIVATE_ARTIFACT_REQUIRED')
        need(type(row['path']) is str and digest(row['sha256']), 'PINNED_PRIVATE_ARTIFACT_REQUIRED')
    exact(a['lease'], ('pid','startTicks','lockPath'), 'EXACT_LEASE_BINDING_REQUIRED')
    need(type(a['lease']['pid']) is int and a['lease']['pid'] > 1 and a['lease']['pid'] not in
         (3284416,3308227,3336085,3367042) and a['lease']['lockPath'] == LOCK
         and type(a['lease']['startTicks']) is str and re.fullmatch('[1-9][0-9]*', a['lease']['startTicks']), 'FRESH_OWN_LEASE_REQUIRED')

def validate_evidence(a, pins, d, now):
    """Pure crosslinks. All supplied bytes must separately pass private read+SHA."""
    exact(d, ARTIFACTS, 'CLOSED_PRIVATE_ARTIFACT_SET_REQUIRED')
    r, decision, pre, accepted = (d[k] for k in ('guardReceipt','guardDecision','guardPreflight','guardAcceptance'))
    need(r.get('name') == GUARD and r.get('phase') == 'APPLIED_NOT_CUSTOMER_ACCEPTANCE'
         and r.get('childImage') == a['guardImage'] and r.get('automaticRetry') is False
         and r.get('automaticRollback') is False and r.get('runtimeDatabaseWrites') == r.get('schemaChanges') == 0,
         'EXACT_COMPLETED_GUARD_REQUIRED')
    need(r.get('decisionSha256') == a['artifacts']['guardDecision']['sha256']
         and decision.get('preflightSha256') == a['artifacts']['guardPreflight']['sha256']
         and decision.get('rootAcceptanceSha256') == a['artifacts']['guardAcceptance']['sha256']
         and accepted.get('preflightSha256') == decision.get('preflightSha256'), 'GUARD_HISTORY_PIN_CROSSLINK_CHANGED')
    binding = r.get('binding')
    need(type(binding) is dict and binding.get('namespace') == GUARD and binding.get('parentImage') == PARENT_IMAGE
         and binding.get('manifestSha256') == pins['guardManifestSha256'] and binding.get('entrySha256') == pins['guardEntrySha256']
         and decision.get('binding') == pre.get('binding') == binding and decision.get('before') == pre.get('before') == r.get('before')
         and accepted.get('namespace') == GUARD and accepted.get('oneApply') is True
         and accepted.get('nonce') == decision.get('nonce'), 'GUARD_HISTORICAL_BINDING_CHANGED')
    tree = r.get('after', {}).get('runtime', {}).get('appTree', {})
    need(all(tree.get(target, {}).get('sha256') == pin for target, pin in pins['guardSourcePins'].items()), 'FIVE_GUARD_SOURCES_NOT_EXACT')
    inspected = d['ownInspect']
    need(inspected.get('status') == 'ROOT_OWN_GUARD_INSPECT_PASSED'
         and inspected.get('guardReceiptSha256') == a['artifacts']['guardReceipt']['sha256']
         and inspected.get('contentImage') == a['guardImage'] and inspected.get('sourcePins') == pins['guardSourcePins']
         and inspected.get('http410CodeNoStoreTestsPassed') is True
         and inspected.get('http410TestArtifactSha256') == a['artifacts']['productTests']['sha256']
         and fresh(inspected.get('capturedAtUtc'), now), 'OWN_GUARD_INSPECT_NOT_PROVEN')
    tests = d['productTests']
    need(tests.get('status') == 'ROOT_REVIEWED_CODE_TESTS_PASSED' and tests.get('sourcePins') == pins['guardSourcePins']
         and tests.get('backendTestsPassed') == 20 and tests.get('actualCatchRouteTestsPassed') == 3
         and tests.get('productTestsPassed') == 29 and tests.get('productionHttp410TestPerformed') is False,
         'EXACT_SOURCE_HTTP410_CODE_TEST_PROOF_REQUIRED')
    expected = {'status':'OWN_COMPLETED_READONLY_NOT_CUSTOMER_ACCEPTANCE','sourceFiles':240,'staticFiles':43,'chainFiles':49,'runtimeWrites':0}
    need(inspected.get('result') == expected, 'EXACT_NATIVE_GUARD_INSPECT_REQUIRED')
    for label, status in (('preview','SQLITE_COPY_PREVIEW_NOT_ACCEPTANCE'), ('dryrun','SQLITE_COPY_DRYRUN_ROLLED_BACK_NOT_ACCEPTANCE')):
        doc = d[label]
        need(doc.get('status') == status and doc.get('scopeSha256') == a['scopeSha256']
             and doc.get('snapshotSha256') == a['snapshotSha256'] and doc.get('cleanupAcceptance') is False
             and doc.get('liveApplyEnabled') is False and fresh(doc.get('createdAtUtc'), now), 'PRIVATE_COPY_PROOF_NOT_EXACT_' + label.upper())
    preview, dryrun = d['preview'], d['dryrun']
    counts, target_ids = preview.get('targetCounts'), preview.get('targetInternalIds')
    need(type(counts) is dict and type(target_ids) is dict and counts == dryrun.get('targetCounts')
         and target_ids == dryrun.get('targetInternalIds')
         and preview.get('businessOutboxBeforeAudit') == dryrun.get('businessOutboxBeforeAudit')
         and all(type(n) is int and n >= 0 for n in counts.values())
         and type(counts.get('chat_thread_messages')) is int and counts.get('client_dialog_messages') == 10,
         'VERIFIED_PRIVATE_COPY_COUNTS_AND_IDS_REQUIRED')
    audit = preview.get('businessOutboxBeforeAudit', [])
    need(all(any(r.get('table') == 'site_order_outbox' and r.get('id') == job and r.get('orderId') == order
                 and r.get('status') == 'uncertain' and digest(r.get('rowSha256')) for r in audit)
             for job, order in ((43,23),(48,28))), 'KNOWN_UNCERTAIN_SITE_AUDIT_NOT_INCLUDED')
    b = d['backupProof']
    need(b.get('status') == 'VERIFIED_PRIVATE_SQLITE_BACKUP' and b.get('databasePath') == str(DATABASE)
         and digest(b.get('backupSha256')) and type(b.get('backupPath')) is str
         and b.get('scopeSha256') == a['scopeSha256'] and b.get('snapshotSha256') == a['snapshotSha256']
         and b.get('schemaSha256') == d['preview'].get('schemaSha256') == d['dryrun'].get('schemaSha256')
         and b.get('guardImage') == a['guardImage'] and b.get('consistentCommittedWal') is True
         and b.get('quickCheck') == 'ok' and b.get('foreignKeyViolations') == 0
         and b.get('selectedMediaDiskCount') in (None,0) and b.get('privateRoot0600') is True
         and fresh(b.get('createdAtUtc'), now), 'PRIVATE_BACKUP_AND_DISK_SCOPE_NOT_EXACT')
    disk = d['diskProbe']
    need(disk.get('status') == 'ROOT_READONLY_SELECTED_MEDIA_DISK_CHECK_PASSED'
         and disk.get('scopeSha256') == a['scopeSha256'] and disk.get('guardImage') == a['guardImage']
         and disk.get('filesOnDiskChecked') is True and disk.get('selectedAttachments') == 0
         and disk.get('selectedUploads') == 0 and disk.get('selectedDiskFiles') == 0
         and fresh(disk.get('capturedAtUtc'),now), 'EXACT_SELECTED_MEDIA_DISK_PROOF_REQUIRED')
    exact(b.get('databaseIdentity'), ('dev','ino','uid','gid','mode'), 'EXACT_LIVE_DB_IDENTITY_REQUIRED')
    need(all(type(v) is int and v >= 0 for v in b['databaseIdentity'].values()), 'EXACT_LIVE_DB_IDENTITY_REQUIRED')
    user = d['userApproval']
    need(user.get('status') == 'USER_CONFIRMED_PERMANENT_PALITRA_CLEANUP'
         and user.get('namespace') == a['namespace'] and user.get('nonce') == a['nonce']
         and user.get('scopeSha256') == a['scopeSha256'] and user.get('snapshotSha256') == a['snapshotSha256']
         and user.get('guardImage') == a['guardImage'] and user.get('backupSha256') == b['backupSha256']
         and user.get('dryrunSha256') == a['artifacts']['dryrun']['sha256'] and user.get('permanentDeleteConfirmed') is True
         and user.get('legacyIncluded') is True and user.get('orderIds') == list(range(18,29))
         and user.get('threadIds') == list(range(10,21)) and user.get('webMessages') == counts['chat_thread_messages']
         and user.get('legacyDialogIds') == [1] and user.get('legacyMessages') == 10
         and user.get('businessOutboxIds') == {'site':target_ids.get('site_order_outbox',[]),
                                              'client':target_ids.get('client_bot_outbox',[])}
         and user.get('uncertainSiteJob43Included') is True and user.get('encryptedPushAuditRetained') is True,
         'EXACT_USER_ACTION_TIME_PERMANENT_SCOPE_REQUIRED')
    times = [epoch(d[k]['createdAtUtc']) for k in ('backupProof','preview','dryrun','userApproval')]
    need(times == sorted(times) and times[-1] <= epoch(a['issuedAtUtc']) and fresh(user['createdAtUtc'], now, 600),
         'BACKUP_PREVIEW_DRYRUN_THEN_CONFIRMATION_REQUIRED')

def private_path(path, directory=False):
    path = Path(path)
    need(path.is_absolute() and path.is_relative_to(ROOT) and '..' not in path.parts, 'EXACT_PRIVATE_RELEASE_PATH_REQUIRED')
    for part in (path, *path.parents):
        need(not part.is_symlink(), 'PRIVATE_PATH_ALIAS_REFUSED')
        if part != path and part.is_relative_to(ROOT):
            parent = part.lstat()
            need(stat.S_ISDIR(parent.st_mode) and parent.st_uid == parent.st_gid == 0
                 and stat.S_IMODE(parent.st_mode) == (0o755 if part == ROOT else 0o700), 'PRIVATE_PARENT_DIRECTORY_REQUIRED')
    s = path.lstat()
    need(s.st_uid == s.st_gid == 0 and stat.S_IMODE(s.st_mode) == ((0o755 if path == ROOT else 0o700) if directory else 0o600)
         and (stat.S_ISDIR(s.st_mode) if directory else stat.S_ISREG(s.st_mode) and s.st_nlink == 1), 'PRIVATE_ROOT_MODE_REQUIRED')
    return path

def private_read(path, pin=None, limit=4*1024*1024):
    path = private_path(path)
    s = path.lstat()
    need(s.st_size <= limit, 'BOUNDED_PRIVATE_FILE_REQUIRED')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'rb') as stream:
        before = os.fstat(stream.fileno()); raw = stream.read(limit+1); after = os.fstat(stream.fileno())
    final = path.lstat()
    fields = ('st_dev','st_ino','st_uid','st_gid','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
    need(len(raw) == s.st_size and all(getattr(s,k) == getattr(before,k) == getattr(after,k) == getattr(final,k) for k in fields), 'PRIVATE_FILE_CHANGED_DURING_READ')
    need(pin is None or digest(pin) and sha(raw) == pin, 'PRIVATE_FILE_SHA_CHANGED')
    return raw

def sqlite_file_sha(path):
    path = Path(path)
    before = path.lstat()
    need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and before.st_size <= 2*1024*1024*1024, 'BACKUP_BOUND')
    flags = os.O_RDONLY | getattr(os,'O_NOFOLLOW',0) | getattr(os,'O_NONBLOCK',0)
    fd = os.open(path,flags)
    h = hashlib.sha256()
    with os.fdopen(fd,'rb') as stream:
        first = os.fstat(stream.fileno())
        for chunk in iter(lambda:stream.read(1024*1024),b''):
            h.update(chunk)
        after = os.fstat(stream.fileno())
    final = path.lstat()
    fields = ('st_dev','st_ino','st_size','st_mtime_ns','st_ctime_ns','st_uid','st_gid','st_mode','st_nlink')
    # Windows reports creation/ctime differently through path and open handle.
    # Runtime is POSIX-only and keeps the complete comparison; synthetic copies
    # on Windows still compare each ctime against the same observation surface.
    if os.name == 'nt':
        need(before.st_ctime_ns == final.st_ctime_ns and first.st_ctime_ns == after.st_ctime_ns, 'PRIVATE_BACKUP_CHANGED')
        fields = tuple(k for k in fields if k != 'st_ctime_ns')
    need(all(getattr(before,k) == getattr(first,k) == getattr(after,k) == getattr(final,k) for k in fields), 'PRIVATE_BACKUP_CHANGED')
    return h.hexdigest()

class BoundedCapture(io.StringIO):
    def write(self, value):
        need(self.tell()+len(value) <= 65536, 'NATIVE_INSPECT_OUTPUT_BOUND')
        return super().write(value)

class Runtime:
    def __init__(self, a, pins, entry_path, admission_path, admission_pin):
        self.a, self.pins, self.entry_path = a, pins, entry_path
        self.admission_path, self.admission_pin = admission_path, admission_pin

    def artifacts(self):
        docs = {}
        historical = {'guardReceipt':'journal','guardDecision':'decision','guardPreflight':'preflight','guardAcceptance':'root-acceptance'}
        for key, row in self.a['artifacts'].items():
            if key in historical:
                need(Path(row['path']) == ROOT / (GUARD + '-' + historical[key] + '.json'), 'EXACT_GUARD_HISTORY_PATH_REQUIRED')
            docs[key] = json.loads(private_read(row['path'], row['sha256']))
        return docs

    def lease(self):
        lease = self.a['lease']
        result = subprocess.run(['lslocks','--noheadings','--output','PID,PATH'], check=True, capture_output=True, timeout=10)
        need(len(result.stdout) <= 1024*1024 and not result.stderr, 'BOUNDED_LEASE_OBSERVATION_REQUIRED')
        rows = [r.strip().split(maxsplit=1) for r in result.stdout.decode().splitlines()]
        need([r for r in rows if len(r) == 2 and r[1] == LOCK] == [[str(lease['pid']), LOCK]], 'EXACT_FRESH_OWN_LEASE_NOT_HELD')
        proc = Path('/proc') / str(lease['pid']) / 'stat'
        need(proc.stat().st_size <= 8192, 'PROCESS_STATE_BOUND')
        need(proc.read_text().rsplit(') ',1)[1].split()[19] == lease['startTicks'], 'LEASE_PROCESS_REUSED')

    def native_inspect(self):
        # Exactly the installed guard's inspect command; never approve/apply.
        private_path(GUARD_CODE, True)
        private_read(GUARD_CODE / 'manifest.json', self.pins['guardManifestSha256'])
        path = GUARD_CODE / 'company-app.py'
        raw = private_read(path, self.pins['guardEntrySha256'])
        stdout, stderr = BoundedCapture(), BoundedCapture()
        old = sys.argv
        try:
            sys.argv = [str(path), 'inspect', '--lease-pid', str(self.a['lease']['pid']),
                        '--receipt-sha', self.a['artifacts']['guardReceipt']['sha256']]
            with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                exec(compile(raw, str(path), 'exec'), {'__name__':'__main__','__file__':str(path)})
        finally:
            sys.argv = old
        need(not stderr.getvalue(), 'NATIVE_INSPECT_REFUSED')
        need(json.loads(stdout.getvalue()) == {'status':'OWN_COMPLETED_READONLY_NOT_CUSTOMER_ACCEPTANCE',
             'sourceFiles':240,'staticFiles':43,'chainFiles':49,'runtimeWrites':0}, 'NATIVE_INSPECT_NOT_EXACT')

    def command(self, args):
        result = subprocess.run(args,check=True,capture_output=True,timeout=10)
        need(len(result.stdout)<=4*1024*1024 and not result.stderr,'BOUNDED_FAST_RUNTIME_READ_REQUIRED')
        return json.loads(result.stdout)

    def fast_snapshot(self):
        rows = self.command(['docker','inspect','synapse-content-1'])
        need(type(rows) is list and len(rows)==1,'EXACT_CONTENT_CONTAINER_REQUIRED')
        row=rows[0];state=row.get('State',{});mounts=row.get('Mounts',[])
        need(type(row.get('Id')) is str and re.fullmatch('[a-f0-9]{64}',row['Id'])
             and row.get('Image')==self.a['guardImage'] and state.get('Running') is True
             and state.get('Restarting') is False and state.get('OOMKilled') is False
             and type(row.get('RestartCount')) is int and type(state.get('StartedAt')) is str,'FAST_CONTENT_IMAGE_OR_VERSION_CHANGED')
        data=[r for r in mounts if r.get('Destination')=='/data']
        need(len(data)==1 and data[0].get('Type')=='volume' and data[0].get('Name')=='synapse_content_data'
             and data[0].get('Source')==str(DATABASE.parent) and data[0].get('RW') is True,'FAST_CONTENT_MOUNT_CHANGED')
        targets=sorted(self.pins['guardSourcePins'])
        need(set(targets)=={'server.js','site-orders.js','palitra-orders-public/shell.js',
              'palitra-orders-public/shop.html','palitra-orders-public/cabinet.html'},'EXACT_FIVE_SOURCE_PINS_REQUIRED')
        js="""const f=require('node:fs'),c=require('node:crypto'),out={};
const names=JSON.parse(process.argv[1]);if(f.realpathSync('/app')!=='/app')throw Error('APP_ALIAS');
for(const n of names){const p='/app/'+n,s=f.lstatSync(p);if(!s.isFile()||s.nlink!==1||s.size>2097152)throw Error('SOURCE_BOUND');
 const fd=f.openSync(p,f.constants.O_RDONLY|f.constants.O_NOFOLLOW);try{const a=f.fstatSync(fd),raw=f.readFileSync(fd),z=f.fstatSync(fd),q=f.lstatSync(p);
 for(const k of ['dev','ino','mode','uid','gid','nlink','size','mtimeMs','ctimeMs'])if(s[k]!==a[k]||s[k]!==z[k]||s[k]!==q[k])throw Error('SOURCE_RACE');
 out[n]=c.createHash('sha256').update(raw).digest('hex');}finally{f.closeSync(fd);}}
process.stdout.write(JSON.stringify(out));"""
        need(self.command(['docker','exec','synapse-content-1','node','-e',js,json.dumps(targets)])==self.pins['guardSourcePins'],
             'FAST_FIVE_GUARD_SOURCES_CHANGED')
        stable={k:row.get(k) for k in ('Id','Image','Config','HostConfig','Mounts','ImageManifestDescriptor','RestartCount')}
        stable['Mounts']=sorted(mounts,key=lambda mount:json.dumps(mount,sort_keys=True,separators=(',',':')))
        stable['StartedAt']=state['StartedAt']
        return sha(json.dumps(stable,sort_keys=True,separators=(',',':')).encode())

    def full_guard_read(self):
        self.lease();before=self.fast_snapshot();self.native_inspect();self.lease()
        after=self.fast_snapshot();need(before==after,'RUNTIME_CHANGED_DURING_FULL_INSPECT')
        self.fast_basis=after

    def fast_guard_read(self):
        self.lease();need(self.fast_snapshot()==self.fast_basis,'CONTENT_CID_IMAGE_MOUNT_VERSION_CHANGED')
        row=self.a['artifacts']['guardReceipt']
        need(json.loads(private_read(row['path'],row['sha256'])).get('childImage')==self.a['guardImage'], 'GUARD_RECEIPT_IMAGE_CHANGED')

    def backup(self, proof, engine):
        path = private_path(proof['backupPath'])
        need(not any(Path(str(path)+suffix).exists() for suffix in ('-wal','-shm','-journal')), 'BACKUP_MUST_BE_SELF_CONTAINED')
        need(sqlite_file_sha(path) == proof['backupSha256'], 'PRIVATE_BACKUP_CHANGED')
        db = sqlite3.connect(path.as_uri()+'?mode=ro&immutable=1', uri=True)
        try:
            db.execute('PRAGMA foreign_keys=ON'); db.execute('PRAGMA query_only=ON')
            need(engine.plan(db)['scopeSha256'] == self.a['scopeSha256'], 'BACKUP_SCOPE_NOT_EXACT')
        finally:
            db.close()
        return path

    def private_evidence(self):
        need(json.loads(private_read(self.admission_path, self.admission_pin)) == self.a, 'ADMISSION_CHANGED')
        validate_admission(self.a, self.pins, time.time())
        d = self.artifacts(); validate_evidence(self.a, self.pins, d, time.time())
        need(json.loads(private_read(self.entry_path.parent/'LOCAL_CODE_PINS.json',self.a['codePinsSha256'])) == self.pins,
             'CODE_PINS_CHANGED')
        private_read(self.entry_path, self.a['entrySha256'])
        private_read(self.entry_path.parent / 'cleanup_runtime.py', self.a['engineSha256'])
        return d

    def current(self, engine):
        d=self.private_evidence();self.full_guard_read()
        return d, self.backup(d['backupProof'], engine)

    def fast_current(self, engine):
        d=self.private_evidence();self.fast_guard_read()
        path=private_path(d['backupProof']['backupPath'])
        need(sqlite_file_sha(path)==d['backupProof']['backupSha256'],'PRIVATE_BACKUP_CHANGED')
        # Shared helper separately repeats exact live + backup scope under lock.
        return d,path

    def open_database(self, proof):
        for part in (DATABASE, *DATABASE.parents):
            need(not part.is_symlink(), 'DATABASE_ALIAS_REFUSED')
        s = DATABASE.lstat()
        need(stat.S_ISREG(s.st_mode) and s.st_nlink == 1 and not stat.S_IMODE(s.st_mode) & 0o022, 'EXACT_LIVE_DB_FILE_REQUIRED')
        need({'dev':s.st_dev,'ino':s.st_ino,'uid':s.st_uid,'gid':s.st_gid,'mode':stat.S_IMODE(s.st_mode)} == proof['databaseIdentity'], 'LIVE_DB_IDENTITY_CHANGED')
        db = sqlite3.connect(DATABASE.as_uri()+'?mode=rw', uri=True)
        db.execute('PRAGMA foreign_keys=ON'); db.execute('PRAGMA busy_timeout=0')
        return db

    def claim(self, planned):
        path = ROOT / ('palitra-order-cleanup-used-' + self.a['nonce'] + '.json')
        fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW, 0o600)
        with os.fdopen(fd, 'w', encoding='utf-8') as out:
            json.dump({'phase':'APPLY_STARTED_UNKNOWN','namespace':self.a['namespace'],'nonce':self.a['nonce'],
                'admissionSha256':self.admission_pin,'scopeSha256':self.a['scopeSha256'],
                'automaticRetry':False,'automaticRestore':False,
                'businessOutboxBeforeAudit':planned['scope']['businessOutboxBeforeAudit']}, out)
            out.flush(); os.fsync(out.fileno())
        self.sync_directory(path.parent)
        return path

    def sync_directory(self, path):
        fd = os.open(path,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
        try:os.fsync(fd)
        finally:os.close(fd)

    def finish(self, path, result):
        # UNKNOWN file stays immutable. Separate new receipt; never rewrite old journals.
        receipt = Path(str(path) + '.receipt.json')
        raw = json.dumps(result,ensure_ascii=False,sort_keys=True).encode()
        fd = os.open(receipt, os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW, 0o600)
        with os.fdopen(fd,'wb') as out:
            out.write(raw); out.flush(); os.fsync(out.fileno())
        self.sync_directory(receipt.parent)
        private_read(receipt,sha(raw))
        return sha(raw)

def run_once(a, pins, engine, runtime):
    validate_admission(a, pins, time.time())
    d, backup_path = runtime.current(engine)
    db = runtime.open_database(d['backupProof'])
    try:
        planned = engine.plan(db)
        need(planned['scopeSha256'] == a['scopeSha256'] and planned['scope']['snapshotSha256'] == a['snapshotSha256'], 'LIVE_SCOPE_CHANGED_BEFORE_CLAIM')
        actual = engine.public(planned,'LIVE_METADATA_CAS_ONLY')
        need(all(actual[key] == d['preview'].get(key) == d['dryrun'].get(key)
                 for key in ('targetCounts','targetInternalIds','businessOutboxBeforeAudit')),
             'LIVE_PREVIEW_COUNTS_IDS_AUDIT_CHANGED')
        validate_admission(a,pins,time.time())
        claim = runtime.claim(planned)  # EXCL one-use before the first mutation.
        def last_gate(current):
            need(current['scopeSha256'] == a['scopeSha256'], 'LAST_SCOPE_CHANGED')
            runtime.fast_current(engine)  # no full 240/43/3DB inspect under writer lock
        def commit_gate():
            validate_admission(a,pins,time.time())
            runtime.lease()
        planned = engine.execute_reviewed_transaction(db, 'palitra-love/order-contact-followup/v1/',
            a['scopeSha256'], backup_path, datetime.now(timezone.utc).isoformat(), last_gate, commit_gate)
        # Commit is already irreversible. Failure below remains UNKNOWN and NEVER retries.
        runtime.lease()
        result = engine.public(planned, 'CLEANUP_COMMITTED_REQUIRES_ROOT_READONLY_ACCEPTANCE')
        result.update(admissionSha256=runtime.admission_pin, guardImage=a['guardImage'],
                      namespace=a['namespace'],nonce=a['nonce'],automaticRetry=False,automaticRestore=False,
                      runtimeAcceptance=False,pending=['ROOT_READONLY_POSTCOMMIT_ACCEPTANCE'])
        receipt_sha = runtime.finish(claim,result)
        need(digest(receipt_sha),'OWN_CLEANUP_RECEIPT_NOT_VERIFIED')
        result['receiptSha256'] = receipt_sha
        return result
    finally:
        db.close()

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--admission', required=True); p.add_argument('--admission-sha', required=True)
    p.add_argument('--apply', action='store_true')
    args = p.parse_args()
    # Disabled default is checked before engine/native/SQLite construction.
    need(args.apply is True, 'EXPLICIT_APPLY_FLAG_REQUIRED')
    need(os.name == 'posix' and os.geteuid() == 0, 'POSIX_ROOT_ONLY')
    a = json.loads(private_read(args.admission, args.admission_sha))
    need(a.get('enabled') is True, 'DISABLED_NO_RUNTIME_AUTHORIZATION')
    need(type(a.get('namespace')) is str and re.fullmatch('palitra-order-cleanup-20261020-[a-z0-9-]{8,60}',a['namespace']), 'NEW_CLEANUP_NAMESPACE_REQUIRED')
    code = ROOT / (a['namespace']+'-code')
    private_path(ROOT,True); private_path(code,True)
    need(Path(__file__) == code/'live_entry.py' and Path(args.admission) == ROOT/(a['namespace']+'-admission.json'), 'EXACT_STAGED_ENTRY_ADMISSION_PATH_REQUIRED')
    pins = json.loads(private_read(code/'LOCAL_CODE_PINS.json', a['codePinsSha256']))
    need(pins['status'] == 'LOCAL_STAGED_CODE_ONLY_NOT_RUNTIME_AUTHORIZATION' and pins['guardName'] == GUARD, 'EXACT_LOCAL_CODE_PINS_REQUIRED')
    validate_admission(a,pins,time.time())
    private_read(code/'live_entry.py',a['entrySha256'])
    raw = private_read(code/'cleanup_runtime.py',a['engineSha256'])
    engine = types.ModuleType('reviewed_cleanup_runtime'); engine.__file__ = str(code/'cleanup_runtime.py')
    exec(compile(raw,engine.__file__,'exec'),engine.__dict__)
    runtime = Runtime(a,pins,code/'live_entry.py',args.admission,args.admission_sha)
    print(json.dumps(run_once(a,pins,engine,runtime),ensure_ascii=False,sort_keys=True))

if __name__ == '__main__':
    sys.dont_write_bytecode = True
    try:
        main()
    except BaseException as error:
        # Lost/SystemExit/partial stdout/SQLite/OS/timeout are all refusal/UNKNOWN.
        value = str(error) if type(error) is ValueError and re.fullmatch('[A-Z][A-Z0-9_]{0,120}',str(error)) else 'REFUSED_OR_UNKNOWN_NO_RETRY'
        print(json.dumps({'status':'REFUSED_OR_UNKNOWN_NO_RETRY','code':value,'runtimeAcceptance':False,
                          'automaticRetry':False,'automaticRestore':False}))
        raise SystemExit(2)
