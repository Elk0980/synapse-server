"""Frozen code entry. Runtime requires independent fresh admission; no defaults."""
import argparse, hashlib, json, os, re, stat, sys, types
from pathlib import Path,PurePosixPath
sys.dont_write_bytecode = True
CODE = Path('/opt/synapse/releases/palitra-app-20261015/palitra-manager-simple-20261020-r4-attempt4-code')
FROZEN = True
MANIFEST_SHA = '00c197914ef64dceb4e99d2fa7b40e9c1aaa6e005e17411afe245ecc44480cb0'
def need(ok, code):
    if not ok: raise ValueError(code)
def sha(raw): return hashlib.sha256(raw).hexdigest()
def read(path):
    for part in [path, *path.parents]:
        need(not part.is_symlink(), 'CODE_ALIAS_REFUSED')
    s = path.lstat()
    need(stat.S_ISREG(s.st_mode) and s.st_nlink == 1 and s.st_uid == s.st_gid == 0
         and stat.S_IMODE(s.st_mode) == 0o600, 'PRIVATE_SINGLE_LINK_CODE_REQUIRED')
    need(s.st_size <= 4*1024*1024, 'BOUNDED_CODE_REQUIRED')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'rb') as file:
        before = os.fstat(file.fileno()); raw = file.read(4*1024*1024+1); after = os.fstat(file.fileno())
    final = path.lstat()
    fields = ('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
    need(all(getattr(s,k)==getattr(before,k)==getattr(after,k)==getattr(final,k) for k in fields)
         and len(raw)==s.st_size, 'CODE_CHANGED_DURING_READ')
    return raw
def load(raw, path):
    module=types.ModuleType('exact_day_code');module.__file__=str(path)
    exec(compile(raw,str(path),'exec'),module.__dict__);return module
def safe_error_code(error):
    value=error.args[0] if type(error) is ValueError and len(error.args)==1 and type(error.args[0]) is str else None
    return value if value is not None and re.fullmatch('[A-Z][A-Z0-9_]{0,100}',value) else 'UNEXPECTED_RELEASE_ERROR'
def main():
    need(FROZEN is True, 'DRAFT_ENTRY_NOT_AUTHORIZED')
    need(os.name=='posix' and os.geteuid()==0 and Path(__file__)==CODE/'company-app.py', 'EXACT_POSIX_ROOT_CODE_REQUIRED')
    for part in (CODE, CODE/'payload'):
        s=part.lstat();need(stat.S_ISDIR(s.st_mode) and s.st_uid==s.st_gid==0 and stat.S_IMODE(s.st_mode)==0o700 and not part.is_symlink(), 'PRIVATE_CODE_DIRECTORY_REQUIRED')
    raw=read(CODE/'manifest.json');need(sha(raw)==MANIFEST_SHA,'FROZEN_MANIFEST_CHANGED');m=json.loads(raw)
    need(m['name']=='palitra-manager-simple-20261020-r4-attempt4' and m['status']=='LOCAL_FROZEN_CODE_ONLY' and m['runtimeAuthorization'] is False,'CODE_ONLY_MANIFEST_REQUIRED')
    need(m.get('htmlClosureAccepted') is True and m.get('FROZEN') is True,'CLOSED_HTML_FROZEN_SCOPE_REQUIRED')
    need(all(type(r.get('path')) is str and not PurePosixPath(r['path']).is_absolute() and '..' not in PurePosixPath(r['path']).parts and PurePosixPath(r['path']).as_posix()==r['path'] for r in m['files']),'CLOSED_CODE_RELATIVE_PATHS_REQUIRED')
    wanted={r['path'] for r in m['files']}|{'manifest.json','company-app.py'}
    need(len(wanted)==len(m['files'])+2,'UNIQUE_CODE_PATHS_REQUIRED')
    dirs={str(p) for label in wanted for p in PurePosixPath(label).parents if str(p)!='.'}
    found={p.relative_to(CODE).as_posix() for p in CODE.rglob('*') if not p.is_dir()}
    need(found==wanted and {p.relative_to(CODE).as_posix() for p in CODE.rglob('*') if p.is_dir()}==dirs,'CLOSED_CODE_PACKAGE_REQUIRED')
    for label in dirs:
        part=CODE/label;s=part.lstat();need(stat.S_ISDIR(s.st_mode) and s.st_uid==s.st_gid==0 and stat.S_IMODE(s.st_mode)==0o700 and not part.is_symlink(),'PRIVATE_NESTED_CODE_DIRECTORY_REQUIRED')
    sealed={}
    for r in m['files']:
        value=read(CODE/r['path']);need(len(value)==r['bytes'] and sha(value)==r['sha256'],'EXACT_FROZEN_HELPER_REQUIRED');sealed[r['path']]=value
    entry=read(CODE/'company-app.py')
    parser=argparse.ArgumentParser();parser.add_argument('command',choices=('preflight','approve','apply','inspect','rollback-plan'))
    parser.add_argument('--lease-pid',type=int,required=True);parser.add_argument('--root-acceptance-sha');parser.add_argument('--decision-sha');parser.add_argument('--receipt-sha');parser.add_argument('--apply',action='store_true')
    args=parser.parse_args()
    controller=load(sealed['controller.py'],CODE/'controller.py');native=load(sealed['native.py'],CODE/'native.py').Native(args.lease_pid)
    release=controller.Release(native,MANIFEST_SHA,sha(entry))
    if args.command=='preflight':result=release.preflight()
    elif args.command=='approve':result=release.approve(args.root_acceptance_sha)
    elif args.command=='apply':result=release.apply(args.decision_sha,args.apply)
    elif args.command=='inspect':result=release.inspect(args.receipt_sha)
    else:result=load(sealed['rollback-plan.py'],CODE/'rollback-plan.py').plan(release,args.receipt_sha)
    print(json.dumps(result,ensure_ascii=False,separators=(',',':')))
if __name__=='__main__':
    try:main()
    except Exception as error:
        print(json.dumps({'status':'REFUSED_OR_UNKNOWN_NO_RETRY','runtimeAcceptance':False,'code':safe_error_code(error)}),file=sys.stderr)
        sys.exit(1)
