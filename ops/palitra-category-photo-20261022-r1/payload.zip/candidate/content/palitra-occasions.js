/* Palitra: публичные поводы (категории витрины), основные 6 на главной и временные праздничные подборки.
   Один модуль для витрины (catalog-live.js, главная) и для редактора ЛК: одинаковые правила с обеих сторон.
   UMD: в браузере — window.PalitraOccasions, в Node — module.exports. Прайс не меняется: товар остаётся
   одним объектом в своём разделе прайса (category.items) со старым id; поводы — только метки при чтении. */
(function (root, factory) {
  'use strict';
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.PalitraOccasions = api;
})(typeof window === 'undefined' ? globalThis : window, function () {
  'use strict';

  /* Тот же список и порядок, что DEFAULT_CATEGORIES в catalog-live.js (без «Весь каталог»).
     key — публичный ключ повода (адрес /catalog?cat=key); source — id разделов прайса (category.id),
     товары которых попадают в повод по старому правилу. Ключ повода и id раздела — разные вещи. */
  const DEFAULT_PUBLIC = Object.freeze([
    { key: 'vypiska', title: 'Выписка', source: ['vypiska'] },
    { key: 'dr-muzhchiny', title: 'День рождения мужчины', source: ['dr-muzhchine'] },
    { key: 'dr-devushki', title: 'День рождения девушки', source: ['dr-zhenschine'] },
    { key: 'dr-malyshey', title: 'День рождения малышей', source: ['dr-detyam'] },
    { key: 'gender-pati', title: 'Гендер пати', source: ['gender-pati'] },
    { key: 'devichnik', title: 'Девичник', source: ['devichnik'] },
    { key: 'malchishnik', title: 'Мальчишник', source: ['malchishnik'] },
    { key: 'dlya-mamy', title: 'Шары для мамы', source: ['dlya-mamy'] },
    { key: 'v-potolok', title: 'Шары в потолок', source: ['v-potolok'] },
    { key: 's-foto', title: 'Шары с фото', source: ['s-foto'] },
    { key: 'dlya-biznesa', title: 'Шары для бизнеса', source: ['dlya-biznesa'] }
  ].map(Object.freeze));
  /* Шесть основных Дарьи (12.10.2026): Выписка, ДР мужчины, ДР девушки, ДР малышей, Гендер пати, Девичник. */
  const DEFAULT_HOME = Object.freeze(['vypiska', 'dr-muzhchiny', 'dr-devushki', 'dr-malyshey', 'gender-pati', 'devichnik']);
  const HOME_MAX = 6;
  const HOLIDAYS_MAX = 12;
  const HOLIDAY_SPAN_MAX_DAYS = 366;
  const HOLIDAY_KEY = /^h-[a-z0-9]+(?:-[a-z0-9]+)*$/;
  const PUBLIC_KEY = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
  const DATE = /^(\d{4})-(\d{2})-(\d{2})$/;

  const isObject = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);
  const unique = (list) => list.filter((value, index) => list.indexOf(value) === index);

  /* Настоящая календарная дата YYYY-MM-DD (без 2027-02-30). */
  function isValidDate(value) {
    const m = DATE.exec(typeof value === 'string' ? value : '');
    if (!m) return false;
    const y = Number(m[1]), mo = Number(m[2]), d = Number(m[3]);
    if (y < 2000 || y > 2100 || mo < 1 || mo > 12 || d < 1) return false;
    return d <= new Date(Date.UTC(y, mo, 0)).getUTCDate();
  }
  const dayNumber = (value) => { const m = DATE.exec(value); return Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3])) / 86400000; };

  /* Часовой пояс принимается только как подтверждённая настройка компании (сервер/хост), не из браузера.
     Пустое значение — пояса нет: расписание праздников выключено. */
  function isValidTimeZone(value) {
    if (typeof value !== 'string' || !value || value.length > 64 || !/^[A-Za-z][A-Za-z0-9_+\-/]*$/.test(value)) return false;
    try { new Intl.DateTimeFormat('en-US', { timeZone: value }).format(0); return true; } catch (_) { return false; }
  }
  /* Местная дата компании в момент now (учитывает летнее время через Intl). */
  function localDate(now, timeZone) {
    if (!isValidTimeZone(timeZone)) return '';
    const time = now instanceof Date ? now.getTime() : Number(now);
    if (!Number.isFinite(time)) return '';
    const parts = new Intl.DateTimeFormat('en-US', { timeZone, year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(new Date(time));
    const get = (type) => (parts.find((p) => p.type === type) || {}).value || '';
    const y = get('year'), m = get('month'), d = get('day');
    return /^\d{4}$/.test(y) && /^\d{2}$/.test(m) && /^\d{2}$/.test(d) ? `${y}-${m}-${d}` : '';
  }

  function catalogOf(data) { return data && isObject(data.publicCatalog) ? data.publicCatalog : null; }
  function baseKeys(categories) {
    return (Array.isArray(categories) ? categories : DEFAULT_PUBLIC)
      .filter((cat) => cat && cat.key && cat.key !== 'all' && !cat.holiday).map((cat) => cat.key);
  }

  /* ---------- свои категории сайта (PALITRA-CATEGORY-LINK, 13.10.2026) ----------
     publicCatalog.categories = [{ key, title, source: [id раздела прайса] }] — только явные записи владельца.
     Ключ задаётся при создании как custom-<id раздела> и больше не меняется (переименование меняет только title).
     Раздел прайса без такой записи на сайте не появляется, как и раньше. Запись принимается целиком или не
     принимается: ровно поля key/title/source, существующие разделы, без повторов ключей, названий и разделов.
     Основные 6 и праздники в этой версии собираются только из постоянных категорий (DEFAULT_PUBLIC):
     встроенная копия этого модуля на главной странице знает только их. */
  const CUSTOM_PREFIX = 'custom-';
  const CUSTOM_KEY = /^custom-[a-z0-9]+(?:-[a-z0-9]+)*$/;
  const CUSTOM_KEY_MAX = 60;
  const CUSTOM_MAX = 24;
  const CUSTOM_TITLE_MAX = 60;
  const CUSTOM_SOURCE_MAX = 4;
  const CUSTOM_FIELDS = 'key,source,title';
  /* Занятые ключи: «Весь каталог», служебные имена объектов и прежние адреса разделов витрины. */
  const RESERVED_KEYS = Object.freeze(['all', '__proto__', 'constructor', 'prototype', 'hasownproperty', 'tostring', 'valueof',
    'shary', 'malysham', 'den-rozhdeniya', 'muzhchinam', 'bukety', 'korziny', 'dofaminovye', 'shary-giganty']);
  const BAD_TITLE = /[\u0000-\u001f\u007f​‎‏‪-‮\u2028\u2029⁦-⁩﻿<>]/;
  const isCustomKey = (key) => typeof key === 'string' && key.startsWith(CUSTOM_PREFIX);
  const titleId = (value) => String(value).toLowerCase().replace(/ё/g, 'е').replace(/\s+/g, ' ').trim();
  /* Постоянные категории без своих (для основных 6 и праздников). */
  function coreCategories(categories) {
    return (Array.isArray(categories) ? categories : DEFAULT_PUBLIC).filter((cat) => cat && !isCustomKey(cat.key));
  }
  function sectionIdsOf(data) {
    return data && Array.isArray(data.categories)
      ? data.categories.filter((cat) => isObject(cat) && typeof cat.id === 'string' && cat.id).map((cat) => cat.id) : [];
  }
  /* Стабильный ключ своей категории по id раздела: только латиница, цифры и дефисы; иначе ''. */
  function customKeyFor(sectionId) {
    const slug = String(sectionId ?? '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
    const key = CUSTOM_PREFIX + slug;
    return slug && key.length <= CUSTOM_KEY_MAX && CUSTOM_KEY.test(key) ? key : '';
  }
  /* Одна проверка для редактора, сервера и витрины: проблемы и принятые записи (в порядке списка). */
  function scanCustom(list, data, baseCategories) {
    const problems = [], accepted = [];
    if (list === undefined) return { problems, accepted };
    if (!Array.isArray(list)) return { problems: ['Свои категории сайта (publicCatalog.categories) должны быть списком'], accepted };
    if (list.length > CUSTOM_MAX) problems.push(`Своих категорий сайта больше ${CUSTOM_MAX}`);
    const core = coreCategories(baseCategories).filter((cat) => cat.key !== 'all' && !cat.holiday);
    const sections = new Set(sectionIdsOf(data));
    const keys = new Set(['all'].concat(core.map((cat) => cat.key)));
    const titles = new Set(['весь каталог'].concat(core.map((cat) => titleId(cat.title || ''))));
    const sources = new Set();
    core.forEach((cat) => (Array.isArray(cat.source) ? cat.source : []).forEach((id) => sources.add(id)));
    list.slice(0, CUSTOM_MAX).forEach((def, i) => {
      if (!isObject(def)) { problems.push(`Своя категория сайта №${i + 1}: должна быть объектом`); return; }
      const out = [];
      const name = typeof def.title === 'string' && def.title.trim() ? `«${def.title.trim()}»` : `№${i + 1}`;
      if (Object.keys(def).sort().join(',') !== CUSTOM_FIELDS) out.push(`Категория сайта ${name}: нужны ровно поля key, title и source`);
      const key = def.key;
      if (typeof key !== 'string' || key.length > CUSTOM_KEY_MAX || !CUSTOM_KEY.test(key)) out.push(`Категория сайта ${name}: ключ должен начинаться с custom- и содержать только латиницу, цифры и дефисы`);
      else if (RESERVED_KEYS.includes(key) || HOLIDAY_KEY.test(key)) out.push(`Категория сайта ${name}: ключ ${key} зарезервирован`);
      else if (keys.has(key)) out.push(`Категория сайта ${name}: ключ ${key} уже занят`);
      const title = def.title;
      if (typeof title !== 'string' || !title.trim() || title !== title.trim() || title.length > CUSTOM_TITLE_MAX || BAD_TITLE.test(title)) {
        out.push(`Категория сайта ${name}: нужно название до ${CUSTOM_TITLE_MAX} символов, без пробелов по краям и служебных знаков`);
      } else if (titles.has(titleId(title))) out.push(`Категория сайта ${name}: такое название уже есть на сайте`);
      const src = def.source;
      if (!Array.isArray(src) || !src.length || src.length > CUSTOM_SOURCE_MAX) out.push(`Категория сайта ${name}: нужен от 1 до ${CUSTOM_SOURCE_MAX} разделов прайса`);
      else {
        if (unique(src).length !== src.length) out.push(`Категория сайта ${name}: раздел прайса указан дважды`);
        for (const id of src) {
          if (typeof id !== 'string' || !sections.has(id)) out.push(`Категория сайта ${name}: раздела прайса ${String(id)} нет`);
          else if (sources.has(id)) out.push(`Категория сайта ${name}: раздел прайса ${id} уже показывается в другой категории`);
        }
      }
      if (out.length) { problems.push(...out); return; }
      keys.add(key); titles.add(titleId(title)); src.forEach((id) => sources.add(id));
      accepted.push(Object.freeze({ key, title, source: Object.freeze(src.slice()) }));
    });
    return { problems, accepted };
  }
  function customCategoriesProblems(list, data, baseCategories) { return scanCustom(list, data, baseCategories).problems; }
  /* Принятые свои категории документа; неверные записи не показываются (сервер их не примет). */
  function customCategories(data, baseCategories) {
    const catalog = catalogOf(data);
    return catalog && Array.isArray(catalog.categories) ? scanCustom(catalog.categories, data, baseCategories).accepted : [];
  }
  /* Единый список поводов документа: переданные (или постоянные) + свои категории. Без своих — тот же массив. */
  function categoriesOf(data, baseCategories) {
    const base = Array.isArray(baseCategories) && baseCategories.length ? baseCategories : DEFAULT_PUBLIC;
    const custom = customCategories(data, base).filter((def) => !base.some((cat) => cat && cat.key === def.key));
    return custom.length ? base.concat(custom) : base;
  }

  /* Проверка одной записи праздника. Возвращает список проблем (пусто — запись верна). */
  function holidayProblems(h, knownKeys, takenKeys) {
    const out = [];
    if (!isObject(h)) return ['Запись праздника должна быть объектом'];
    const name = typeof h.title === 'string' && h.title.trim() ? `«${h.title.trim()}»` : String(h.key || '?');
    if (typeof h.key !== 'string' || !HOLIDAY_KEY.test(h.key) || h.key.length > 40) out.push(`Праздник ${name}: ключ должен начинаться с h- и содержать латиницу, цифры и дефисы`);
    else if (takenKeys && takenKeys.has(h.key)) out.push(`Праздник ${name}: ключ ${h.key} уже занят`);
    if (typeof h.title !== 'string' || !h.title.trim() || h.title.length > 60) out.push(`Праздник ${name}: нужно название до 60 символов`);
    const startOk = isValidDate(h.start), endOk = isValidDate(h.end);
    if (!startOk) out.push(`Праздник ${name}: дата начала должна быть в виде ГГГГ-ММ-ДД`);
    if (!endOk) out.push(`Праздник ${name}: дата окончания должна быть в виде ГГГГ-ММ-ДД`);
    if (startOk && endOk) {
      const span = dayNumber(h.end) - dayNumber(h.start);
      if (span < 0) out.push(`Праздник ${name}: окончание раньше начала`);
      else if (span >= HOLIDAY_SPAN_MAX_DAYS) out.push(`Праздник ${name}: показ дольше ${HOLIDAY_SPAN_MAX_DAYS} дней`);
    }
    if (!Array.isArray(h.include) || !h.include.length) out.push(`Праздник ${name}: выберите хотя бы одну категорию`);
    else {
      const known = new Set(knownKeys);
      for (const key of h.include) {
        if (typeof key !== 'string') { out.push(`Праздник ${name}: неверная категория`); continue; }
        // Праздник собирается только из обычных поводов: вложенные праздники и ссылка на себя дали бы цикл.
        if (key === h.key || HOLIDAY_KEY.test(key)) out.push(`Праздник ${name}: нельзя включать праздник в праздник (${key})`);
        else if (!known.has(key)) out.push(`Праздник ${name}: категории ${key} нет на сайте`);
      }
      if (unique(h.include).length !== h.include.length) out.push(`Праздник ${name}: категория указана дважды`);
    }
    if (h.pinned !== undefined && typeof h.pinned !== 'boolean') out.push(`Праздник ${name}: «закрепить» должно быть да или нет`);
    return out;
  }
  function holidaysProblems(list, knownKeys) {
    if (list === undefined) return [];
    if (!Array.isArray(list)) return ['Праздники должны быть списком'];
    const out = [];
    if (list.length > HOLIDAYS_MAX) out.push(`Праздников больше ${HOLIDAYS_MAX}`);
    const taken = new Set();
    for (const h of list) {
      out.push(...holidayProblems(h, knownKeys, taken));
      if (isObject(h) && typeof h.key === 'string') taken.add(h.key);
    }
    return out;
  }
  function homeProblems(home, knownKeys) {
    if (home === undefined) return [];
    if (!Array.isArray(home)) return ['Основные категории должны быть списком'];
    const out = [];
    const known = new Set(knownKeys);
    if (home.length > HOME_MAX) out.push(`Основных категорий больше ${HOME_MAX}`);
    for (const key of home) if (typeof key !== 'string' || !known.has(key)) out.push(`Основная категория ${String(key)} не найдена на сайте`);
    if (unique(home).length !== home.length) out.push('Основная категория указана дважды');
    return out;
  }

  /* Статус праздника для показа: без подтверждённого пояса — 'no-timezone' (не показывается). */
  function holidayStatus(h, now, timeZone, knownKeys) {
    if (holidayProblems(h, knownKeys || baseKeys()).length) return 'invalid';
    if (!isValidTimeZone(timeZone)) return 'no-timezone';
    const today = localDate(now === undefined || now === null ? Date.now() : now, timeZone);
    if (!today) return 'no-timezone';
    if (today < h.start) return 'upcoming';
    if (today > h.end) return 'ended'; // окончание включительно: весь день end по местному времени ещё показ
    return 'active';
  }
  function activeHolidays(data, options = {}) {
    const known = baseKeys(options.categories);
    const list = catalogOf(data) && Array.isArray(catalogOf(data).holidays) ? catalogOf(data).holidays : [];
    const seen = new Set();
    return list.filter((h) => {
      if (!isObject(h) || seen.has(h.key)) return false;
      seen.add(h.key);
      return holidayStatus(h, options.now, options.timeZone, known) === 'active';
    }).sort((a, b) => (Number(Boolean(b.pinned)) - Number(Boolean(a.pinned))) || (a.start < b.start ? -1 : a.start > b.start ? 1 : 0));
  }

  /* Основные категории: сохранённый порядок (только существующие, без повторов, не больше 6) или шесть Дарьи. */
  function homeKeys(data, categories) {
    const known = new Set(baseKeys(categories));
    const saved = catalogOf(data) && Array.isArray(catalogOf(data).home) ? catalogOf(data).home : null;
    return unique((saved || DEFAULT_HOME).filter((key) => typeof key === 'string' && known.has(key))).slice(0, HOME_MAX);
  }

  /* Поводы товара без праздников. Нет поля publicCategories — прежнее правило по разделу прайса (source);
     явный список — ровно эти поводы; явный [] — ни одного повода (товар остаётся во «Весь каталог»). */
  function basePublicKeys(item, ownerId, categories) {
    const list = Array.isArray(categories) ? categories : DEFAULT_PUBLIC;
    const known = new Set(baseKeys(list));
    if (item && Array.isArray(item.publicCategories)) {
      return unique(item.publicCategories.filter((key) => typeof key === 'string' && known.has(key)));
    }
    return list.filter((pub) => pub && pub.key !== 'all' && !pub.holiday && (pub.source || []).includes(ownerId)).map((pub) => pub.key);
  }
  /* Поводы товара вместе с активными праздниками (праздник = объединение своих категорий, без повторов). */
  function publicKeysOf(item, ownerId, categories) {
    const keys = basePublicKeys(item, ownerId, categories);
    const holidays = (Array.isArray(categories) ? categories : []).filter((pub) => pub && pub.holiday
      && Array.isArray(pub.include) && pub.include.some((key) => keys.includes(key)));
    return unique(keys.concat(holidays.map((pub) => pub.key)));
  }

  /* Список поводов для фильтра каталога: «Весь каталог», закреплённые активные праздники, основные (в выбранном
     порядке), остальные поводы (в прежнем порядке, затем свои категории документа), затем незакреплённые
     активные праздники. */
  function publicCategories(baseCategories, data, options = {}) {
    const base = categoriesOf(data, Array.isArray(baseCategories) && baseCategories.length ? baseCategories : [{ key: 'all', title: 'Весь каталог', source: [] }].concat(DEFAULT_PUBLIC))
      .filter((cat) => cat && typeof cat.key === 'string' && !cat.holiday);
    const all = base.filter((cat) => cat.key === 'all');
    const plain = base.filter((cat) => cat.key !== 'all');
    const home = homeKeys(data, plain);
    const main = home.map((key) => plain.find((cat) => cat.key === key));
    const rest = plain.filter((cat) => !home.includes(cat.key));
    const holidays = activeHolidays(data, { now: options.now, timeZone: options.timeZone, categories: plain })
      .map((h) => ({ key: h.key, title: h.title.trim(), source: [], holiday: true, pinned: h.pinned === true, include: unique(h.include) }));
    return all.concat(holidays.filter((h) => h.pinned), main, rest, holidays.filter((h) => !h.pinned));
  }

  /* Раскладка главной: закреплённые праздники, основные (до 6) и «Показать ещё» (остальные поводы и
     незакреплённые праздники). Ключи — публичные ключи поводов. */
  function homeLayout(data, baseCategories, options = {}) {
    const cats = publicCategories(baseCategories, data, options);
    const plain = cats.filter((cat) => cat.key !== 'all' && !cat.holiday);
    const main = homeKeys(data, plain);
    return {
      pinned: cats.filter((cat) => cat.holiday && cat.pinned).map((cat) => ({ key: cat.key, title: cat.title })),
      main,
      more: plain.filter((cat) => !main.includes(cat.key)).map((cat) => cat.key),
      moreHolidays: cats.filter((cat) => cat.holiday && !cat.pinned).map((cat) => ({ key: cat.key, title: cat.title }))
    };
  }


  /* PALITRA-CATEGORY-PHOTO: optional cover of a public category, independent of product photos.
     Store only an asset path produced by the existing authenticated uploader. No arbitrary URLs. */
  const CATEGORY_PHOTO_PATH = /^\/api\/assets\/[A-Za-z0-9][A-Za-z0-9_.-]{0,200}$/;
  function isCategoryPhoto(value) {
    return typeof value === 'string' && CATEGORY_PHOTO_PATH.test(value) && !value.includes('..');
  }
  function categoryPhotoProblems(value, data, categories) {
    if (value === undefined) return [];
    if (!isObject(value)) return ['Фотографии категорий должны быть объектом'];
    const known = new Set(productOrderScopes(data, categories).filter(s => s.key !== 'all').map(s => s.key));
    const problems = [];
    for (const [key, src] of Object.entries(value)) {
      if (!known.has(key)) problems.push('Фотография: категория не найдена — ' + key);
      if (!isCategoryPhoto(src)) problems.push('Фотография категории ' + key + ': нужен загруженный файл кабинета');
    }
    return problems;
  }
  function categoryPhoto(data, key) {
    const photos = catalogOf(data) && catalogOf(data).categoryPhotos;
    return isObject(photos) && Object.prototype.hasOwnProperty.call(photos, key) && isCategoryPhoto(photos[key]) ? photos[key] : '';
  }

  /* PALITRA-PRODUCT-ORDER: a view owns an ID sequence, never product rows.
     Missing IDs retain their source order. A category/holiday becoming inactive does not erase its order. */
  function productOrderScopes(data, categories) {
    const base = categoriesOf(data, categories).filter(c => c && c.key !== 'all' && !c.holiday);
    const holidays = catalogOf(data) && Array.isArray(catalogOf(data).holidays) ? catalogOf(data).holidays : [];
    const seen = new Set(['all']);
    return [{ key: 'all', title: 'Весь каталог' }].concat(base, holidays.filter(h => h && typeof h.key === 'string' && HOLIDAY_KEY.test(h.key))
      .map(h => ({ key: h.key, title: h.title, holiday: true, include: h.include })))
      .filter((scope, i) => i === 0 || (!seen.has(scope.key) && seen.add(scope.key)));
  }
  function productOrderItemIds(data, key, categories) {
    const scopes = productOrderScopes(data, categories), scope = scopes.find(s => s.key === key);
    if (!scope) return [];
    const base = categoriesOf(data, categories), ids = [];
    for (const cat of (data && Array.isArray(data.categories) ? data.categories : [])) {
      if (!cat || !Array.isArray(cat.items)) continue;
      for (const item of cat.items) {
        if (!item || typeof item.id !== 'string') continue;
        const keys = basePublicKeys(item, cat.id, base);
        if (key === 'all' || (scope.holiday ? (Array.isArray(scope.include) && scope.include.some(k => keys.includes(k))) : keys.includes(key))) ids.push(item.id);
      }
    }
    return unique(ids);
  }
  function productOrderProblems(value, data, categories) {
    if (value === undefined) return [];
    if (!isObject(value)) return ['publicCatalog.productOrder должен быть объектом списков id'];
    const known = new Set(productOrderScopes(data, categories).map(s => s.key));
    const ids = new Set((data && Array.isArray(data.categories) ? data.categories : []).flatMap(c => c && Array.isArray(c.items) ? c.items.filter(i => i && typeof i.id === 'string').map(i => i.id) : []));
    const problems = [];
    for (const key of Object.keys(value)) {
      if (!known.has(key)) problems.push(`Порядок товаров: категории или подборки ${key} нет`);
      const list = value[key];
      if (!Array.isArray(list)) { problems.push(`Порядок ${key}: нужен список id товаров`); continue; }
      if (list.length > ids.size) problems.push(`Порядок ${key}: слишком много позиций`);
      if (list.some(id => typeof id !== 'string' || !ids.has(id))) problems.push(`Порядок ${key}: неизвестный id товара`);
      if (new Set(list).size !== list.length) problems.push(`Порядок ${key}: id товара повторяется`);
    }
    return problems;
  }
  function orderProducts(data, list, key) {
    const input = Array.isArray(list) ? list.slice() : [];
    const orders = catalogOf(data) && catalogOf(data).productOrder;
    const ids = isObject(orders) && Object.prototype.hasOwnProperty.call(orders, key) && Array.isArray(orders[key]) ? orders[key] : [];
    const ranks = new Map(); ids.forEach((id, i) => { if (typeof id === 'string' && !ranks.has(id)) ranks.set(id, i); });
    if (!ranks.size) return input;
    return input.map((item, index) => ({ item, index, rank: ranks.has(item.id) ? ranks.get(item.id) : Infinity }))
      .sort((a, b) => a.rank - b.rank || a.index - b.index).map(entry => entry.item);
  }

  return {
    categoryPhoto, categoryPhotoProblems, isCategoryPhoto,
    productOrderScopes, productOrderItemIds, productOrderProblems, orderProducts,
    DEFAULT_PUBLIC, DEFAULT_HOME, HOME_MAX, HOLIDAYS_MAX, HOLIDAY_KEY, PUBLIC_KEY,
    CUSTOM_PREFIX, CUSTOM_KEY, CUSTOM_MAX, CUSTOM_TITLE_MAX, CUSTOM_SOURCE_MAX, RESERVED_KEYS,
    isValidDate, isValidTimeZone, localDate, catalogOf, baseKeys,
    isCustomKey, coreCategories, customKeyFor, customCategoriesProblems, customCategories, categoriesOf,
    holidayProblems, holidaysProblems, homeProblems, holidayStatus, activeHolidays,
    homeKeys, basePublicKeys, publicKeysOf, publicCategories, homeLayout
  };
});
