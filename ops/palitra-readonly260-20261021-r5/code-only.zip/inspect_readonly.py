"""New read-only inspector. No installation, cleanup, old entry or Native init.

Fail-closed: literal history and all 43 static pins must close from sealed
receipts before any runtime success can be emitted. Not runtime admission.
"""
import argparse,collections,contextlib,copy,functools,hashlib,json,os,re,sqlite3,stat,subprocess,sys,tempfile,time,types
from datetime import datetime,timezone
from pathlib import Path,PurePosixPath
import capture_managed260 as M
import collect_runtime as C
import evidence_validator as E
import literal_history as H
import static_closure as S
import storage_seals as T
import entry_r1_history as F

ROOT=Path('/opt/synapse/releases/palitra-app-20261015');DATA=Path('/var/lib/docker/volumes/synapse_content_data/_data')
NAME='palitra-clear-orders-guard-20261020-r1';GUARD_CODE=ROOT/(NAME+'-code')
MANIFEST_SHA='86abb1a09c3244fe58cd7dceca40faf379c7d058a22c71e78fb543056d7c5282'
ENTRY_SHA='283e6211887e7b50d4aa134a97d86de04d160f818fff0284a722de692aa20e9c'
BUNDLE_SHA='81b2a1bcf492c1ccebdb6910b5e5b5e8e1ab3ec63bca57b4b121666168a45ef3'
CAPTURE_SHA='3854d183bb729245ceb5120d3b2a2d853dc6ec4f1d9481741cf93af91c65b6fb'
FAST_PROBE_SHA='2e4f023ad698316decafe4d93f8c6c51c297b97cbd9044d5ffed609069bd723b'
PROBE_SHA='146732c590b3eb2fe45071c506fcef3798400868d5d2a4adaedad600f7a1d855'
MANAGED_PATH=ROOT/'palitra-clear-managed260-r1-managed-proof.json'
FEATURES_SHA='dcc2c3c91029021117321066698cb555896b8cb13cc132e947142dece9e36bae'
DARYA_NAME='palitra-darya-workspace-20261020-r2'
DARYA_SHA='18ba2aff5b3b62a27de5c0c6bc9be8c0532a30e8a057b4e43b830e45324d510c'
PUSH_SHA='00abb8d802d59b86013e8ca893c08ae41799ef887c4c330b501538c4f5176870'
FROZEN_NATIVE_MANIFEST_SHA='dd82ce11f239823d005a0e05132f92b640776984f01013094d07e07e62c6d812'
INCREMENTAL_MANIFEST_SHA='8894c2f449b18698848e5e3f60d973ba64e307316a2b3adc630336601c95c853'
HISTORICAL_NATIVE_TRUE='c23c78fd5d86f30a3bd538de3298a0e844e775a63ffad6403581a3f14f7997ea'
RELEASED_LEASE_PIDS=frozenset((3401855,3462715))
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def need(v,c):
    if not v:raise ValueError(c)
def read(path,limit=16*1024*1024):
    p=Path(path)
    for part in [p,*p.parents]:need(not part.is_symlink(),'READONLY_PATH_ALIAS_REFUSED')
    s=p.lstat();need(stat.S_ISREG(s.st_mode) and s.st_nlink==1 and s.st_uid==s.st_gid==0 and s.st_size<=limit,'ROOT_BOUNDED_REGULAR_INPUT_REQUIRED')
    fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
    try:
        with os.fdopen(fd,'rb',closefd=False) as f:raw=f.read(limit+1)
        z=os.fstat(fd);t=p.lstat();fields=lambda x:(x.st_dev,x.st_ino,x.st_size,x.st_mtime_ns,x.st_ctime_ns)
        need(len(raw)==s.st_size and fields(s)==fields(z)==fields(t),'INPUT_CHANGED_DURING_READ');return raw
    finally:os.close(fd)
def pinned(path,pin):
    path=Path(path);raw=read(path);need(sha(raw)==pin,'EXACT_READONLY_INPUT_PIN_REQUIRED')
    if any(path.name.endswith(suffix+'.json') for suffix in ('-journal','-decision','-root-acceptance','-preflight','-keys','-managed-proof','-root-post-up-audit')):need(stat.S_IMODE(path.lstat().st_mode)==0o600,'PRIVATE_HISTORICAL_ARTIFACT_MODE_REQUIRED')
    return raw
def namespace():return {'__builtins__':__builtins__,'collections':collections,'closing':contextlib.closing,'copy':copy,'functools':functools,'hashlib':hashlib,'json':json,'os':os,'Path':Path,'PurePosixPath':PurePosixPath,'re':re,'sqlite3':sqlite3,'stat':stat,'tempfile':tempfile,'time':time,'types':types,'datetime':datetime,'timezone':timezone,'Refused':ValueError,'MAX_ROWS':50000,'MAX_FILE_BYTES':128*1024*1024}
class Factory:
    def __init__(self,pid,code_pins,mode='full'):
        need(mode in ('full','runtime-cas'),'EXACT_READONLY_MODE_REQUIRED');self.mode=mode
        need(type(pid) is int and pid>1 and pid not in RELEASED_LEASE_PIDS,'NEW_LEASE_REQUIRED_RELEASED_PID_REFUSED')
        self.pid=pid;self.ticks=M.lease(pid);self.code=Path(__file__).resolve().parent
        need(type(code_pins) is dict and code_pins,'VERIFIED_ENTRY_CODE_PINS_REQUIRED');self.code_pins=code_pins
        self.bundle=json.loads(pinned(self.code/'read_primitives.json',BUNDLE_SHA));self.ns={}
        need(self.bundle['nativeConstructorCompiled'] is False and self.bundle['oldEntryImported'] is False and self.bundle['oldStableCompiled'] is False,'ISOLATED_READ_PRIMITIVES_REQUIRED')
        for name,source in self.bundle['sources'].items():
            if name in ('content_functions','content_class'):continue
            env=namespace();exec(compile(source,'<pinned-isolated-'+name+'>','exec'),env);self.ns[name]=env
        for method in ('__init__','stable','build','up','apply','backup'):need(method not in self.ns['native']['Native'].__dict__,'NATIVE_WRITER_COMPILED')
        self.allowed_scripts={sha(v.encode()) for env in self.ns.values() for k,v in env.items() if k in ('TREE_JS','GRAPH_PROBE','ENV','FLAGS_JS','FLAG_JS','DB_JS','KEY_JS','HEALTH_JS') and type(v) is str}
        self.allowed_scripts.add(sha("process.stdout.write(process.env.DATABASE_PATH||'/data/content.sqlite')".encode()))
        raws={key:pinned(ROOT/(NAME+'-'+suffix+'.json'),E.SHA[key]) for key,suffix in [('guardReceipt','journal'),('guardDecision','decision'),('guardAcceptance','root-acceptance'),('guardPreflight','preflight')]}
        self.receipt=E.history(raws);self.history=H.collect(str(GUARD_CODE/'manifest.json'),MANIFEST_SHA,lambda p:read(p))
        self.history['pins'].update({str(GUARD_CODE/'company-app.py'):ENTRY_SHA,**{str(ROOT/(NAME+'-'+suffix+'.json')):E.SHA[key] for key,suffix in [('guardReceipt','journal'),('guardDecision','decision'),('guardAcceptance','root-acceptance'),('guardPreflight','preflight')]}})
        self.history['artifacts'].update({str(ROOT/(NAME+'-'+suffix+'.json')):json.loads(raws[key]) for key,suffix in [('guardReceipt','journal'),('guardDecision','decision'),('guardAcceptance','root-acceptance'),('guardPreflight','preflight')]})
        darya_path=ROOT/(DARYA_NAME+'-journal.json');darya_raw=pinned(darya_path,DARYA_SHA);self.history['pins'][str(darya_path)]=DARYA_SHA;self.history['artifacts'][str(darya_path)]=json.loads(darya_raw)
        managed_raw=pinned(MANAGED_PATH,C.MANAGED_SHA);self.managed=json.loads(managed_raw)
        need(self.managed['leasePid']==3462715 and self.managed['leaseStartTicks']=='461164687' and self.managed['current260']['version']==260,'EXACT_HISTORICAL_MANAGED260_CONTENT_SEAL_REQUIRED')
        self.stable_managed_sha=sha(self.ns['native']['encoded'](managed_facts(self.managed)));self.fresh_managed_sha=None;self.push_binding_sha=None
        host=lambda root:str(DATA)+root[len('/data'):] if root.startswith('/data/') else None
        historical=self.managed['historical257'];hist_root=host(historical['root']);need(hist_root is not None,'EXACT_HISTORICAL257_HOST_ROOT_REQUIRED')
        managed_static={hist_root+'/'+name:historical['selected'][name]['sha256'] for name in ('assets/order.js','assets/storefront.js')}
        chain=self.receipt['after']['containers']['content']['files'];baseline_overlay=str(ROOT/(DARYA_NAME+'-overlay.json'))
        need(chain.count(baseline_overlay)==1 and chain.index(baseline_overlay)==41,'EXACT_SEALED_DARYA_CHAIN42_REQUIRED')
        stages,self.storage_stages=F.collect_stages(ROOT,chain[42:],self.history,pinned)
        stages[0]['acceptedSupplement']=F.load(ROOT,pinned,self.history,stages[0],stages[1],json.loads(darya_raw),self.ns['canonical']['canonical_host_config'])
        self.static=S.extend_sealed_workspace(set(self.receipt['after']['staticModes']),darya_raw,DARYA_SHA,stages,managed_static)
        self.history_guard()
        if self.mode=='full':self.managed_guard()
        self.make_handles()
        if self.mode=='full':self.storage_guard()
    def lease(self):need(M.lease(self.pid)==self.ticks,'LEASE_PROCESS_CHANGED')
    def history_guard(self):
        self.lease()
        for path,pin in self.history['pins'].items():pinned(path,pin)
        for name,pin in self.code_pins.items():pinned(self.code/name,pin)
        pinned(MANAGED_PATH,C.MANAGED_SHA);pinned(self.code/'read_primitives.json',BUNDLE_SHA)
    def managed_guard(self):
        self.lease();pinned(self.code/'capture_managed260.py',CAPTURE_SHA);pinned(self.code/'managed260-probe.cjs',PROBE_SHA)
        r=subprocess.run([sys.executable,str(self.code/'capture_managed260.py'),'--lease-pid',str(self.pid)],capture_output=True,timeout=75)
        need(r.returncode==0 and not r.stderr and len(r.stdout)<=512*1024,'MANAGED260_CHANGED_OR_CAPTURE_REFUSED')
        fresh=json.loads(r.stdout)
        need(fresh.get('leasePid')==self.pid and fresh.get('leaseStartTicks')==self.ticks and managed_facts(fresh)==managed_facts(self.managed),'FRESH_MANAGED260_CONTENT_OR_LEASE_CHANGED')
        pin=sha(self.ns['native']['encoded'](fresh));need(self.fresh_managed_sha is None or pin==self.fresh_managed_sha,'MANAGED260_CHANGED_DURING_INSPECTION');self.fresh_managed_sha=pin;self.lease()
    def managed_cas_guard(self):
        self.lease();pinned(self.code/'capture_managed260.py',CAPTURE_SHA)
        base=pinned(self.code/'managed260-probe.cjs',PROBE_SHA)
        fast=pinned(self.code/'fast-managed260.cjs',FAST_PROBE_SHA)
        proof_raw=pinned(MANAGED_PATH,C.MANAGED_SHA)
        invocation=base.decode()+'\n'+fast.decode()+"\nconst input=fs.readFileSync(0);if(input.length>524288)throw Error('INPUT_BOUND');const result=JSON.stringify(module.exports.captureFast(JSON.parse(input)));if(Buffer.byteLength(result)>524288)throw Error('OUTPUT_BOUND');process.stdout.write(result);"
        # Full 3x140 proof may exceed Linux MAX_ARG_STRLEN; use bounded stdin.
        proof_input=json.dumps(self.managed,ensure_ascii=False,separators=(',',':')).encode();need(len(proof_input)<=512*1024,'BOUNDED_MANAGED_CAS_INPUT_REQUIRED')
        r=subprocess.run(['docker','exec','-i','synapse-content-1','node','--disable-warning=ExperimentalWarning','-e',invocation],capture_output=True,timeout=75,input=proof_input)
        need(r.returncode==0 and not r.stderr and len(r.stdout)<=512*1024,'MANAGED260_RUNTIME_CAS_REFUSED')
        result=json.loads(r.stdout)
        need(set(result)=={'schema','status','workspaceSha256','versions','managedVersion','existingWal','databaseOpenCount','revisionOrDocumentScans','runtimeWrites'} and result['schema']=='palitra-managed260-runtime-cas/v1' and result['status']=='MANAGED260_FILES_AND_POINTER_CAS_NOT_FULL_INSPECTION' and result['managedVersion']==260 and result['existingWal'] is True and result['databaseOpenCount']==1 and result['revisionOrDocumentScans']==result['runtimeWrites']==0,'EXACT_MANAGED_RUNTIME_CAS_DTO_REQUIRED')
        encoded=self.ns['native']['encoded']
        need(result['workspaceSha256']==sha(encoded(self.managed['workspace'])),'ACTUAL_MANAGED_POINTER_SEAL_CHANGED')
        expected=[{'version':self.managed[key]['version'],'factsSha256':self.managed[key]['factsSha256'],'directoriesSha256':self.managed[key]['directoriesSha256']} for key in ('historical257','historical259','current260')]
        need(result['versions']==expected,'ACTUAL_MANAGED_CLOSED140_SEALS_CHANGED')
        need(pinned(self.code/'managed260-probe.cjs',PROBE_SHA)==base and pinned(self.code/'fast-managed260.cjs',FAST_PROBE_SHA)==fast and pinned(MANAGED_PATH,C.MANAGED_SHA)==proof_raw,'MANAGED_RUNTIME_CAS_INPUT_CHANGED')
        self.lease();return result
    def run(self,args):
        need(type(args) is list and all(type(x) is str for x in args),'EXACT_READ_ARGUMENTS_REQUIRED')
        allowed=False;containers=('synapse-content-1','synapse-chat-1')
        if args[:2]==['docker','inspect']:
            formats={self.ns['backend']['LABELS'],self.ns['backend']['WORKER_INSPECT'],'{{json .Mounts}}','{{.Id}}'}
            allowed=len(args)==3 and args[-1] in containers or len(args)==5 and args[2]=='--format' and args[3] in formats and args[-1] in containers
        if args[:3]==['docker','image','inspect']:
            images={self.receipt['before']['containers']['content']['image'],E.IMAGE}
            allowed=len(args)==4 and args[-1] in images or len(args)==6 and args[3:5]==['--platform','linux/amd64'] and args[-1] in images
        if args[:2]==['docker','compose']:
            metadata=self.receipt['after']['containers'];commands=[['docker','compose']+[v for path in metadata['content']['files'] for v in ('-f',path)]+['config','--format','json']]
            for service,row in metadata.items():commands.append(['docker','compose','--project-name',row['project'],'--project-directory',row['workingDir']]+[v for path in row['files'] for v in ('--file',path)]+['config','--hash',service])
            need(args in commands,'ONLY_EXACT_READONLY_COMPOSE_CONFIG_ALLOWED');allowed=True
        if args[:2]==['docker','exec']:
            scripts=sha(args[-1].encode()) if args else '';plain=len(args)==6 and args[2] in containers and args[3] in ('node','/usr/local/bin/node') and args[4]=='-e'
            clear=sum((['--env',k+'='] for k in self.ns['backend']['CLEAR']),[])+['--env','NODE_DISABLE_COMPILE_CACHE=1']
            graph_prefix=['docker','exec']+clear+['synapse-chat-1','/usr/local/bin/node','-e']
            graph=args[:-1]==graph_prefix
            need((plain or graph) and scripts in self.allowed_scripts,'EXACT_PINNED_READONLY_NODE_PROBE_REQUIRED');allowed=True
        need(allowed,'NON_READONLY_NATIVE_COMMAND_REFUSED')
        cwd=self.receipt['after']['containers']['content']['workingDir'] if args[:2]==['docker','compose'] else None
        r=subprocess.run(args,check=True,capture_output=True,timeout=60,cwd=cwd,stdin=subprocess.DEVNULL)
        need(len(r.stdout)<=32*1024*1024 and not r.stderr,'BOUNDED_READONLY_NATIVE_RESULT_REQUIRED');return r.stdout
    def make_handles(self):
        ns=self.ns;self.a=object.__new__(ns['selected']['Activate']);self.a.run=self.run
        self.b=object.__new__(ns['backend']['NativeBackend']);self.b.run=self.run;self.b.db_path=DATA/'content.sqlite';self.b.g=types.SimpleNamespace(**ns['graph'])
        self.n=object.__new__(ns['native']['Native']);self.n.run=self.run;self.n.a=types.SimpleNamespace(decode=ns['backend']['decode'],read=read,exact_path=ns['backend']['exact_path'],LABELS=ns['backend']['LABELS']);self.n.b=self.b;self.n.base=copy.deepcopy(self.receipt['before']);self.n._parent_image_cache=None
        parent=self.receipt['before']['containers']['content']['image'];need(parent==ns['native']['PARENT'],'EXACT_GUARD_PARENT_IMAGE_REQUIRED')
        parents=[r for r in self.history['artifacts'].values() if isinstance(r,dict) and r.get('childImage')==parent and isinstance(r.get('childProof',{}).get('platformImageBinding'),dict)]
        need(len(parents)==1,'EXACT_SEALED_PARENT_PLATFORM_BINDING_REQUIRED');self.n.parent_platform_manifest=parents[0]['childProof']['platformImageBinding']['manifestDigest']
        self.n._canonical_host_config=ns['canonical']['canonical_host_config']
        self.p=object.__new__(ns['push']['PushEnable']);self.p.run=self.run;self.p.c=types.SimpleNamespace(path=ns['selected']['path'],obj=ns['selected']['obj'])
        self.p.root=ROOT;self.p.key_directory=ns['push']['KEY_DIRECTORY'];self.p.public_roots=[Path('/opt/synapse/sites')]
        self.p.r=types.SimpleNamespace(cabinet=Path('/opt/synapse/sites/synapse/cabinet/palitra-orders'),frozen=self.frozen_public_metadata)
        if self.mode=='full':self.make_databases()
    def frozen_public_metadata(self):
        # Exactly the immutable manifest that the old Release.frozen() reads.
        # No fabricated roots or old constructor is supplied to Push.binding.
        path=ROOT/'bundle-root-final/manifest.json';raw=pinned(path,FROZEN_NATIVE_MANIFEST_SHA);document=json.loads(raw)
        incremental=json.loads(pinned(self.code/'incremental-manifest.json',INCREMENTAL_MANIFEST_SHA))
        expected={row['target']:row['sha256'] for row in document['content']};expected['palitra-orders-public/native-host.js']=HISTORICAL_NATIVE_TRUE
        need(expected==incremental['source39'],'SOURCE39_NOT_EXACT_FROZEN_LINEAGE')
        need(type(document.get('roots')) is dict and type(document['roots'].get('customer')) is str,'EXACT_FROZEN_CUSTOMER_ROOT_METADATA_REQUIRED')
        self.history['pins'][str(path)]=FROZEN_NATIVE_MANIFEST_SHA;return document
    def push_guard(self):
        ns=self.ns['push'];journal_raw=pinned(ROOT/'push-r1-journal.json',PUSH_SHA);j=json.loads(journal_raw);keys_raw=pinned(ROOT/'push-r1-keys.json',j['keyReceiptSha256']);keys=json.loads(keys_raw)
        need(j['phase']=='PUSH_SERVER_CONFIG_APPLIED_NOT_DEVICE_PROOF' and keys['phase']=='PUSH_KEYS_CREATED_NOT_ENABLED' and keys['directory']==str(ns['KEY_DIRECTORY']),'EXACT_SEALED_PUSH_KEYS_REQUIRED')
        expected=sorted(j['before']['mounts']+[{'Type':'bind','Source':keys['directory'],'Destination':ns['TARGET'],'RW':False}],key=lambda row:row['Destination'])
        mounts=self.p.mounts()
        need(mounts==expected and self.p.private_meta(Path(keys['directory']))==keys['keyMetadata'] and self.p.flag() is True,'PUSH_MOUNT_METADATA_FLAG_CHANGED')
        binding=self.p.binding(mounts);need(binding==j['before']['binding'],'EXACT_SEALED_PUSH_DATABASE_BINDING_CHANGED')
        binding_sha=sha(self.ns['native']['encoded'](binding));need(self.push_binding_sha is None or binding_sha==self.push_binding_sha,'PUSH_DATABASE_BINDING_CHANGED_DURING_INSPECTION');self.push_binding_sha=binding_sha
        decode=self.ns['backend']['decode'];probe=decode(self.run(['docker','exec','synapse-content-1','node','-e',ns['KEY_JS']]))
        need(probe=={'keyValid':True,'publicKeySha256':keys['publicKeySha256'],'webPushVersion':'3.6.7','transportReady':True},'PUSH_LIBRARY_OR_PUBLIC_IDENTITY_CHANGED')
        if self.mode=='full':need(decode(self.run(['docker','exec','synapse-content-1','node','-e',ns['HEALTH_JS']]))=={'status':200,'ok':True,'service':'content'},'CONTENT_HEALTH_FAILED')
        need(pinned(ROOT/'push-r1-journal.json',PUSH_SHA)==journal_raw and pinned(ROOT/'push-r1-keys.json',j['keyReceiptSha256'])==keys_raw,'PUSH_HISTORY_CHANGED_DURING_READ')
    def make_databases(self):
        temp_root=ROOT/'palitra-clear-managed260-r1-readonly-temp';s=temp_root.lstat();need(stat.S_ISDIR(s.st_mode) and not temp_root.is_symlink() and s.st_uid==s.st_gid==0 and stat.S_IMODE(s.st_mode)==0o700,'PRECREATED_PRIVATE_READONLY_TEMP_ROOT_REQUIRED')
        class Files:
            @staticmethod
            def mode(p):return stat.S_IMODE(Path(p).stat().st_mode)
            @staticmethod
            def write(p,raw,mode):
                p=Path(p);need(p.parent.parent==temp_root and p.parent.name.startswith('r11-traffic-read-') and p.name in ('snapshot.sqlite','snapshot.sqlite-wal') and mode==0o600,'ONLY_PRIVATE_EPHEMERAL_TRAFFIC_CLONE_ALLOWED')
                fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,mode)
                with os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
        exact=self.ns['backend']['exact_path'];files=Files()
        rns=namespace();exec(compile(self.bundle['sources']['report'],'<isolated-content-report-base>','exec'),rns)
        cns=namespace();exec(compile(self.bundle['sources']['content_functions'],'<isolated-content-functions>','exec'),cns)
        rns['connection_seal']=cns['connection_seal'];rns['preserves']=cns['preserves'];cns['_common']=types.SimpleNamespace(ReportDatabase=rns['ReportDatabase']);exec(compile(self.bundle['sources']['content_class'],'<isolated-content-class>','exec'),cns)
        self.databases={'report':self.ns['report']['ReportDatabase'](DATA/'salon-reports.sqlite',exact,files,self.n.data_mount),'content':cns['ContentDatabase'](DATA/'content.sqlite',exact,files,self.n.content_data_mount),'traffic':self.ns['traffic']['TrafficDatabase'](DATA/'app-entry-stats.sqlite',exact,files,self.n.content_data_mount,temp_root)}
    def database_guard(self,minimum):
        out={}
        for key,db in self.databases.items():
            out[key]=db.guard(minimum[key]);db.backup_guard(self.receipt['backups'][key])
        need(all(row['revision']>=3 for row in out['report']['content']['cache'].values()),'BOTH_REPORT_REVISIONS3_REQUIRED');return out
    def image_guard(self):
        parent=self.n._parent_image();child=self.n._image(E.IMAGE);a=parent['RootFS']['Layers'];b=child['RootFS']['Layers']
        need(type(a) is list and type(b) is list and b[:len(a)]==a and len(b)==len(a)+1 and child['Config']==parent['Config'],'EXACT_SEALED_ONE_COPY_IMAGE_REQUIRED')
        records=self.storage_stages[-1][1];encoded=self.ns['native']['encoded']
        proof={'image':E.IMAGE,'parentImage':self.receipt['before']['containers']['content']['image'],'oneCopyLayer':True,'imageConfigSha256':sha(encoded(child['Config'])),'appTreeSha256':sha(encoded(self.receipt['after']['runtime']['appTree'])),'sourceFiles':240,'changedTargets':sorted(r['target'] for r in records),'platformImageBinding':self.n._platform_image(E.IMAGE,child)}
        need(proof==self.receipt['childProof'],'EXACT_HISTORICAL_CHILD_PLATFORM_PROOF_CHANGED')
    def storage_guard(self):
        self.lease()
        for journal,records,stage in self.storage_stages:T.modern_guard(ROOT,journal,records,read,self.databases,stage['receiptSha256'],stage['manifestSha256'],sha(stage['recordsBytes']))
        # Completed workspace contexts/backups carry their own exact binding.
        for path,journal in self.history['artifacts'].items():
            if not path.endswith('-journal.json') or not isinstance(journal,dict) or journal.get('phase')!='APPLIED_NOT_CUSTOMER_ACCEPTANCE' or 'contextSha256' not in journal:continue
            need('sourceBackups' in journal and 'trafficDatabaseBackup' in journal,'UNSUPPORTED_HISTORICAL_CONTEXT_FORMAT')
            name=journal['name'];code=ROOT/(name+'-code');pin=journal['inputs']['manifest'];raw=pinned(code/'payload/MANIFEST.json',pin);records=json.loads(raw)['records']
            self.history['pins'][str(code/'payload/MANIFEST.json')]=pin
            T.legacy_workspace_guard(ROOT,journal,records,read,self.databases)
    def context(self):
        after=self.receipt['after'];source={name:after['runtime']['appTree'][name]['sha256'] for name in after['sourceModes']}
        return {'native':self.n,'backend':self.b,'account':self.a,'receipt':self.receipt,'sourcePins':source,'staticPins':self.static['sha256'],'staticModes':after['staticModes'],'managed_guard':self.managed_guard,'history_guard':self.history_guard,'storage_guard':self.storage_guard,'image_guard':self.image_guard,'push_guard':self.push_guard,'database_guard':self.database_guard,'lease':self.lease,'decode':self.ns['backend']['decode'],'flagsScript':self.ns['backend']['FLAGS_JS'],'read':read,'canonical_host_config':self.n._canonical_host_config}
def main(pid,code_pins,mode='full'):
    need(os.name=='posix' and os.geteuid()==0,'ROOT_LINUX_READONLY_ONLY');factory=Factory(pid,code_pins,mode)
    result=C.capture(factory.context()) if mode=='full' else C.runtime_cas(factory.context(),factory.managed_cas_guard)
    need(factory.push_binding_sha is not None and (mode!='full' or factory.fresh_managed_sha is not None),'ALL_FRESH_READONLY_GUARDS_REQUIRED')
    result.update(schema='palitra-readonly-managed260-inspection/v2' if mode=='full' else 'palitra-readonly-managed260-runtime-cas/v2',mode=mode,status='EXACT_INSTALLED_GUARD_WITH_MANAGED260_READONLY_R2' if mode=='full' else 'EXACT_INSTALLED_GUARD_WITH_MANAGED260_RUNTIME_CAS_R2',image=E.IMAGE,guardReceiptSha256=E.SHA['guardReceipt'],stableManagedFactsSha256=factory.stable_managed_sha,pushBindingSha256=factory.push_binding_sha,lease={'pid':factory.pid,'startTicks':factory.ticks,'lock':M.LOCK},capturedAtUtc=datetime.now(timezone.utc).isoformat(),runtimeSnapshotSha256=sha(factory.ns['native']['encoded'](factory.receipt['after'])),workerFactsSha256=sha(factory.ns['native']['encoded'](factory.receipt['after']['worker'])))
    if mode=='full':result.update(freshManagedCaptureSha256=factory.fresh_managed_sha,fullInspection=True)
    else:result['managedCasSha256']=sha(factory.ns['native']['encoded'](result['managedPointerCas']))
    return result

def managed_facts(value):
    need(type(value) is dict and 'leasePid' in value and 'leaseStartTicks' in value,'MANAGED_CAPTURE_LEASE_FIELDS_REQUIRED')
    return {key:item for key,item in value.items() if key not in ('leasePid','leaseStartTicks')}
if __name__=='__main__':
    print(json.dumps({'status':'VERIFIED_READONLY_ENTRY_REQUIRED','runtimeWrites':0,'runtimeAdmission':False}),file=sys.stderr);sys.exit(2)
