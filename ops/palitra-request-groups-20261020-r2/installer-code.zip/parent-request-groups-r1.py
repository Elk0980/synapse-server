"""Read-only historical seam for the completed, inspected merged quickfix R4.

Accepts only the exact completed journal. Never adopts UNKNOWN, replays an
admission, snapshots the old running parent, applies, approves or restores data.
Pins were generated from ROOT_OUTCOME_REQUEST_GROUPS_R1.json and the frozen merged R4 bytes.
"""
import copy, hashlib, json, re, types
from pathlib import Path, PurePosixPath
ROOT = Path('/opt/synapse/releases/palitra-app-20261015')
PARENT_NAME = 'palitra-request-groups-20261020-r1'
PARENT_IMAGE = 'sha256:d51b57bd1e4d63d72f323dcbabbcc689667303c65149c8a2415c1bef38191ddc'
PARENT_LEASE_PID = 3336085
NATIVE_SHA = 'bf3354c6c7d88dbf354f90d9c445535b430c955a886942df8b5afd73d313f708'
CONTROLLER_SHA = '5b518c54a8ea6b22ac694232beb8ce6505cd08b80f2a89b35af4bbf5e0e01784'
MANIFEST_SHA = '045467934f93a22d07464dbbd6811fab4fe423fa4f1ff9fd902a0ec3cf8a1add'
ENTRY_SHA = '830369005566318fbeb929de9836252977f04d7c9f616f15606477e6a5dbc890'
PARENT_SEAM_SHA = '5d1fc08571068b82af0e8bf2ad21c91230bca0f4bc2a4ae854e81bc7d12ec8ea'
JOURNAL_SHA = 'eaa66bd0cc0b5416513e3eede31aa9c5f8e7b3d96228dcd4a8a0a1b445b17d84'
DECISION_SHA = '1569eb0c4629b5370e3fbaeff26d98bfe86660a16e87422b8284dc9e3b8836e3'
ACCEPTANCE_SHA = 'dc4ba0bbf23ea833bbc0fb04e8e43cffeb71e76658b63deaf845a33a8490fcb0'
PREFLIGHT_SHA = 'ce3a6018412a2b10561342b440a13a471d3f3775b5ae8ccb6709314564a96f52'
RELEASED = (3161783, 3196874, 3200094, 3202295, 3204327, 3205870, 3207300, 3208973, 3210573, 3213993, 3215428, 3221971, 3222059, 3231260, 3239627, 3242810, 3263438, 3284416, 3308227, 3336085)
PARENT_CODE = ROOT / (PARENT_NAME + '-code')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
encoded = lambda value: json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
digest = lambda value: type(value) is str and re.fullmatch('[a-f0-9]{64}',value) is not None


def need(ok,code):
    if not ok: raise ValueError(code)


def module(raw,path):
    result=types.ModuleType('sealed_merged_r4_'+path.stem);result.__file__=str(path)
    exec(compile(raw,str(path),'exec'),result.__dict__);return result


def canonical_host_config(host):
    """Only the ordering of distinct textual Binds is semantically irrelevant.

    Every binding's source, target, options and every other HostConfig field stay
    in the full canonical serialization. Other arrays are deliberately untouched.
    """
    need(type(host) is dict,'HOST_CONFIG_OBJECT_REQUIRED')
    value=copy.deepcopy(host);binds=value.get('Binds')
    need(type(binds) is list and 1<=len(binds)<=64
         and all(type(row) is str and 0<len(row)<=8192 for row in binds)
         and len(set(binds))==len(binds),'UNIQUE_EXACT_TEXTUAL_BINDINGS_REQUIRED')
    # Docker's bind order is irrelevant only when each mount destination is
    # unique. Docker sources may be absolute paths or exact named volumes.
    parts=[row.split(':') for row in binds]
    need(all(len(row) in (2,3) and (row[0].startswith('/') or re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*',row[0]) is not None)
             and row[1].startswith('/') and row[1]!='/'
             and (len(row)==2 or len(row[2])>0) for row in parts)
         and len({row[1] for row in parts})==len(parts),'UNIQUE_ABSOLUTE_BIND_DESTINATIONS_REQUIRED')
    value['Binds']=sorted(binds)
    return value


def load_current_request_groups_r1(pid):
    need(type(pid) is int and pid>1 and pid not in RELEASED,'FRESH_LABEL_ACTUAL_PID_REQUIRED')
    for path in [PARENT_CODE/'company-app.py',PARENT_CODE,*PARENT_CODE.parents]:
        need(not path.is_symlink(),'PARENT_REQUEST_GROUPS_R1_CODE_ALIAS_REFUSED')
    raw=(PARENT_CODE/'company-app.py').read_bytes()
    need(sha(raw)==ENTRY_SHA,'EXACT_FROZEN_REQUEST_GROUPS_R1_ENTRY_REQUIRED')
    entry=module(raw,PARENT_CODE/'company-app.py')
    need(entry.FROZEN is True and entry.CODE==PARENT_CODE and entry.MANIFEST_SHA==MANIFEST_SHA,
         'EXACT_REQUEST_GROUPS_R1_ENTRY_NAMESPACE_REQUIRED')
    read=entry.read
    pins={PARENT_CODE/'company-app.py':ENTRY_SHA,PARENT_CODE/'native.py':NATIVE_SHA,
          PARENT_CODE/'controller.py':CONTROLLER_SHA,PARENT_CODE/'manifest.json':MANIFEST_SHA,
          PARENT_CODE/'parent-client-chat-offers-r1.py':PARENT_SEAM_SHA,
          ROOT/(PARENT_NAME+'-journal.json'):JOURNAL_SHA,
          ROOT/(PARENT_NAME+'-decision.json'):DECISION_SHA,
          ROOT/(PARENT_NAME+'-root-acceptance.json'):ACCEPTANCE_SHA,
          ROOT/(PARENT_NAME+'-preflight.json'):PREFLIGHT_SHA}
    values={}
    for path,pin in pins.items():
        raw=read(path);need(digest(pin) and sha(raw)==pin,'EXACT_COMPLETED_REQUEST_GROUPS_R1_HISTORY_REQUIRED')
        values[path]=raw
    manifest=json.loads(values[PARENT_CODE/'manifest.json'])
    need(manifest['name']==PARENT_NAME and manifest['FROZEN'] is True
         and manifest['status']=='LOCAL_FROZEN_CODE_ONLY' and manifest['runtimeAuthorization'] is False
         and manifest['sourceFiles']==240 and manifest['sourceBefore']==240 and manifest['sourceAfter']==240 and manifest['staticFiles']==43
         and manifest['chainBefore']==46 and manifest['chainAfter']==47
         and manifest['runtimePayloadFiles']==6 and manifest['staticChanges']==4 and manifest['additions']==0,
         'EXACT_FROZEN_REQUEST_GROUPS_R1_MANIFEST_REQUIRED')
    found=set()
    for row in manifest['files']:
        name=row['path']
        need(type(name) is str and not PurePosixPath(name).is_absolute()
             and PurePosixPath(name).as_posix()==name and '..' not in PurePosixPath(name).parts
             and name not in found,'REQUEST_GROUPS_R1_MANIFEST_PATH_REQUIRED')
        found.add(name);raw=read(PARENT_CODE/name)
        need(sha(raw)==row['sha256'] and len(raw)==row['bytes'],'EXACT_REQUEST_GROUPS_R1_MANIFEST_CLOSURE_REQUIRED')
        pins[PARENT_CODE/name]=row['sha256']
    nmod=module(values[PARENT_CODE/'native.py'],PARENT_CODE/'native.py')
    cmod=module(values[PARENT_CODE/'controller.py'],PARENT_CODE/'controller.py')
    old=nmod.Native(pid);release=cmod.Release(old,MANIFEST_SHA,ENTRY_SHA)
    state=json.loads(values[ROOT/(PARENT_NAME+'-journal.json')])
    decision=json.loads(values[ROOT/(PARENT_NAME+'-decision.json')])
    preflight=json.loads(values[ROOT/(PARENT_NAME+'-preflight.json')])
    acceptance=json.loads(values[ROOT/(PARENT_NAME+'-root-acceptance.json')])
    expected_binding=dict(release.binding(),leasePid=PARENT_LEASE_PID)
    need(state['schema']==1 and state['name']==PARENT_NAME
         and state['phase']=='APPLIED_NOT_CUSTOMER_ACCEPTANCE'
         and state['decisionSha256']==DECISION_SHA and state['childImage']==PARENT_IMAGE,
         'EXACT_COMPLETED_REQUEST_GROUPS_R1_REQUIRED_NO_UNKNOWN_ADOPTION')
    need(state['binding']==decision['binding']==preflight['binding']==expected_binding
         and state['before']==decision['before']==preflight['before']
         and decision['rootAcceptanceSha256']==ACCEPTANCE_SHA
         and decision['preflightSha256']==PREFLIGHT_SHA
         and preflight['runtimeAuthorization'] is False and preflight['runtimeWrites']==0
         and acceptance['preflightSha256']==PREFLIGHT_SHA
         and acceptance['leasePid']==PARENT_LEASE_PID and acceptance['oneApply'] is True
         and type(acceptance['nonce']) is str and re.fullmatch('[a-f0-9]{32}',acceptance['nonce'])
         and acceptance['nonce']==decision['nonce']
         and acceptance['expiresAtUtc']==decision['expiresAtUtc'],
         'EXACT_REQUEST_GROUPS_R1_HISTORICAL_ADMISSION_LINKS_REQUIRED')
    need(all(acceptance.get(key)==expected_binding[key] for key in
             ('namespace','manifestSha256','entrySha256','codeAcceptanceSha256','nativeBasisSha256',
              'leasePid','parentImage','payloadScopeSha256','uiReviewSha256','htmlReviewSha256')),
         'EXACT_REQUEST_GROUPS_R1_HISTORICAL_BINDING_REQUIRED')
    need(state['automaticRetry'] is False and state['automaticRollback'] is False
         and state['runtimeDatabaseWrites']==state['schemaChanges']==0
         and state['workerRecreated'] is False and state['staticChanges']==4
         and state['written']==release.static_targets and len(old.records)==6
         and len(old.static_files.records)==4 and all(r['beforeSha256'] is not None and r['target']!='palitra-order-memo.cjs' for r in old.records),'EXACT_REQUEST_GROUPS_R1_CODE_ONLY_EFFECT_REQUIRED')
    overlay=release.paths['overlay'];overlay_pin=state['overlaySha256'];pins[overlay]=overlay_pin
    need(digest(overlay_pin) and sha(read(overlay))==overlay_pin,'EXACT_REQUEST_GROUPS_R1_OVERLAY_REQUIRED')
    need(json.loads(read(overlay))=={'services':{'content':{'image':PARENT_IMAGE}}},
         'EXACT_REQUEST_GROUPS_R1_CONTENT_ONLY_OVERLAY_REQUIRED')
    base=copy.deepcopy(state['after']);content=base['containers']['content']
    chain=state['before']['containers']['content']['files']+[str(overlay)]
    expected_content=copy.deepcopy(state['before']['containers']['content'])
    expected_content.update(image=PARENT_IMAGE,files=chain,configFiles=','.join(chain),
        filePins={**expected_content['filePins'],str(overlay):overlay_pin},configHash=state['plannedConfigHash'])
    need(len(chain)==len(set(chain))==47 and content==expected_content
         and base['containers']['chat']==state['before']['containers']['chat']
         and type(base['contentCid']) is str and bool(base['contentCid'])
         and base['contentCid']!=state['before']['contentCid']
         and all(base[key]==state['before'][key] for key in
                 ('worker','selected','l12','sourceModes','staticModes')),
         'EXACT_REQUEST_GROUPS_R1_FULL240_43_47_REQUIRED')
    need({k:v for k,v in base['runtime'].items() if k!='appTree'}
         =={k:v for k,v in state['before']['runtime'].items() if k!='appTree'},
         'EXACT_REQUEST_GROUPS_R1_PROTECTED_RUNTIME_REQUIRED')
    child=state['childProof']
    need(child['image']==PARENT_IMAGE and child['parentImage']==nmod.PARENT
         and child['sourceFiles']==240 and child['oneCopyLayer'] is True
         and child['changedTargets']==sorted(r['target'] for r in old.records)
         and child['appTreeSha256']==sha(encoded(base['runtime']['appTree'])),
         'EXACT_REQUEST_GROUPS_R1_CHILD_PROOF_REQUIRED')
    binding=child['platformImageBinding']
    need(binding['target']==PARENT_IMAGE and binding['platform']=='linux/amd64'
         and type(binding['manifestDigest']) is str
         and re.fullmatch('sha256:[a-f0-9]{64}',binding['manifestDigest']) is not None,
         'EXACT_REQUEST_GROUPS_R1_PARENT_PLATFORM_REQUIRED')
    source=dict(old.current.source)
    for row in old.records:source[row['target']]=row['sha256']
    static={**old.current.static,**{target:row['sha256'] for target,row in old.static_files.records.items()}}
    need(len(source)==240 and len(static)==43 and len(base['sourceModes'])==240
         and len(base['staticModes'])==43
         and all(base['runtime']['appTree'][target]['sha256']==pin for target,pin in source.items()),
         'EXACT_REQUEST_GROUPS_R1_SOURCE_STATIC_MAP_REQUIRED')
    need(source.get('palitra-order-memo.cjs')==old.current.memo_source_sha256
         and base['runtime']['appTree']['palitra-order-memo.cjs']==state['before']['runtime']['appTree']['palitra-order-memo.cjs'],
         'EXACT_CURRENT_MEMO_RETAINED_IN_COMPLETED_PARENT')
    def stable():
        old.stable()
        for path,pin in pins.items():need(sha(read(path))==pin,'SEALED_COMPLETED_REQUEST_GROUPS_R1_HISTORY_CHANGED')
        old.code_backup_guard(state['codeBackups'])
        release.context_guard(state['contextPins'],True)
        old.backup_guard(state['backups'])
    stable()
    need(old.verify_child(PARENT_IMAGE,state['before'])==child,'EXACT_REQUEST_GROUPS_R1_INDEPENDENT_CHILD_PROOF_REQUIRED')
    # Fresh read-only minima after the completed up; no historical admission replay.
    minimum_after=old.checkpoint(state['minimumBeforeUp'])
    stable()
    return old.a,old.b,old.prior,types.SimpleNamespace(
        base=base,source=source,static=static,stable=stable,cabinet=old.current.cabinet,
        managed_guard=old.current.managed_guard,
        content_migration=copy.deepcopy(old.current.content_migration),
        report_minimum=copy.deepcopy(minimum_after['report']),
        traffic_minimum=copy.deepcopy(minimum_after['traffic']),
        parent_release=PARENT_NAME,parent_receipt=JOURNAL_SHA,parent_decision=DECISION_SHA,
        memo_source_sha256=source['palitra-order-memo.cjs'],parent_image=PARENT_IMAGE,parent_chain_count=47,parent_platform_manifest=binding['manifestDigest'])
