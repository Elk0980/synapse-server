"""Offline closed package generator. No runtime proof or installation is emitted.

Generation requires actual map/inspector references, but not a future cleanup
receipt. That receipt is read and accepted only at the runtime action gate.
"""
import copy,json,os
from pathlib import Path
from manifest_inputs import need,read_pin,reviewed_components,sha,NAMESPACE
import map_closure
from native_adapter import OLD_NATIVE_SHA

def plan(config,map_reference,override_reference,inspector_reference,old_native_reference,static_extension_reference=None):
    native_map=read_pin(map_reference,json_document=True);overrides=read_pin(override_reference,json_document=True)
    need(overrides.get('schema')=='palitra-unified-reviewed-consumer-map/v1' and overrides.get('nativeMapSha256')==map_reference['sha256'] and type(overrides.get('records')) is dict,'EXACT_REVIEWED_NATIVE_CONSUMER_MAPPING_REQUIRED')
    raw_inspector=read_pin(inspector_reference,json_document=True)
    need(raw_inspector.get('status')=='FROZEN_READONLY_CODE_ONLY_NOT_RUNTIME_ADMISSION' and raw_inspector.get('runtimeAuthorization') is False,'FINAL_FROZEN_READONLY_INSPECTOR_REQUIRED')
    need(old_native_reference['sha256']==OLD_NATIVE_SHA,'EXACT_HISTORICAL_READ_PRIMITIVES_REQUIRED');read_pin(old_native_reference)
    from static_extension import from_reference
    extension=from_reference(static_extension_reference) if static_extension_reference is not None else None
    closure=map_closure.close(native_map,config['components'],overrides['records'],extension);resolved=copy.deepcopy(config)
    resolved['status']='FINAL_ROOT_REVIEWED_INPUTS_NOT_RUNTIME_AUTHORIZATION'
    by_key={r['key']:r for r in closure['consumers']}
    for group,component in resolved['components'].items():
        if group=='managed-site':continue
        for index,row in enumerate(component['records']):
            mapping=by_key[group+':'+str(index)];row['runtimeTarget']=mapping['runtimeTargets'][0] if mapping['runtimeTargets'] else None;row['staticTargets']=mapping['staticTargets']
    reviewed_components(resolved)
    # Proofs/admission are intentionally absent here. Code first, native
    # workspace publication later: no requirement for a future adoption receipt.
    return {'schema':'palitra-unified-generated-package/v1','status':'CODE_ONLY_NOT_RUNTIME_AUTHORIZATION','namespace':NAMESPACE,'runtimeAuthorization':False,'assetVersion':config['assetVersion'],'map':closure,'productReviews':{g:v['review'] for g,v in config['components'].items()},'nativeMap':map_reference,'staticExtension':static_extension_reference,'consumerMap':override_reference,'compatibilityInspectorManifest':inspector_reference,'oldNative':old_native_reference,'acceptedPostCleanupBasis':None,'nativeAdoptionReceipt':None,'runtimeWrites':0}

def emit(plan,source_directory,schema_reference,output):
    source_directory=Path(source_directory);output=Path(output)
    own_root=source_directory.resolve().parent
    need(own_root.name=='GENERATION_R5' and own_root.parent.name=='INSTALLER_UNIFIED_R1_DRAFT' and output.is_absolute() and own_root in output.resolve().parents and 'generated' in output.relative_to(own_root).parts,'ONLY_OWN_NEW_GENERATED_DIRECTORY_ALLOWED')
    need(not output.exists(),'NEW_PACKAGE_REQUIRED_NO_OVERWRITE')
    map_closure.verify(plan['map']);output.mkdir(parents=True,mode=0o700)
    files={};payloads={}
    def put(name,raw):
        p=output/name;p.parent.mkdir(parents=True,exist_ok=True)
        with p.open('xb') as f:f.write(raw)
        os.chmod(p,0o600);files[name]=sha(raw);return {'path':name,'sha256':sha(raw)}
    modules=sorted(source_directory.glob('*.py'))
    need({'native_adapter.py','install_protocol.py','native_entry.py','forward_guard.py','schema_migration.py','post_cleanup_basis.py'}<=set(p.name for p in modules),'COMPLETE_NATIVE_PACKAGE_CODE_REQUIRED')
    for p in modules:put(p.name,p.read_bytes())
    for p in sorted(source_directory.glob('*.cjs')):put(p.name,p.read_bytes())
    schema=put('schema.sql',read_pin(schema_reference));put('historical-native-read-source.py',read_pin(plan['oldNative']))
    for index,row in enumerate(plan['map']['runtimeRecords']):payloads[row['target']]=put('payload/runtime-'+str(index),read_pin(row['input']))
    for index,row in enumerate(plan['map']['staticRecords']):
        if row['target'] not in payloads:payloads[row['target']]=put('payload/static-'+str(index),read_pin(row['input']))
    for index,row in enumerate(plan['map']['managedRecords']):put('native-adoption/'+str(index),read_pin(row['input']))
    value={**plan,'schemaFile':schema,'payloads':payloads}
    put('package.json',json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
    manifest={'schema':'palitra-unified-native-code-manifest/v1','status':'GENERATED_CODE_ONLY_NOT_RUNTIME_AUTHORIZATION','namespace':NAMESPACE,'runtimeAuthorization':False,'files':files,'mutableRuntimeFiles':[]}
    raw=json.dumps(manifest,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
    with (output/'code-manifest.json').open('xb') as f:f.write(raw)
    os.chmod(output/'code-manifest.json',0o600)
    return {'status':'LOCAL_GENERATED_CODE_ONLY_REQUIRES_ROOT_REVIEW','manifestSha256':sha(raw),'files':len(files),'runtimeAuthorization':False,'runtimeWrites':0}
