"""New forward content basis; immutable inspector and old backups unchanged."""
import copy,hashlib,importlib,sys
from pathlib import Path
from manifest_inputs import need,read_pin,digest
def load_inspector(directory,expected_manifest_sha):
    # Supplied by the generated, Root-reviewed package; never a CLI override.
    need(digest(expected_manifest_sha),'FINAL_REVIEWED_INSPECTOR_MANIFEST_REQUIRED')
    directory=Path(directory);manifest=read_pin({'path':str(directory/'readonly-code-pins.json'),'sha256':expected_manifest_sha},json_document=True)
    need(manifest['status']=='FROZEN_READONLY_CODE_ONLY_NOT_RUNTIME_ADMISSION' and manifest['runtimeAuthorization'] is False,'EXACT_FROZEN_INSPECTOR_CODE_REQUIRED')
    files=manifest['files'];need({p.name for p in directory.iterdir()}==set(files)|{'readonly-code-pins.json'},'CLOSED_INSPECTOR_DIRECTORY_REQUIRED')
    for name,pin in files.items():read_pin({'path':str(directory/name),'sha256':pin})
    need(not any(n in sys.modules for n in ('inspect_readonly','capture_managed260','collect_runtime','evidence_validator','literal_history','static_closure','storage_seals')),'FRESH_NATIVE_PROCESS_REQUIRED_NO_MODULE_SHADOW')
    sys.dont_write_bytecode=True;sys.path.insert(0,str(directory));module=importlib.import_module('inspect_readonly')
    need(Path(module.__file__).resolve()==(directory/'inspect_readonly.py').resolve(),'EXACT_LOADED_INSPECTOR_REQUIRED');return module,files

def factory_type(R3):
    class ForwardFactory(R3.Factory):
        def __init__(self,pid,pins,minimum,*,finish=False):
            need(type(minimum) is dict and set(minimum)=={'identity','family','content'},'EXACT_ACCEPTED_NATIVE_CONTENT_MINIMUM_REQUIRED')
            self._inspector=R3;self.forward_minimum=copy.deepcopy(minimum);self._first_content=True;super().__init__(pid,pins,'runtime-cas' if finish else 'full')
            if finish:
                # Native publication may already have advanced beyond260.
                # Keep all sealed history/storage/backups, but the new forward
                # managed141 guard is supplied by the new installer, not relabelled.
                self.make_databases();self.mode='full';self.storage_guard()
        def database_guard(self,minimum):
            out={}
            for key,db in self.databases.items():
                selected=self.forward_minimum if key=='content' and self._first_content else minimum[key]
                out[key]=db.guard(selected)
                # Retain exact historical private backup guards for ALL3 DBs.
                db.backup_guard(self.receipt['backups'][key])
            self._first_content=False
            self.last_databases=copy.deepcopy(out)
            need(all(row['revision']>=3 for row in out['report']['content']['cache'].values()),'BOTH_REPORT_REVISIONS3_REQUIRED');return out
        def capture_forward(self):
            self._first_content=True;result=R3.C.capture(self.context())
            result.update(schema='palitra-accepted-forward-content-full-inspection/v1',status='NEW_FORWARD_CONTENT_FULL_INSPECTION_NOT_HISTORICAL_PASS',runtimeAdmission=False)
            return result
        def accept_exact_schema_result(self,minimum,result,expected_before):
            need(result['status']=='SCHEMA_PREPARED_IN_CALLER_TRANSACTION_NOT_COMMITTED' and result['oldBusinessRowsChanged']==0 and result['beforeContentSha256']==expected_before and result['protectedContentSha256']==expected_before and len(result['tablesAdded'])==5,'EXACT_APPROVED_FIVE_TABLE_TRANSITION_REQUIRED')
            need(set(minimum)=={'identity','family','content'} and minimum['identity']==self.forward_minimum['identity'],'CURRENT_CONTENT_IDENTITY_MUST_REMAIN_EXACT')
            self.forward_minimum=copy.deepcopy(minimum);self._first_content=True
    return ForwardFactory

def assert_old_backups_and_new_content(factory,minimum):
    """Independent checkpoints after image/schema transitions; no old minima edit."""
    return factory.database_guard(minimum)
