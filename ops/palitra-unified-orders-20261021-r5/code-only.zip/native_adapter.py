"""Concrete content-only driver generated from exact reviewed read primitives.

No old Native constructor, old stable(), migration, or entry is loaded. The
inherited bodies listed below only inspect images/trees/configuration. New
writer actions have their own exact argument lists and one-use flags.
"""
import ast,base64,copy,hashlib,json,os,re,sqlite3,stat,subprocess,time,types
from pathlib import Path,PurePosixPath
from manifest_inputs import need,digest,read_pin,IMAGE,NAMESPACE
from private_files import PrivateFiles,StaticFiles,exact,read,encoded,sha
import map_closure
import schema_migration as M

ROOT=Path('/opt/synapse/releases/palitra-app-20261015')
DATA=Path('/var/lib/docker/volumes/synapse_content_data/_data')
OLD_NATIVE_SHA='95f79586baf667a7105ddddbc5ffaab70dad468cedfa84aed77fce307d6d87f6'
READ_METHODS=frozenset(('_image','_parent_image','_platform_image','_tree','_runtime','data_mount','content_data_mount','_base_alias_guard'))
SOURCE_JS="const f=require('node:fs'),p='/app/'+process.argv[1],s=f.lstatSync(p);if(!s.isFile()||s.isSymbolicLink()||s.nlink!==1||s.uid!==0||s.gid!==0||s.size>2097152)throw Error('SOURCE_TYPE');const fd=f.openSync(p,f.constants.O_RDONLY|f.constants.O_NOFOLLOW|f.constants.O_NONBLOCK);try{const a=f.fstatSync(fd),b=f.readFileSync(fd),z=f.fstatSync(fd),q=f.lstatSync(p);for(const k of ['dev','ino','mode','uid','gid','nlink','size','mtimeMs','ctimeMs'])if(s[k]!==a[k]||s[k]!==z[k]||s[k]!==q[k])throw Error('SOURCE_CHANGED');if(b.length!==s.size)throw Error('SOURCE_SIZE');process.stdout.write(b.toString('base64'));}finally{f.closeSync(fd)}"
def read_primitives(raw):
    need(sha(raw)==OLD_NATIVE_SHA,'EXACT_REVIEWED_NATIVE_SOURCE_REQUIRED')
    parsed=ast.parse(raw);klass=next(x for x in parsed.body if isinstance(x,ast.ClassDef) and x.name=='Native')
    chosen=[]
    for node in klass.body:
        if isinstance(node,ast.FunctionDef) and node.name in READ_METHODS:
            node.decorator_list=[];chosen.append(node)
    need({n.name for n in chosen}==READ_METHODS,'EXACT_READ_METHOD_CLOSURE_REQUIRED')
    script=next(n.value.value for n in parsed.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='TREE_JS' for t in n.targets))
    ns={'__builtins__':__builtins__,'copy':copy,'hashlib':hashlib,'json':json,'os':os,'Path':Path,'PurePosixPath':PurePosixPath,'re':re,'stat':stat,'need':need,'digest':digest,'sha':sha,'encoded':encoded,'image':lambda v:type(v) is str and re.fullmatch('sha256:[a-f0-9]{64}',v) is not None,'PARENT':IMAGE,'PLATFORM':'linux/amd64','DATA':DATA,'TREE_JS':script,'BASE_ALIAS':'synapse-'+NAMESPACE+'-base:local','MANIFEST_TYPES':frozenset(('application/vnd.oci.image.manifest.v1+json','application/vnd.docker.distribution.manifest.v2+json')),'INDEX_TYPES':frozenset(('application/vnd.oci.image.index.v1+json','application/vnd.docker.distribution.manifest.list.v2+json'))}
    module=ast.Module(body=[ast.ClassDef(name='Reads',bases=[],keywords=[],body=chosen,decorator_list=[])],type_ignores=[])
    exec(compile(ast.fix_missing_locations(module),'<exact-native-read-methods>','exec'),ns)
    need(not ({'__init__','stable','build','up','apply','backup'}&set(ns['Reads'].__dict__)),'OLD_NATIVE_WRITER_COMPILED')
    return ns

def verify_sealed_baseline(closure,receipt,static):
    before=receipt['after']
    need(closure['appTreeBefore']==before['runtime']['appTree'] and closure['staticBaselineBefore']==static['sha256'] and closure['staticBaselineModes']==before['staticModes'] and closure['sourceBefore']=={n:before['runtime']['appTree'][n]['sha256'] for n in before['sourceModes']},'GENERATED_MAP_MUST_MATCH_INDEPENDENT_SEALED_INSPECTOR')
    return True

class Driver:
    def __init__(self,factory,closure,private,old_native_bytes,payloads,code_guard):
        need(map_closure.verify(closure) and callable(code_guard),'CLOSED_NATIVE_MAP_AND_CODE_GUARD_REQUIRED')
        self.factory=factory;self.map=closure;self.private=private;self.payloads=payloads;self.code_guard=code_guard
        self.ns=read_primitives(old_native_bytes);self.n=object.__new__(self.ns['Reads']);self.n.run=self.run
        self.n.a=types.SimpleNamespace(decode=json.loads,read=read,exact_path=exact)
        self.n._parent_image_cache=None;self.n.parent_platform_manifest=factory.receipt['childProof']['platformImageBinding']['manifestDigest']
        self.n._canonical_host_config=factory.n._canonical_host_config;self.n.data_mount=self.n.data_mount
        self.child=None;self.overlay=None;self.config_hash=None;self.started=set();self.db_minimum=None
        self.alias=self.ns['BASE_ALIAS'];self.tag='synapse-'+NAMESPACE+'-content'
        self.static=StaticFiles(private,closure['staticRecords'],self.guard)
        self.metadata_before=copy.deepcopy(factory.receipt['after']['containers'])
        need(len(self.metadata_before['content']['files'])==49,'EXACT_PARENT_CHAIN49_REQUIRED')
        before=factory.receipt['after']
        verify_sealed_baseline(closure,factory.receipt,factory.static)
        # Phase-specific static state is bound by backup/apply or finish/accept
        # before any child snapshot; accept may already have published bytes.
        self.guard()
    def static_extension_guard(self):
        # Metadata facts are independent of the old43 closure; read current bytes
        # on every side of publication and preserve canonical parent boundaries.
        for row in self.map['staticExtensionFacts']['files'] if self.map['staticExtensionFacts'] else []:
            p=exact(row['path']);s=p.lstat();expected=self.map['staticAfter'][row['path']] if row['path'] in self.static.published else row['sha256']
            need(str(p.parent.resolve())==row['parentReal'] and stat.S_ISREG(s.st_mode) and s.st_nlink==1 and s.st_uid==s.st_gid==0 and stat.S_IMODE(s.st_mode)==row['mode'] and sha(read(p))==expected,'EXACT_STATIC6_CURRENT_METADATA_AND_BYTES_REQUIRED')
    def guard(self):
        self.code_guard();self.private.guard();self.factory.lease();self.factory.history_guard()
    def payload(self,row):
        raw=read_pin(self.payloads[row['target']]);need(len(raw)==row['bytes'] and sha(raw)==row['sha256'],'EXACT_GENERATED_NATIVE_PAYLOAD_REQUIRED');return raw
    def compose(self,operation,with_overlay=True):
        meta=self.metadata_before['content'];files=meta['files']+([str(self.overlay)] if with_overlay else [])
        return ['docker','compose','--project-name',meta['project'],'--project-directory',meta['workingDir']]+[v for p in files for v in ('--file',p)]+operation
    def allowed_extra(self,args):
        images={IMAGE,self.alias,self.tag}|({self.child} if self.child else set())
        if args[:3]==['docker','image','inspect']:
            return len(args)==4 and args[-1] in images or len(args)==6 and args[3:5]==['--platform','linux/amd64'] and args[-1] in images or len(args)==6 and args[3:5]==['--format','{{.Id}}'] and args[-1] in images
        if args[:3]==['docker','image','ls']:return args in (['docker','image','ls','--quiet',self.alias],['docker','image','ls','--quiet',self.tag])
        prefix=['docker','run','--rm','--network=none','--read-only','--cap-drop=ALL','--security-opt=no-new-privileges','--entrypoint=node']
        if args[:len(prefix)]==prefix:
            if len(args)==len(prefix)+3 and args[-3] in images and args[-2:] == ['-e',self.ns['TREE_JS']]:return True
            return len(args)==len(prefix)+4 and args[len(prefix):len(prefix)+3]==[IMAGE,'-e',SOURCE_JS] and args[-1] in {r['target'] for r in self.map['runtimeRecords'] if r['beforeSha256'] is not None}
        if self.overlay:
            if args==self.compose(['config','--hash','content']):return True
            if args==['docker','compose']+[v for p in self.metadata_before['content']['files']+[str(self.overlay)] for v in ('-f',p)]+['config','--format','json']:return True
        return False
    def _execute(self,args,timeout=90,*,writer=False):
        need(type(args) is list and all(type(v) is str for v in args),'EXACT_NATIVE_ARGUMENTS_REQUIRED')
        r=subprocess.run(args,capture_output=True,check=True,timeout=timeout,stdin=subprocess.DEVNULL,cwd=self.metadata_before['content']['workingDir'] if args[:2]==['docker','compose'] else None)
        need(len(r.stdout)<=32*1024*1024 and len(r.stderr)<=8*1024*1024 and (writer or not r.stderr),'BOUNDED_NATIVE_RESULT_REQUIRED')
        # Docker build/compose normally put progress on stderr. It stays
        # private and is recorded only as a hash, never treated as read proof.
        self.last_stderr_sha256=sha(r.stderr);return r.stdout
    def run(self,args):
        # Fallback remains the sealed read-only transport, with no retry on its
        # exceptions. New-image/config reads are separately closed above.
        if self.allowed_extra(args):return self._execute(args)
        return self.factory.run(args)
    def _write_command(self,key,args):
        commands={'base-alias':['docker','image','tag',IMAGE,self.alias],'one-copy-build':['docker','build','--network=none','--pull=false','--tag',self.tag,'--iidfile',str(self.private.root/'context/image.id'),str(self.private.root/'context')]}
        if self.overlay is not None:commands['content-up']=self.compose(['up','--detach','--no-build','--pull','never','--no-deps','content'])
        need(key in commands and args==commands[key] and key not in self.started,'EXACT_ONE_USE_NATIVE_ACTION_REQUIRED')
        self.guard();self.started.add(key)
        raw=self._execute(args,180,writer=True)
        return {'status':'COMMAND_RETURNED_ZERO_REQUIRES_FULL_READBACK','stdoutSha256':sha(raw),'stderrSha256':getattr(self,'last_stderr_sha256',sha(b''))}
    def make_context(self):
        self.guard();context=self.private.root/'context';self.private.mkdir(context)
        self.private.mkdir(context/'app',0o755);dirs=set()
        for row in self.map['runtimeRecords']:
            for parent in PurePosixPath(row['target']).parents:
                if str(parent)!='.':dirs.add(parent.as_posix())
        for name in sorted(dirs,key=lambda n:(n.count('/'),n)):self.private.mkdir(context/'app'/name,0o755)
        for row in self.map['runtimeRecords']:self.private.write(context/'app'/row['target'],self.payload(row),row['mode'])
        self.private.write(context/'Dockerfile',('FROM '+self.alias+'\nCOPY app/ /app/\n').encode())
        return context
    def context_guard(self,context):
        need(context==self.private.root/'context','EXACT_PRIVATE_BUILD_CONTEXT_REQUIRED')
        wanted={'Dockerfile':(0o600,sha(('FROM '+self.alias+'\nCOPY app/ /app/\n').encode()))}
        wanted.update({'app/'+r['target']:(r['mode'],r['sha256']) for r in self.map['runtimeRecords']})
        actual={};wanted_dirs={'app'}|{'app/'+p.as_posix() for r in self.map['runtimeRecords'] for p in PurePosixPath(r['target']).parents if str(p)!='.'}
        actual_dirs=set()
        for path in context.rglob('*'):
            exact(path);s=path.lstat();rel=path.relative_to(context).as_posix()
            need(os.name!='posix' or s.st_uid==s.st_gid==0,'ROOT_CONTEXT_REQUIRED')
            if stat.S_ISDIR(s.st_mode):need(stat.S_IMODE(s.st_mode)==0o755,'EXACT_CONTEXT_DIRECTORY_MODE_REQUIRED');actual_dirs.add(rel)
            else:need(stat.S_ISREG(s.st_mode) and s.st_nlink==1,'REGULAR_CONTEXT_ONLY');actual[rel]=(stat.S_IMODE(s.st_mode),sha(read(path)))
        need(actual==wanted and actual_dirs==wanted_dirs,'EXACT_CLOSED_BUILD_CONTEXT_REQUIRED')
    def build(self):
        context=self.make_context();self.context_guard(context);self.guard()
        need(self.run(['docker','image','ls','--quiet',self.alias]).strip()==self.run(['docker','image','ls','--quiet',self.tag]).strip()==b'','NEW_IMAGE_NAMES_REQUIRED_NO_REPLAY')
        binding=self.n._base_alias_guard();cmd=['docker','image','tag',IMAGE,self.alias]
        self._write_command('base-alias',cmd);self.n._base_alias_guard(binding,True);self.context_guard(context)
        cmd=['docker','build','--network=none','--pull=false','--tag',self.tag,'--iidfile',str(context/'image.id'),str(context)]
        self._write_command('one-copy-build',cmd);self.n._base_alias_guard(binding,True)
        target=read(context/'image.id').decode().strip();need(re.fullmatch('sha256:[a-f0-9]{64}',target) is not None and target!=IMAGE,'EXACT_NEW_CHILD_IMAGE_REQUIRED')
        self.child=target;need(self.run(['docker','image','inspect','--format','{{.Id}}',self.tag]).decode().strip()==target,'EXACT_NEW_CHILD_TAG_REQUIRED')
        parent=self.n._parent_image();child=self.n._image(target);a=parent['RootFS']['Layers'];b=child['RootFS']['Layers']
        need(b[:len(a)]==a and len(b)==len(a)+1 and child['Config']==parent['Config'],'EXACT_ONE_COPY_CHILD_CONFIG_REQUIRED')
        platform=self.n._platform_image(target,child);need(self.n._tree(target)==self.map['appTreeAfter'],'FULL_CHILD_TREE_MUST_MATCH_CLOSED_DELTA')
        return {'image':target,'parentImage':IMAGE,'oneCopyLayer':True,'platformImageBinding':platform,'appTreeSha256':sha(encoded(self.map['appTreeAfter'])),'sourceFiles':len(self.map['sourceAfter'])}
    def plan(self):
        need(self.child is not None,'VERIFIED_CHILD_BEFORE_PLAN_REQUIRED');self.overlay=ROOT/(NAMESPACE+'-overlay.json')
        # An overlay is a private EXCL Root artifact outside the context directory.
        need(self.private.root.parent==ROOT,'EXACT_RELEASE_PRIVATE_ROOT_REQUIRED')
        fd=os.open(exact(self.overlay,True),os.O_CREAT|os.O_EXCL|os.O_WRONLY|getattr(os,'O_NOFOLLOW',0),0o600)
        with os.fdopen(fd,'wb') as f:f.write(encoded({'services':{'content':{'image':self.child}}}));f.flush();os.fsync(f.fileno())
        result=self.run(self.compose(['config','--hash','content'])).decode().strip();match=re.fullmatch(r'content\s+([a-f0-9]{64})',result)
        need(match is not None,'EXACT_CONTENT_ONLY_COMPOSE_PLAN_REQUIRED');self.config_hash=match[1];return self.config_hash
    def up(self):
        need(self.child is not None and digest(self.config_hash) and self.db_minimum is not None,'SCHEMA_AND_CHILD_AND_PLAN_REQUIRED_BEFORE_UP')
        cmd=self.compose(['up','--detach','--no-build','--pull','never','--no-deps','content'])
        return self._write_command('content-up',cmd)
    def metadata(self):
        need(self.child is not None and self.overlay is not None and digest(self.config_hash),'EXACT_CHILD_METADATA_ARGUMENTS_REQUIRED')
        expected=copy.deepcopy(self.metadata_before);row=expected['content'];files=row['files']+[str(self.overlay)]
        need(len(files)==len(set(files))==50,'EXACT_FORWARD_CHAIN50_REQUIRED')
        row.update(image=self.child,files=files,configFiles=','.join(files),filePins={**row['filePins'],str(self.overlay):sha(read(self.overlay))},configHash=self.config_hash)
        actual=json.loads(self.run(['docker','inspect','--format',self.factory.ns['backend']['LABELS'],'synapse-content-1']))
        actual.update(files=files,filePins={p:sha(read(p)) for p in files})
        need(actual==row and self.factory.b.metadata('chat')==expected['chat'],'EXACT_CONTENT_ONLY_METADATA_TRANSITION_REQUIRED')
        return expected
    def snapshot_child(self,managed_guard):
        self.guard();need(callable(managed_guard),'EXACT_MANAGED_PHASE_GUARD_REQUIRED');f=self.factory;before=f.receipt['after']
        self.static_extension_guard();first=self.metadata();worker=f.b.worker_facts();selected={s:f.a.selected(s) for s in ('content','chat')}
        flags=json.loads(self.run(['docker','exec','synapse-content-1','node','-e',f.ns['backend']['FLAGS_JS']]))
        need(worker==before['worker'] and selected==before['selected'] and flags==before['l12'],'UNCHANGED_WORKER_SELECTION_FLAGS_REQUIRED')
        for service,row in first.items():
            resolved=self.run(f.b._resolve_command(row,service)).decode().strip()
            need(re.fullmatch(re.escape(service)+r'\s+'+re.escape(row['configHash']),resolved) is not None,'RESOLVED_CHILD_COMPOSE_HASH_CHANGED')
        need(f.b.heartbeat(worker['startedAt'],time.time())['freshAfterWorkerStart'] is True,'FRESH_UNCHANGED_WORKER_HEARTBEAT_REQUIRED');f.b.graph(new=True);f.push_guard();managed_guard();f.storage_guard()
        tree=self.n._tree();need(tree==self.map['appTreeAfter'],'FULL_CHILD_TREE_CHANGED')
        for name,pin in self.map['staticBefore'].items():
            expected=self.map['staticAfter'][name] if name in self.static.published else pin
            s=exact(name).lstat();need(stat.S_IMODE(s.st_mode)==self.map['staticModes'][name] and sha(read(name))==expected,'FULL_STATIC49_OR_BASE43_CHANGED')
        cid=self.run(['docker','inspect','--format','{{.Id}}','synapse-content-1']).decode().strip();runtime=self.n._runtime(self.child,first,cid)
        need({k:v for k,v in before['runtime'].items() if k!='appTree'}==runtime,'UNCHANGED_RUNTIME_ENV_MOUNTS_CONFIG_REQUIRED')
        need(first==self.metadata() and tree==self.n._tree() and worker==f.b.worker_facts() and selected=={s:f.a.selected(s) for s in ('content','chat')},'CHILD_SNAPSHOT_CHANGED_DURING_READ')
        f.database_guard(self.db_minimum)
        for name,pin in self.map['staticBefore'].items():
            expected=self.map['staticAfter'][name] if name in self.static.published else pin
            s=exact(name).lstat();need(stat.S_IMODE(s.st_mode)==self.map['staticModes'][name] and sha(read(name))==expected,'LATE_FULL_STATIC49_OR_BASE43_CHANGED')
        need(self.n._runtime(self.child,first,cid)==runtime and self.run(['docker','inspect','--format','{{.Id}}','synapse-content-1']).decode().strip()==cid,'LATE_RUNTIME_CONFIG_OR_CID_CHANGED')
        managed_guard();f.push_guard();f.storage_guard();self.guard();self.static_extension_guard();return {'containers':first,'runtime':{**runtime,'appTree':tree},'worker':worker,'selected':selected,'l12':flags,'contentCid':cid,'sourceModes':{n:{k:tree[n][k] for k in ('uid','gid','mode')} for n in self.map['sourceAfter']},'staticModes':self.map['staticModes']}
    def backup_databases(self,minimum):
        self.guard();result={}
        for key,old in self.factory.databases.items():
            db=copy.copy(old);original=old.files;private=self.private;dest=private.root/(key+'-before.sqlite')
            class Files:
                mode=staticmethod(original.mode)
                @staticmethod
                def write(path,raw,mode):
                    if Path(path)==dest:return private.write(path,raw,mode)
                    return original.write(path,raw,mode)
            db.files=Files();result[key]=db.backup(dest,minimum[key]);db.backup_guard(result[key])
        self.factory.database_guard(minimum);self.guard();return result
    def backup_sources(self):
        self.guard();result=[]
        need(self.n._tree(IMAGE)==self.map['appTreeBefore'],'EXACT_PARENT_TREE_BEFORE_SOURCE_BACKUP_REQUIRED')
        for index,row in enumerate(self.map['runtimeRecords']):
            if row['beforeSha256'] is None:
                need(row['target'] not in self.map['sourceBefore'] and row['target'] not in self.map['appTreeBefore'],'NEW_SOURCE_ABSENCE_PROOF_REQUIRED');continue
            cmd=['docker','run','--rm','--network=none','--read-only','--cap-drop=ALL','--security-opt=no-new-privileges','--entrypoint=node',IMAGE,'-e',SOURCE_JS,row['target']]
            value=base64.b64decode(self.run(cmd),validate=True);need(len(value)<=2*1024*1024 and sha(value)==row['beforeSha256'],'EXACT_EXISTING_SOURCE_BACKUP_REQUIRED')
            path=self.private.root/('source-'+str(index)+'.before');self.private.write(path,value);result.append({'target':row['target'],'path':str(path),'sha256':sha(value)})
        self.guard();return result
    def migrate(self,schema_bytes,schema_pin,started_at,before_sha,migration_admission,last_cas):
        self.guard();path=DATA/'content.sqlite';facts=self.factory.databases['content'].facts();identity_before=self.factory.databases['content'].identity(facts)
        db=sqlite3.connect(path,timeout=5)
        try:
            need(db.execute('PRAGMA journal_mode').fetchone()[0].lower()=='wal','EXISTING_WAL_REQUIRED_NO_MODE_CHANGE');db.execute('BEGIN IMMEDIATE')
            need(M.seal(db)['sha256']==before_sha,'EXACT_CONTENT_BEFORE_SCHEMA_REQUIRED');last_cas()
            result=M.apply_schema(db,schema_bytes=schema_bytes,schema_sha256=schema_pin,started_at=started_at,expected_before_sha256=before_sha,verify_admission=migration_admission)
            need(M.seal(db)['sha256']==result['afterContentSha256'],'EXACT_SCHEMA_POSTCHECK_REQUIRED');self.guard();migration_admission();db.commit()
        except BaseException:
            if db.in_transaction:db.rollback()
            raise
        finally:db.close()
        current=self.factory.databases['content'].read();need(current['identity']==identity_before,'CONTENT_DB_IDENTITY_CHANGED_ACROSS_SCHEMA')
        self.factory.accept_exact_schema_result(current,result,before_sha)
        self.db_minimum=self.factory.database_guard({**self.factory.receipt['minimumBeforeUp'],'content':current})
        return {**result,'nativeCommitStatus':'SCHEMA_COMMITTED_WITH_PROTECTED_CONTENT_PRESERVED'}
