"""Durable one-attempt protocol; native workspace adoption is a later read gate.

The code itself is never authorization. Every service action is bound to a
fresh external Root action receipt. There is no retry/apply-resume or DB restore.
"""
import copy,json,os,time
from pathlib import Path
from manifest_inputs import need,digest,IMAGE,RECEIPT,NAMESPACE,read_pin
from private_files import read,encoded,sha,exact,PrivateFiles
import schema_migration as M

class Admission:
    def __init__(self,reference,package_sha,mode,clock=time.time):
        need(mode in ('apply','finish','accept') and digest(package_sha),'EXACT_UNIFIED_ACTION_MODE_REQUIRED')
        self.reference=reference;self.package_sha=package_sha;self.mode=mode;self.clock=clock;self.initial=None
    def check(self):
        p=exact(self.reference['path']);s=p.lstat()
        need(os.name!='posix' or s.st_uid==s.st_gid==0 and (s.st_mode&0o777)==0o600,'PRIVATE_ROOT_ACTION_RECEIPT_REQUIRED')
        raw=read(p);need(sha(raw)==self.reference['sha256'],'EXACT_ROOT_ACTION_RECEIPT_REQUIRED');v=json.loads(raw)
        required={'schema','status','mode','namespace','packageSha256','parentImage','parentReceiptSha256','lease','createdAtUnix','expiresAtUnix','nonce','queue','bindings','runtimeAuthorization'}
        need(set(v)==required and v['schema']=='palitra-unified-root-action/v1' and v['status']=='ROOT_AUTHORIZED_ONE_ATTEMPT' and v['runtimeAuthorization'] is True,'EXACT_EXTERNAL_ROOT_ACTION_REQUIRED')
        need((v['mode'],v['namespace'],v['packageSha256'],v['parentImage'],v['parentReceiptSha256'])==(self.mode,NAMESPACE,self.package_sha,IMAGE,RECEIPT),'ROOT_ACTION_PACKAGE_PARENT_MODE_CHANGED')
        need(type(v['nonce']) is str and len(v['nonce'])==64 and digest(v['nonce']),'EXACT_ACTION_NONCE_REQUIRED')
        need(set(v['lease'])=={'pid','startTicks'} and type(v['lease']['pid']) is int and v['lease']['pid']>1 and type(v['lease']['startTicks']) is str and v['lease']['startTicks'].isdigit(),'ACTUAL_NEW_ROOT_LEASE_BINDING_REQUIRED')
        need(set(v['queue'])=={'resource','owner','clear'} and v['queue']=={'resource':'synapse-content-production','owner':'Root','clear':True},'EXPLICIT_CURRENT_SINGLE_WRITER_QUEUE_REQUIRED')
        need(type(v['createdAtUnix']) in (int,float) and type(v['expiresAtUnix']) in (int,float) and 0<v['expiresAtUnix']-v['createdAtUnix']<=1800 and v['createdAtUnix']<=self.clock()<v['expiresAtUnix'],'FRESH_UNEXPIRED_ACTION_REQUIRED')
        need(self.initial is None or self.initial==v,'ROOT_ACTION_CHANGED_DURING_RUN');self.initial=copy.deepcopy(v);return v

class Journal:
    def __init__(self,private,bindings):self.private=private;self.bindings=copy.deepcopy(bindings);self.steps=[]
    def record(self,phase,status,facts=None,*,runtime_acceptance=False):
        need(type(runtime_acceptance) is bool and (not runtime_acceptance or phase=='complete' and status=='APPLIED_AND_ROOT_ACCEPTED' and type(facts) is dict and digest(facts.get('acceptanceSha256'))),'ONLY_CLOSED_FINAL_ROOT_ACCEPTANCE_FLAG_ALLOWED')
        value={'schema':'palitra-unified-one-attempt-journal/v1','namespace':NAMESPACE,'sequence':len(self.steps),'phase':phase,'status':status,'bindings':self.bindings,'previousSha256':sha(encoded(self.steps[-1])) if self.steps else None,'facts':facts,'automaticRetry':False,'automaticRestore':False,'runtimeAcceptance':runtime_acceptance}
        self.private.json(self.private.root/('phase-'+str(len(self.steps)).zfill(3)+'.json'),value);self.steps.append(value);return value
    def action(self,name,call):
        self.record(name,'STARTED_UNKNOWN_NO_RETRY')
        result=call();self.record(name,'COMPLETED_NOT_CUSTOMER_ACCEPTANCE',result);return result

class Controller:
    def __init__(self,admission,driver,package,private):
        self.admission=admission;self.driver=driver;self.package=package;self.private=private
        auth=admission.check();need(auth['lease']=={'pid':driver.factory.pid,'startTicks':driver.factory.ticks},'ROOT_ACTION_ACTUAL_LEASE_CHANGED')
        self.journal=Journal(private,{'packageSha256':admission.package_sha,'rootActionSha256':admission.reference['sha256'],'nonce':auth['nonce'],'lease':auth['lease'],'mapSha256':package['map']['closureSha256']})
    def gate(self):
        value=self.admission.check();self.driver.guard();need(value['lease']=={'pid':self.driver.factory.pid,'startTicks':self.driver.factory.ticks},'LATE_ACTUAL_LEASE_CHANGED');return value
    def apply(self):
        need(self.admission.mode=='apply','APPLY_ACTION_REQUIRED');auth=self.gate();f=self.driver.factory
        full=self.journal.action('fresh-full-forward-basis',f.capture_forward)
        need(full.get('runtimeWrites')==0 and full.get('runtimeAdmission') is False and full.get('sourceFiles')==240 and full.get('staticFiles')==43 and full.get('chainFiles')==49,'EXACT_FULL_PREINSTALL_INSPECTION_REQUIRED')
        self.gate();minimum=copy.deepcopy(f.last_databases)
        backups=self.journal.action('consistent-three-private-backups',lambda:self.driver.backup_databases(minimum))
        self.journal.action('private-source-backups',self.driver.backup_sources)
        self.journal.action('private-static-backups',self.driver.static.backup)
        child=self.journal.action('one-copy-child-build',self.driver.build)
        planned=self.journal.action('content-only-plan',self.driver.plan)
        binding=auth['bindings'];need(binding['beforeContentSha256']==self.package['beforeContentSha256'],'EXACT_APPROVED_CURRENT_FULL_CONTENT_REQUIRED')
        schema=read_pin(self.package['schemaFile']);before=binding['beforeContentSha256']
        def migration_action():
            self.gate();return {'schema':'palitra-unified-explicit-migration-admission/v1','oneUse':True,'beforeContentSha256':before,'schemaSha256':self.package['schemaFile']['sha256'],'startedAt':binding['startedAt']}
        def last_cas():
            self.gate();old=f.mode;f.mode='runtime-cas'
            try:
                result=f._inspector.C.runtime_cas(f.context(),f.managed_cas_guard)
                need(result.get('runtimeWrites')==0 and result.get('fullInspection') is False,'NARROW_PREMUTATION_CAS_REQUIRED')
            finally:f.mode=old
        migration=self.journal.action('explicit-five-table-schema',lambda:self.driver.migrate(schema,self.package['schemaFile']['sha256'],binding['startedAt'],before,migration_action,last_cas))
        self.gate();self.journal.action('one-content-up',self.driver.up)
        snapshot=self.journal.action('full-child-readback-before-native-adoption',lambda:self.driver.snapshot_child(f.managed_guard))
        pending={'schema':'palitra-unified-pending-native-adoption/v1','status':'RUNTIME_CODE_SCHEMA_READY_REQUIRES_NATIVE_WORKSPACE_ADOPTION','runtimeAcceptance':False,'packageSha256':self.admission.package_sha,'rootActionSha256':self.admission.reference['sha256'],'applyDirectory':{'path':str(self.private.root),'identity':self.private.root_identity},'child':child,'plannedConfigHash':planned,'migration':migration,'backups':backups,'minimum':self.driver.db_minimum,'staticBackups':self.driver.static.backups,'snapshot':snapshot,'mapSha256':self.package['map']['closureSha256'],'managedAdoptionPlanSha256':binding['managedAdoptionPlan']['sha256'],'automaticRetry':False,'automaticRestore':False}
        self.private.json(self.private.root/'pending-native-adoption.json',pending)
        self.journal.record('native-workspace-publication','REQUIRES_SEPARATE_NATIVE_UI_ACTION_NO_RAW_OVERWRITE',{'planSha256':binding['managedAdoptionPlan']['sha256']})
        return pending
    def finish(self,pending,managed_receipt,managed_guard):
        # This path never builds, migrates, restores or performs content up.
        need(self.admission.mode=='finish' and not self.driver.started,'FRESH_READ_FINISH_PROCESS_REQUIRED');auth=self.gate()
        need(pending['schema']=='palitra-unified-pending-native-adoption/v1' and pending.get('status')=='RUNTIME_CODE_SCHEMA_READY_REQUIRES_NATIVE_WORKSPACE_ADOPTION' and pending['packageSha256']==self.admission.package_sha and pending['mapSha256']==self.package['map']['closureSha256'] and pending['runtimeAcceptance'] is False,'EXACT_PENDING_RUNTIME_BINDING_REQUIRED')
        need(pending['child'].get('parentImage')==IMAGE and pending['child'].get('oneCopyLayer') is True and set(pending['minimum'])==set(pending['backups'])=={'report','content','traffic'} and pending['migration'].get('nativeCommitStatus')=='SCHEMA_COMMITTED_WITH_PROTECTED_CONTENT_PRESERVED' and digest(pending['plannedConfigHash']),'EXACT_COMPLETED_CODE_AND_SCHEMA_OUTCOME_REQUIRED')
        need(auth['bindings']['pendingNativeAdoptionSha256']==sha(encoded(pending)),'EXACT_PENDING_RECEIPT_BINDING_REQUIRED')
        require_native_adoption(managed_receipt,self.package,pending)
        apply=pending.get('applyDirectory');need(type(apply) is dict and set(apply)=={'path','identity'} and Path(apply['path'])==self.driver.private.root.parent/(NAMESPACE+'-apply'),'EXACT_ACCEPTED_APPLY_NAMESPACE_REQUIRED')
        self.driver.child=pending['child']['image'];self.driver.overlay=self.driver.private.root.parent/(NAMESPACE+'-overlay.json');self.driver.config_hash=pending['plannedConfigHash'];self.driver.db_minimum=pending['minimum']
        self.driver.static.bind_sealed_backups(Path(apply['path']),apply['identity'],pending['staticBackups'])
        self.driver.static.backup_guard();managed_guard();self.journal.action('full-child-readback-after-native-adoption',lambda:self.driver.snapshot_child(managed_guard))
        for row in self.package['map']['staticRecords']:
            self.gate();self.journal.action('static-'+str(len(self.driver.static.published)),lambda row=row:self.driver.static.publish(row['target'],self.driver.payload(row)))
        snapshot=self.journal.action('full-installed-readback',lambda:self.driver.snapshot_child(managed_guard))
        self.gate()
        installed={'schema':'palitra-unified-installed-pending-root-acceptance/v1','status':'INSTALLED_PENDING_ROOT_ACCEPTANCE','runtimeAcceptance':False,'packageSha256':self.admission.package_sha,'finishRootActionSha256':self.admission.reference['sha256'],'applyDirectory':pending['applyDirectory'],'finishDirectory':{'path':str(self.private.root),'identity':self.private.root_identity},'child':pending['child'],'plannedConfigHash':pending['plannedConfigHash'],'minimum':self.driver.db_minimum,'staticBackups':pending['staticBackups'],'snapshot':snapshot,'snapshotSha256':sha(encoded(snapshot)),'mapSha256':self.package['map']['closureSha256'],'managedAdoptionReceiptSha256':sha(encoded(managed_receipt)),'automaticRetry':False,'automaticRestore':False}
        self.private.json(self.private.root/'installed-pending-acceptance.json',installed)
        self.journal.record('installed','INSTALLED_PENDING_ROOT_ACCEPTANCE',{'installedReceiptSha256':sha(encoded(installed)),'snapshotSha256':installed['snapshotSha256']})
        return installed
    def accept(self,installed,managed_receipt,managed_guard,acceptance_check):
        # Separate fresh read-only action, after external Root verification.
        # Never build, migrate, up or publish/replay static in this phase.
        need(self.admission.mode=='accept' and not self.driver.started,'FRESH_READONLY_ACCEPT_PROCESS_REQUIRED');auth=self.gate()
        need(installed.get('schema')=='palitra-unified-installed-pending-root-acceptance/v1' and installed.get('status')=='INSTALLED_PENDING_ROOT_ACCEPTANCE' and installed.get('runtimeAcceptance') is False and installed.get('packageSha256')==self.admission.package_sha and installed.get('mapSha256')==self.package['map']['closureSha256'] and installed.get('snapshotSha256')==sha(encoded(installed['snapshot'])),'EXACT_INSTALLED_PENDING_ACCEPTANCE_REQUIRED')
        finish=installed['finishDirectory'];need(set(finish)=={'path','identity'} and Path(finish['path'])==self.private.root.parent/(NAMESPACE+'-finish'),'EXACT_SEALED_FINISH_NAMESPACE_REQUIRED')
        from private_files import SealedBackupSource
        finish_source=SealedBackupSource(Path(finish['path']),finish['identity']);finish_source.guard()
        need(Path(auth['bindings']['installedPendingAcceptance']['path'])==finish_source.root/'installed-pending-acceptance.json' and sha(read(auth['bindings']['installedPendingAcceptance']['path']))==auth['bindings']['installedPendingAcceptance']['sha256'],'EXACT_FINISH_RECEIPT_RAW_FILE_BINDING_REQUIRED')
        need(installed['managedAdoptionReceiptSha256']==sha(encoded(managed_receipt)),'EXACT_ADOPTION_RECEIPT_MUST_PERSIST_THROUGH_ACCEPT')
        apply=installed['applyDirectory'];need(set(apply)=={'path','identity'} and Path(apply['path'])==self.private.root.parent/(NAMESPACE+'-apply'),'EXACT_ACCEPTED_APPLY_NAMESPACE_REQUIRED')
        self.driver.child=installed['child']['image'];self.driver.overlay=self.private.root.parent/(NAMESPACE+'-overlay.json');self.driver.config_hash=installed['plannedConfigHash'];self.driver.db_minimum=installed['minimum']
        self.driver.static.bind_sealed_backups(Path(apply['path']),apply['identity'],installed['staticBackups'])
        # Select the expected already-published state; snapshot_child actually
        # reads/verifies every resulting hash/mode. This never calls publish.
        self.driver.static.published=set(self.driver.static.records)
        snapshot=self.journal.action('readonly-installed-acceptance-readback',lambda:self.driver.snapshot_child(managed_guard))
        need(snapshot==installed['snapshot'],'INSTALLED_RUNTIME_CHANGED_BEFORE_ROOT_ACCEPTANCE');self.gate();finish_source.guard();acceptance=acceptance_check()
        need(acceptance.get('schema')=='palitra-unified-whole-app-acceptance/v1' and acceptance.get('status')=='ROOT_VERIFIED_OLD_NEW_OPEN_SESSIONS' and acceptance.get('packageSha256')==self.admission.package_sha and acceptance.get('managedReceiptSha256')==sha(encoded(managed_receipt)) and acceptance.get('installedReceiptSha256')==auth['bindings']['installedPendingAcceptance']['sha256'] and acceptance.get('snapshotSha256')==installed['snapshotSha256'] and acceptance.get('clientAndStaff') is True and acceptance.get('draftAndFilePreserved') is True and acceptance.get('oldAndNewQueriesCurrent') is True and acceptance.get('bottomComposer') is True,'ACTUAL_POST_PUBLICATION_WHOLE_APP_ACCEPTANCE_REQUIRED')
        return self.journal.record('complete','APPLIED_AND_ROOT_ACCEPTED',{'snapshot':snapshot,'installedReceiptSha256':auth['bindings']['installedPendingAcceptance']['sha256'],'acceptanceSha256':sha(encoded(acceptance)),'runtimeAcceptance':True,'databaseRestores':0},runtime_acceptance=True)

def validate_bindings(mode,bindings):
    common={'compatibilityInspectorManifestSha256','inspectorDirectory','managedAdoptionPlan'}
    fields={'apply':{'cleanupReceipt','postCapture','acceptedPostCleanupBasis','preFullInspectionSha256','cleanupUserApprovalSha256','acceptedNativeMinimum','beforeContentSha256','schemaSha256','startedAt'},'finish':{'pendingNativeAdoption','pendingNativeAdoptionSha256','nativeAdoptionReceipt'},'accept':{'installedPendingAcceptance','nativeAdoptionReceipt','wholeAppAcceptance'}}
    need(mode in fields and set(bindings)==common|fields[mode],'EXACT_NEW_ACTION_BINDING_DOMAIN_REQUIRED');return True

def require_native_adoption(receipt,package,pending):
    need(type(receipt) is dict and receipt.get('schema')=='palitra-unified-native-workspace-adoption/v1' and receipt.get('status')=='ROOT_VERIFIED_NATIVE_UI_SAVE_AND_PUBLIC_READBACK','ACTUAL_NATIVE_WORKSPACE_SAVE_READBACK_REQUIRED')
    need(receipt.get('planSha256')==pending['managedAdoptionPlanSha256'] and receipt.get('packageSha256')==pending['packageSha256'] and receipt.get('parentVersion')==260 and type(receipt.get('currentVersion')) is int and receipt['currentVersion']>260,'EXACT_NATIVE_FORWARD_ADOPTION_BINDING_REQUIRED')
    need(receipt.get('rawRuntimeFileWrites')==0 and receipt.get('filesBefore')==140 and receipt.get('filesAfter')==141 and receipt.get('priceUnchanged') is True,'EXACT_NATIVE141_ADOPTION_PRICE_GUARD_REQUIRED')
    expected={r['managedPath']:r['input']['sha256'] for r in package['map']['managedRecords']}
    need(receipt.get('changedFiles')==expected and receipt.get('other137Unchanged') is True and digest(receipt.get('full141FactsSha256')) and digest(receipt.get('nativeSaveReceiptSha256')),'FULL_NATIVE_ADOPTION_DELTA_PROOF_REQUIRED')

def require_native_plan(plan,package):
    need(plan.get('schema')=='palitra-unified-native-workspace-plan/v1' and plan.get('status')=='ROOT_REVIEWED_NATIVE_UI_PLAN_NOT_PUBLICATION' and plan.get('transport')=='native-ui' and plan.get('runtimeAuthorization') is False and plan.get('parentVersion')==260 and plan.get('rawRuntimeFileWrites')==0,'REVIEWED_NATIVE_UI_PLAN_REQUIRED_BEFORE_RUNTIME_CODE')
    need(plan.get('changedFiles')=={r['managedPath']:r['input']['sha256'] for r in package['map']['managedRecords']} and plan.get('priceUnchanged') is True,'EXACT_NATIVE_PLAN_PAYLOADS_AND_PRICE_REQUIRED')
    need(plan.get('newTrackerMetadata')=={'uid':0,'gid':0,'mode':0o644,'nlink':1,'regular':True,'canonical':True},'REVIEWED_NEW_TRACKER_NATIVE_METADATA_REQUIRED')
    return True
