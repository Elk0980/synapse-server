"""Explicit completion-only caller. Never applies/builds/migrates/restarts R8.

The installed runtime remains the immutable R8 package. Corrected caller helpers
are a separate closed manifest and require a fresh dual-bound external action.
"""
import argparse,copy,hashlib,importlib,json,os,re,stat,subprocess,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('/opt/synapse/releases/palitra-app-20261015')
DATA=Path('/var/lib/docker/volumes/synapse_content_data/_data')
RUNTIME='palitra-unified-orders-20261021-r8'
NAME=RUNTIME+'-completion-c1'
RUNTIME_SHA='a0d12a5bc58a99c5b554d8204db26796fec3f86684ca65b3213f5de6f8e2fff0'
ENTRY_SHA='99d23faeeb8f7c0375802c0dd2b719570dc8436c98de696846a6b475a9ddd9c3'
FAILED_STDOUT='6d1f8d0bc84eeab50716d92194705ca25c2b5c9900e3db96c00dfb1773647865'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encode=lambda v:json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
digest=lambda v:type(v) is str and re.fullmatch('[a-f0-9]{64}',v) is not None
def need(v,c):
    if not v:raise ValueError(c)
def read_file(path,limit=16*1024*1024,native=True):
    p=Path(path);need(p.is_absolute(),'ABSOLUTE_COMPLETION_PATH_REQUIRED')
    for q in [p,*p.parents]:need(not q.is_symlink(),'COMPLETION_ALIAS_REFUSED')
    s=p.lstat();need(stat.S_ISREG(s.st_mode) and s.st_nlink==1 and s.st_size<=limit,'BOUNDED_COMPLETION_FILE_REQUIRED')
    if native:need(s.st_uid==s.st_gid==0 and stat.S_IMODE(s.st_mode)==0o600,'ROOT600_COMPLETION_FILE_REQUIRED')
    raw=p.read_bytes();z=p.lstat()
    keys=('st_dev','st_ino','st_size','st_mtime_ns','st_ctime_ns')
    need(len(raw)==s.st_size and all(getattr(s,k)==getattr(z,k) for k in keys),'COMPLETION_READ_RACE');return raw
def load_completion(directory,pin,native=True):
    directory=Path(directory);need(digest(pin),'EXACT_COMPLETION_MANIFEST_PIN_REQUIRED')
    if native:need(os.name=='posix' and os.geteuid()==0 and directory==ROOT/(NAME+'-code'),'EXACT_COMPLETION_NATIVE_NAMESPACE_REQUIRED')
    raw=read_file(directory/'completion-manifest.json',native=native);need(sha(raw)==pin,'COMPLETION_MANIFEST_CHANGED');v=json.loads(raw)
    need(v.get('schema')=='palitra-r8-completion-code/v1' and v.get('namespace')==NAME and v.get('runtimePackageSha256')==RUNTIME_SHA and v.get('runtimeAuthorization') is False,'EXACT_COMPLETION_CODE_ONLY_CONTRACT')
    expected={'completion_entry.py','native-workspace-service.cjs','native-adoption-probe.cjs'}
    need(set(v['files'])==expected and {p.name for p in directory.iterdir()}==expected|{'completion-manifest.json'},'CLOSED_COMPLETION_CODE_DOMAIN_REQUIRED')
    for name,p in v['files'].items():need(digest(p) and sha(read_file(directory/name,native=native))==p,'COMPLETION_CODE_CHANGED')
    return v

class CompletionAdmission:
    def __init__(self,reference,completion_sha,mode,code_guard,clock=time.time):
        need(mode in ('save','finish','accept') and digest(completion_sha),'ONLY_COMPLETION_ACTION_MODES_ALLOWED')
        self.reference=reference;self.completion_sha=completion_sha;self.mode=mode;self.code_guard=code_guard;self.clock=clock
        # Original Controller uses package_sha solely as deployed payload provenance.
        self.package_sha=RUNTIME_SHA;self.initial=None
    def check(self):
        self.code_guard();raw=read_file(self.reference['path']);need(sha(raw)==self.reference['sha256'],'EXACT_COMPLETION_ROOT_ACTION_REQUIRED');v=json.loads(raw)
        expected={'schema','status','mode','namespace','runtimePackageSha256','completionManifestSha256','parentImage','parentReceiptSha256','lease','createdAtUnix','expiresAtUnix','nonce','queue','bindings','runtimeAuthorization'}
        need(set(v)==expected and v['schema']=='palitra-unified-r8-completion-root-action/v1' and v['status']=='ROOT_AUTHORIZED_ONE_ATTEMPT' and v['runtimeAuthorization'] is True,'EXTERNAL_COMPLETION_ROOT_ACTION_REQUIRED')
        from manifest_inputs import IMAGE,RECEIPT
        need((v['mode'],v['namespace'],v['runtimePackageSha256'],v['completionManifestSha256'],v['parentImage'],v['parentReceiptSha256'])==(self.mode,NAME,RUNTIME_SHA,self.completion_sha,IMAGE,RECEIPT),'EXACT_DUAL_RUNTIME_COMPLETION_BINDING_REQUIRED')
        need(digest(v['nonce']) and v['queue']=={'resource':'synapse-content-production','owner':'Root','clear':True},'EXACT_ROOT_QUEUE_NONCE_REQUIRED')
        need(set(v['lease'])=={'pid','startTicks'} and type(v['lease']['pid']) is int and v['lease']['pid']>1 and type(v['lease']['startTicks']) is str and v['lease']['startTicks'].isdigit(),'EXACT_COMPLETION_LEASE_BINDING_REQUIRED')
        need(type(v['createdAtUnix']) in (int,float) and type(v['expiresAtUnix']) in (int,float) and 0<v['expiresAtUnix']-v['createdAtUnix']<=1800 and v['createdAtUnix']<=self.clock()<v['expiresAtUnix'],'FRESH_COMPLETION_ACTION_REQUIRED')
        common={'compatibilityInspectorManifestSha256','inspectorDirectory','managedAdoptionPlan'}
        modes={'save':{'pendingNativeAdoption','pendingNativeAdoptionSha256','failedSaveMetadata'},'finish':{'pendingNativeAdoption','pendingNativeAdoptionSha256','nativeAdoptionReceipt'},'accept':{'installedPendingAcceptance','nativeAdoptionReceipt','wholeAppAcceptance'}}
        need(set(v['bindings'])==common|modes[self.mode],'EXACT_COMPLETION_BINDING_DOMAIN_REQUIRED')
        need(self.initial is None or v==self.initial,'COMPLETION_ACTION_CHANGED');self.initial=copy.deepcopy(v);return v

def main(argv=None):
    p=argparse.ArgumentParser();p.add_argument('--mode',choices=('save','finish','accept'),required=True);p.add_argument('--manifest-sha',required=True);p.add_argument('--action',required=True,type=Path);p.add_argument('--action-sha',required=True);a=p.parse_args(argv)
    directory=Path(__file__).resolve().parent;load_completion(directory,a.manifest_sha)
    runtime_dir=ROOT/(RUNTIME+'-code')
    need(sha(read_file(runtime_dir/'native_entry.py'))==ENTRY_SHA,'FROZEN_R8_ENTRY_CHANGED')
    sys.path.insert(0,str(runtime_dir));from native_entry import load_package
    package,_=load_package(runtime_dir,RUNTIME_SHA)
    def codes():load_completion(directory,a.manifest_sha);load_package(runtime_dir,RUNTIME_SHA)
    action=CompletionAdmission({'path':str(a.action),'sha256':a.action_sha},a.manifest_sha,a.mode,codes);auth=action.check();bindings=auth['bindings']
    from private_files import PrivateFiles,read,encoded,exact
    from manifest_inputs import read_pin
    from forward_guard import load_inspector,factory_type
    from install_protocol import Controller,require_native_plan
    def private_json(ref):
        need(type(ref) is dict and set(ref)=={'path','sha256'} and digest(ref['sha256']),'EXACT_PRIVATE_JSON_REFERENCE_REQUIRED')
        path=Path(ref['path']);need(ROOT in path.parents and path.suffix=='.json','PRIVATE_RELEASE_JSON_REQUIRED')
        raw=read_file(path);need(sha(raw)==ref['sha256'],'PRIVATE_COMPLETION_PROOF_CHANGED');return json.loads(raw)
    plan=private_json(bindings['managedAdoptionPlan']);require_native_plan(plan,package);need(plan['transport']=='native-workspace-service','ORIGINAL_NATIVE_SERVICE_TRANSPORT_REQUIRED');package['_managedAdoptionPlan']=plan
    need(bindings['compatibilityInspectorManifestSha256']==package['compatibilityInspectorManifest']['sha256'],'R8_COMPATIBILITY_INSPECTOR_PIN_REQUIRED')
    inspector_path=Path(bindings['inspectorDirectory']);need(inspector_path.parent==ROOT,'STAGED_COMPATIBILITY_INSPECTOR_REQUIRED');inspector,pins=load_inspector(inspector_path,bindings['compatibilityInspectorManifestSha256'])
    def lease():need(inspector.M.lease(auth['lease']['pid'])==auth['lease']['startTicks'],'FRESH_COMPLETION_LEASE_REQUIRED')
    outcome_proof_check=lambda:None
    def guard():
        action.check();lease()
        for ref in bindings.values():
            if type(ref) is dict and set(ref)=={'path','sha256'}:private_json(ref)
        outcome_proof_check()
    if a.mode in ('save','finish'):
        pending=private_json(bindings['pendingNativeAdoption'])
        need(sha(encoded(pending))==bindings['pendingNativeAdoptionSha256'] and pending.get('schema')=='palitra-unified-pending-native-adoption/v1' and pending.get('status')=='RUNTIME_CODE_SCHEMA_READY_REQUIRES_NATIVE_WORKSPACE_ADOPTION' and pending.get('packageSha256')==RUNTIME_SHA and pending.get('mapSha256')==package['map']['closureSha256'] and pending.get('runtimeAcceptance') is False,'EXACT_ACTUAL_R8_PENDING_REQUIRED')
        need(pending['migration'].get('nativeCommitStatus')=='SCHEMA_COMMITTED_WITH_PROTECTED_CONTENT_PRESERVED' and pending['migration'].get('oldBusinessRowsChanged')==0 and pending['child'].get('sourceFiles')==244 and pending['child'].get('oneCopyLayer') is True,'ACTUAL_COMMITTED_R8_NOT_REAPPLY_REQUIRED')
        need(pending['managedAdoptionPlanSha256']==bindings['managedAdoptionPlan']['sha256'] and pending['managedAdoptionBaseRevision']==plan['baseRevision'],'UNCHANGED_R8_PLAN_REQUIRED')
    else:pending=None
    if a.mode=='save':
        failed=private_json(bindings['failedSaveMetadata'])
        need(Path(bindings['failedSaveMetadata']['path'])==ROOT/(RUNTIME+'-save')/'NATIVE_CALL_META.json' and failed.get('returncode')==2 and failed.get('stdoutSha256')==FAILED_STDOUT and failed.get('stderrSha256')==sha(b'') and not (DATA/(RUNTIME+'-save')).exists(),'EXACT_CONFIRMED_PREWRITE_R8_FAILURE_REQUIRED')
        need({v.name for v in (ROOT/(RUNTIME+'-save')).iterdir()}=={'SAVE_STARTED.json','NATIVE_CALL_META.json'},'FAILED_R8_SAVE_EVIDENCE_MUST_REMAIN_EXACT')
        # Fresh original read-only DB floors/identity/schema and actual child
        # are checked before creating even the new caller attempt directory.
        saved_factory=factory_type(inspector)(auth['lease']['pid'],pins,pending['minimum']['content'],finish=True)
        need(saved_factory.ticks==auth['lease']['startTicks'],'ACTUAL_SAVE_LEASE_START_CHANGED')
        def current_runtime():
            guard();saved_factory.database_guard(pending['minimum'])
            r=subprocess.run(['docker','inspect','--format','{{.Image}}','synapse-content-1'],capture_output=True,timeout=20)
            need(r.returncode==0 and not r.stderr and r.stdout.decode().strip()==pending['child']['image'],'R8_CHILD_MUST_ALREADY_BE_SERVING')
        current_runtime();area=ROOT/(NAME+'-save');data_area=DATA/(NAME+'-save');need(not area.exists() and not data_area.exists(),'COMPLETION_SAVE_EXISTS_NO_REPLAY');area.mkdir(mode=0o700);private=PrivateFiles(area)
        def save_gate():
            current_runtime();private.guard()
        old=read_pin({'path':str(inspector.MANAGED_PATH),'sha256':inspector.C.MANAGED_SHA},json_document=True)
        need(inspector.C.MANAGED_SHA=='2676eea3de58aa150bcd8782005b6a1f51571f03ceb8dc2ea6f6f1804cace86d' and old['current260']['revision']==plan['baseRevision'],'IMMUTABLE_ORIGINAL_MANAGED260_REQUIRED')
        payloads={row['managedPath']:read(runtime_dir/'native-adoption'/str(i)).decode() for i,row in enumerate(package['map']['managedRecords'])}
        for row in package['map']['managedRecords']:need(sha(payloads[row['managedPath']].encode())==row['input']['sha256'],'UNCHANGED_R8_MANAGED3_PAYLOADS_REQUIRED')
        probe=read(directory/'native-adoption-probe.cjs');script=read(directory/'native-workspace-service.cjs')
        value={'schema':'palitra-unified-native-service-input/v1','namespace':NAME,'packageSha256':RUNTIME_SHA,'completionManifestSha256':a.manifest_sha,'completionRootActionSha256':a.action_sha,'planSha256':bindings['managedAdoptionPlan']['sha256'],'pendingSha256':bindings['pendingNativeAdoptionSha256'],'action':auth,'old':old,'plan':plan,'payloads':payloads,'probeSource':probe.decode(),'probeSha256':sha(probe)}
        raw=encoded(value);need(len(raw)<=9*1024*1024,'BOUNDED_COMPLETION_SAVE_INPUT');save_gate()
        private.json(area/'SAVE_STARTED.json',{'status':'STARTED_UNKNOWN_NO_RETRY','runtimePackageSha256':RUNTIME_SHA,'completionManifestSha256':a.manifest_sha,'completionRootActionSha256':a.action_sha,'automaticRetry':False})
        invocation=script.decode()+"\nlet raw=fs.readFileSync(0);need(raw.length<=9*1024*1024,'SERVICE_INPUT_BOUND');run(JSON.parse(raw)).then(v=>process.stdout.write(JSON.stringify(v))).catch(e=>{process.stdout.write(JSON.stringify({status:'REFUSED_OR_UNKNOWN_NO_AUTOMATIC_RETRY',code:/^[A-Z][A-Z0-9_]{0,120}$/.test(e.message)?e.message:e.name}));process.exitCode=2;});"
        result=subprocess.run(['docker','exec','-i','synapse-content-1','node','--disable-warning=ExperimentalWarning','-e',invocation],input=raw,capture_output=True,timeout=300)
        failure=None
        if len(result.stdout)<=32768:
            try:
                parsed=json.loads(result.stdout);candidate=parsed.get('code') if type(parsed) is dict else None;failure=candidate if type(candidate) is str and re.fullmatch('[A-Za-z][A-Za-z0-9_]{0,120}',candidate) else None
            except (ValueError,TypeError):pass
        private.json(area/'NATIVE_CALL_META.json',{'returncode':result.returncode,'stdoutSha256':sha(result.stdout),'stderrSha256':sha(result.stderr),'serviceFailureCode':failure,'automaticRetry':False})
        need(result.returncode==0 and not result.stderr and len(result.stdout)<=32768,'NATIVE_COMPLETION_SAVE_REFUSED_OR_UNKNOWN_NO_RETRY');out=json.loads(result.stdout);save_gate()
        need(type(out) is dict and out.get('status')=='NATIVE_SERVICE_SAVED_REQUIRES_ROOT_PUBLIC_READBACK' and out.get('currentVersion')==261 and out.get('runtimeAcceptance') is False,'EXACT_COMPLETION_NATIVE_SAVE_STATUS_REQUIRED')
        def data_ref(ref,name,limit):
            need(type(ref) is dict and set(ref)=={'path','sha256'} and ref['path']=='/data/'+NAME+'-save/'+name,'EXACT_COMPLETION_DATA_REFERENCE_REQUIRED');path=data_area/name;raw=read_file(path,limit);need(sha(raw)==ref['sha256'],'COMPLETION_DATA_CHANGED');return {'path':str(path),'sha256':ref['sha256']}
        outcome=data_ref(out['outcome'],'NATIVE_SAVE_OUTCOME.json',4*1024*1024);backup=data_ref(out['backup'],'content.sqlite',256*1024*1024)
        facts=json.loads(read_file(outcome['path']))
        need(facts.get('completionManifestSha256')==a.manifest_sha and facts.get('completionRootActionSha256')==a.action_sha and facts.get('runtimePackageSha256')==RUNTIME_SHA and facts.get('packageSha256')==RUNTIME_SHA and facts.get('pendingSha256')==bindings['pendingNativeAdoptionSha256'] and facts.get('planSha256')==bindings['managedAdoptionPlan']['sha256'],'EXACT_COMPLETION_SAVE_OUTCOME_REQUIRED')
        proof={**out,'outcome':outcome,'backup':backup,'runtimePackageSha256':RUNTIME_SHA,'completionManifestSha256':a.manifest_sha,'completionRootActionSha256':a.action_sha,'runtimeAcceptance':False,'automaticRetry':False,'automaticRestore':False}
        private.json(area/'SAVED_REQUIRES_PUBLIC_READBACK.json',proof);print(json.dumps(proof));return 0
    receipt=private_json(bindings['nativeAdoptionReceipt'])
    need(receipt.get('runtimePackageSha256')==RUNTIME_SHA and receipt.get('packageSha256')==RUNTIME_SHA and receipt.get('completionManifestSha256')==a.manifest_sha and digest(receipt.get('completionRootActionSha256')),'DUAL_BOUND_COMPLETION_ADOPTION_REQUIRED')
    outcome_ref=receipt.get('completionOutcome');need(type(outcome_ref) is dict and set(outcome_ref)=={'path','sha256'} and Path(outcome_ref['path'])==DATA/(NAME+'-save')/'NATIVE_SAVE_OUTCOME.json','EXACT_RAW_COMPLETION_OUTCOME_REFERENCE_REQUIRED')
    outcome_raw=read_file(outcome_ref['path'],4*1024*1024);need(sha(outcome_raw)==outcome_ref['sha256']==receipt.get('nativeSaveReceiptSha256'),'RAW_NATIVE_SAVE_OUTCOME_SHA_REQUIRED');outcome=json.loads(outcome_raw)
    def outcome_proof_check():need(sha(read_file(outcome_ref['path'],4*1024*1024))==outcome_ref['sha256'],'LATE_RAW_NATIVE_SAVE_OUTCOME_CHANGED')
    need(outcome.get('completionManifestSha256')==a.manifest_sha and outcome.get('completionRootActionSha256')==receipt['completionRootActionSha256'] and outcome.get('runtimePackageSha256')==RUNTIME_SHA and outcome.get('full141FactsSha256')==receipt.get('full141FactsSha256') and outcome.get('currentRevision')==receipt.get('currentRevision'),'COMPLETION_OUTCOME_PROVENANCE_CHANGED')
    need(outcome.get('packageSha256')==RUNTIME_SHA and outcome.get('planSha256')==receipt.get('planSha256')==bindings['managedAdoptionPlan']['sha256'] and outcome.get('status')=='NATIVE_SERVICE_SAVED_REQUIRES_ROOT_PUBLIC_READBACK' and outcome.get('saveCalls')==1 and outcome.get('currentVersion')==receipt.get('currentVersion')==261 and outcome.get('other137Unchanged') is True and outcome.get('priceUnchanged') is True and outcome.get('rawRuntimeFileWrites')==0,'EXACT_ACTUAL_C1_SAVE_FACTS_REQUIRED')
    if pending is not None:need(outcome.get('pendingSha256')==bindings['pendingNativeAdoptionSha256'],'SAME_ACTUAL_R8_PENDING_THROUGH_COMPLETION_REQUIRED')
    installed=private_json(bindings['installedPendingAcceptance']) if a.mode=='accept' else None
    minimum=installed['minimum']['content'] if installed else pending['minimum']['content']
    factory=factory_type(inspector)(auth['lease']['pid'],pins,minimum,finish=True);need(factory.ticks==auth['lease']['startTicks'],'ACTUAL_COMPLETION_LEASE_START_CHANGED')
    # Original R8 phase paths are required by the unchanged Controller contract.
    area=ROOT/(RUNTIME+'-'+a.mode);need(not area.exists(),'COMPLETION_PHASE_EXISTS_NO_REPLAY');area.mkdir(mode=0o700);private=PrivateFiles(area)
    from native_adapter import Driver
    payloads={k:{'path':str(runtime_dir/v['path']),'sha256':v['sha256']} for k,v in package['payloads'].items()}
    driver=Driver(factory,package['map'],private,read(runtime_dir/'historical-native-read-source.py'),payloads,guard)
    controller=Controller(action,driver,package,private);controller.journal.bindings.update(runtimePackageSha256=RUNTIME_SHA,completionManifestSha256=a.manifest_sha)
    script=read(directory/'native-adoption-probe.cjs').decode();invocation=script+"\nconst raw=fs.readFileSync(0);need(raw.length<=1048576,'INPUT_BOUND');process.stdout.write(JSON.stringify(capture(JSON.parse(raw))));"
    def managed_guard():
        guard();factory.lease();r=subprocess.run(['docker','exec','-i','synapse-content-1','node','--disable-warning=ExperimentalWarning','-e',invocation],input=encoded({'old':factory.managed,'plan':plan}),capture_output=True,timeout=90)
        need(r.returncode==0 and not r.stderr and len(r.stdout)<=32768,'CORRECTED_NATIVE141_READBACK_REFUSED');v=json.loads(r.stdout)
        need(v.get('status')=='EXACT_NATIVE141_READONLY_NOT_INSTALL_ACCEPTANCE' and v.get('runtimeWrites')==0 and v.get('historicalUnchanged') is True and v.get('currentVersion')==receipt['currentVersion'] and v.get('currentRevision')==receipt['currentRevision'] and v.get('full141FactsSha256')==receipt['full141FactsSha256'],'EXACT_COMPLETION_RECEIPT_READBACK_REQUIRED');guard();factory.lease();return v
    result=controller.finish(pending,receipt,managed_guard) if a.mode=='finish' else controller.accept(installed,receipt,managed_guard,lambda:private_json(bindings['wholeAppAcceptance']))
    print(json.dumps({'status':result.get('status'),'runtimeAcceptance':result.get('runtimeAcceptance',False),'runtimePackageSha256':RUNTIME_SHA,'completionManifestSha256':a.manifest_sha,'automaticRetry':False,'automaticRestore':False}));return 0

if __name__=='__main__':
    try:raise SystemExit(main())
    except Exception as e:
        code=str(e) if type(e) is ValueError and re.fullmatch('[A-Z][A-Z0-9_]{0,120}',str(e)) else type(e).__name__
        print(json.dumps({'status':'REFUSED_OR_UNKNOWN_NO_AUTOMATIC_RETRY','code':code,'automaticRetry':False,'automaticRestore':False}));raise SystemExit(2)
