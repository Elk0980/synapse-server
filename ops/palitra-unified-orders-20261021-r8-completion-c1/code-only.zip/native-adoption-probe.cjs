'use strict';
// New read-only 140 ->141 verifier. Never saves/publishes or changes a pointer.
const fs=require('node:fs'),crypto=require('node:crypto'),{DatabaseSync}=require('node:sqlite');
const SITE='site-44bbe13f1bad5e005b2a',COMPANY='palitra-love';
const PREFIX='/data/projects/'+COMPANY+'/sites/'+SITE+'/versions/';
const PRICE='79d62dd78fc00347758c248a2b733e407bdacccf6094fe0a8f3e69f01c7a5943';
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const need=(v,c)=>{if(!v)throw Error(c);};
function canonical(v){return Array.isArray(v)?'['+v.map(canonical).join(',')+']':v&&typeof v==='object'?'{'+Object.keys(v).sort().map(k=>JSON.stringify(k)+':'+canonical(v[k])).join(',')+'}':JSON.stringify(v);}
function relative(n){return typeof n==='string'&&n.length>0&&n.length<1024&&!/[\\:\x00-\x1f]/.test(n)&&!n.startsWith('/')&&n.split('/').every(p=>p&&p!=='.'&&p!=='..');}
const same=(a,b,c)=>need(canonical(a)===canonical(b),c);
function inventory(root,manifest,count){
  need(count===140||count===141,'EXACT_COUNT_REQUIRED');const files={},directories={};let bytes=0;
  function walk(folder,rel){const s=fs.lstatSync(folder);need(s.isDirectory()&&!s.isSymbolicLink()&&fs.realpathSync(folder)===folder,'MANAGED_DIRECTORY_ALIAS');directories[rel||'.']={uid:s.uid,gid:s.gid,mode:s.mode&511};
    for(const n of fs.readdirSync(folder).sort()){
      const p=folder+'/'+n,r=rel?rel+'/'+n:n;need(relative(r),'MANAGED_PATH');const a=fs.lstatSync(p);
      need(!a.isSymbolicLink()&&fs.realpathSync(p)===p,'MANAGED_ALIAS');
      if(a.isDirectory()){walk(p,r);continue;}
      need(a.isFile()&&a.nlink===1&&a.size<=32*1024*1024&&(a.mode&0o7000)===0&&(bytes+=a.size)<=512*1024*1024,'MANAGED_FILE_BOUND');
      const fd=fs.openSync(p,fs.constants.O_RDONLY|fs.constants.O_NOFOLLOW|fs.constants.O_NONBLOCK);let raw;
      try{const b=fs.fstatSync(fd);raw=fs.readFileSync(fd);const z=fs.fstatSync(fd),q=fs.lstatSync(p);for(const k of ['dev','ino','mode','uid','gid','size','nlink','mtimeMs','ctimeMs'])need(a[k]===b[k]&&a[k]===z[k]&&a[k]===q[k],'MANAGED_READ_RACE');need(raw.length===a.size,'MANAGED_READ_SIZE');}finally{fs.closeSync(fd);}
      files[r]={sha256:hash(raw),bytes:raw.length,uid:a.uid,gid:a.gid,mode:a.mode&511,nlink:a.nlink,regular:true,canonical:true};need(Object.keys(files).length<=count,'MANAGED_FILE_COUNT');
    }
  }
  walk(root,'');need(Object.keys(files).length===count&&Object.keys(manifest).length===count,'MANAGED_CLOSED_COUNT');same(Object.keys(files).sort(),Object.keys(manifest).sort(),'MANAGED_MANIFEST_SET');
  for(const n of Object.keys(files)){const m=manifest[n];need(m&&m.sha256===files[n].sha256&&m.bytes===files[n].bytes,'MANAGED_MANIFEST_BYTES');}
  return {files,directories,factsSha256:hash(canonical(files)),directoriesSha256:hash(canonical(directories)),fileCount:count};
}
function validate(old,plan,current,historical,apiPrice){
  need(old.current260.version===260&&current.version>260&&current.fileCount===141,'EXACT_FORWARD_VERSION141');
  for(const key of ['historical257','historical259','current260'])same(historical[key],old[key],'HISTORICAL_MANAGED_DRIFT');
  same(apiPrice,old.apiPrice,'API_PRICE_CHANGED');need(apiPrice.sha256===PRICE,'EXACT_PRICE_PIN');
  const before=old.current260;need(before.fileCount===140&&before.mismatches.length===0,'CLEAN260_BASIS');same(current.directories,before.directories,'DIRECTORIES_CHANGED');
  const changes=plan.changedFiles;need(changes&&Object.keys(changes).sort().join('|')==='assets/order.js|assets/palitra-attribution.js|assets/storefront.js','EXACT_THREE_NATIVE_INPUTS');
  same(Object.keys(current.files).sort(),Object.keys(before.files).concat('assets/palitra-attribution.js').sort(),'EXACT141_PATH_DELTA');
  for(const n of Object.keys(before.files)){
    const a={...before.files[n]},b={...current.files[n]};
    if(n==='assets/order.js'||n==='assets/storefront.js'){need(b.sha256===changes[n],'REVIEWED_MANAGED_PAYLOAD');delete a.sha256;delete a.bytes;delete b.sha256;delete b.bytes;}
    same(a,b,'OTHER_MANAGED_FILE_DRIFT');
    const ma={...before.manifest[n]},mb={...current.manifest[n]};
    if(n==='assets/order.js'||n==='assets/storefront.js'){delete ma.sha256;delete ma.bytes;delete mb.sha256;delete mb.bytes;}
    same(ma,mb,'OTHER_MANAGED_MANIFEST_DRIFT');
  }
  const added={...current.files['assets/palitra-attribution.js']};need(added.sha256===changes['assets/palitra-attribution.js'],'TRACKER_PAYLOAD');delete added.sha256;delete added.bytes;same(added,plan.newTrackerMetadata,'REVIEWED_NATIVE_NEW_FILE_METADATA');
  same(current.files['data/price.json'],before.files['data/price.json'],'SEALED_STORED_PRICE_CHANGED');return true;
}
function capture(input){
  const {old,plan}=input;const db=new DatabaseSync('/data/content.sqlite',{readOnly:true});let result;
  try{
    db.exec('PRAGMA query_only=ON;BEGIN');
    const workspace=()=>{const r=db.prepare('SELECT m.id,m.company_code,m.publication_status,w.current_revision FROM managed_sites m JOIN site_workspaces w ON w.site_id=m.id WHERE m.id=?').get(SITE);need(r&&r.id===SITE&&r.company_code===COMPANY&&/^[a-f0-9]{64}$/.test(r.current_revision),'EXACT_WORKSPACE');return {...r};};
    const before=workspace();const normalized={...before,current_revision:old.workspace.current_revision};same(normalized,old.workspace,'WORKSPACE_FIELDS_CHANGED');
    function seal(rev,count){need(/^[a-f0-9]{64}$/.test(rev),'EXACT_REVISION');const r=db.prepare('SELECT version,manifest_json FROM site_workspace_revisions WHERE site_id=? AND revision=?').get(SITE,rev);need(r&&Number.isSafeInteger(r.version)&&typeof r.manifest_json==='string'&&Buffer.byteLength(r.manifest_json)<=1024*1024,'BOUNDED_REVISION');const manifest=JSON.parse(r.manifest_json),root=PREFIX+rev;const first=inventory(root,manifest,count);same(first,inventory(root,manifest,count),'MANAGED_CHANGED_DURING_INVENTORY');return {revision:rev,version:r.version,root,manifestSha256:hash(r.manifest_json),manifestBytes:Buffer.byteLength(r.manifest_json),rootFacts:first.directories['.'],...first,mismatches:[],pricePath:'data/price.json',selected:Object.fromEntries(['dostavka-i-oplata/index.html','assets/order.js','assets/storefront.js','data/price.json'].map(n=>[n,first.files[n]])),manifest};}
    const historical={};for(const key of ['historical257','historical259','current260']){
      // Historical257 may have sealed pre-existing manifest drift. It must be
      // preserved byte-exact, not silently rewritten as a clean new version.
      const expected=old[key],root=expected.root;need(root===PREFIX+expected.revision,'HISTORICAL_ROOT');
      const row=db.prepare('SELECT version,manifest_json FROM site_workspace_revisions WHERE site_id=? AND revision=?').get(SITE,expected.revision);need(row&&row.version===expected.version&&hash(row.manifest_json)===expected.manifestSha256,'HISTORICAL_REVISION_CHANGED');
      const actual=inventory(root,Object.fromEntries(Object.entries(expected.files).map(([n,r])=>[n,{sha256:r.sha256,bytes:r.bytes}])),140);same(actual.files,expected.files,'HISTORICAL_FILES_DRIFT');same(actual.directories,expected.directories,'HISTORICAL_DIRECTORIES_DRIFT');historical[key]=expected;
    }
    const current=seal(before.current_revision,141),price=db.prepare('SELECT id,version,body FROM documents WHERE key=? ORDER BY version DESC LIMIT 1').get('palitra/price');need(price&&typeof price.body==='string','PRICE_DOCUMENT');const apiPrice={key:'palitra/price',id:price.id,version:price.version,sha256:hash(Buffer.from(price.body)),bytes:Buffer.byteLength(price.body)};
    validate(old,plan,current,historical,apiPrice);same(workspace(),before,'POINTER_CHANGED_DURING_CAPTURE');
    result={schema:'palitra-unified-native-adoption-readback/v1',status:'EXACT_NATIVE141_READONLY_NOT_INSTALL_ACCEPTANCE',currentVersion:current.version,currentRevision:current.revision,full141FactsSha256:current.factsSha256,workspaceSha256:hash(canonical(before)),apiPriceSha256:apiPrice.sha256,historicalUnchanged:true,runtimeWrites:0};db.exec('ROLLBACK');
  }finally{db.close();}
  return result;
}
module.exports={canonical,validate,inventory,capture};
