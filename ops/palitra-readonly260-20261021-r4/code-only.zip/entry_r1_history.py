"""Exact retained entry-R1 stop and its separately accepted sealed transition.

Never rewrites/promotes an UNKNOWN journal. No old module/Native/entry executes.
Predicates are taken from the byte-pinned ACK parent-entry-r1 read contract.
"""
import copy,hashlib,json,re
from pathlib import Path,PurePosixPath
NAME='palitra-client-order-entry-20261020-r1'
ACK='palitra-client-order-ack-20261020-r3'
IMAGE='sha256:c2f110af73c127fadceba6b60e5225311835aea404a4bb10125b9e80b958f622'
ACK_IMAGE='sha256:562fa1206c15f3e5e344c1e093052aa9e4171a51abd001fb29068ddc6092d8f7'
PINS={'manifest.json':'2b4469cd2444ec5a6a276efad592ac4fa2e892b2f977756132bf8db1bd4bd553','company-app.py':'c122a3952eefa2e305eb49b0eb20a5ef18b1181185d15f06cd51a3f1980c3c8b','native.py':'0b17f6acdb64c45a48bb2dcb5286b26acee653473b8df3da8a3998ee0e0ed75d','controller.py':'55a9371cafdb152290a8108e17a383799fc184c320c08be2d676bd439cd8ffb1','journal':'754961b8765093933ee442bf4df40495a61a4472264192dee9baf5174cf2e667','root-post-up-audit':'b2520bdbc12fe90ba8bc8b3c42105c38bcdde16870bdf142ac8f2275a90744ae','decision':'15c7a3790ccbac3c8abd770841d2c3c812cde2ab6706ea1080b2990766108829','root-acceptance':'824c08c670564bbbca560807f90c8109a05b8443153beb1dd532732a7e4da326','preflight':'10eb7779947875302250db506e7edb15cd0c5a9fba3237f42c66eb488ccbdfe5','ack-journal':'f09443b415cfa5959f95f0fce7235ae013c853d595a85cdb6ded284cb85f901a'}
BINDING={'schema':1,'namespace':NAME,'manifestSha256':PINS['manifest.json'],'entrySha256':PINS['company-app.py'],'codeAcceptanceSha256':'3c1442523892785a141564089b54903b4ff20291408becddf26aff9aabf372ff','nativeBasisSha256':'a846136b3a12060b11450050dc39cf1e73a715761511de7b63957fa9464a3530','parentImage':'sha256:0d8a86b8ace8ea919c389aa07cef2ce71e527fd618f2e7acf290c6b2ede9032c','target':'palitra-orders-public/shell.js','beforeSha256':'9e36a2380cfe1c2282e41e79af2b1d04f91f7cf4577d8b7cd505b3a62f5d2f71','afterSha256':'94fafe89342b9f74777b9fcac544b1533e9941e7e099f19ff249cb9e9d8c09ee','leasePid':3242810,'payloadScopeSha256':'8727be13a09e9b5b01df84443e5a677f06409630767dbeaf5fcdba75c078e526','uiReviewSha256':'2a1a411341b54855f588df26ad932c94dbbd3cc2cd2cacfed371375c6983d427','htmlReviewSha256':'46d69e15fa0237f875afefd810b773b51fb542e8caf7ecb516faaf7810de1869'}
STATUS='EXACT_ACCEPTED_ENTRY_R1_SUPPLEMENTAL_TRANSITION_NOT_PHASE_PROMOTION'
FORWARD=(NAME,ACK,'palitra-client-quickfix-20261020-r4','palitra-client-chat-offers-20261020-r1','palitra-request-groups-20261020-r1','palitra-request-groups-20261020-r2','palitra-clear-orders-guard-20261020-r1')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encoded=lambda value:json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def need(v,c):
    if not v:raise ValueError(c)
def collect_stages(root,overlays,history,pinned):
    """Closed seven actual modern layouts; records are mandatory for every row."""
    root=Path(root)
    need(overlays==[str(root/(name+'-overlay.json')) for name in FORWARD],'EXACT_SEVEN_FORWARD_OVERLAYS_REQUIRED')
    stages=[];storage=[]
    for index,name in enumerate(FORWARD):
        journal=str(root/(name+'-journal.json'))
        need(journal in history['artifacts'] and journal in history['pins'],'EXACT_FORWARD_JOURNAL_PIN_REQUIRED')
        obj=history['artifacts'][journal];raw=pinned(journal,history['pins'][journal]);need(json.loads(raw)==obj and obj['name']==name,'EXACT_FORWARD_JOURNAL_NAME_REQUIRED')
        phase='CONTENT_UP_STARTED_UNKNOWN' if index==0 else 'APPLIED_NOT_CUSTOMER_ACCEPTANCE'
        need(obj.get('phase')==phase and type(obj.get('codeBackups',{}).get('static')) is list,'EXACT_FORWARD_PHASE_AND_MODERN_STATIC_REQUIRED')
        code=root/(name+'-code');mp=obj['binding']['manifestSha256'];mr=pinned(code/'manifest.json',mp);manifest=json.loads(mr)
        need(manifest['name']==name and manifest['FROZEN'] is True and manifest['runtimeAuthorization'] is False,'EXACT_FORWARD_FROZEN_MANIFEST_REQUIRED')
        matches=[r for r in manifest['files'] if r['path']=='records.json'];need(len(matches)==1,'PINNED_STATIC_RECORDS_REQUIRED')
        rr=pinned(code/'records.json',matches[0]['sha256']);records=json.loads(rr)
        need(len(rr)==matches[0]['bytes'] and records['name']==name and sha(rr)==obj['binding']['payloadScopeSha256'],'EXACT_FORWARD_RECORD_SCOPE_REQUIRED')
        for path,pin in [(str(code/'manifest.json'),mp),(str(code/'records.json'),matches[0]['sha256'])]:
            need(path not in history['pins'] or history['pins'][path]==pin,'FORWARD_HISTORY_PIN_CONFLICT');history['pins'][path]=pin
        stage={'receiptBytes':raw,'receiptSha256':history['pins'][journal],'manifestBytes':mr,'manifestSha256':mp,'recordsBytes':rr}
        stages.append(stage);storage.append((obj,records['records'],stage))
    return stages,storage
def load(root,pinned,history,stage,successor,baseline,canonical):
    root=Path(root);code=root/(NAME+'-code');raws={};pins={}
    def take(path,pin):
        raw=pinned(path,pin);need(sha(raw)==pin,'EXACT_SUPPLEMENTAL_INPUT_PIN_REQUIRED')
        label=str(path);need(label not in history['pins'] or history['pins'][label]==pin,'SUPPLEMENTAL_HISTORY_PIN_CONFLICT')
        pins[label]=pin;history['pins'][label]=pin
        if label.endswith('.json'):history['artifacts'][label]=json.loads(raw)
        return raw
    for name in ('company-app.py','native.py','controller.py','manifest.json'):raws[name]=take(code/name,PINS[name])
    for suffix in ('journal','decision','root-acceptance','preflight','root-post-up-audit'):raws[suffix]=take(root/(NAME+'-'+suffix+'.json'),PINS[suffix])
    manifest=json.loads(raws['manifest.json'])
    need(manifest.get('name')==NAME and manifest.get('FROZEN') is True and manifest.get('status')=='LOCAL_FROZEN_CODE_ONLY' and manifest.get('runtimeAuthorization') is False,'EXACT_SUPPLEMENTAL_FROZEN_MANIFEST_REQUIRED')
    seen=set()
    for row in manifest['files']:
        name=row['path'];p=PurePosixPath(name)
        need(type(name) is str and name and p.as_posix()==name and not p.is_absolute() and '..' not in p.parts and name not in seen,'SUPPLEMENTAL_CLOSED_MANIFEST_PATH_REQUIRED');seen.add(name)
        raw=take(code/name,row['sha256']);need(len(raw)==row['bytes'],'SUPPLEMENTAL_MANIFEST_SIZE_CHANGED')
    need(raws['journal']==stage['receiptBytes'] and raws['manifest.json']==stage['manifestBytes'] and str(code/'records.json') in pins and sha(stage['recordsBytes'])==BINDING['payloadScopeSha256'],'EXACT_SUPPLEMENTAL_STAGE_REQUIRED')
    need(successor['receiptSha256']==PINS['ack-journal'] and sha(successor['receiptBytes'])==PINS['ack-journal'],'EXACT_ACCEPTED_ACK_SUCCESSOR_REQUIRED')
    proof=validate(root,raws,pins,json.loads(stage['recordsBytes'])['records'],json.loads(successor['receiptBytes']),baseline,canonical)
    state=json.loads(raws['journal']);overlay=root/(NAME+'-overlay.json');overlay_raw=take(overlay,state['overlaySha256'])
    need(json.loads(overlay_raw)=={'services':{'content':{'image':IMAGE}}},'EXACT_ENTRY_CONTENT_ONLY_OVERLAY_REQUIRED')
    return proof
def validate(root,raws,pins,records,successor,baseline,canonical):
    """Pure predicate set; all raw bytes have already been exact-pin read."""
    state,decision,preflight,acceptance,audit=(json.loads(raws[k]) for k in ('journal','decision','preflight','root-acceptance','root-post-up-audit'))
    need(state['name']==NAME and state['phase']=='CONTENT_UP_STARTED_UNKNOWN' and state['decisionSha256']==PINS['decision'] and state['childImage']==IMAGE,'EXACT_RETAINED_ENTRY_STOP_REQUIRED')
    need(state['binding']==decision['binding']==preflight['binding']==BINDING and state['before']==decision['before']==preflight['before']==baseline['after'],'EXACT_ENTRY_HISTORICAL_BINDING_AND_BASE_REQUIRED')
    need(decision['rootAcceptanceSha256']==PINS['root-acceptance'] and decision['preflightSha256']==PINS['preflight'] and acceptance['preflightSha256']==PINS['preflight'] and acceptance['leasePid']==3242810 and acceptance['nonce']==decision['nonce'] and acceptance['oneApply'] is True,'EXACT_ENTRY_ADMISSION_LINKS_REQUIRED')
    need(all(acceptance.get(k)==BINDING[k] for k in ('namespace','manifestSha256','entrySha256','codeAcceptanceSha256','nativeBasisSha256','leasePid','parentImage','payloadScopeSha256','uiReviewSha256','htmlReviewSha256')),'EXACT_ENTRY_ADMISSION_BINDING_REQUIRED')
    need(audit['schema']==1 and audit['namespace']==NAME and audit['status']=='INSTALLED_ACCEPTED_BY_SUPPLEMENTAL_RUNTIME_AUDIT_NOT_CUSTOMER_ACCEPTANCE' and audit['originalJournalUnchanged'] is True and audit['originalJournalPhase']=='CONTENT_UP_STARTED_UNKNOWN' and audit['originalGuardStop']=='POST_UP_NORMALIZED_RUNTIME_CHANGED' and audit['originalGuardResultRetained'] is True and audit['noRepeatOfApplyBuildUp'] is True and audit['runtimeAuthorization'] is False and audit['leasePid']==3242810 and audit['childImage']==IMAGE and audit['sourceFiles']==239 and audit['staticFiles']==43 and audit['chainFiles']==43 and audit['runtimeDatabaseWrites']==audit['schemaChanges']==audit['runtimeMutations']==0 and audit['schemasDataAndPrefixesPreserved'] is True and audit['workerAuthPushPricePreserved'] is True,'EXACT_ACCEPTED_SUPPLEMENTAL_AUDIT_REQUIRED')
    audit_path=str(Path(root)/(NAME+'-root-post-up-audit.json'))
    need(audit['inputPins']=={p:pin for p,pin in pins.items() if p!=audit_path},'EXACT_ENTRY_AUDIT_INPUT_CLOSURE_REQUIRED')
    static_targets=sorted([str(PurePosixPath('/opt/synapse/sites/synapse/cabinet/palitra-orders')/r['static']) for r in records if r.get('static') is not None],key=lambda p:(PurePosixPath(p).name=='cabinet.html',p))
    need(len(records)==4 and len(static_targets)==3 and state['automaticRetry'] is False and state['automaticRollback'] is False and state['runtimeDatabaseWrites']==state['schemaChanges']==0 and state['workerRecreated'] is False and state['staticChanges']==3 and state['written']==static_targets and audit['databaseBackups']==state['backups'] and audit['codeBackups']==state['codeBackups'] and audit['contextPins']==state['contextPins'] and audit['minimumBeforeUp']==state['minimumBeforeUp'],'EXACT_ENTRY_CODE_ONLY_EFFECT_REQUIRED')
    overlay=str(Path(root)/(NAME+'-overlay.json'));overlay_pin=state['overlaySha256'];before=state['before'];base=copy.deepcopy(audit['after']);chain=before['containers']['content']['files']+[overlay]
    expected_content=copy.deepcopy(before['containers']['content']);expected_content.update(image=IMAGE,files=chain,configFiles=','.join(chain),filePins={**expected_content['filePins'],overlay:overlay_pin},configHash=state['plannedConfigHash'])
    need(len(chain)==len(set(chain))==43 and base['containers']['content']==expected_content and base['containers']['chat']==before['containers']['chat'] and base['contentCid']==audit['runningContentId'] and base['contentCid']!=before['contentCid'] and all(base[k]==before[k] for k in ('worker','selected','l12','sourceModes','staticModes')),'EXACT_ENTRY_FULL239_43_43_REQUIRED')
    host=audit['hostBindOrderProof'];actual=host['actualHostConfig'];prior=host['reconstructedPriorHostConfig'];order=host['permutation']
    need(host['status']=='EXACT_FULL_PRIOR_HOST_CONFIG_REPRODUCED' and host['field']=='Binds' and host['count']==9 and host['sameNineBindingsOnlyOrderChanged'] is True and host['allOtherHostConfigFieldsByteEquivalent'] is True and len(actual['Binds'])==len(set(actual['Binds']))==9 and len(order)==9 and set(order)==set(range(9)) and prior==dict(actual,Binds=[actual['Binds'][i] for i in order]) and sha(encoded(actual))==host['actualHostConfigSha256']==base['runtime']['hostConfigSha256'] and sha(encoded(prior))==host['beforeHostConfigSha256']==before['runtime']['hostConfigSha256'],'EXACT_ENTRY_NINE_BIND_ORDER_PROOF_REQUIRED')
    need({k:v for k,v in before['runtime'].items() if k not in ('appTree','hostConfigSha256')}=={k:v for k,v in base['runtime'].items() if k not in ('appTree','hostConfigSha256')} and audit['runtimeDifferenceProof']=={'different':['hostConfigSha256'],'otherFiveRuntimeHashesEqual':True},'EXACT_ENTRY_OTHER_RUNTIME_FACTS_REQUIRED')
    tree=copy.deepcopy(before['runtime']['appTree'])
    for row in records:
        target=row['target'];need(tree[target]['sha256']==row['beforeSha256'] and tree[target]['type']=='file' and tree[target]['nlink']==1,'EXACT_ENTRY_PRIOR_SOURCE_REQUIRED');tree[target].update(sha256=row['sha256'],bytes=row['bytes'])
    need(base['runtime']['appTree']==tree and len(base['sourceModes'])==239 and len(base['staticModes'])==43,'EXACT_ENTRY_FULL_SOURCE_TRANSITION_REQUIRED')
    child=state['childProof'];need(child==audit['childProof'] and child['image']==IMAGE and child['sourceFiles']==239 and child['changedTargets']==sorted(r['target'] for r in records) and child['appTreeSha256']==sha(encoded(tree)),'EXACT_ENTRY_CHILD_PROOF_REQUIRED')
    platform=child['platformImageBinding'];need(platform['target']==IMAGE and platform['platform']=='linux/amd64' and type(platform['manifestDigest']) is str and re.fullmatch('sha256:[a-f0-9]{64}',platform['manifestDigest']) is not None,'EXACT_ENTRY_PLATFORM_BINDING_REQUIRED')
    base['runtime']['hostConfigSha256']=sha(encoded(canonical(actual)))
    need(successor['name']==ACK and successor['phase']=='APPLIED_NOT_CUSTOMER_ACCEPTANCE' and successor['childImage']==ACK_IMAGE and successor['before']==base,'EXACT_SEALED_ACK_TRANSITION_REQUIRED')
    return {'status':STATUS,'receiptSha256':PINS['journal'],'auditSha256':PINS['root-post-up-audit'],'successorSha256':PINS['ack-journal'],'retainedPhase':'CONTENT_UP_STARTED_UNKNOWN','runtimeAuthorization':False,'rows':[{'target':str(PurePosixPath('/opt/synapse/sites/synapse/cabinet/palitra-orders')/r['static']),'beforeSha256':r['beforeSha256'],'sha256':r['sha256']} for r in records if r.get('static') is not None]}
