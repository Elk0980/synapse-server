"""Frozen code entry. Runtime requires independent fresh admission; no defaults."""
import argparse, hashlib, json, os, stat, sys, types
from pathlib import Path
sys.dont_write_bytecode = True
CODE = Path('/opt/synapse/releases/palitra-app-20261015/report-day-source20-cache-20261020-r1-code')
MANIFEST_SHA = 'af27d93d443302d70f80e1228e73dc9c05b295cd2418e6d7d40f5c7122454f7d'
def need(ok, code):
    if not ok: raise ValueError(code)
def sha(raw): return hashlib.sha256(raw).hexdigest()
def read(path):
    for part in [path, *path.parents]:
        need(not part.is_symlink(), 'CODE_ALIAS_REFUSED')
    s = path.lstat()
    need(stat.S_ISREG(s.st_mode) and s.st_nlink == 1 and s.st_uid == s.st_gid == 0
         and stat.S_IMODE(s.st_mode) == 0o600, 'PRIVATE_SINGLE_LINK_CODE_REQUIRED')
    need(s.st_size <= 4*1024*1024, 'BOUNDED_CODE_REQUIRED')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'rb') as file:
        before = os.fstat(file.fileno()); raw = file.read(4*1024*1024+1); after = os.fstat(file.fileno())
    final = path.lstat()
    fields = ('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
    need(all(getattr(s,k)==getattr(before,k)==getattr(after,k)==getattr(final,k) for k in fields)
         and len(raw)==s.st_size, 'CODE_CHANGED_DURING_READ')
    return raw
def load(raw, path):
    module=types.ModuleType('exact_day_code');module.__file__=str(path)
    exec(compile(raw,str(path),'exec'),module.__dict__);return module
def main():
    need(os.name=='posix' and os.geteuid()==0 and Path(__file__)==CODE/'company-app.py', 'EXACT_POSIX_ROOT_CODE_REQUIRED')
    for part in (CODE, CODE/'payload'):
        s=part.lstat();need(stat.S_ISDIR(s.st_mode) and s.st_uid==s.st_gid==0 and stat.S_IMODE(s.st_mode)==0o700 and not part.is_symlink(), 'PRIVATE_CODE_DIRECTORY_REQUIRED')
    raw=read(CODE/'manifest.json');need(sha(raw)==MANIFEST_SHA,'FROZEN_MANIFEST_CHANGED');m=json.loads(raw)
    need(m['name']=='report-day-source20-cache-20261020-r1' and m['status']=='LOCAL_FROZEN_CODE_ONLY' and m['runtimeAuthorization'] is False,'CODE_ONLY_MANIFEST_REQUIRED')
    wanted={r['path'] for r in m['files']}|{'manifest.json','company-app.py'}
    found={p.relative_to(CODE).as_posix() for p in CODE.rglob('*') if not p.is_dir()}
    need(found==wanted and {p.relative_to(CODE).as_posix() for p in CODE.rglob('*') if p.is_dir()}=={'payload'},'CLOSED_CODE_PACKAGE_REQUIRED')
    sealed={}
    for r in m['files']:
        value=read(CODE/r['path']);need(len(value)==r['bytes'] and sha(value)==r['sha256'],'EXACT_FROZEN_HELPER_REQUIRED');sealed[r['path']]=value
    entry=read(CODE/'company-app.py')
    parser=argparse.ArgumentParser();parser.add_argument('command',choices=('preflight','approve','apply','inspect','rollback-plan'))
    parser.add_argument('--lease-pid',type=int,required=True);parser.add_argument('--root-acceptance-sha');parser.add_argument('--decision-sha');parser.add_argument('--receipt-sha');parser.add_argument('--apply',action='store_true')
    args=parser.parse_args()
    controller=load(sealed['controller.py'],CODE/'controller.py');native=load(sealed['native.py'],CODE/'native.py').Native(args.lease_pid)
    release=controller.Release(native,MANIFEST_SHA,sha(entry))
    if args.command=='preflight':result=release.preflight()
    elif args.command=='approve':result=release.approve(args.root_acceptance_sha)
    elif args.command=='apply':result=release.apply(args.decision_sha,args.apply)
    elif args.command=='inspect':result=release.inspect(args.receipt_sha)
    else:result=load(sealed['rollback-plan.py'],CODE/'rollback-plan.py').plan(release,args.receipt_sha)
    print(json.dumps(result,ensure_ascii=False,separators=(',',':')))
if __name__=='__main__':
    try:main()
    except Exception:
        print(json.dumps({'status':'REFUSED_OR_UNKNOWN_NO_RETRY','runtimeAcceptance':False}),file=sys.stderr)
        sys.exit(1)
