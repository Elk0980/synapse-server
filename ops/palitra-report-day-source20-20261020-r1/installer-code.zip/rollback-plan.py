"""Read-only concrete rollback descriptor; never executes up or restores data."""
import hashlib
import json
from pathlib import Path

PARENT = 'sha256:0d8a86b8ace8ea919c389aa07cef2ce71e527fd618f2e7acf290c6b2ede9032c'
NAME = 'report-day-source20-cache-20261020-r1'
TARGET = 'company-app/customer-report-cache.cjs'
BEFORE = '3fca5842514e2ba770ea19b94183002a437cae9b065358537055fa3772d23d92'
AFTER = '5fb7f5ca7f897d04bd2c4907ad8422122209fa1df37d2a8a52b5fcdb4fbf7e70'
ROOT = Path('/opt/synapse/releases/palitra-app-20261015')


def plan(release, receipt_pin):
    # inspect requires own completed pinned receipt and a fresh actual read lease.
    # UNKNOWN or absent installations cannot produce this descriptor.
    release.inspect(receipt_pin)
    state = release.a.pinned(release.paths['journal'], receipt_pin, True)
    if state['binding']['parentImage'] != PARENT or state['name'] != NAME:
        raise ValueError('EXACT_FORWARD_COMPLETED_RECEIPT_REQUIRED')
    files = state['after']['containers']['content']['files']
    if len(files) != len(set(files)) or len(files) != 43:
        raise ValueError('EXACT_FORWARD_CHAIN43_REQUIRED')
    overlay = ROOT / (NAME + '-rollback-r1-overlay.json')
    raw = json.dumps({'services': {'content': {'image': PARENT}}}, sort_keys=True, separators=(',', ':')).encode()
    if str(overlay) in files:
        raise ValueError('FRESH_ROLLBACK_NAMESPACE_REQUIRED')
    prefix = ['docker', 'compose'] + [arg for file in [*files, str(overlay)] for arg in ('-f', file)]
    return {
        'schema': 1, 'status': 'PLAN_ONLY_NOT_ROLLBACK_AUTHORIZATION',
        'namespace': NAME + '-rollback-r1', 'forwardReceiptSha256': receipt_pin,
        'fromImage': state['childImage'], 'toImage': PARENT,
        'currentCidRequired': state['after']['contentCid'],
        'overlayPath': str(overlay), 'overlayUtf8': raw.decode(),
        'overlaySha256': hashlib.sha256(raw).hexdigest(),
        'composeFilesBefore': files, 'composeFilesAfter': [*files, str(overlay)],
        'planArgv': prefix + ['config', '--hash', 'content'],
        'oneUpArgv': prefix + ['up', '-d', '--no-deps', '--no-build', '--pull', 'never', 'content'],
        'expectedSourceFiles': 239, 'expectedStaticFiles': 43, 'expectedChainFiles': 44,
        'onlySourceReversal': {'path': TARGET, 'fromSha256': AFTER, 'toSha256': BEFORE},
        'mandatoryBeforeExecution': [
            'Fresh actual own lease; old writer PID is not authorization',
            'Fresh full child/source239/static43/chain43/worker/env/mount/CID CAS',
            'Verify exact preserved parent image and full tree before code reversal',
            'New pinned Root rollback admission bound to this receipt/current facts/new lease and expiry',
            'New EXCL UNKNOWN journal before mutation; never replay old apply/approve',
            'Final rollback compose plan, then fresh consistent report/content/traffic backups',
            'Recheck current data prefix, all seals, CAS, lease and expiry immediately before one up',
            'Verify parent source239/static43/chain44 with unchanged normalized runtime and current data'
        ],
        'databaseRestore': False, 'schemaChanges': 0, 'staticChanges': 0,
        'workerRecreated': False, 'automaticRetry': False, 'automaticRollback': False,
        'unknownRule': 'Read-only diagnosis first; no blind forward or rollback retry',
        'dataRule': 'Keep live newer user rows/WAL and import receipts; never restore old DB backups'
    }
