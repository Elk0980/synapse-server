"""Independent immutable context/code/DB-backup boundary checks.

Only exact byte-pinned completed journals are inputs. No old release methods
execute, and an unrecognised completed format refuses instead of passing.
"""
import hashlib,json,os,re,stat
from pathlib import Path,PurePosixPath

sha=lambda raw:hashlib.sha256(raw).hexdigest()
REPORT_GUARD_SHA='08456dc9fcfae875b22c631a461e0cedea5a702b5f8d43ae770de7cff6e78a63'
LEGACY_CONTEXTS={
 'multi-company-app-20261019-r3':{'receipt':'1e35fab2235f9acbdda2f114da61338b9bc13deaec109a12fd7798c242222b7b','helper':'13d967286f9858b282a36b52c65e2ef4cf5fcb725de928915fc2c1eecf184616','manifest':'4467e8d052f0e680ff18935e7ffb62e9e71368812f2f4dea1e13ebadf1314c75','records':21,'sources':6,'static':11,'reportBackup':False},
 'multi-company-app-20261019-r5':{'receipt':'9dae816f03ab641c702b20e746ac65fb5f2b3a657f06d3fcc820a7b5df48438a','helper':'b9108632e8f1d1cba15a6f0749c7b31642b1e12d4dd41b8b9aa9eb830b2848bd','manifest':'2ddecd2cfa48faf96c0bf9ff20291c941549d6f11e7ebbd671138441b5f47885','records':4,'sources':4,'static':4,'reportBackup':True},
 'multi-company-app-20261019-r6':{'receipt':'70c0489236d120a84074b3a45acacc21c3e26e3fe42408b8324af8439280d0ea','helper':'1f4b048551ba20309e129212a269ed53765cd99997802ee2b16d6985cfc46de0','manifest':'0157a28111ea0056422c3143d2c886805d69716d9fb5cc6332ecd09b31ecefd2','records':4,'sources':4,'static':4,'reportBackup':True}}

def need(value,code):
    if not value:raise ValueError(code)

def legacy_contract(journal,receipt_sha):
    """Only the three exact pre-content/traffic storage contracts differ.

    Their original context and backup methods were compared as AST/code; no
    historical constructor, loader, controller or writer is imported/executed.
    """
    need(type(journal) is dict and journal.get('phase')=='APPLIED_NOT_CUSTOMER_ACCEPTANCE','EXACT_COMPLETED_LEGACY_CONTEXT_REQUIRED')
    profile=LEGACY_CONTEXTS.get(journal.get('name'))
    if profile is None:
        need(all(field in journal for field in ('sourceBackups','reportDatabaseBackup','contentDatabaseBackup','trafficDatabaseBackup')),'UNSUPPORTED_HISTORICAL_CONTEXT_FORMAT')
        return None
    inputs=journal.get('inputs',{})
    need(receipt_sha==profile['receipt'] and inputs.get('manifest')==profile['manifest'] and inputs.get('helper')==profile['helper'],'EXACT_OLD_CONTEXT_RECEIPT_HELPER_MANIFEST_REQUIRED')
    need(journal.get('automaticRetry') is False and journal.get('automaticCodeRollback') is False and journal.get('workerRecreated') is False and journal.get('mainDbDirectWrites')==journal.get('queueEdits')==journal.get('oldJournalWrites')==0,'EXACT_OLD_CONTEXT_CODE_ONLY_EFFECT_REQUIRED')
    need('sourceBackups' in journal and 'contentDatabaseBackup' not in journal and 'trafficDatabaseBackup' not in journal,'EXACT_PRE_CONTENT_TRAFFIC_BACKUP_CONTRACT_REQUIRED')
    if profile['reportBackup']:
        need(inputs.get('dbGuard')==REPORT_GUARD_SHA and type(journal.get('reportDatabaseBackup')) is dict,'EXACT_OLD_REPORT_BACKUP_CONTRACT_REQUIRED')
    else:
        need('reportDatabaseBackup' not in journal,'EXACT_R3_NO_PREEXISTING_REPORT_BACKUP_REQUIRED')
        need(journal.get('reportDatabaseBefore')=={'path':'/data/salon-reports.sqlite','files':{'db':None,'wal':None,'shm':None}},'EXACT_R3_ADMITTED_REPORT_ABSENCE_REQUIRED')
    return profile

def relative(value):
    return type(value) is str and value and not PurePosixPath(value).is_absolute() and PurePosixPath(value).as_posix()==value and '..' not in PurePosixPath(value).parts

def facts(path,directory=False,mode=None):
    path=Path(path)
    for p in [path,*path.parents]:need(not p.is_symlink(),'SEALED_STORAGE_ALIAS_REFUSED')
    s=path.lstat()
    need((stat.S_ISDIR(s.st_mode) if directory else stat.S_ISREG(s.st_mode) and s.st_nlink==1) and s.st_uid==s.st_gid==0,'ROOT_REGULAR_SEALED_STORAGE_REQUIRED')
    need(mode is None or stat.S_IMODE(s.st_mode)==mode,'SEALED_STORAGE_MODE_CHANGED')
    return s

def bytes_guard(path,pin,read,mode=0o600,size=None):
    before=facts(path,mode=mode);raw=read(path);after=facts(path,mode=mode)
    fields=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
    need(fields(before)==fields(after) and sha(raw)==pin and (size is None or len(raw)==size),'SEALED_STORAGE_BYTES_CHANGED');return raw

def context_guard(root,pins,read):
    """Current uniform completed releases: closed pins plus exact directories."""
    facts(root,True,0o700);need(type(pins) is dict and 3<=len(pins)<=1024 and 'Dockerfile' in pins and 'image.id' in pins,'EXACT_COMPLETED_CONTEXT_PINS_REQUIRED')
    need(all(relative(name) and type(row) is dict and set(row)=={'sha256','mode'} and re.fullmatch('[a-f0-9]{64}',row['sha256']) and row['mode'] in (0o600,0o644) for name,row in pins.items()),'CLOSED_CONTEXT_PIN_SCHEMA_REQUIRED')
    dirs={str(p) for name in pins for p in PurePosixPath(name).parents if str(p)!='.'}
    actual_files=set();actual_dirs=set()
    for p in Path(root).rglob('*'):
        label=p.relative_to(root).as_posix();s=facts(p,directory=p.is_dir())
        if stat.S_ISDIR(s.st_mode):need(label in dirs and stat.S_IMODE(s.st_mode)==0o755,'SEALED_CONTEXT_DIRECTORY_CHANGED');actual_dirs.add(label)
        else:need(label in pins,'UNLISTED_CONTEXT_FILE');actual_files.add(label)
    need(actual_dirs==dirs and actual_files==set(pins),'SEALED_CONTEXT_CLOSURE_CHANGED')
    for name,row in pins.items():bytes_guard(Path(root)/name,row['sha256'],read,row['mode'])

def modern_guard(root,journal,records,read,databases,receipt_sha=None,manifest_sha=None,records_sha=None):
    name=journal['name'];need(re.fullmatch('[a-z0-9][a-z0-9-]{0,120}',name),'EXACT_SEALED_NAMESPACE_REQUIRED')
    directory=Path(root)/(name+'-backup');s=facts(directory,True,0o700);backup=journal['codeBackups']
    actual={k:getattr(s,k) for k in ('st_dev','st_ino','st_uid','st_gid','st_mode')}
    additions=[r['target'] for r in records if r['beforeSha256'] is None]
    if additions or 'absentSources' in backup:
        need(name=='palitra-client-chat-offers-20261020-r1' and receipt_sha=='ea69eddb4d4cf91449f468a9bcce69b7b3be7a4cbcd1c148832f0e32e7b6807c' and manifest_sha=='21569bfe0acd9d08eb29b888b0c26df9b42e856d20fbe33fc6e467f20cfb7fd1' and records_sha=='1d4a8b66506dd7d68a777cbffae920f07354c9438613077f35c634459a46ace1' and journal['binding']['manifestSha256']==manifest_sha and journal['binding']['payloadScopeSha256']==records_sha and journal['phase']=='APPLIED_NOT_CUSTOMER_ACCEPTANCE' and len(records)==16 and additions==['palitra-order-memo.cjs'] and set(backup)=={'directoryIdentity','sources','static','absentSources'} and backup['absentSources']==additions,'EXACT_SEALED_OFFERS_MEMO_ADDITION_REQUIRED')
    else:need(set(backup)=={'directoryIdentity','sources','static'},'SEALED_REPLACEMENT_BACKUP_KEYS_CHANGED')
    need(backup['directoryIdentity']==actual,'SEALED_CODE_BACKUP_DIRECTORY_CHANGED')
    source={r['target']:r['beforeSha256'] for r in records if r['beforeSha256'] is not None};static={str(Path('/opt/synapse/sites/synapse/cabinet/palitra-orders')/r['static']):r['beforeSha256'] for r in records if r.get('static') is not None}
    need(all(type(pin) is str and re.fullmatch('[a-f0-9]{64}',pin) for pin in [*source.values(),*static.values()]),'SEALED_EXISTING_SOURCE_AND_STATIC_PINS_REQUIRED')
    for kind,expected,prefix in [('sources',source,'source-'),('static',static,'static-')]:
        rows=backup[kind];need(type(rows) is list and len(rows)==len(expected) and {r['target']:r['sha256'] for r in rows}==expected,'SEALED_CODE_BACKUP_CLOSURE_CHANGED')
        for i,row in enumerate(rows):
            p=Path(row['path']);need(p==directory/(prefix+str(i)),'EXACT_SEALED_CODE_BACKUP_PATH_REQUIRED');bytes_guard(p,row['sha256'],read)
    need(set(journal['backups'])=={'content','report','traffic'},'THREE_SEALED_DATABASE_BACKUPS_REQUIRED')
    identity=[s.st_dev,s.st_ino,s.st_uid,s.st_gid,stat.S_IMODE(s.st_mode)]
    for key,stem in [('report','reports'),('content','content'),('traffic','traffic')]:
        row=journal['backups'][key];need(row['bridgeBackupDirectoryIdentity']==identity,'SEALED_DATABASE_BACKUP_DIRECTORY_CHANGED')
        if row.get('status')!='ABSENT':
            p=Path(row['path']);need(p.parent==directory and re.fullmatch(stem+r'(?:-refresh-[1-9][0-9]{0,3})?[.]sqlite',p.name),'EXACT_SEALED_DATABASE_BACKUP_PATH_REQUIRED')
        databases[key].backup_guard(row)
    context_guard(Path(root)/(name+'-context'),journal['contextPins'],read)
    need(read(Path(root)/(name+'-context/image.id')).decode('ascii').strip()==journal['childImage'],'SEALED_CONTEXT_IMAGE_ID_CHANGED')
    for target in static:need(not os.path.lexists(Path(target).with_name('.'+name+'-'+Path(target).name+'.pending')),'SEALED_STATIC_PENDING_EXISTS')

def legacy_workspace_guard(root,journal,records,read,databases,receipt_sha=None):
    """Pinned workspace/notify completed format with explicit static/backups."""
    profile=legacy_contract(journal,receipt_sha)
    if profile is not None:need(len(records)==profile['records'],'EXACT_OLD_CONTEXT_RECORD_COUNT_REQUIRED')
    name=journal['name'];need(re.fullmatch('[a-z0-9][a-z0-9-]{0,120}',name),'EXACT_SEALED_NAMESPACE_REQUIRED')
    context=Path(root)/(name+'-context');facts(context,True,0o700)
    wanted={'Dockerfile':sha(('FROM '+name+'-base\nCOPY app/ /app/\n').encode())}
    wanted.update({'app/'+r['target']:r['sha256'] for r in records});wanted.update({'static/'+str(i):r['sha256'] for i,r in enumerate(journal['static'])})
    dirs={'app','static'}|{str(p) for key in wanted for p in PurePosixPath(key).parents if str(p)!='.'}
    actual={};seen_dirs=set();image_seen=False
    for p in context.rglob('*'):
        label=p.relative_to(context).as_posix();s=facts(p,directory=p.is_dir())
        if p.is_dir():need(label in dirs and stat.S_IMODE(s.st_mode)==(0o700 if label=='static' else 0o755),'SEALED_LEGACY_CONTEXT_DIRECTORY_CHANGED');seen_dirs.add(label)
        elif label=='image.id':need(stat.S_IMODE(s.st_mode) in (0o600,0o644) and read(p).decode('ascii').strip()==journal['childImage'],'SEALED_LEGACY_CONTEXT_IMAGE_CHANGED');image_seen=True
        else:
            need(label in wanted and sha(read(p))==wanted[label],'SEALED_LEGACY_CONTEXT_CHANGED');actual[label]=wanted[label]
    need(image_seen and actual==wanted and seen_dirs==dirs and sha(json.dumps(sorted(actual.items()),separators=(',',':')).encode())==journal['contextSha256'],'SEALED_LEGACY_CONTEXT_CLOSURE_CHANGED')
    for target,row in journal['sourceModes'].items():facts(context/'app'/target,mode=row['mode'])
    directory=Path(root)/(name+'-backup');s=facts(directory,True,0o700);need(journal['backupIdentity']==[s.st_dev,s.st_ino,s.st_uid],'SEALED_LEGACY_BACKUP_DIRECTORY_CHANGED')
    existing={r['target']:r.get('beforeSourceSha256',r.get('beforeSha256')) for r in records if r.get('beforeSourceSha256',r.get('beforeSha256')) is not None}
    if profile is not None:need(len(existing)==profile['sources'],'EXACT_OLD_EXISTING_SOURCE_COUNT_REQUIRED')
    need(len(journal['sourceBackups'])==len(existing) and {r['target']:r['baseSha256'] for r in journal['sourceBackups']}==existing,'SEALED_LEGACY_SOURCE_BACKUP_CLOSURE_CHANGED')
    static={str(Path('/opt/synapse/sites/synapse/cabinet/palitra-orders')/r['static']):r for r in records if r.get('static') is not None}
    if profile is not None:need(len(static)==profile['static'],'EXACT_OLD_STATIC_COUNT_REQUIRED')
    need(len(journal['static'])==len(static) and {r['target'] for r in journal['static']}==set(static),'SEALED_LEGACY_STATIC_BACKUP_CLOSURE_CHANGED')
    fields=[('report','reportDatabaseBackup','reports'),('content','contentDatabaseBackup','content'),('traffic','trafficDatabaseBackup','traffic')] if profile is None else ([('report','reportDatabaseBackup','reports')] if profile['reportBackup'] else [])
    wanted_files={'reports.sqlite','content.sqlite'} if profile is None else ({'reports.sqlite'} if profile['reportBackup'] else set())
    for key,field,stem in fields:
        row=journal[field];databases[key].backup_guard(row)
        if row.get('status')!='ABSENT':need(Path(row['path'])==directory/(stem+'.sqlite'),'SEALED_LEGACY_DB_BACKUP_PATH_CHANGED');wanted_files.add(stem+'.sqlite')
    for row in journal['static']:
        record=static[row['target']];need(row['baseSha256']==record['beforeSha256'] and row['sha256']==record['sha256'] and (row['backup'] is None)==(row['baseSha256'] is None),'SEALED_LEGACY_STATIC_RECORD_CHANGED')
    for row in journal['sourceBackups']+journal['static']:
        if row['backup'] is None:continue
        p=Path(row['backup']);need(p.parent==directory,'SEALED_LEGACY_BACKUP_PATH_CHANGED');wanted_files.add(p.name);bytes_guard(p,row['baseSha256'],read)
    need({p.name for p in directory.iterdir()}==wanted_files,'SEALED_LEGACY_BACKUP_DIRECTORY_CLOSURE_CHANGED')
