"""Explicit readonly R2 collector seam. Dependency is DISABLED until its exact
manifest, closure, result DTO and staged paths receive a separate Root review.
Never translates a new result into the old guard's own-inspect status.
"""
import hashlib,json,re,subprocess
from pathlib import PurePosixPath
from datetime import datetime,timezone

STATUS='EXACT_INSTALLED_GUARD_WITH_MANAGED260_READONLY_R2'
SCHEMA='palitra-readonly-managed260-inspection/v2'
IMAGE='sha256:951db09e9e6c4781350bbced7e7a9e4ef099077a368e38a6b1fac40e0a4a6a22'
RECEIPT='34ce6389ef04a5db158d5b1a27734e2d09c919df28b35a9dad4561af48d42892'
IMMUTABLE_MANAGED='2676eea3de58aa150bcd8782005b6a1f51571f03ceb8dc2ea6f6f1804cace86d'
CAS_STATUS='EXACT_INSTALLED_GUARD_WITH_MANAGED260_RUNTIME_CAS_R2'
CAS_SCHEMA='palitra-readonly-managed260-runtime-cas/v2'
COMMON={'mode','status','schema','image','guardReceiptSha256','managedProofSha256','stableManagedFactsSha256',
 'sourceFiles','staticFiles','chainFiles','managedVersions','runtimeSnapshotSha256','workerFactsSha256',
 'pushBindingSha256','lease','capturedAtUtc','codeManifestSha256','runtimeWrites','runtimeAdmission','fullInspection','databaseCaptureSemantics'}
FULL_KEYS=COMMON|{'freshManagedCaptureSha256','currentDatabaseSeals'}
CAS_KEYS=COMMON|{'managedPointerCas','managedCasSha256'}
STABLE=('image','guardReceiptSha256','managedProofSha256','stableManagedFactsSha256','sourceFiles','staticFiles','chainFiles',
 'managedVersions','runtimeSnapshotSha256','workerFactsSha256','pushBindingSha256','codeManifestSha256','lease')
digest=lambda v:type(v)is str and re.fullmatch('[a-f0-9]{64}',v)is not None
canonical=lambda value:json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def need(ok,code):
 if not ok:raise ValueError(code)
def capture_epoch(value):
 need(type(value)is str and (value.endswith('Z') or value.endswith('+00:00')),'UTC_R2_CAPTURE_REQUIRED')
 try:parsed=datetime.fromisoformat(value.replace('Z','+00:00'))
 except ValueError:raise ValueError('UTC_R2_CAPTURE_REQUIRED')
 need(parsed.tzinfo is not None and parsed.utcoffset().total_seconds()==0,'UTC_R2_CAPTURE_REQUIRED')
 return parsed.timestamp()
def _db_seals(value):
 need(type(value)is dict and set(value)=={'content','report','traffic'},'ALL_THREE_DATABASE_BINDINGS_REQUIRED')
 for name,row in value.items():
  fields={'identity','family','contentSha256'}|({'tables','schemaSha256'} if name=='content' else set())
  need(type(row)is dict and set(row)==fields and type(row['family'])is dict
       and digest(row['contentSha256']),'CURRENT_DATABASE_SEAL_REQUIRED')
  if name=='traffic':
   family=row['family'];null_sha=hashlib.sha256(canonical(None)).hexdigest()
   need(set(family)=={'db','wal','shm','journal'},'CLOSED_TRAFFIC_DATABASE_FAMILY_REQUIRED')
   if row['identity'] is None:
    need(all(item is None for item in family.values()) and row['contentSha256']==null_sha,
         'EXACT_ABSENT_TRAFFIC_DATABASE_REQUIRED')
   else:
    identity=row['identity']
    need(type(identity)is list and len(identity)==5 and all(type(n)is int and n>=0 for n in identity)
         and identity[2:]==[0,0,0o600] and row['contentSha256']!=null_sha,
         'EXACT_EXISTING_TRAFFIC_IDENTITY_REQUIRED')
    for item in family.values():
     if item is None:continue
     need(type(item)is dict and set(item)=={'identity','bytes','mtimeNs','ctimeNs','sha256'}
          and type(item['identity'])is list and len(item['identity'])==5
          and all(type(n)is int and n>=0 for n in item['identity']) and item['identity'][2:]==[0,0,0o600]
          and all(type(item[k])is int and item[k]>=0 for k in ('bytes','mtimeNs','ctimeNs'))
          and digest(item['sha256']),'EXACT_EXISTING_TRAFFIC_FAMILY_REQUIRED')
    need(family['db'] is not None and family['db']['identity']==identity
         and (family['journal'] is None or family['journal']['bytes']==0),'EXACT_EXISTING_TRAFFIC_FAMILY_REQUIRED')
  else:
   need(type(row['identity'])is dict and bool(row['identity']),'CURRENT_DATABASE_SEAL_REQUIRED')
  if name=='content':
   need(digest(row['schemaSha256']) and type(row['tables'])is dict and bool(row['tables']),'CURRENT_CONTENT_TABLE_SEALS_REQUIRED')
   for table,item in row['tables'].items():
    need(type(table)is str and bool(table) and type(item)is dict and set(item)=={'count','rowMultisetSha256','columnsSha256'}
         and type(item['count'])is int and item['count']>=0 and digest(item['rowMultisetSha256']) and digest(item['columnsSha256']),
         'CURRENT_CONTENT_TABLE_SEALS_REQUIRED')
def _managed_cas(value,seal):
 fields={'schema','status','workspaceSha256','versions','managedVersion','existingWal','databaseOpenCount','revisionOrDocumentScans','runtimeWrites'}
 need(type(value)is dict and set(value)==fields and value['schema']=='palitra-managed260-runtime-cas/v1'
      and value['status']=='MANAGED260_FILES_AND_POINTER_CAS_NOT_FULL_INSPECTION' and digest(value['workspaceSha256'])
      and type(value['managedVersion'])is int and value['managedVersion']==260 and value['existingWal']is True
      and type(value['databaseOpenCount'])is int and value['databaseOpenCount']==1
      and type(value['revisionOrDocumentScans'])is int and value['revisionOrDocumentScans']==0
      and type(value['runtimeWrites'])is int and value['runtimeWrites']==0,'ONE_READONLY_WAL_POINTER_CAS_REQUIRED')
 need(type(value['versions'])is list and len(value['versions'])==3,'ALL_MANAGED_VERSION_CAS_REQUIRED')
 for row,version in zip(value['versions'],(257,259,260)):
  need(type(row)is dict and set(row)=={'version','factsSha256','directoriesSha256'} and type(row['version'])is int
       and row['version']==version and digest(row['factsSha256']) and digest(row['directoriesSha256']),'ALL_MANAGED_VERSION_CAS_REQUIRED')
 need(digest(seal) and hashlib.sha256(canonical(value)).hexdigest()==seal,'EXACT_MANAGED_CAS_SEAL_REQUIRED')
def validate_inspector_result(result,admission,pins,now,mode='full'):
 dependency=pins.get('inspector')
 need(type(dependency)is dict and dependency.get('enabled')is True,'INSPECTOR_DEPENDENCY_NOT_BOUND')
 need(mode in ('full','runtime-cas') and type(result)is dict and set(result)==(FULL_KEYS if mode=='full' else CAS_KEYS),'CLOSED_NEW_R2_INSPECTION_REQUIRED')
 need(result['mode']==mode and result['status']==(STATUS if mode=='full' else CAS_STATUS)
      and result['schema']==(SCHEMA if mode=='full' else CAS_SCHEMA) and result['fullInspection']is (mode=='full'),
      'ONLY_NEW_MANAGED260_R2_INSPECTOR_ACCEPTED')
 need(result['image']==admission['guardImage']==IMAGE and result['guardReceiptSha256']==admission['artifacts']['guardReceipt']['sha256']==RECEIPT
      and result['managedProofSha256']==IMMUTABLE_MANAGED,'EXACT_CURRENT260_GUARD_BINDING_REQUIRED')
 need(result['codeManifestSha256']==admission['inspectorManifestSha256']==dependency['manifestSha256'],'EXACT_R2_CODE_REQUIRED')
 need(all(type(result[k])is int and result[k]==n for k,n in [('sourceFiles',240),('staticFiles',43),('chainFiles',49),('runtimeWrites',0)])
      and result['managedVersions']==[257,259,260] and all(type(x)is int for x in result['managedVersions'])
      and result['runtimeAdmission']is False,'FULL_READONLY_CLOSURE_REQUIRED')
 need(all(digest(result[k])for k in ['stableManagedFactsSha256','runtimeSnapshotSha256','workerFactsSha256','pushBindingSha256']),'FULL_RUNTIME_WORKER_PUSH_BINDINGS_REQUIRED')
 expected={'pid':admission['lease']['pid'],'startTicks':admission['lease']['startTicks'],'lock':admission['lease']['lockPath']}
 need(result['lease']==expected and type(result['lease']['pid'])is int and result['lease']['pid'] not in (3401855,3462715,3471272,3471456,3471638),'EXACT_FRESH_OWN_INSPECTOR_LEASE_REQUIRED')
 need(0<=now-capture_epoch(result['capturedAtUtc'])<=600,'FRESH_R2_INSPECTION_REQUIRED')
 if mode=='full':
  need(result['databaseCaptureSemantics']=='CONSISTENT_PER_DB_READONLY_TRANSACTIONS_NOT_GLOBAL_ATOMIC_SNAPSHOT'
       and digest(result['freshManagedCaptureSha256']),'FULL_CURRENT_DATABASE_INSPECTION_REQUIRED')
  _db_seals(result['currentDatabaseSeals'])
 else:
  need(result['databaseCaptureSemantics']=='ONE_READONLY_QUERY_ONLY_CONTENT_CONNECTION_EXISTING_WAL_CURRENT_MANAGED_POINTER_ONLY_CALLER_MUST_HOLD_WRITER_TRANSACTION',
       'CAS_IS_NOT_FULL_DATABASE_INSPECTION')
  _managed_cas(result['managedPointerCas'],result['managedCasSha256'])
 return result
def compare_stable(prior,current):
 need(all(prior[k]==current[k] for k in STABLE),'FRESH_RUNTIME_INSPECTION_FACTS_CHANGED')
 if prior['mode']==current['mode']=='full':
  need(prior['freshManagedCaptureSha256']==current['freshManagedCaptureSha256'],'FRESH_MANAGED_CAPTURE_CHANGED')
  # Dynamic traffic events may advance; actual absence/identity may not change.
  need(prior['currentDatabaseSeals']['traffic']['identity']==current['currentDatabaseSeals']['traffic']['identity'],
       'CURRENT_TRAFFIC_DATABASE_IDENTITY_OR_ABSENCE_CHANGED')
def invoke_inspector(admission,pins,private_read,private_path,mode='full'):
 dependency=pins.get('inspector')
 need(type(dependency)is dict and dependency.get('enabled')is True,'INSPECTOR_DEPENDENCY_NOT_BOUND')
 need(mode in ('full','runtime-cas'),'EXPLICIT_R2_MODE_REQUIRED')
 manifest_path=PurePosixPath(dependency['manifestPath']);entry=PurePosixPath(dependency['entryPath'])
 need(manifest_path.is_absolute() and manifest_path.name=='readonly-code-pins.json' and entry.parent==manifest_path.parent
      and entry.name=='readonly_entry.py','EXACT_REVIEWED_R2_INSPECTOR_PATH_REQUIRED')
 private_path(entry.parent,True)
 raw=private_read(manifest_path,dependency['manifestSha256']);manifest=json.loads(raw)
 need(type(manifest)is dict and set(manifest)=={'schema','status','runtimeAuthorization','files'} and manifest['schema']==1
      and manifest['status']=='FROZEN_READONLY_CODE_ONLY_NOT_RUNTIME_ADMISSION' and manifest['runtimeAuthorization']is False
      and type(dependency.get('files'))is dict and dependency['files'] and manifest['files']==dependency['files'],'CLOSED_REVIEWED_R2_CODE_CLOSURE_REQUIRED')
 need(dependency['files'].get('readonly_entry.py')==dependency['entrySha256'],'PINNED_R2_ENTRY_REQUIRED')
 for name,pin in dependency['files'].items():
  p=PurePosixPath(name);need(p.name==name and name!='readonly-code-pins.json' and digest(pin),'PINNED_R2_CLOSURE_FILE_REQUIRED')
  private_read(entry.parent/p,pin)
 result=subprocess.run(['python3','-B',str(entry),'--mode',mode,'--lease-pid',str(admission['lease']['pid']),'--code-pins-sha',dependency['manifestSha256']],
                       check=True,capture_output=True,timeout=180)
 need(not result.stderr and len(result.stdout)<=65536,'BOUNDED_READONLY_INSPECTOR_OUTPUT_REQUIRED')
 # Collector rechecks its own package and runtime CAS; adapter additionally pins
 # every input again after completion without changing a byte of that package.
 private_read(manifest_path,dependency['manifestSha256'])
 for name,pin in dependency['files'].items():private_read(entry.parent/name,pin)
 try:return json.loads(result.stdout)
 except (TypeError,ValueError):raise ValueError('EXACT_NEW_R2_INSPECTOR_JSON_REQUIRED')
