"""Explicit completion-only caller. Never applies/builds/migrates/restarts R8.

The installed runtime remains the immutable R8 package. Corrected caller helpers
are a separate closed manifest and require a fresh dual-bound external action.
"""
import argparse,copy,hashlib,importlib,json,os,re,sqlite3,stat,subprocess,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('/opt/synapse/releases/palitra-app-20261015')
DATA=Path('/var/lib/docker/volumes/synapse_content_data/_data')
RUNTIME='palitra-unified-orders-20261021-r8'
NAME=RUNTIME+'-completion-c2'
SAVED_NAME=RUNTIME+'-completion-c1'
SAVED_MANIFEST='88ecc0018d4e5d7686b89e55b4561059ba36ca5f79cfb0dce455b54364707c3e'
RUNTIME_SHA='a0d12a5bc58a99c5b554d8204db26796fec3f86684ca65b3213f5de6f8e2fff0'
ENTRY_SHA='99d23faeeb8f7c0375802c0dd2b719570dc8436c98de696846a6b475a9ddd9c3'
FAILED_STDOUT='6d1f8d0bc84eeab50716d92194705ca25c2b5c9900e3db96c00dfb1773647865'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encode=lambda v:json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
digest=lambda v:type(v) is str and re.fullmatch('[a-f0-9]{64}',v) is not None
def need(v,c):
    if not v:raise ValueError(c)
def read_file(path,limit=16*1024*1024,native=True):
    p=Path(path);need(p.is_absolute(),'ABSOLUTE_COMPLETION_PATH_REQUIRED')
    for q in [p,*p.parents]:need(not q.is_symlink(),'COMPLETION_ALIAS_REFUSED')
    s=p.lstat();need(stat.S_ISREG(s.st_mode) and s.st_nlink==1 and s.st_size<=limit,'BOUNDED_COMPLETION_FILE_REQUIRED')
    if native:need(s.st_uid==s.st_gid==0 and stat.S_IMODE(s.st_mode)==0o600,'ROOT600_COMPLETION_FILE_REQUIRED')
    raw=p.read_bytes();z=p.lstat()
    keys=('st_dev','st_ino','st_size','st_mtime_ns','st_ctime_ns')
    need(len(raw)==s.st_size and all(getattr(s,k)==getattr(z,k) for k in keys),'COMPLETION_READ_RACE');return raw
def load_completion(directory,pin,native=True):
    directory=Path(directory);need(digest(pin),'EXACT_COMPLETION_MANIFEST_PIN_REQUIRED')
    if native:need(os.name=='posix' and os.geteuid()==0 and directory==ROOT/(NAME+'-code'),'EXACT_COMPLETION_NATIVE_NAMESPACE_REQUIRED')
    raw=read_file(directory/'completion-manifest.json',native=native);need(sha(raw)==pin,'COMPLETION_MANIFEST_CHANGED');v=json.loads(raw)
    need(v.get('schema')=='palitra-r8-completion-code/v2' and v.get('namespace')==NAME and v.get('runtimePackageSha256')==RUNTIME_SHA and v.get('runtimeAuthorization') is False,'EXACT_COMPLETION_CODE_ONLY_CONTRACT')
    expected={'completion_entry.py','native-adoption-probe.cjs'}
    need(set(v['files'])==expected and {p.name for p in directory.iterdir()}==expected|{'completion-manifest.json'},'CLOSED_COMPLETION_CODE_DOMAIN_REQUIRED')
    for name,p in v['files'].items():need(digest(p) and sha(read_file(directory/name,native=native))==p,'COMPLETION_CODE_CHANGED')
    return v

class CompletionAdmission:
    def __init__(self,reference,completion_sha,mode,code_guard,clock=time.time):
        need(mode in ('finish','accept') and digest(completion_sha),'ONLY_COMPLETION_ACTION_MODES_ALLOWED')
        self.reference=reference;self.completion_sha=completion_sha;self.mode=mode;self.code_guard=code_guard;self.clock=clock
        # Original Controller uses package_sha solely as deployed payload provenance.
        self.package_sha=RUNTIME_SHA;self.initial=None
    def check(self):
        self.code_guard();raw=read_file(self.reference['path']);need(sha(raw)==self.reference['sha256'],'EXACT_COMPLETION_ROOT_ACTION_REQUIRED');v=json.loads(raw)
        expected={'schema','status','mode','namespace','runtimePackageSha256','completionManifestSha256','parentImage','parentReceiptSha256','lease','createdAtUnix','expiresAtUnix','nonce','queue','bindings','runtimeAuthorization'}
        need(set(v)==expected and v['schema']=='palitra-unified-r8-completion-root-action/v2' and v['status']=='ROOT_AUTHORIZED_ONE_ATTEMPT' and v['runtimeAuthorization'] is True,'EXTERNAL_COMPLETION_ROOT_ACTION_REQUIRED')
        from manifest_inputs import IMAGE,RECEIPT
        need((v['mode'],v['namespace'],v['runtimePackageSha256'],v['completionManifestSha256'],v['parentImage'],v['parentReceiptSha256'])==(self.mode,NAME,RUNTIME_SHA,self.completion_sha,IMAGE,RECEIPT),'EXACT_DUAL_RUNTIME_COMPLETION_BINDING_REQUIRED')
        need(digest(v['nonce']) and v['queue']=={'resource':'synapse-content-production','owner':'Root','clear':True},'EXACT_ROOT_QUEUE_NONCE_REQUIRED')
        need(set(v['lease'])=={'pid','startTicks'} and type(v['lease']['pid']) is int and v['lease']['pid']>1 and type(v['lease']['startTicks']) is str and v['lease']['startTicks'].isdigit(),'EXACT_COMPLETION_LEASE_BINDING_REQUIRED')
        need(type(v['createdAtUnix']) in (int,float) and type(v['expiresAtUnix']) in (int,float) and 0<v['expiresAtUnix']-v['createdAtUnix']<=1800 and v['createdAtUnix']<=self.clock()<v['expiresAtUnix'],'FRESH_COMPLETION_ACTION_REQUIRED')
        common={'compatibilityInspectorManifestSha256','inspectorDirectory','managedAdoptionPlan','currentApiPrice'}
        modes={'finish':{'pendingNativeAdoption','pendingNativeAdoptionSha256','nativeAdoptionReceipt'},'accept':{'installedPendingAcceptance','nativeAdoptionReceipt','wholeAppAcceptance'}}
        need(set(v['bindings'])==common|modes[self.mode],'EXACT_COMPLETION_BINDING_DOMAIN_REQUIRED')
        need(self.initial is None or v==self.initial,'COMPLETION_ACTION_CHANGED');self.initial=copy.deepcopy(v);return v

def load_saved_completion(native=True):
    directory=ROOT/(SAVED_NAME+'-code')
    raw=read_file(directory/'completion-manifest.json',native=native)
    need(sha(raw)==SAVED_MANIFEST,'IMMUTABLE_C1_MANIFEST_CHANGED');v=json.loads(raw)
    expected={'completion_entry.py','native-workspace-service.cjs','native-adoption-probe.cjs'}
    need(v.get('schema')=='palitra-r8-completion-code/v1' and v.get('namespace')==SAVED_NAME and v.get('runtimePackageSha256')==RUNTIME_SHA and v.get('runtimeAuthorization') is False and set(v['files'])==expected and {p.name for p in directory.iterdir()}==expected|{'completion-manifest.json'},'CLOSED_IMMUTABLE_C1_CODE_REQUIRED')
    for name,pin in v['files'].items():need(digest(pin) and sha(read_file(directory/name,native=native))==pin,'IMMUTABLE_C1_CODE_CHANGED')
    return v

def require_price_proof(proof,auth,clock=time.time):
    fields={'schema','key','document','nonce','lease','capturedAtUnix','runtimePackageSha256','savedCompletionManifestSha256','currentRevision','currentVersion','runtimeWrites','runtimeAuthorization'}
    need(type(proof) is dict and set(proof)==fields and proof['schema']=='palitra-completion-current-api-price/v1' and proof['key']=='palitra/price','EXPLICIT_CURRENT_API_PRICE_PROOF_REQUIRED')
    d=proof['document'];need(type(d) is dict and set(d)=={'id','version','sha256','bytes'} and type(d['id']) is int and d['id']>0 and type(d['version']) is int and d['version']>0 and digest(d['sha256']) and type(d['bytes']) is int and 0<d['bytes']<=16*1024*1024,'BOUNDED_CURRENT_API_PRICE_METADATA_REQUIRED')
    need(proof['runtimePackageSha256']==RUNTIME_SHA and proof['savedCompletionManifestSha256']==SAVED_MANIFEST and proof['runtimeWrites']==0 and proof['runtimeAuthorization'] is False and proof['currentVersion']==261 and digest(proof['currentRevision']),'CURRENT_PRICE_RUNTIME_C1_BINDING_REQUIRED')
    need(proof['nonce']==auth['nonce'] and proof['lease']==auth['lease'],'CURRENT_PRICE_ACTION_NONCE_LEASE_REQUIRED')
    t=proof['capturedAtUnix'];need(type(t) in (int,float) and 0<t<=auth['createdAtUnix']<=clock()<auth['expiresAtUnix']<=t+1800,'FRESH_CURRENT_PRICE_ACTION_INTERVAL_REQUIRED')
    return proof

def current_api_price(proof,path=DATA/'content.sqlite',native=True):
    # A short read-only snapshot, independently sealed from historical raw140.
    # No body is persisted, returned or printed; only its UTF-8 metadata is used.
    p=Path(path)
    for q in [p,*p.parents]:need(not q.is_symlink(),'CURRENT_PRICE_DB_ALIAS_REFUSED')
    before=p.lstat();need(stat.S_ISREG(before.st_mode) and before.st_nlink==1,'EXISTING_CURRENT_PRICE_DB_REQUIRED')
    if native:need(before.st_uid==before.st_gid==0,'ROOT_CURRENT_PRICE_DB_REQUIRED')
    con=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True,timeout=5)
    try:
        con.execute('PRAGMA query_only=ON');con.execute('BEGIN')
        meta=con.execute("SELECT id,version,length(CAST(body AS BLOB)),typeof(body) FROM documents WHERE key=? ORDER BY version DESC LIMIT 1",('palitra/price',)).fetchone()
        need(meta is not None and meta[3]=='text' and type(meta[2]) is int and 0<meta[2]<=16*1024*1024,'BOUNDED_EXISTING_API_PRICE_REQUIRED')
        row=con.execute('SELECT id,version,body FROM documents WHERE key=? ORDER BY version DESC LIMIT 1',('palitra/price',)).fetchone()
        need(row is not None and type(row[2]) is str,'CURRENT_API_PRICE_DOCUMENT_REQUIRED');raw=row[2].encode('utf-8')
        actual={'id':row[0],'version':row[1],'sha256':sha(raw),'bytes':len(raw)}
        need(actual==proof['document'],'CURRENT_API_PRICE_CHANGED')
        pointer=con.execute('SELECT w.current_revision,r.version FROM managed_sites m JOIN site_workspaces w ON w.site_id=m.id JOIN site_workspace_revisions r ON r.site_id=m.id AND r.revision=w.current_revision WHERE m.id=? AND m.company_code=?',('site-44bbe13f1bad5e005b2a','palitra-love')).fetchone()
        need(pointer==(proof['currentRevision'],261),'CURRENT_C1_POINTER_CHANGED')
        con.rollback()
    finally:con.close()
    after=p.lstat();need(all(getattr(before,k)==getattr(after,k) for k in ('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink')),'CURRENT_PRICE_DB_IDENTITY_CHANGED')
    return actual

def controller_type(Controller,read,encoded):
    # Only this explicit accept path seam differs from immutable R8 Controller.
    # The original apply/overlay namespace stays R8; finish is inherited exact.
    NAMESPACE=RUNTIME
    class CompletionController(Controller):
        def accept(self,installed,managed_receipt,managed_guard,acceptance_check):
            # Separate fresh read-only action, after external Root verification.
            # Never build, migrate, up or publish/replay static in this phase.
            need(self.admission.mode=='accept' and not self.driver.started,'FRESH_READONLY_ACCEPT_PROCESS_REQUIRED');auth=self.gate()
            need(installed.get('schema')=='palitra-unified-installed-pending-root-acceptance/v1' and installed.get('status')=='INSTALLED_PENDING_ROOT_ACCEPTANCE' and installed.get('runtimeAcceptance') is False and installed.get('packageSha256')==self.admission.package_sha and installed.get('mapSha256')==self.package['map']['closureSha256'] and installed.get('snapshotSha256')==sha(encoded(installed['snapshot'])),'EXACT_INSTALLED_PENDING_ACCEPTANCE_REQUIRED')
            finish=installed['finishDirectory'];need(set(finish)=={'path','identity'} and Path(finish['path'])==self.private.root.parent/(NAME+'-finish'),'EXACT_SEALED_FINISH_NAMESPACE_REQUIRED')
            from private_files import SealedBackupSource
            finish_source=SealedBackupSource(Path(finish['path']),finish['identity']);finish_source.guard()
            need(Path(auth['bindings']['installedPendingAcceptance']['path'])==finish_source.root/'installed-pending-acceptance.json' and sha(read(auth['bindings']['installedPendingAcceptance']['path']))==auth['bindings']['installedPendingAcceptance']['sha256'],'EXACT_FINISH_RECEIPT_RAW_FILE_BINDING_REQUIRED')
            need(installed['managedAdoptionReceiptSha256']==sha(encoded(managed_receipt)),'EXACT_ADOPTION_RECEIPT_MUST_PERSIST_THROUGH_ACCEPT')
            apply=installed['applyDirectory'];need(set(apply)=={'path','identity'} and Path(apply['path'])==self.private.root.parent/(NAMESPACE+'-apply'),'EXACT_ACCEPTED_APPLY_NAMESPACE_REQUIRED')
            self.driver.child=installed['child']['image'];self.driver.overlay=self.private.root.parent/(NAMESPACE+'-overlay.json');self.driver.config_hash=installed['plannedConfigHash'];self.driver.db_minimum=installed['minimum']
            self.driver.static.bind_sealed_backups(Path(apply['path']),apply['identity'],installed['staticBackups'])
            # Select the expected already-published state; snapshot_child actually
            # reads/verifies every resulting hash/mode. This never calls publish.
            self.driver.static.published=set(self.driver.static.records)
            snapshot=self.journal.action('readonly-installed-acceptance-readback',lambda:self.driver.snapshot_child(managed_guard))
            need(snapshot==installed['snapshot'],'INSTALLED_RUNTIME_CHANGED_BEFORE_ROOT_ACCEPTANCE');self.gate();finish_source.guard();acceptance=acceptance_check()
            need(acceptance.get('schema')=='palitra-unified-whole-app-acceptance/v1' and acceptance.get('status')=='ROOT_VERIFIED_OLD_NEW_OPEN_SESSIONS' and acceptance.get('packageSha256')==self.admission.package_sha and acceptance.get('managedReceiptSha256')==sha(encoded(managed_receipt)) and acceptance.get('installedReceiptSha256')==auth['bindings']['installedPendingAcceptance']['sha256'] and acceptance.get('snapshotSha256')==installed['snapshotSha256'] and acceptance.get('clientAndStaff') is True and acceptance.get('draftAndFilePreserved') is True and acceptance.get('oldAndNewQueriesCurrent') is True and acceptance.get('bottomComposer') is True,'ACTUAL_POST_PUBLICATION_WHOLE_APP_ACCEPTANCE_REQUIRED')
            return self.journal.record('complete','APPLIED_AND_ROOT_ACCEPTED',{'snapshot':snapshot,'installedReceiptSha256':auth['bindings']['installedPendingAcceptance']['sha256'],'acceptanceSha256':sha(encoded(acceptance)),'runtimeAcceptance':True,'databaseRestores':0},runtime_acceptance=True)
    return CompletionController

def main(argv=None):
    p=argparse.ArgumentParser();p.add_argument('--mode',choices=('finish','accept'),required=True);p.add_argument('--manifest-sha',required=True);p.add_argument('--action',required=True,type=Path);p.add_argument('--action-sha',required=True);a=p.parse_args(argv)
    directory=Path(__file__).resolve().parent;load_completion(directory,a.manifest_sha)
    runtime_dir=ROOT/(RUNTIME+'-code')
    need(sha(read_file(runtime_dir/'native_entry.py'))==ENTRY_SHA,'FROZEN_R8_ENTRY_CHANGED')
    sys.path.insert(0,str(runtime_dir));from native_entry import load_package
    package,_=load_package(runtime_dir,RUNTIME_SHA)
    def codes():load_completion(directory,a.manifest_sha);load_saved_completion();load_package(runtime_dir,RUNTIME_SHA)
    action=CompletionAdmission({'path':str(a.action),'sha256':a.action_sha},a.manifest_sha,a.mode,codes);auth=action.check();bindings=auth['bindings']
    from private_files import PrivateFiles,read,encoded,exact
    from manifest_inputs import read_pin
    from forward_guard import load_inspector,factory_type
    from install_protocol import Controller,require_native_plan
    def private_json(ref):
        need(type(ref) is dict and set(ref)=={'path','sha256'} and digest(ref['sha256']),'EXACT_PRIVATE_JSON_REFERENCE_REQUIRED')
        path=Path(ref['path']);need(ROOT in path.parents and path.suffix=='.json','PRIVATE_RELEASE_JSON_REQUIRED')
        raw=read_file(path);need(sha(raw)==ref['sha256'],'PRIVATE_COMPLETION_PROOF_CHANGED');return json.loads(raw)
    plan=private_json(bindings['managedAdoptionPlan']);require_native_plan(plan,package);need(plan['transport']=='native-workspace-service','ORIGINAL_NATIVE_SERVICE_TRANSPORT_REQUIRED');package['_managedAdoptionPlan']=plan
    need(bindings['compatibilityInspectorManifestSha256']==package['compatibilityInspectorManifest']['sha256'],'R8_COMPATIBILITY_INSPECTOR_PIN_REQUIRED')
    inspector_path=Path(bindings['inspectorDirectory']);need(inspector_path.parent==ROOT,'STAGED_COMPATIBILITY_INSPECTOR_REQUIRED');inspector,pins=load_inspector(inspector_path,bindings['compatibilityInspectorManifestSha256'])
    def lease():need(inspector.M.lease(auth['lease']['pid'])==auth['lease']['startTicks'],'FRESH_COMPLETION_LEASE_REQUIRED')
    price_proof=require_price_proof(private_json(bindings['currentApiPrice']),auth)
    outcome_proof_check=lambda:None
    def guard():
        action.check();lease()
        for ref in bindings.values():
            if type(ref) is dict and set(ref)=={'path','sha256'}:private_json(ref)
        outcome_proof_check();require_price_proof(price_proof,auth);current_api_price(price_proof)
    if a.mode=='finish':
        pending=private_json(bindings['pendingNativeAdoption'])
        need(sha(encoded(pending))==bindings['pendingNativeAdoptionSha256'] and pending.get('schema')=='palitra-unified-pending-native-adoption/v1' and pending.get('status')=='RUNTIME_CODE_SCHEMA_READY_REQUIRES_NATIVE_WORKSPACE_ADOPTION' and pending.get('packageSha256')==RUNTIME_SHA and pending.get('mapSha256')==package['map']['closureSha256'] and pending.get('runtimeAcceptance') is False,'EXACT_ACTUAL_R8_PENDING_REQUIRED')
        need(pending['migration'].get('nativeCommitStatus')=='SCHEMA_COMMITTED_WITH_PROTECTED_CONTENT_PRESERVED' and pending['migration'].get('oldBusinessRowsChanged')==0 and pending['child'].get('sourceFiles')==244 and pending['child'].get('oneCopyLayer') is True,'ACTUAL_COMMITTED_R8_NOT_REAPPLY_REQUIRED')
        need(pending['managedAdoptionPlanSha256']==bindings['managedAdoptionPlan']['sha256'] and pending['managedAdoptionBaseRevision']==plan['baseRevision'],'UNCHANGED_R8_PLAN_REQUIRED')
    else:pending=None
    receipt=private_json(bindings['nativeAdoptionReceipt'])
    need(receipt.get('runtimePackageSha256')==RUNTIME_SHA and receipt.get('packageSha256')==RUNTIME_SHA and receipt.get('completionManifestSha256')==SAVED_MANIFEST and digest(receipt.get('completionRootActionSha256')),'DUAL_BOUND_COMPLETION_ADOPTION_REQUIRED')
    outcome_ref=receipt.get('completionOutcome');need(type(outcome_ref) is dict and set(outcome_ref)=={'path','sha256'} and Path(outcome_ref['path'])==DATA/(SAVED_NAME+'-save')/'NATIVE_SAVE_OUTCOME.json','EXACT_RAW_COMPLETION_OUTCOME_REFERENCE_REQUIRED')
    outcome_raw=read_file(outcome_ref['path'],4*1024*1024);need(sha(outcome_raw)==outcome_ref['sha256']==receipt.get('nativeSaveReceiptSha256'),'RAW_NATIVE_SAVE_OUTCOME_SHA_REQUIRED');outcome=json.loads(outcome_raw)
    def outcome_proof_check():need(sha(read_file(outcome_ref['path'],4*1024*1024))==outcome_ref['sha256'],'LATE_RAW_NATIVE_SAVE_OUTCOME_CHANGED')
    need(outcome.get('completionManifestSha256')==SAVED_MANIFEST and outcome.get('completionRootActionSha256')==receipt['completionRootActionSha256'] and outcome.get('runtimePackageSha256')==RUNTIME_SHA and outcome.get('full141FactsSha256')==receipt.get('full141FactsSha256') and outcome.get('currentRevision')==receipt.get('currentRevision'),'COMPLETION_OUTCOME_PROVENANCE_CHANGED')
    need(outcome.get('packageSha256')==RUNTIME_SHA and outcome.get('planSha256')==receipt.get('planSha256')==bindings['managedAdoptionPlan']['sha256'] and outcome.get('status')=='NATIVE_SERVICE_SAVED_REQUIRES_ROOT_PUBLIC_READBACK' and outcome.get('saveCalls')==1 and outcome.get('currentVersion')==receipt.get('currentVersion')==261 and outcome.get('other137Unchanged') is True and outcome.get('priceUnchanged') is True and outcome.get('rawRuntimeFileWrites')==0,'EXACT_ACTUAL_C1_SAVE_FACTS_REQUIRED')
    need(price_proof['currentRevision']==outcome['currentRevision'],'CURRENT_PRICE_SAME_C1_REVISION_REQUIRED')
    if pending is not None:need(outcome.get('pendingSha256')==bindings['pendingNativeAdoptionSha256'],'SAME_ACTUAL_R8_PENDING_THROUGH_COMPLETION_REQUIRED')
    installed=private_json(bindings['installedPendingAcceptance']) if a.mode=='accept' else None
    minimum=installed['minimum']['content'] if installed else pending['minimum']['content']
    factory=factory_type(inspector)(auth['lease']['pid'],pins,minimum,finish=True);need(factory.ticks==auth['lease']['startTicks'],'ACTUAL_COMPLETION_LEASE_START_CHANGED')
    # Preflight price drift must refuse BEFORE consuming a new C2 phase area.
    guard()
    # Immutable R8 apply/overlay remain; this fresh C2 finish namespace is explicit.
    area=ROOT/(NAME+'-'+a.mode);need(not area.exists(),'COMPLETION_PHASE_EXISTS_NO_REPLAY');area.mkdir(mode=0o700);private=PrivateFiles(area)
    from native_adapter import Driver
    payloads={k:{'path':str(runtime_dir/v['path']),'sha256':v['sha256']} for k,v in package['payloads'].items()}
    driver=Driver(factory,package['map'],private,read(runtime_dir/'historical-native-read-source.py'),payloads,guard)
    CompletionController=controller_type(Controller,read,encoded)
    controller=CompletionController(action,driver,package,private);controller.journal.bindings.update(runtimePackageSha256=RUNTIME_SHA,completionManifestSha256=a.manifest_sha,currentApiPrice=bindings['currentApiPrice'])
    script=read(directory/'native-adoption-probe.cjs').decode();invocation=script+"\nconst raw=fs.readFileSync(0);need(raw.length<=1048576,'INPUT_BOUND');process.stdout.write(JSON.stringify(capture(JSON.parse(raw))));"
    def managed_guard():
        guard();factory.lease();r=subprocess.run(['docker','exec','-i','synapse-content-1','node','--disable-warning=ExperimentalWarning','-e',invocation],input=encoded({'old':factory.managed,'plan':plan,'currentApiPrice':{'key':'palitra/price',**price_proof['document']}}),capture_output=True,timeout=90)
        need(r.returncode==0 and not r.stderr and len(r.stdout)<=32768,'CORRECTED_NATIVE141_READBACK_REFUSED');v=json.loads(r.stdout)
        need(v.get('status')=='EXACT_NATIVE141_READONLY_NOT_INSTALL_ACCEPTANCE' and v.get('runtimeWrites')==0 and v.get('historicalUnchanged') is True and v.get('currentVersion')==receipt['currentVersion'] and v.get('currentRevision')==receipt['currentRevision'] and v.get('full141FactsSha256')==receipt['full141FactsSha256'],'EXACT_COMPLETION_RECEIPT_READBACK_REQUIRED');guard();factory.lease();return v
    def acceptance_proof():
        proof=private_json(bindings['wholeAppAcceptance'])
        need(proof.get('currentApiPriceSha256')==price_proof['document']['sha256'] and proof.get('completionManifestSha256')==a.manifest_sha,'ACTUAL_C2_CURRENT_PRICE_ACCEPTANCE_REQUIRED');return proof
    result=controller.finish(pending,receipt,managed_guard) if a.mode=='finish' else controller.accept(installed,receipt,managed_guard,acceptance_proof)
    print(json.dumps({'status':result.get('status'),'runtimeAcceptance':result.get('runtimeAcceptance',False),'runtimePackageSha256':RUNTIME_SHA,'completionManifestSha256':a.manifest_sha,'automaticRetry':False,'automaticRestore':False}));return 0

if __name__=='__main__':
    try:raise SystemExit(main())
    except Exception as e:
        code=str(e) if type(e) is ValueError and re.fullmatch('[A-Z][A-Z0-9_]{0,120}',str(e)) else type(e).__name__
        print(json.dumps({'status':'REFUSED_OR_UNKNOWN_NO_AUTOMATIC_RETRY','code':code,'automaticRetry':False,'automaticRestore':False}));raise SystemExit(2)
