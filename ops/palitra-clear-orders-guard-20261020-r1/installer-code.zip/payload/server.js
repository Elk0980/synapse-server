'use strict';

/* Synapse Business — сервис контента сайтов.
   Хранит JSON-документы (например, прайс ALVI) с историей версий.
   Кабинет проверяет сессию, проект и права; сайты читают отдельный публичный маршрут.
   Внешних пакетов нет: Node 24, встроенный node:sqlite. */

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');
const {create: createSalonCompanyApp} = require('./company-app/runtime.cjs');
const { createAuthStore, COMPANIES, PERMISSIONS, DEPENDENCIES, PRICE_CLIENT_PRESET } = require('./auth-store');
const { createSiteStore } = require('./site-store');
const {createWorkspaceFeature}=require('./site-workspace-feature');
const {createPalitraPhotoFeature}=require('./palitra-photo-feature');
const {createSharpDecoder}=require('./palitra-image-decoder');
const { createHughSettingsStore } = require('./hugh-settings-store');
const { createProjectChat } = require('./project-chat');
const { createTelegramSources, readSourceConfig } = require('./telegram-sources');
const {createContentFactorySourceBridge}=require('./content-factory-source-bridge');
const {createSourceContext}=require('./content-factory-source-context');
const { createOwnerPrivateChat } = require('./owner-private-chat');
const { createActorOnboarding } = require('./actor-onboarding');
const { createActorWorkspace } = require('./actor-workspace');
const { createHughProviders } = require('./hugh-providers');
const {createMediaMentorSuggest, createMediaMentorSuggestRoute} = require('./media-mentor-suggest');
const { clientIp, originOf } = require('./site-orders');
const { clientCompanyConfig } = require('./client-bot-config');
const { createClientDialogs } = require('./client-dialogs');
// PALITRA-WEBCHAT-PHASEB: общий чат сайта (ядро customer-chat.js) на native очереди клиентского бота.
const { createCustomerChatNative } = require('./customer-chat-native-adapter.cjs');
const { createWorkflow, createWorkflowHttp, canAccess: palitraCanAccess } = require('./palitra-workflow.cjs');
const { createManagerAttention } = require('./palitra-manager-attention.cjs');
const { createResponseReport } = require('./palitra-response-report.cjs');
const { createCustomerChatHttp, CHAT_CSRF_HEADER } = require('./customer-chat-http.cjs');
const { createClientIntakeProxy } = require('./client-intake-proxy');
const { hashPassword, verifyPassword } = require('./passwords');
const { createCompanyLinksReader } = require('./company-links-reader');
const { createEmailUnsubscribeProxy, TOKEN: EMAIL_UNSUBSCRIBE_TOKEN } = require('./email-unsubscribe-proxy');
const { resolveSessionSecret } = require('./session-secret');
const palitraPrice = require('./palitra-price-validate.js');
// PALITRA-REVIEW39-WIRING:IMPORT:BEGIN
const { createPalitraTaskReview } = require('./palitra-task-review.cjs');
const { createProjectFormsFeature } = require('./project-forms.cjs');
// PALITRA-REVIEW39-WIRING:IMPORT:END

const PORT = Number.parseInt(process.env.PORT || '8080', 10);
const DATABASE_PATH = process.env.DATABASE_PATH || '/data/content.sqlite';
const API_KEY = (process.env.API_KEY || '').trim();            // ключ владельца (Влад)
const ASSETS_DIR = process.env.ASSETS_DIR || path.join(path.dirname(DATABASE_PATH), 'assets');
const MAX_ASSET = 8 * 1024 * 1024;
const MAX_PUBLISHING_ASSET = 10 * 1024 * 1024;
// Видео для очереди контента: вертикальные ролики до 60 МБ. Проверяется контейнер по сигнатуре, не по расширению.
const MAX_PUBLISHING_VIDEO = Number.parseInt(process.env.MAX_PUBLISHING_VIDEO_BYTES || '', 10) || 60 * 1024 * 1024;
const PUBLISHING_ASSET_ORIGIN = 'https://synapse.synapsebusiness.ru';
const ASSET_TYPES = { 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp', 'video/mp4': '.mp4', 'video/webm': '.webm' };
const VIDEO_TYPES = new Set(['video/mp4', 'video/webm']);
const ASSET_MIME = { jpg: 'image/jpeg', png: 'image/png', webp: 'image/webp', mp4: 'video/mp4', webm: 'video/webm' };
const SEED_DIR = process.env.SEED_DIR || path.join(__dirname, 'seed');
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || '').split(',').map((s) => s.trim()).filter(Boolean);
const HISTORY_LIMIT = 10;
const MAX_BODY = 1024 * 1024;
const SITES = new Set(['alvi', 'avokado', 'avokado2', 'avokado3', 'palitra']);
const DOCUMENT_VALIDATORS = { site: validateSite, price: validatePrice };
const OWNER_DOCUMENTS = new Map([['synapse-business/trademarks', validateMarkdown]]);
const CONTENT_COMPANIES = { alvi: 'alvi', avokado: 'avokado', avokado2: 'avokado', avokado3: 'avokado', palitra: 'palitra-love' };
const SESSION_TTL = 30 * 24 * 60 * 60;
const LOGIN_WINDOW = 10 * 60 * 1000;
const LOGIN_LIMIT = 10;
// Ключ подписи сессий: переменная окружения главнее, иначе постоянный приватный файл рядом с базой.
const SESSION_SECRET = resolveSessionSecret({
  envSecret: process.env.SESSION_SECRET,
  databasePath: DATABASE_PATH,
  onEvent: (event, { file }) => console.warn(event === 'created'
    ? `content: SESSION_SECRET не задан — создан постоянный ключ подписи сессий ${file}; потребуется один повторный вход`
    : `content: SESSION_SECRET не задан — используется сохранённый ключ подписи сессий ${file}`),
}).secret;
const CRM_URL = (process.env.CRM_URL || 'http://crm:8080').replace(/\/$/, '');
const CRM_API_KEY = (process.env.CRM_API_KEY || '').trim();
const readCompanyLinks = createCompanyLinksReader({crmUrl: CRM_URL, apiKey: CRM_API_KEY, companies: CONTENT_COMPANIES});
const publicEmailUnsubscribe = createEmailUnsubscribeProxy({crmUrl: CRM_URL, apiKey: CRM_API_KEY});
const CHAT_URL = (process.env.CHAT_URL || 'http://chat:8080').replace(/\/$/, '');
const CHAT_API_KEY = (process.env.CHAT_API_KEY || '').trim();
const HUGH_RUNTIME_URL = (process.env.HUGH_RUNTIME_URL || 'http://hugh-runtime:8080').replace(/\/$/, '');
// Локальный обработчик Хью на компьютере владельца: хеш его ключа и компании, обслуживаемые только им.
const HUGH_LOCAL_WORKER_KEY_SHA256 = (process.env.HUGH_LOCAL_WORKER_KEY_SHA256 || '').trim();
const HUGH_LOCAL_WORKER_COMPANIES = (process.env.HUGH_LOCAL_WORKER_COMPANIES || '').split(',').map((s) => s.trim()).filter(Boolean);
// Telegram Mini App чата проекта: несекретный числовой ID бота для проверки подписи Telegram. Пусто — вход отключён.
const TELEGRAM_BOT_ID = (process.env.TELEGRAM_BOT_ID || '').trim();
const CRM_IDENTITY_HEADER = 'x-synapse-crm-identity';
const openClientIntake = createClientIntakeProxy({crmUrl:CRM_URL,apiKey:CRM_API_KEY,identityHeader:crmIdentityHeader});
const loginFailures = new Map();

/* Ответ службы Хью для кабинета: только известные поля и короткие строки,
   без произвольного текста стороннего сервера и без ключей. */
function sanitizeRuntime(payload) {
  const data = payload && typeof payload === 'object' && !Array.isArray(payload) ? payload : {};
  const text = (value, limit) => String(value ?? '').replace(/[\r\n\t]+/g, ' ').slice(0, limit);
  const link = String(data.loginUrl || data.verificationUrl || '');
  return {
    connected: data.connected === true,
    authenticated: data.authenticated === true,
    configured: true,
    state: text(data.state, 40) || 'unknown',
    provider: text(data.provider, 40) || 'codex',
    model: text(data.model, 60),
    loginUrl: /^https:\/\/(?:[\w-]+\.)*(?:openai|chatgpt)\.com\/[^\s"'<>]*$/.test(link) && link.length <= 300 ? link : '',
    userCode: /^[A-Za-z0-9-]{1,32}$/.test(String(data.userCode || '')) ? String(data.userCode) : '',
    error: text(data.error, 200),
  };
}

function logAuthorizationDenial(request, error) {
  const session = sessionData(request);
  const login = String(error.login || session?.user?.login || 'неизвестен').replace(/[\r\n\t]/g, ' ');
  const route = String(request.url || '/').split('?')[0].replace(/[\r\n\t]/g, ' ');
  const reason = String(error.message || 'Отказано').replace(/[\r\n\t]/g, ' ');
  console.warn(`content: authorization_denied time=${new Date().toISOString()} login=${JSON.stringify(login)} route=${JSON.stringify(route)} reason=${JSON.stringify(reason)}`);
}

function logAccountMutation(action, actor, target, before, after) {
  console.log(`content: account_${action} time=${new Date().toISOString()} actor=${JSON.stringify(actor.login)}` +
    ` target=${JSON.stringify(target.login)} old_companies=${JSON.stringify(before.companyCodes)}` +
    ` new_companies=${JSON.stringify(after?.companyCodes || [])}` +
    ` old_permissions=${JSON.stringify(before.permissions)} new_permissions=${JSON.stringify(after?.permissions || [])}`);
}

function publicIdentity(identity) {
  return {
    userId: identity.id, login: identity.login, displayName: identity.displayName,
    author: identity.displayName, role: identity.role, companies: identity.companies,
    permissions: identity.permissions,
    sites: identity.companies.map((company) => company.contentSiteId).filter(Boolean),
  };
}

function crmIdentityHeader(identity) {
  return Buffer.from(JSON.stringify({
    v: 1,
    userId: identity.id,
    role: identity.role,
    userName: identity.displayName || identity.login,
    permissions: identity.permissions,
    companyCodes: identity.companyCodes,
  })).toString('base64url');
}

function b64url(value) { return Buffer.from(value).toString('base64url'); }
function signature(payload) { return crypto.createHmac('sha256', SESSION_SECRET).update(payload).digest('base64url'); }
function makeSession(identity) {
  const payload = b64url(JSON.stringify({ uid: identity.id, sessionVersion: identity.sessionVersion,
    exp: Math.floor(Date.now() / 1000) + SESSION_TTL, csrf: crypto.randomBytes(24).toString('base64url') }));
  return `${payload}.${signature(payload)}`;
}
function sessionData(request) {
  const cookies = Object.fromEntries(String(request.headers.cookie || '').split(';').map((part) => part.trim().split(/=(.*)/s)).filter(([key]) => key));
  const [payload, sig] = String(cookies.synapse_session || '').split('.');
  if (!payload || !sig) return null;
  const expected = signature(payload);
  if (sig.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
  try {
    const token = JSON.parse(Buffer.from(payload, 'base64url').toString());
    if (token.exp < Math.floor(Date.now() / 1000)) return null;
    const current = authStore.getById(token.uid);
    if (!current || current.sessionVersion !== token.sessionVersion) return null;
    // PALITRA-CRM: server-only срок cookie и непрозрачная ссылка на ЭТУ cookie (HMAC); не перечисляются и не сериализуются.
    return Object.defineProperties({ user: current, csrf: token.csrf }, {
      exp: { value: token.exp },
      cookieRef: { value: crypto.createHmac('sha256', SESSION_SECRET).update(`palitra-crm-cookie-ref:${payload}.${sig}`).digest('hex') },
    });
  } catch { return null; }
}

if (!Number.isInteger(PORT) || PORT < 1 || PORT > 65535) {
  throw new Error('PORT должен быть целым числом от 1 до 65535');
}
if (!API_KEY) {
  console.warn('content: API_KEY пуст — запасной вход по ключу владельца отключён');
}

const db = new DatabaseSync(DATABASE_PATH);
// Private source snapshots live outside the existing chat/order/account database.
const salonCompanyApp = createSalonCompanyApp({databasePath:path.join(path.dirname(DATABASE_PATH),'salon-reports.sqlite')});
db.exec(`
  PRAGMA foreign_keys = ON;
  PRAGMA journal_mode = WAL;
  CREATE TABLE IF NOT EXISTS documents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    key TEXT NOT NULL,
    version INTEGER NOT NULL,
    created_at TEXT NOT NULL,
    author TEXT,
    body TEXT NOT NULL,
    UNIQUE (key, version)
  );
  CREATE INDEX IF NOT EXISTS documents_key_idx ON documents(key, version DESC);
`);
const authStore = createAuthStore(db, process.env.AUTH_USERS || '');
const companyTeam = require('./company-team').createCompanyTeam(authStore);
const actorOnboarding = createActorOnboarding({ db, authStore,
  requireSession: (request) => requireSession(request),
  requireCsrf: (request, session) => requireCsrf(request, session),
  readJson: (request) => readJson(request), sendJson: (response, status, payload) => send(response, status, payload) });
const actorWorkspace = createActorWorkspace({ db, authStore,
  requireSession: (request) => requireSession(request),
  requireCsrf: (request, session) => requireCsrf(request, session),
  readJson: (request) => readJson(request), sendJson: (response, status, payload) => send(response, status, payload),
  ask: (payload) => projectChat.askHugh(JSON.stringify(payload)),
  loadActorProfile: (code, userId) => actorOnboarding.getOwnProfile(code, userId),
  // Узкая статистика для участника: CRM получает доступ только к его компании; клиенту
  // модуль отдаёт лишь агрегированные счётчики, без CRM, ссылок, аккаунтов и истории постов.
  loadSocialOverview: async (code, user) => {
    if (!CRM_API_KEY) return null;
    const identity = crmIdentityHeader({ id: user.id, role: 'editor', displayName: 'Участник',
      permissions: ['analytics.view'], companyCodes: [code] });
    const upstream = await fetch(`${CRM_URL}/social-stats?companyCode=${encodeURIComponent(code)}`, {
      headers: { 'x-api-key': CRM_API_KEY, [CRM_IDENTITY_HEADER]: identity },
      signal: AbortSignal.timeout(5000) });
    return upstream.ok ? upstream.json() : null;
  } });
const hughSettingsStore = createHughSettingsStore(db);
// Заявки с сайта принимаются только для Palitra: сайт задаёт Caddy, список Origin — точный allowlist.
const clientCompanies = clientCompanyConfig(process.env, CONTENT_COMPANIES);
// PALITRA: при включённом оформлении/CRM — ровно адрес магазина в существующий список Origin Palitra; иначе тот же объект.
const ORDER_SITES = require('./palitra-host-adapter.cjs').withShopOrigin(clientCompanies.orderSites, process.env);
const ORDER_BODY_LIMIT = 32 * 1024;
// PALITRA-APP-WORKPLACE: записи рабочего места Palitra принимаются только со страницы кабинета Synapse (точный Origin).
const PALITRA_APP_ORIGIN = 'https://synapse.synapsebusiness.ru';
/* Защищённое хранилище ключей провайдеров Хью: владелец вводит ключ в ЛК, ключ шифруется
   внешним мастер-ключом и наружу не возвращается. Без мастер-ключа хранилище закрыто. */
const hughProviders = createHughProviders({ db });
const projectChat = createProjectChat({ db, authStore, assetsDir: ASSETS_DIR,
  fallback: { providerStore: hughProviders },
  runnerUrl: HUGH_RUNTIME_URL, chatUrl: CHAT_URL, chatApiKey: CHAT_API_KEY,
  localWorker: { keySha256: HUGH_LOCAL_WORKER_KEY_SHA256, companies: HUGH_LOCAL_WORKER_COMPANIES },
  // Соль для хеша IP выводится из секрета сессий: сам IP не хранится, отдельного секрета не нужно.
  siteOrders: { sites: ORDER_SITES, groupNotificationSites: [], priceReader: (site) => latestStmt.get(`${site}/price`)?.body ?? null,
    ipSalt: crypto.createHash('sha256').update(`site-orders-ip:${SESSION_SECRET}`).digest('hex') },
  miniApp: { botId: TELEGRAM_BOT_ID, sessionSecret: SESSION_SECRET },
  // Команды Хью в группах: сводка плана берётся из CRM тем же служебным ключом; имя бота — не секрет.
  crmUrl: CRM_URL, crmApiKey: CRM_API_KEY, botUsername: (process.env.TELEGRAM_BOT_USERNAME || '').trim().replace(/^@/, ''),
  cabinetUrl: (process.env.CABINET_PUBLIC_URL || 'https://synapse.synapsebusiness.ru/cabinet.html').trim(),
  requireSession, requireCsrf, sendJson: send, readBody: readJson });
const taskDispatchWorker = require('./task-dispatch-worker').createTaskDispatchWorker({db,crmUrl:CRM_URL,crmApiKey:CRM_API_KEY,fallback:projectChat.fallback});
const contentPlanRunner = require('./content-plan-runner').createContentPlanRunner({crmUrl:CRM_URL,crmApiKey:CRM_API_KEY,fallback:projectChat.fallback,
  alerts:require('./hugh-owner-alerts').createHughOwnerAlerts({db}),reviewDelayNotifications:true,
  onReviewDelayError:()=>console.warn('content: проверка просроченных согласований не выполнена; повтор при следующей проверке')});
// Необязательный приватный конфиг на постоянном томе content. Без него приём выключен.
const telegramSources = createTelegramSources({db, assetsDir:ASSETS_DIR, authStore, requireSession, requireCsrf, sendJson:send,
  config:readSourceConfig(path.join(path.dirname(DATABASE_PATH),'telegram-sources.json'))});
if (!telegramSources.healthy) console.warn('content: настройки источников Telegram требуют проверки; приём выключен');
const contentFactorySources=createContentFactorySourceBridge({db,authStore,assetsDir:ASSETS_DIR,
  requireSession,requireCsrf,readJson,sendJson:send,publishingOrigin:PUBLISHING_ASSET_ORIGIN,
  maxImageBytes:MAX_PUBLISHING_ASSET,maxVideoBytes:MAX_PUBLISHING_VIDEO,ready:()=>Boolean(CRM_API_KEY),
  crmCall:contentFactoryCrm});
const contentFactorySourceContext=createSourceContext({db});
async function contentFactoryCrm(action,companyCode,body,user){
    let upstream;
    try{upstream=await fetch(`${CRM_URL}/internal/content-factory/${action}?companyCode=${encodeURIComponent(companyCode)}`,{
      method:'POST',redirect:'error',headers:{'content-type':'application/json','x-api-key':CRM_API_KEY,
        [CRM_IDENTITY_HEADER]:crmIdentityHeader(user)},body:JSON.stringify(body),signal:AbortSignal.timeout(10000)});
    }catch{fail(502,'Ответ CRM не получен. Повторите тот же запрос.');}
    const result=await upstream.json().catch(()=>null);
    if(!upstream.ok)fail(upstream.status,typeof result?.error==='string'?result.error.slice(0,500):'CRM не завершила операцию');
    if(!result||typeof result!=='object')fail(502,'CRM вернула неполный ответ. Повторите тот же запрос.');
    return result;
}
for (const issue of [...projectChat.localWorker.issues, ...projectChat.miniApp.issues]) console.warn(`content: ${issue}`);
/* Клиентские Telegram-боты: переписка клиентов с менеджером и уведомления о заявках.
   Включается только именем бота (не секрет); токен живёт только в сервисе chat. Пусто — выключен. */
// Общий предел сохранённых файлов клиентских ботов (МБ); пусто — 1024 МБ. Сверх предела файл не сохраняется, история не удаляется.
const CLIENT_DIALOGS_MAX_STORAGE_MB = Number.parseInt(process.env.CLIENT_DIALOGS_MAX_STORAGE_MB || '', 10);
// PALITRA-APP-WORKPLACE: ответ владельца из приложения уходит, только пока автор — действующий владелец той же версии сессии.
const ownerStillValid = (userId, sessionVersion) => { const user = authStore.getById(userId); return Boolean(user && user.role === 'owner' && user.sessionVersion === sessionVersion); };
// Existing CRM permissions only, scoped to Palitra Love. No grants are changed.
function palitraSessionAccess(session, write = false) {
  if (!palitraCanAccess(session?.user, write ? 'crm.edit' : 'crm.view')) fail(403, 'Нет доступа к заказам Palitra Love');
  return session;
}
const palitraActorValid = (id, version, write) => {
  const user = authStore.getById(id);
  return Boolean(user && user.sessionVersion === version && palitraCanAccess(user, write ? 'crm.edit' : 'crm.view'));
};
const palitraWriterStillValid = (id, version) => palitraActorValid(id, version, true);
const palitraReaderStillValid = (id, version) => palitraActorValid(id, version, false);
let palitraWorkflow = null;
let palitraPushHost = null;
let palitraContactFollowup = null;
const palitraMemoAssets = require('./palitra-order-memo.cjs').createMemoAssets({
  db, transaction: projectChat.transaction, getUser: id => authStore.getById(id), canAccess: palitraCanAccess
});
const palitraMemoHttp = require('./palitra-order-memo.cjs').createMemoHttp({
  assets: palitraMemoAssets, requireSession, requireCsrf, origin: PALITRA_APP_ORIGIN
});
async function palitraReadBody(request, previous) {
  const body = await readJson(request), fresh = requireSession(request);
  if (fresh.user.id !== previous.user.id || fresh.user.sessionVersion !== previous.user.sessionVersion) fail(403, 'Доступ изменился');
  palitraSessionAccess(fresh, true); requireCsrf(request, fresh);
  return body;
}

/* PALITRA-WEBCHAT-PHASEB: чат сайта. Одна SQLite, ОДНА транзакция хоста (projectChat.transaction — та же, что у siteOrders и
   магазина), одна очередь client_bot_outbox и существующий мост. Включается только PALITRA_CUSTOMER_CHAT_ENABLED=true;
   выключенный — новых копий нет, ожидающие копии чата останавливаются, прежние диалоги и заявки работают как раньше. */
const palitraShopParse = require('./palitra-host-adapter.cjs').parseShop(process.env);
const customerChatNative = createCustomerChatNative({ db, transaction: projectChat.transaction, siteOrders: projectChat.siteOrders, ownerStillValid: palitraWriterStillValid,
  ownerCanRead: palitraReaderStillValid, onCustomerMessage: event => palitraWorkflow?.onCustomerMessage(event),
  onOrderThreadCreated: event => {
    if (!palitraWorkflow) fail(503, 'Автоответ заявки ещё не подключён');
    return palitraWorkflow.onOrderThreadCreated(event);
  },
  customerQuestions: thread => palitraWorkflow?.customerQuestions(thread) || [],
  automaticReplyView: message => palitraWorkflow?.orderReplyDisplay(message) || null,
  workflowOrder: (owner, orderId) => {
    if (!palitraWorkflow) fail(503, 'Этапы заказа ещё не подключены');
    return palitraWorkflow.getOrder(owner, orderId);
  },
  onMessageStored: event => {
    // Обычное сообщение сохраняется даже при ошибке необязательной проекции.
    // Workflow изолирует свою запись SAVEPOINT; уведомление не зависит от её успеха.
    try { palitraWorkflow?.onMessageStored(event); }
    catch (_) { console.warn('palitra: этап переписки временно не обновлён'); }
    return palitraPushHost?.onMessageStored(event);
  },
  readCompletionMedia: input => palitraMemoAssets.read(input),
  onNativeOrderCreated: event => palitraContactFollowup?.register(event),
  followupNotificationEnabled: () => palitraContactFollowup?.enabled === true,
  origins: palitraShopParse.ok ? [...palitraShopParse.shop.origins] : [`https://${require('./palitra-host-adapter.cjs').FIXED.hostname}`],
  enabled: process.env.PALITRA_CUSTOMER_CHAT_ENABLED === 'true' && palitraShopParse.ok,
  // PALITRA-WEBCHAT-PHASEE: новые загрузки файлов (сайт и приложение) — отдельный выключатель, по умолчанию выключен.
  // Включает только Root после обновления единственного моста (sendPhoto/sendDocument + upload-source). Чтение уже
  // сохранённых файлов от него не зависит.
  uploadsEnabled: process.env.PALITRA_WEB_UPLOADS_ENABLED === 'true' });
const clientDialogs = createClientDialogs({ db, assetsDir: ASSETS_DIR, siteOrders: projectChat.siteOrders,
  ...(CLIENT_DIALOGS_MAX_STORAGE_MB >= 0 ? { maxStorage: CLIENT_DIALOGS_MAX_STORAGE_MB * 1024 * 1024 } : {}),
  ownerStillValid: palitraWriterStillValid, ownerCanRead: palitraReaderStillValid, bots: clientCompanies.bots,
  // PALITRA-WEBCHAT-PHASEB: общая транзакция и единственное подключение адаптера чата к закрытым функциям бота.
  transact: projectChat.transaction, chatIntegration: customerChatNative.attach,
  contactFollowupGuard: job => palitraContactFollowup?.guardTelegram(job) || null });
palitraPushHost = require('./palitra-push-host.cjs').createPalitraPushHost({
  db, transaction: projectChat.transaction, getCore: () => customerChatNative.core(),
  getUser: id => authStore.getById(id), requireSession, requireCsrf,
  canReadPalitra: user => palitraCanAccess(user, 'crm.view'),
  contactFollowupEnabled: () => palitraContactFollowup?.enabled === true,
  enabled: process.env.PALITRA_WEB_PUSH_ENABLED === 'true', keyPath: '/run/secrets/palitra-push/vapid.json'
});
palitraContactFollowup = require('./native-contact-followup.cjs').createFollowupDispatcher({
  db, transaction: projectChat.transaction,
  enabled: customerChatNative.enabled && process.env.PALITRA_CONTACT_FOLLOWUP_ENABLED === 'true',
  enabledAfterUtc: process.env.PALITRA_CONTACT_FOLLOWUP_ENABLED_AFTER_UTC || '',
  notify: event => ({ telegramJobId: clientDialogs.enqueueOrderContactFollowup(event),
    pushJobs: palitraPushHost.onOrderFollowup(event).enqueued })
});
/* Личная переписка владельца по проектам: собственные таблицы и собственная область доступа.
   Из общего чата сюда переиспользован только транспорт обращения к модели (askHugh),
   который ничего не читает и не пишет в таблицы чата проекта. */
const ownerPrivateChat = createOwnerPrivateChat({ db, authStore,
  ask: (payload) => projectChat.askHugh(JSON.stringify(payload)),
  skills: projectChat.skills || null,
  requireSession, requireCsrf, sendJson: send, readBody: readJson });

/* Подсказки Медиа-наставника: разбор брифа, черновик контент-плана, разбор результатов.
   Транспорт к модели — тот же askHugh, что и у личной переписки владельца: второго пути
   к провайдерам и второго места для ключей не заводим.
   Бриф и статистика читаются на сервере служебным ключом CRM: принимать их от клиента нельзя,
   иначе подсказку можно построить на подложенных данных чужой компании. */
const mediaMentorSuggestRoute = createMediaMentorSuggestRoute({
  suggester: createMediaMentorSuggest({ask: (payload) => projectChat.askHugh(payload)}),
  loadBrief: async (code, identity) => {
    const upstream = await fetch(`${CRM_URL}/media-mentor?companyCode=${encodeURIComponent(code)}`,
      {headers: {'x-api-key': CRM_API_KEY, [CRM_IDENTITY_HEADER]: crmIdentityHeader(identity)}});
    if (!upstream.ok) return null;
    const data = await upstream.json();
    return data?.brief?.fields ?? null;
  },
  // Разбор результатов читает и статистику, и текущий план: выводы без плана были бы «в воздух».
  loadStats: async (code, {from, to} = {}, identity) => {
    const params = new URLSearchParams({companyCode: code});
    if (from) params.set('from', from);
    if (to) params.set('to', to);
    const statsUpstream = await fetch(`${CRM_URL}/social-stats?${params}`,
      {headers: {'x-api-key': CRM_API_KEY, [CRM_IDENTITY_HEADER]: crmIdentityHeader(identity)}});
    if (!statsUpstream.ok) return null;
    const planUpstream = await fetch(`${CRM_URL}/media-mentor?companyCode=${encodeURIComponent(code)}`,
      {headers: {'x-api-key': CRM_API_KEY, [CRM_IDENTITY_HEADER]: crmIdentityHeader(identity)}});
    const plan = planUpstream.ok ? (await planUpstream.json())?.plan ?? null : null;
    return {overview: await statsUpstream.json(), plan};
  },
  requireSession, requireCsrf, requirePermission,
  sendJson: send, readBody: readJson, fail,
});

const latestStmt = db.prepare('SELECT * FROM documents WHERE key = ? ORDER BY version DESC LIMIT 1');
const byVersionStmt = db.prepare('SELECT * FROM documents WHERE key = ? AND version = ?');
const historyStmt = db.prepare(
  'SELECT version, created_at, author, length(body) AS size FROM documents WHERE key = ? ORDER BY version DESC LIMIT ?'
);
const insertStmt = db.prepare(
  'INSERT INTO documents (key, version, created_at, author, body) VALUES (?, ?, ?, ?, ?)'
);
palitraWorkflow = createWorkflow({ db, transaction: projectChat.transaction, siteOrders: projectChat.siteOrders, getUser: id => authStore.getById(id),
  validateCompletionMedia: input => customerChatNative.core().validateCompletionMedia(input),
  prepareCompletion: input => {
    const { threadId } = customerChatNative.orderThread('palitra', input.orderId);
    if (!threadId) fail(409, 'У заказа нет подтверждённого чата для памятки');
    return customerChatNative.core().prepareOrderCompletion({ ...input, threadId });
  },
  appendCompletion: input => {
    const { threadId } = customerChatNative.orderThread('palitra', input.orderId);
    if (!threadId) fail(409, 'У заказа нет подтверждённого чата для отзыва и памятки');
    return customerChatNative.core().appendOrderCompletion({ ...input, threadId });
  }
});
const palitraWorkflowHttp = createWorkflowHttp({ workflow: palitraWorkflow, requireSession, requireCsrf, readJson, origin: PALITRA_APP_ORIGIN });
const palitraManagerAttention = createManagerAttention({db,canAccess:palitraCanAccess});
// PALITRA_RESPONSE_REPORT: observation starts once; report reads never write.
function palitraResponseChannelState() {
  const bot = Object.entries(clientCompanies.bots).find(([, value]) => value?.site === 'palitra');
  const telegram = !bot || !clientDialogs.enabledFor('palitra') ? 'not_connected'
    : clientDialogs.bridgeState(bot[0]).ready === true ? 'connected' : 'unobserved';
  return { site: customerChatNative.enabled && customerChatNative.isAttached() ? 'connected' : 'not_connected',
    telegram, vk: 'not_connected', instagram: 'not_connected', youtube: 'not_connected', tiktok: 'not_connected' };
}
const palitraResponseReport = createResponseReport({db,transaction:projectChat.transaction,
  getUser:id=>authStore.getById(id),channelState:palitraResponseChannelState});
palitraResponseReport.initializeObservation();
// PALITRA_RESPONSE_REPORT_END


/* Первичное наполнение: seed/<site>-<doc>.json кладётся как версия 1, если документа ещё нет. */
function seedDocuments() {
  if (!fs.existsSync(SEED_DIR)) return;
  for (const file of fs.readdirSync(SEED_DIR)) {
    if (!file.endsWith('.json')) continue;
    const stem = file.replace(/\.json$/, '');
    const key = stem === 'synapse-business-trademarks' ? 'synapse-business/trademarks' : stem.replace('-', '/');
    const latest = latestStmt.get(key);
    // Пока документ никто не правил руками (все версии — seed), обновлённый seed из репозитория
    // становится новой версией. После первого сохранения из кабинета seed больше не вмешивается.
    if (latest && latest.author !== 'seed') continue;
    try {
      const raw = fs.readFileSync(path.join(SEED_DIR, file), 'utf8');
      JSON.parse(raw);
      if (latest && latest.body === raw) continue;
      insertStmt.run(key, latest ? latest.version + 1 : 1, new Date().toISOString(), 'seed', raw);
      console.log(`content: документ ${key} ${latest ? 'обновлён' : 'создан'} из seed`);
    } catch (error) {
      console.error(`content: seed ${file} пропущен — ${error.message}`);
    }
  }
}
seedDocuments();

function send(response, status, payload, extraHeaders) {
  const body = typeof payload === 'string' ? payload : JSON.stringify(payload);
  response.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(body),
    'cache-control': 'no-store',
    ...(extraHeaders || {}),
  });
  response.end(body);
}

function fail(status, message, details) {
  const error = new Error(message);
  error.status = status;
  error.details = details;
  throw error;
}

async function readJson(request) {
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > MAX_BODY) fail(413, 'Документ не должен превышать 1 МБ');
    chunks.push(chunk);
  }
  if (chunks.length === 0) fail(400, 'Ожидалось тело запроса в формате JSON');
  try {
    const value = JSON.parse(Buffer.concat(chunks).toString('utf8'));
    if (!value || Array.isArray(value) || typeof value !== 'object') {
      fail(400, 'Тело запроса должно быть JSON-объектом');
    }
    return value;
  } catch (error) {
    if (error.status) throw error;
    fail(400, 'Некорректный JSON');
  }
}

/* Возвращает имя автора по ключу владельца или сессии кабинета. */
function requireAuth(request, site) {
  const given = (request.headers['x-api-key'] || '').toString().trim();
  if (API_KEY && given === API_KEY) return { author: 'system-owner' };
  let identity;
  if (!given) identity = sessionData(request)?.user;
  if (!identity) fail(401, given ? 'Неверный ключ доступа' : 'Требуется вход в кабинет или ключ доступа');
  if (identity.id && site && identity.role !== 'owner' && !identity.companyCodes.includes(CONTENT_COMPANIES[site])) {
    fail(403, 'У вашей учётной записи нет доступа к этому сайту');
  }
  return publicIdentity(identity);
}

/* Проверка документа сайта: секции с id, поля key/value — строки, фон — объект. */
function validateSite(doc) {
  const problems = [];
  if (!Array.isArray(doc.sections)) problems.push('Нет списка секций sections');
  const ids = new Set();
  for (const sec of doc.sections || []) {
    if (!sec || typeof sec.id !== 'string' || !sec.id) { problems.push('У секции нет id'); continue; }
    if (ids.has(sec.id)) problems.push(`Повторяющийся id секции ${sec.id}`);
    ids.add(sec.id);
    for (const f of sec.fields || []) {
      if (!f || typeof f.key !== 'string') { problems.push(`Секция ${sec.id}: поле без key`); continue; }
      if (typeof f.value !== 'string') problems.push(`Поле ${f.key}: значение должно быть строкой`);
      if (f.value && f.value.length > 4000) problems.push(`Поле ${f.key}: длиннее 4000 символов`);
      if (/<\s*(script|iframe|object|style)/i.test(f.value || '')) problems.push(`Поле ${f.key}: недопустимая разметка`);
      if (f.href != null && !/^(https?:\/\/|mailto:|tel:|#|\/|[\w-]+\.html)/i.test(String(f.href))) problems.push(`Поле ${f.key}: недопустимая ссылка`);
      if (f.src != null && f.src !== '' && !/^(img\/|\/api\/assets\/|https:\/\/)[\w\-./%]+$/.test(String(f.src))) problems.push(`Поле ${f.key}: недопустимый путь к картинке`);
      if (f.layout != null && typeof f.layout !== 'object') problems.push(`Поле ${f.key}: layout должен быть объектом`);
      if (f.style != null) {
        if (typeof f.style !== 'object') problems.push(`Поле ${f.key}: style должен быть объектом`);
        else {
          if (f.style.font && !/^[\w ]{1,40}$/.test(f.style.font)) problems.push(`Поле ${f.key}: недопустимый шрифт`);
          if (f.style.size != null && !(Number(f.style.size) >= 50 && Number(f.style.size) <= 300)) problems.push(`Поле ${f.key}: размер от 50% до 300%`);
        }
      }
    }
    if (sec.background && typeof sec.background !== 'object') problems.push(`Секция ${sec.id}: фон должен быть объектом`);
    if (sec.background && sec.background.image && !/^(img\/|\/api\/assets\/|https:\/\/)[\w\-./%]+$/.test(sec.background.image)) {
      problems.push(`Секция ${sec.id}: недопустимый путь к фону`);
    }
  }
  if (problems.length) fail(422, 'Документ не прошёл проверку', problems);
}

function safeAssetName(name) {
  const base = String(name || 'image').normalize('NFKD').replace(/[^\w.-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60) || 'image';
  return base;
}

async function readRaw(request, limit) {
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > limit) fail(413, `Файл не должен превышать ${Math.round(limit / 1024 / 1024)} МБ`);
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

/* Проверка прайса: лимиты «не больше 8», уникальные id, ссылки витрины на существующие позиции. */
function validatePrice(doc) {
  const problems = [];
  if (!Array.isArray(doc.categories)) problems.push('Нет списка разделов categories');
  const ids = new Set();
  for (const cat of doc.categories || []) {
    if (!cat || typeof cat.id !== 'string' || !cat.id.trim()) { problems.push('У раздела нет id'); continue; }
    if (typeof cat.title !== 'string' || !cat.title.trim()) problems.push(`Раздел ${cat.id}: пустое название`);
    if (!['programs', 'table'].includes(cat.kind)) problems.push(`Раздел ${cat.id}: неизвестный тип ${cat.kind}`);
    if (!['self', 'two'].includes(cat.block)) problems.push(`Раздел ${cat.id}: блок главной должен быть self или two`);
    if (ids.has(cat.id)) problems.push(`Повторяющийся id ${cat.id}`);
    ids.add(cat.id);
    for (const it of cat.items || []) {
      if (!it || typeof it.id !== 'string' || !it.id.trim()) { problems.push(`Раздел ${cat.id}: у позиции нет id`); continue; }
      if (ids.has(it.id)) problems.push(`Повторяющийся id ${it.id}`);
      ids.add(it.id);
      if (typeof it.title !== 'string' || !it.title.trim()) problems.push(`Позиция ${it.id}: пустое название`);
      if (it.oldPrice != null && typeof it.oldPrice !== 'string') problems.push(`Позиция ${it.id}: старая цена должна быть строкой`);
      if (it.quizEnabled != null && typeof it.quizEnabled !== 'boolean') problems.push(`Позиция ${it.id}: признак участия в квизе должен быть логическим`);
      if (it.gallery != null) {
        // Дополнительные фото товара (обложка — прежнее поле photo): до 8 адресов сайта или https.
        if (!Array.isArray(it.gallery)) problems.push(`Позиция ${it.id}: дополнительные фото должны быть списком`);
        else {
          if (it.gallery.length > 8) problems.push(`Позиция ${it.id}: больше 8 дополнительных фото`);
          for (const photo of it.gallery) {
            if (typeof photo !== 'string' || photo.length > 1000 || !(/^\/(?!\/)/.test(photo) || /^https:\/\//i.test(photo))) {
              problems.push(`Позиция ${it.id}: некорректный адрес дополнительного фото`); break;
            }
          }
        }
      }
    }
  }
  const showcase = doc.showcase || {};
  for (const block of ['self', 'two']) {
    const list = showcase[block] || [];
    if (!Array.isArray(list)) { problems.push(`Витрина ${block} должна быть списком id`); continue; }
    const max = Number(doc.blocks?.[block]?.max) || 8;
    if (list.length > max) problems.push(`Витрина ${block}: больше ${max} позиций (${list.length})`);
    for (const id of list) if (!ids.has(id)) problems.push(`Витрина ${block}: позиции ${id} нет в прайсе`);
    if (new Set(list).size !== list.length) problems.push(`Витрина ${block}: позиции повторяются`);
  }
  // «до 8 популярных в разделе»
  for (const cat of doc.categories || []) {
    const popular = (cat.items || []).filter((it) => (showcase.self || []).includes(it.id) || (showcase.two || []).includes(it.id));
    if (popular.length > 8) problems.push(`Раздел ${cat.id}: отмечено больше 8 популярных (${popular.length})`);
  }
  if (problems.length) fail(422, 'Документ не прошёл проверку', problems);
}

function validateMarkdown(doc) {
  if (Object.keys(doc).join(',') !== 'markdown' || typeof doc.markdown !== 'string') {
    fail(422, 'Markdown-документ должен содержать только строку markdown');
  }
}

function nextVersion(key) {
  const latest = latestStmt.get(key);
  return latest ? latest.version + 1 : 1;
}

function saveVersion(key, doc, author) {
  const version = nextVersion(key);
  const now = new Date().toISOString();
  const body = JSON.stringify({ ...doc, version, updatedAt: now });
  insertStmt.run(key, version, now, author || null, body);
  return { version, updatedAt: now };
}

const siteStore = createSiteStore(db, authStore, saveVersion);
const workspaceFeature=createWorkspaceFeature({db,authStore,companies:COMPANIES,siteStore,palitraShop:require('./palitra-host-adapter.cjs').shopConfig(process.env),
  requirePermission,requireCsrf,readJson:async request=>{
    try{return JSON.parse((await readRaw(request,8*1024*1024+65536)).toString('utf8'));}
    catch(error){if(error.status)throw error;fail(400,'Некорректный JSON');}
  },databasePath:DATABASE_PATH,assetsDir:ASSETS_DIR});
// Фото черновика Palitra: только site-44bbe13f1bad5e005b2a/index.html (PALITRA-BOT-EDITOR-35).
const palitraDecodeImage=createSharpDecoder(require("/data/palitra-photo-deps/node_modules/sharp"));
const photoFeature=createPalitraPhotoFeature({db,authStore,requireSession,requireCsrf,readJson,readRaw,
  workspaceStore:workspaceFeature.store,assetsDir:ASSETS_DIR,decodeImage:palitraDecodeImage,expectedPublicUrl:"https://palitra-love-draft-1.synapsebusiness.ru/"});
/* PALITRA (13.10.2026, Phase 2+3): оформление заказа фиксированного магазина и CRM — в ТОЙ ЖЕ SQLite и вложенной
   транзакции хоста (projectChat.transaction, как siteOrders). Всё выключено по умолчанию: PALITRA_CHECKOUT_ENABLED=true
   включает только существующий приём заявок на адресе магазина; CRM — PALITRA_CRM_ENABLED=true и явный PALITRA_CRM_BOT_ID. */
// PALITRA-WEBCHAT-PHASEB: HTTP чата сайта — AccountService того адреса магазина, на который пришёл запрос; имя бота — не секрет.
const customerChatHttp = createCustomerChatHttp({ core: customerChatNative.core, site: 'palitra', enabled: customerChatNative.enabled,
  origins: palitraShopParse.ok ? [...palitraShopParse.shop.origins] : [],
  widgetSettings: () => palitraWorkflow.getPublicWidgetSettings(),
  account: (request) => workspaceFeature.draftAccount(request),
  botUsername: (site) => Object.values(clientCompanies.bots).find((bot) => bot && bot.site === site)?.username || '' });
const palitraHost=require('./palitra-host-adapter.cjs').createPalitraHostAdapter({env:process.env,db,
  customerChat:{ http: customerChatHttp, submitWithChat: customerChatNative.submitWithChat },
  transaction:projectChat.transaction,siteOrders:projectChat.siteOrders,
  priceRow:()=>latestStmt.get('palitra/price')??null,
  authStore,sessionData,requireCsrf,clientIp,originOf,
  refKey:crypto.createHash('sha256').update(`palitra-crm-site-ref:${SESSION_SECRET}`).digest(),
  // PALITRA-MAIN: AccountService того адреса магазина, на который пришёл запрос (черновик или одобренный основной).
  draftAccount:request=>workspaceFeature.draftAccount(request),
  issueOrderLink:input=>clientDialogs.issueOrderLink(input),
  // PALITRA-MAIN: фото прайса — тот же каталог, что у существующего /content/palitra/assets/:name (пишет редактор прайса).
  palitraAssetsDir:path.join(ASSETS_DIR,'palitra'),
  // PALITRA-WEBCHAT-PHASEC: отдельный каталог оболочки /chat (три постоянных файла); publicDir review39 и CRM не трогаются.
  chatPublicDir:path.join(__dirname,'palitra-review-public'),
  loadIntegration:()=>require('./palitra-crm/app/lib/host-integration')});
if(palitraHost.draftHook)workspaceFeature.setDraftHook(palitraHost.draftHook);
if(!palitraHost.enabled||palitraHost.reason)console.log(`content: Palitra checkout=${palitraHost.checkoutEnabled} crm=${palitraHost.crmEnabled} — ${palitraHost.reason}`);

// PALITRA-REVIEW39-WIRING:INIT:BEGIN
const palitraTaskReview39 = createPalitraTaskReview({
  db, requireSession, requireCsrf, readJson, saveVersion,
  initialTasks: [],
  publicDir: path.join(__dirname, 'palitra-review-public'),
});
// PALITRA-REVIEW39-WIRING:INIT:END
const projectForms = createProjectFormsFeature({ db, requireSession, requireCsrf, readJson });
function requireSession(request) {
  const session = sessionData(request);
  if (!session) fail(401, 'Требуется вход в кабинет');
  return session;
}

function requirePermission(request, permission, companyCode, obscure = false) {
  const session = requireSession(request);
  const user = session.user;
  if (user.role !== 'owner' && !user.permissions.includes(permission)) fail(403, 'Недостаточно прав');
  if (companyCode && user.role !== 'owner' && !user.companyCodes.includes(companyCode)) {
    fail(obscure ? 404 : 403, obscure ? 'Объект не найден' : 'Нет доступа к компании');
  }
  return session;
}

// Cabinet access never trusts the presence of an API-key header: validate its value.
function requireContentAccess(request, permission, site, write = false) {
  if (request.headers['x-api-key']) return requireAuth(request, site);
  const session = requirePermission(request, permission, CONTENT_COMPANIES[site]);
  if (write) requireCsrf(request, session);
  return publicIdentity(session.user);
}

function requireCsrf(request, session) {
  if (String(request.headers['x-csrf-token'] || '') !== session.csrf) fail(403, 'Некорректный CSRF-токен');
}

function corsHeaders(request) {
  const origin = request.headers.origin;
  if (!origin) return {};
  if (ALLOWED_ORIGINS.includes('*') || ALLOWED_ORIGINS.includes(origin)) {
    return {
      'access-control-allow-origin': origin,
      'access-control-allow-methods': 'GET, PUT, POST, PATCH, DELETE, OPTIONS',
      'access-control-allow-headers': 'Content-Type, X-API-Key, X-Author, X-Filename, X-File-Name, X-CSRF-Token',
      'vary': 'Origin',
    };
  }
  return {};
}

async function readRequestBody(request) {
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > MAX_BODY) fail(413, 'Документ не должен превышать 1 МБ');
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

async function crmLeadCompany(id) {
  let upstreamResponse;
  try {
    upstreamResponse = await fetch(`${CRM_URL}/leads/${id}`, { headers: { 'x-api-key': CRM_API_KEY } });
  } catch (error) {
    console.error('content: ошибка проверки заявки CRM:', error);
    fail(502, 'CRM недоступна');
  }
  if (!upstreamResponse.ok) fail(404, 'Заявка не найдена');
  try {
    return (await upstreamResponse.json()).companyCode;
  } catch {
    fail(502, 'Некорректный ответ CRM');
  }
}

async function crmCompanyOwnerScope(id) {
  let upstreamResponse;
  try {
    upstreamResponse = await fetch(`${CRM_URL}/companies/${id}?includeDeleted=true`, {
      headers: { 'x-api-key': CRM_API_KEY },
    });
  } catch (error) {
    console.error('content: ошибка проверки владельца карточки CRM:', error);
    fail(502, 'CRM недоступна');
  }
  if (!upstreamResponse.ok) fail(404, 'Компания не найдена');
  try {
    return (await upstreamResponse.json()).ownerScope;
  } catch {
    fail(502, 'Некорректный ответ CRM');
  }
}

async function proxyCrm(request, response, url, cors) {
  const initialSession = requireSession(request);
  const identity = initialSession.user;
  const readOnly = request.method === 'GET';
  const crmPath = url.pathname.slice('/content/crm'.length) || '/';
  if (crmPath.startsWith('/internal/')) fail(403, 'Служебный маршрут недоступен');
  if (/^\/coordination(?:\/|$)/.test(crmPath) && identity.role !== 'owner') fail(403, 'Координация доступна владельцу');
  if (/^\/(?:vk-community|vk-tools)(?:\/|$)/.test(crmPath)) {
    if (identity.role !== 'owner') fail(403,'Подключение и сообщения ВК доступны владельцу');
    const code = url.searchParams.get('companyCode');
    if (!code || !/^[a-z0-9][a-z0-9_-]{0,63}$/i.test(code)) fail(400,'Выберите компанию');
  }
  // Испытания моделей — часть того же owner-only раздела: цены и аккаунты клиентам не показываем.
  if (/^\/(catalog|finances|ai-trials)(?:\/|$)/.test(crmPath) && identity.role !== 'owner') fail(403,'Коммерческие условия и финансы доступны владельцу');
  const companyModule = /^\/(company-information|autoposting)(?:\/|$)/.exec(crmPath)?.[1];
  if (/^\/(?:studio-journey|reviews|platform-demand|social-stats)(?:\/|$)/.test(crmPath)) {
    const code=url.searchParams.get('companyCode');
    if (!code || !/^[a-z0-9][a-z0-9_-]{0,63}$/i.test(code)) fail(400,'Выберите компанию');
    if(identity.role!=='owner')requirePermission(request,readOnly?(/^\/(?:platform-demand|social-stats)/.test(crmPath)?'analytics.view':'crm.view'):'crm.edit',code);
    if (/^\/social-stats\/(?:accounts|import|baseline)$/.test(crmPath) && !readOnly && identity.role!=='owner') fail(403,'Настройки аккаунтов и замер до начала работы доступны владельцу');
    /* Аналитический доступ Onlypult — ключ к кабинету источника, а не настройка показа.
       Owner-only И на чтение тоже: список профилей an_… выдаётся общим кабинетом и
       клиентскому аккаунту с analytics.view не показывается. */
    if (/^\/social-stats\/analytics(?:\/|$)/.test(crmPath) && identity.role!=='owner') fail(403,'Аналитический доступ и профили Onlypult настраивает владелец');
  }
  if (/^\/autoposting\/posts\/\d+\/(?:approve|reject)$/.test(crmPath) && identity.role!=='owner' && !identity.permissions.includes('autoposting.approve')) fail(403,'Нет права согласовывать публикации');
  // Отметка «опубликовано вне ЛК» — решение владельца компании; права редактора недостаточно.
  if (/^\/autoposting\/posts\/\d+\/receipts$/.test(crmPath) && identity.role!=='owner') fail(403,'Отмечать публикацию вне кабинета может только владелец');
  if (crmPath==='/autoposting/plan-summary') fail(404,'Адрес не найден');
  if (/^\/autoposting\/settings\/[^/]+\/profiles$/.test(crmPath) && identity.role!=='owner') {
    fail(403,'Профили общего аккаунта публикаций настраивает владелец');
  }
  if (companyModule) {
    const code = url.searchParams.get('companyCode');
    if (!code || !/^[a-z0-9][a-z0-9_-]{0,63}$/i.test(code)) fail(400, 'Выберите компанию');
    if (identity.role !== 'owner') {
      requirePermission(request, `${companyModule}.${readOnly ? 'view' : 'edit'}`, code);
    }
  }
  // Внедрение Медиа-наставника: этапы ведёт администратор Synapse, клиент читает их
  // и отвечает на опрос ЛК по уже выданному праву раздела публикаций своей компании.
  const mentorRollout = /^\/media-mentor-rollout(?:\/|$)/.test(crmPath);
  if (mentorRollout) {
    const code = url.searchParams.get('companyCode');
    if (!code || !/^[a-z0-9][a-z0-9_-]{0,63}$/i.test(code)) fail(400, 'Выберите компанию');
    if (identity.role !== 'owner') {
      if (crmPath !== '/media-mentor-rollout/survey' && !readOnly) {
        fail(403, 'Этапы внедрения ведёт администратор Synapse');
      }
      requirePermission(request, 'autoposting.view', code);
    }
  }
  // Бриф и контент-план Медиа-наставника переиспользуют права автопостинга: новых прав нет.
  // Согласование версии плана — решение владельца и не даёт разрешения публиковать.
  const mentorPlan = /^\/media-mentor(?:\/|$)/.test(crmPath);
  if (mentorPlan) {
    const code = url.searchParams.get('companyCode');
    if (!code || !/^[a-z0-9][a-z0-9_-]{0,63}$/i.test(code)) fail(400, 'Выберите компанию');
    if (crmPath === '/media-mentor/plan/decision' && identity.role !== 'owner') {
      fail(403, 'Согласовывать и отклонять план может только владелец');
    }
    if (identity.role !== 'owner') {
      requirePermission(request, `autoposting.${readOnly ? 'view' : 'edit'}`, code);
    }
  }
  if (/^\/(?:email-campaigns|email-subscriptions)(?:\/|$)/.test(crmPath) && identity.role !== 'owner') {
    fail(403, 'Рассылки доступны только владельцу');
  }
  if (['/company-email', '/email-status', '/email-settings', '/email-settings/check'].includes(crmPath) && identity.role !== 'owner') {
    fail(403, 'Настройки и диагностика почты доступны только владельцу');
  }
  const analyticsReadPath = /^\/(?:platform-demand|social-stats)(?:\/|$)/.test(crmPath) || new Set([
    '/dashboard', '/summary', '/external-stats', '/expenses', '/tasks/summary',
  ]).has(crmPath);
  let session = initialSession;
  if (identity.role !== 'owner' && identity.companyCodes.length === 0) {
    fail(403, 'Аккаунту не назначена компания');
  }
  if (identity.role !== 'owner' && !companyModule && !mentorRollout && !mentorPlan) {
    if (readOnly) {
      const permission = analyticsReadPath && identity.permissions.includes('analytics.view')
        ? 'analytics.view' : 'crm.view';
      session = requirePermission(request, permission);
    } else {
      session = requirePermission(request, 'crm.edit');
    }
  }
  if (!readOnly) requireCsrf(request, session);

  const clientDatabasePath = /^\/(?:contacts|companies|legal-entities|tasks|deals)(?:\/|$)/.test(crmPath) &&
    crmPath !== '/tasks/summary';
  const companyOverview = /^\/companies\/\d+\/overview$/.test(crmPath);
  const ownerOnlyPipelinePath = /^\/(?:pipeline-stages|pipelines|pipeline-rules)(?:\/|$)/.test(crmPath) ||
    /^\/companies\/\d+\/(?:overview|pipeline|service)(?:\/|$)/.test(crmPath);
  if (ownerOnlyPipelinePath && identity.role !== 'owner') {
    fail(403, 'Воронка и сервисные поля доступны только владельцу');
  }
  if (identity.role !== 'owner' && clientDatabasePath && !companyOverview) {
    const requestedCompany = url.searchParams.get('companyCode');
    if (!requestedCompany) fail(400, 'Уточните компанию');
    if (!identity.companyCodes.some(
      (code) => code.toLowerCase() === requestedCompany.toLowerCase()
    )) fail(403, 'Нет доступа к компании');
  }

  const companyScoped = /^\/(?:leads(?:\/|\.|$)|dashboard(?:\/|$)|summary(?:\/|$)|expenses(?:\/|$)|external-stats(?:\/|$)|tasks\/summary$)/.test(crmPath);
  if (identity.role !== 'owner' && companyScoped) {
    const requestedCompany = url.searchParams.get('companyCode');
    if (requestedCompany && !identity.companyCodes.includes(requestedCompany.toLowerCase())) {
      fail(403, 'Нет доступа к компании');
    }
    if (!requestedCompany && identity.companyCodes.length > 1) fail(403, 'Уточните компанию');
    if (!requestedCompany) url.searchParams.set('companyCode', identity.companyCodes[0]);
  }
  if (!CRM_API_KEY) fail(503, 'Прокси CRM не настроен');
  if(request.method==='POST'&&crmPath==='/media-mentor/generation'){
    const code=url.searchParams.get('companyCode').toLowerCase(),body=await readJson(request);
    if(Object.keys(body).length!==2||!Object.hasOwn(body,'month')||!Object.hasOwn(body,'clientRequestId'))fail(400,'Нужны только месяц и ключ запроса');
    function freshGenerationUser(){
      const current=requirePermission(request,'autoposting.edit',code);requirePermission(request,'autoposting.view',code);requireCsrf(request,current);
      if(current.user.id!==initialSession.user.id)fail(403,'Доступ изменился во время подготовки');
      return current.user;
    }
    const previous=await contentFactoryCrm('plan-lookup',code,body,freshGenerationUser());
    freshGenerationUser();
    if(previous.job)return send(response,200,previous,{...cors,'cache-control':'no-store'});
    const sourceLibrary=contentFactorySourceContext.capture(code);
    const result=await contentFactoryCrm('plan-start',code,{request:body,sourceLibrary},freshGenerationUser());
    freshGenerationUser();return send(response,200,result,{...cors,'cache-control':'no-store'});
  }
  if (identity.role !== 'owner' && crmPath === '/expenses' && request.method !== 'GET') {
    fail(403, 'Расходы вносит владелец');
  }
  const leadMatch = crmPath.match(/^\/leads\/(\d+)(?:\/|$)/);
  let requestBody = null;
  const companyWrite = (request.method === 'POST' && crmPath === '/companies') ||
    (request.method === 'PATCH' && /^\/companies\/\d+$/.test(crmPath));
  const externalStatsWrite = crmPath === '/external-stats' && request.method !== 'GET';
  if (identity.role !== 'owner' && (companyWrite || externalStatsWrite)) {
    requestBody = await readRequestBody(request);
    let body;
    try { body = JSON.parse(requestBody.toString('utf8')); } catch { fail(400, 'Некорректный JSON'); }
    if (externalStatsWrite && body && typeof body === 'object' &&
      !identity.companyCodes.some((code) => code.toLowerCase() === String(body.companyCode || '').toLowerCase())) {
      fail(403, 'Нет доступа к компании');
    }
    if (body && typeof body === 'object' && Object.hasOwn(body, 'pipelineStage')) {
      fail(403, 'Воронка и сервисные поля доступны только владельцу');
    }
  }
  const companyMutation = crmPath.match(/^\/companies\/(\d+)$/);
  if (identity.role !== 'owner' && companyMutation && ['PATCH', 'DELETE'].includes(request.method)) {
    const ownerScope = await crmCompanyOwnerScope(companyMutation[1]);
    const requestedCompany = url.searchParams.get('companyCode');
    if (!requestedCompany || ownerScope?.toLowerCase() !== requestedCompany.toLowerCase()) {
      fail(403, 'Карточка компании принадлежит другой базе');
    }
  }
  if (leadMatch && url.searchParams.get('companyCode')) {
    const leadCompany=await crmLeadCompany(leadMatch[1]);
    if(leadCompany?.toLowerCase()!==url.searchParams.get('companyCode').toLowerCase()) fail(404,'Заявка не найдена в выбранной компании');
  }
  if (identity.role !== 'owner' && leadMatch) {
    const leadCompany = await crmLeadCompany(leadMatch[1]);
    const allowed = leadCompany && identity.companyCodes.some((code) => {
      return code.toLowerCase() === leadCompany.toLowerCase();
    });
    if (!allowed) fail(404, 'Заявка не найдена');
    if (request.method === 'PATCH' && crmPath === `/leads/${leadMatch[1]}`) {
      requestBody = await readRequestBody(request);
      let body;
      try { body = JSON.parse(requestBody.toString('utf8')); } catch { fail(400, 'Некорректный JSON'); }
      if (body && typeof body === 'object' && Object.hasOwn(body, 'companyCode')) {
        fail(403, 'Смена компании доступна только владельцу');
      }
    }
  }
  let forwardIdentity = identity;
  const completionWrite = (request.method === 'PUT' && crmPath === '/media-mentor/workflow') ||
    (request.method === 'POST' && /^\/autoposting\/posts\/\d+\/variants$/.test(crmPath)) ||
    (request.method === 'POST' && /^\/media-mentor\/plan\/variants\/(?:decision|transfer)$/.test(crmPath));
  if (completionWrite) {
    requestBody = await readRequestBody(request);
    const current = requirePermission(request, 'autoposting.edit', url.searchParams.get('companyCode'));
    requireCsrf(request, current);
    if (current.user.id !== initialSession.user.id) fail(403, 'Доступ изменился во время подготовки');
    if (crmPath === '/media-mentor/plan/variants/decision' && current.user.role !== 'owner') {
      fail(403, 'Согласовывать и отклонять вариант может только владелец');
    }
    forwardIdentity = current.user;
  }
  const target = new URL(`${CRM_URL}${crmPath}${url.search}`);
  const headers = { ...request.headers, host: target.host, 'x-api-key': CRM_API_KEY };
  delete headers.cookie;
  // CRM accepts this header as trusted context, so caller-supplied claims must never pass through.
  delete headers[CRM_IDENTITY_HEADER];
  headers[CRM_IDENTITY_HEADER] = crmIdentityHeader(forwardIdentity);
  if (requestBody) {
    delete headers['transfer-encoding'];
    headers['content-length'] = requestBody.length;
  }
  const upstream = http.request(target, { method: request.method, headers }, (upstreamResponse) => {
    const responseHeaders = { ...upstreamResponse.headers, ...cors };
    response.writeHead(upstreamResponse.statusCode || 502, responseHeaders);
    upstreamResponse.pipe(response);
  });
  upstream.on('error', (error) => {
    console.error('content: ошибка прокси CRM:', error);
    if (!response.headersSent) send(response, 502, { error: 'CRM недоступна' }, cors);
    else response.destroy(error);
  });
  if (requestBody) upstream.end(requestBody);
  else request.pipe(upstream);
}

async function proxyChat(request, response, url, cors) {
  const session = requireSession(request);
  if (session.user.role !== 'owner') fail(403, 'Чат доступен только владельцу');
  if (request.method !== 'GET') requireCsrf(request, session);
  if (!CHAT_API_KEY) fail(503, 'Прокси чата не настроен');

  const chatPath = url.pathname.slice('/content/hugh'.length) || '/';
  const target = new URL(`${CHAT_URL}${chatPath}${url.search}`);
  const headers = { ...request.headers, host: target.host, 'x-api-key': CHAT_API_KEY };
  delete headers.cookie;
  delete headers.origin;
  delete headers.referer;
  const upstream = http.request(target, { method: request.method, headers }, (upstreamResponse) => {
    const responseHeaders = { ...upstreamResponse.headers, ...cors };
    response.writeHead(upstreamResponse.statusCode || 502, responseHeaders);
    upstreamResponse.pipe(response);
  });
  upstream.on('error', (error) => {
    console.error('content: ошибка прокси чата:', error);
    if (!response.headersSent) send(response, 502, { error: 'Чат недоступен' }, cors);
    else response.destroy(error);
  });
  request.pipe(upstream);
}

/* PALITRA-WEBCHAT-PHASEE: файл владельца — чат сайта (customer-threads) и прежний диалог (client-dialogs), одна обработка.
   status и file — только чтение по свежей сессии того же владельца (без CSRF, как у файлов D); prepare и bytes —
   точный PALITRA_APP_ORIGIN и CSRF до чтения тела, после него — свежая сессия того же владельца и CSRF ещё раз;
   тело bytes — не больше заявленного размера. Владелец передаётся дальше только из свежей сессии. */
async function ownerUploadRoute({ request, response, route, session, reply, headers, ops }) {
  if (!route.methods.includes(request.method)) fail(405, 'Метод не поддерживается');
  const ownerOf = (s) => ({ id: s.user.id, sessionVersion: s.user.sessionVersion });
  const fresh = () => {
    const current = requireSession(request);
    if (current.user.id !== session.user.id || current.user.sessionVersion !== session.user.sessionVersion) fail(403, 'Доступ изменился');
    palitraSessionAccess(current, !['GET', 'HEAD'].includes(request.method));
    return current;
  };
  try {
    if (route.action === 'status') return reply(200, ops.status(ownerOf(fresh())), headers);
    if (route.action === 'file') {
      return require('./customer-chat-media.cjs').serveProtected({ request, response, resolve: () => ops.file(ownerOf(fresh())), open: ops.open });
    }
    if (request.headers.origin !== PALITRA_APP_ORIGIN) fail(403, 'Запрос с другого адреса запрещён');
    requireCsrf(request, session);
    if (route.action === 'prepare') {
      if (!/^application\/json(?:\s*;|$)/i.test(String(request.headers['content-type'] || ''))) fail(415, 'Ожидался JSON');
      const body = await readJson(request);
      const current = fresh();
      requireCsrf(request, current);
      const result = ops.prepare(ownerOf(current), body);
      return reply(result.duplicate ? 200 : 201, result, headers);
    }
    if (String(request.headers['content-type'] || '').split(';')[0].trim().toLowerCase() !== 'application/octet-stream') fail(415, 'Ожидался файл');
    const begun = ops.begin(ownerOf(session));
    let bytes, current;
    try {
      const length = request.headers['content-length'];
      if (length !== undefined && (!/^\d{1,9}$/.test(String(length)) || Number(length) !== begun.declaredSize)) {
        fail(Number(length) > begun.declaredSize ? 413 : 422, 'Размер файла не совпал с выбранным — выберите тот же файл');
      }
      bytes = await readRaw(request, begun.declaredSize);
      current = fresh();
      requireCsrf(request, current);
    } catch (error) { if (begun.claim) ops.release(begun.claim, error.message); throw error; }
    const result = ops.finish(ownerOf(current), begun.claim || null, bytes);
    return reply(result.duplicate ? 200 : 201, result, headers);
  } catch (error) {
    // Отказы модулей загрузки — с их кодом (страница различает «выберите тот же файл», «срок истёк», «проверьте отправку»).
    if (error && error.status && typeof error.code === 'string' && !response.headersSent) return reply(error.status, { error: error.message, code: error.code }, headers);
    throw error;
  }
}

const server = http.createServer(async (request, response) => {
  const cors = corsHeaders(request);
  const reply = (status, payload, extra) => send(response, status, payload, { ...cors, ...(extra || {}) });
  try {
    // Private namespace precedes public hosts/generic content/OPTIONS.
    const projectFormsUrl = new URL(request.url, 'http://localhost');
    if (await projectForms.handle(request, projectFormsUrl, (status, payload, extra) => send(response, status, payload, extra))) return;
    // PALITRA-WEB-PUSH: exact same-origin endpoints before Main's catch-all; existing identity only.
    const pushUrl = new URL(request.url, 'http://localhost');
    if (palitraPushHost.http.matches(pushUrl.pathname)) {
      await palitraPushHost.http.handle(request, response, pushUrl, String(request.headers.host || '').toLowerCase());
      return;
    }
    // PALITRA-CRM: /api/crm/* и /palitra-app/* только на точном хосте приложения Synapse; CRM выключена — false.
    if(await palitraHost.handleSynapse(request,response))return;
    if(await workspaceFeature.publicHost(request,response))return;
    if (request.method === 'OPTIONS') {
      response.writeHead(204, cors);
      return response.end();
    }
    const url = new URL(request.url, 'http://localhost');
    const parts = url.pathname.split('/').filter(Boolean);
    // PALITRA-REVIEW39-WIRING:ROUTES:BEGIN
    if (await palitraTaskReview39.handle(request, reply, url)) return;
    if (palitraTaskReview39.serve(request, response, url)) return;
    // PALITRA-REVIEW39-WIRING:ROUTES:END
    // Caddy asks whether the hostname belongs to an active project draft before obtaining TLS.
    if(url.pathname==='/internal/site-workspace/tls') {
      const domain=url.searchParams.get('domain');
      if(request.method!=='GET'||!workspaceFeature.store.publishedHost(domain))return reply(403,{allowed:false});
      return reply(200,{allowed:true});
    }
    if(await photoFeature.handle(request,reply,url))return;
    if(await workspaceFeature.routes(request,reply,url))return;

    // Локальный обработчик Хью: свой ключ, проверка до чтения тела, только известные маршруты.
    if (url.pathname.startsWith('/content/project-chat-worker/')) {
      await projectChat.localWorker.handle(request, response, url);
      return;
    }
    // Вход в чат проекта из Telegram Mini App: без cookie кабинета, по подписи Telegram.
    if (url.pathname === '/content/project-chat-miniapp/session') {
      await projectChat.miniApp.handle(request, response, url);
      return;
    }
    if (url.pathname.startsWith('/content/internal/project-chat/')) {
      const supplied = String(request.headers['x-api-key'] || '');
      if (!CHAT_API_KEY || Buffer.byteLength(supplied) !== Buffer.byteLength(CHAT_API_KEY) ||
          !crypto.timingSafeEqual(Buffer.from(supplied),Buffer.from(CHAT_API_KEY))) fail(401,'Нет доступа');
      const route = url.pathname.slice('/content/internal/project-chat'.length);
      if (route === '/binding' && request.method === 'GET') {
        const chatId=url.searchParams.get('chatId');
        const room = projectChat.bridge.getBinding(chatId);
        const source = telegramSources.binding(chatId);
        // Известный источник первичен даже при конфликте настроек; обычная комната сохраняет контракт.
        return reply(200,source ? {room:null,source} : {room});
      }
      if (route === '/source-migrate' && request.method === 'POST') {
        const body=await readJson(request); return reply(200,telegramSources.migrate(body.chatId,body.newChatId));
      }
      if (route === '/source-receipt' && request.method === 'GET') return reply(200,{item:telegramSources.receipt(url.searchParams.get('chatId'),url.searchParams.get('messageId'))});
      if (route === '/source-receive' && request.method === 'POST') {
        let body; try {body=JSON.parse((await readRaw(request,28*1024*1024)).toString('utf8'));} catch {fail(400,'Некорректный исходник');}
        return reply(200,telegramSources.receive(body));
      }
      // capabilities объявляет мост: правку отправленного сообщения получает только мост, который её умеет.
      if (route === '/outbox' && request.method === 'GET') return reply(200,{jobs:projectChat.bridge.pendingTelegram(1,{capabilities:url.searchParams.get('capabilities')||''})});
      if (route === '/attachment' && request.method === 'GET') {
        const file = projectChat.bridge.readAttachment(url.searchParams.get('id'),url.searchParams.get('companyCode'));
        return reply(200,{name:file.name,mime:file.mime,base64:file.bytes.toString('base64')});
      }
      if (route === '/migrate' && request.method === 'POST') {
        const body=await readJson(request);
        return reply(200,projectChat.bridge.migrateBinding({chatId:body.chatId,newChatId:body.newChatId}));
      }
      if (route === '/receive' && request.method === 'POST') {
        let body;
        try { body=JSON.parse((await readRaw(request,12*1024*1024)).toString('utf8')); } catch { fail(400,'Некорректное событие'); }
        const chatId=String(body.chatId || ''), messageId=String(body.messageId || '');
        if (!/^-?\d+$/.test(chatId) || !/^\d+$/.test(messageId)) fail(400,'Некорректное событие');
        const incoming=body.files || [];
        if(!Array.isArray(incoming) || incoming.length>1) fail(400,'Слишком много вложений');
        // Квитанция, вложения и сообщение сохраняются одной транзакцией внутри модуля комнаты.
        const files=incoming.map(file=>{
          if(typeof file.base64!=='string' || file.base64.length>11200000) fail(413,'Файл слишком большой');
          return {name:file.name,mime:file.mime,bytes:Buffer.from(file.base64,'base64')};
        });
        if (body.command) {
          if (files.length) fail(400,'Команда без вложений');
          return reply(200,await projectChat.bridge.receiveCommand({chatId,messageId,authorId:body.authorId,authorName:body.authorName,text:body.text,command:body.command}));
        }
        return reply(200,projectChat.bridge.receiveTelegram({chatId,messageId,authorId:body.authorId,
          authorName:body.authorName,text:body.text,files,addressed:body.addressed===true}));
      }
      if (route === '/acknowledge' && request.method === 'POST') {
        const body=await readJson(request);
        projectChat.bridge.acknowledgeTelegram(body.jobId,body);
        return reply(200,{ok:true});
      }
      fail(404,'Маршрут не найден');
    }
    // Мост клиентского бота: тот же внутренний ключ службы chat, свои маршруты и таблицы.
    if (url.pathname.startsWith('/content/internal/client-bot/')) {
      const supplied = String(request.headers['x-api-key'] || '');
      if (!CHAT_API_KEY || Buffer.byteLength(supplied) !== Buffer.byteLength(CHAT_API_KEY) ||
          !crypto.timingSafeEqual(Buffer.from(supplied),Buffer.from(CHAT_API_KEY))) fail(401,'Нет доступа');
      // Reuse existing authenticated worker poll; no second timer or worker.
      if (url.pathname === '/content/internal/client-bot/outbox' && request.method === 'GET' && url.searchParams.get('botKey') === 'palitra') {
        // Existing authenticated 3-second worker poll, no new timer/worker/backfill.
        try { palitraContactFollowup.tick(); } catch { console.warn('content: CONTACT_FOLLOWUP_DEFERRED'); }
        palitraPushHost.requestDrain();
      }
      return await clientDialogs.handleInternal(request, response, url, { readJson, readRaw, send: (res, status, payload) => send(res, status, payload) });
    }
    if (url.pathname.startsWith('/content/project-chat-runtime/')) {
      const session=requireSession(request);
      if(session.user.role!=='owner') fail(403,'Доступно только владельцу');
      const route=url.pathname.slice('/content/project-chat-runtime'.length);
      if(!((route==='/status' && request.method==='GET') || (route==='/login' && request.method==='POST'))) fail(404,'Маршрут не найден');
      if(request.method==='POST') requireCsrf(request,session);
      // Компания задаёт путь: её локальный обработчик отвечает сам, до проверки общего ключа службы.
      // Сессия, роль и CSRF уже проверены; тело читается только после этого.
      let companyCode='';
      if(request.method==='POST'){
        const raw=(await readRaw(request,4096)).toString('utf8').trim();
        let body={};
        if(raw){ try { body=JSON.parse(raw); } catch { fail(400,'Некорректный JSON'); } }
        companyCode=String(body?.companyCode ?? '');
      } else companyCode=String(url.searchParams.get('companyCode') ?? '');
      if(companyCode && !/^[a-z0-9_-]{1,40}$/.test(companyCode)) fail(400,'Некорректный код компании');
      if(companyCode && projectChat.localWorker.isLocal(companyCode)){
        if(route==='/status') return reply(200,projectChat.localWorker.ownerStatus(companyCode),{'cache-control':'no-store'});
        const login=projectChat.localWorker.requestLogin(companyCode);
        return reply(login.accepted?202:200,login.status,{'cache-control':'no-store'});
      }
      if(!CHAT_API_KEY) return reply(503,{state:'unconfigured',connected:false,configured:false,provider:'codex',
        error:'Служба Хью не настроена'},{'cache-control':'no-store'});
      try {
        // /login внутри рантайма ждёт ответ account/login/start до 30 с. Прокси обязан пережить
        // это ожидание, иначе владелец видит сетевую ошибку вместо выданных ссылки и кода.
        // Быстрый /status остаётся на прежней границе: он не должен держать вкладку.
        const upstream=await fetch(`${HUGH_RUNTIME_URL}${route}`,{method:request.method,
          headers:{'content-type':'application/json','x-api-key':CHAT_API_KEY,authorization:`Bearer ${CHAT_API_KEY}`},
          ...(request.method==='POST'?{body:'{}'}:{}),signal:AbortSignal.timeout(route==='/login'?35000:12000)});
        // Наружу отдаём только известные поля: чужой ответ по этому адресу не станет эхом в кабинете.
        return reply(upstream.status,sanitizeRuntime(await upstream.json().catch(()=>null)),{'cache-control':'no-store'});
      } catch { return reply(503,{state:'unavailable',connected:false,configured:true,provider:'codex',
        error:'Подключение Хью пока недоступно'},{'cache-control':'no-store'}); }
    }
    if (await contentFactorySources.handle(request,response,url)) return;
    if (await telegramSources.handle(request,response,url)) return;
    if (await projectChat.handle(request,response,url)) return;

    if (await actorOnboarding.handle(request,response,url)) return;
    if (await actorWorkspace.handle(request,response,url)) return;

    if (url.pathname === '/content/crm' || url.pathname.startsWith('/content/crm/')) {
      return await proxyCrm(request, response, url, cors);
    }
    if (url.pathname === '/content/admin/hugh-settings') {
      const session = requireSession(request);
      if (session.user.role !== 'owner') fail(403, 'Доступно только владельцу');
      if (request.method === 'GET') return reply(200, hughSettingsStore.get());
      if (request.method === 'PUT') {
        requireCsrf(request, session);
        const body = await readJson(request);
        if (Object.keys(body).join(',') !== 'settings') fail(400, 'Переданы лишние поля');
        return reply(200, hughSettingsStore.save(body.settings, session.user.id));
      }
      fail(405, 'Метод не поддерживается');
    }
    // Личная переписка владельца по проектам. Область проверяется внутри модуля по серверной
    // сессии; ни один клиентский маршрут к этим таблицам не обращается.
    if (url.pathname === '/content/owner-chat' || url.pathname.startsWith('/content/owner-chat/')) {
      if (await ownerPrivateChat.handle(request, response, url)) return;
    }
    // Подсказки Медиа-наставника живут в content: провайдеры и мастер-ключ здесь,
    // а все адреса /media-mentor* целиком проксируются в CRM и до модуля бы не дошли.
    if (url.pathname === '/content/media-mentor-suggest'
      || url.pathname === '/content/media-mentor-analyze'
      || url.pathname === '/content/media-mentor-review') {
      if (await mediaMentorSuggestRoute.handle(request, response, url)) return;
    }
    if (url.pathname === '/content/hugh' || url.pathname.startsWith('/content/hugh/')) {
      return await proxyChat(request, response, url, cors);
    }

    if (request.method === 'POST' && url.pathname === '/content/login') {
      const ip = String(request.headers['x-forwarded-for'] || request.socket.remoteAddress || '').split(',')[0].trim();
      const now = Date.now();
      const failures = (loginFailures.get(ip) || []).filter((time) => now - time < LOGIN_WINDOW);
      if (failures.length >= LOGIN_LIMIT) fail(429, 'Слишком много попыток, подождите 10 минут');
      const body = await readJson(request);
      const login = String(body.login || '').trim().toLowerCase();
      const identity = authStore.getByLogin(login);
      if (!identity || !verifyPassword(String(body.password || ''), identity.passwordHash)) {
        failures.push(now); loginFailures.set(ip, failures);
        const error = new Error('Неверный логин или пароль');
        error.status = 401;
        error.login = login || 'неизвестен';
        throw error;
      }
      loginFailures.delete(ip);
      return reply(200, publicIdentity(identity), { 'set-cookie': `synapse_session=${makeSession(identity)}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=${SESSION_TTL}` });
    }
    if (request.method === 'POST' && url.pathname === '/content/logout') {
      // PALITRA-CRM: до очистки cookie отзывается CRM-доступ ровно этой cookie (другие устройства и права не меняются).
      { const ending = sessionData(request); if (ending) palitraHost.revokeHostSession(ending.cookieRef); }
      return reply(200, { ok: true }, { 'set-cookie': 'synapse_session=; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=0' });
    }

    if (request.method === 'GET' && url.pathname === '/content/whoami') {
      const session = requireSession(request);
      return reply(200, { ...publicIdentity(session.user), csrfToken: session.csrf });
    }
    if (request.method === 'GET' && url.pathname === '/health') {
      return reply(200, { ok: true, service: 'content' });
    }

    /* Настройка провайдеров Хью: только владелец, только с CSRF на запись.
       Ключ уходит на сервер и обратно никогда не возвращается. */
    if (url.pathname === '/content/hugh-providers' || /^\/content\/hugh-providers\/[a-z0-9-]{1,32}(?:\/(?:check|balance))?$/.test(url.pathname)) {
      const session = requireSession(request);
      if (session.user.role !== 'owner') fail(403, 'Настройка провайдеров доступна владельцу');
      const match = /^\/content\/hugh-providers\/([a-z0-9-]{1,32})(\/(?:check|balance))?$/.exec(url.pathname);
      if (url.pathname === '/content/hugh-providers' && request.method === 'GET') return reply(200, hughProviders.status());
      if (match && !match[2] && request.method === 'PUT') {
        requireCsrf(request, session);
        return reply(200, hughProviders.save(match[1], await readJson(request), session.user));
      }
      if (match && match[2] && request.method === 'POST') {
        requireCsrf(request, session);
        if(match[2]==='/balance'){
          if(match[1]!=='deepseek')fail(400,'Автоматический источник баланса не подключён');
          return reply(200,await hughProviders.refreshBalance());
        }
        // Проверка соединения — явное отдельное действие владельца, а не следствие сохранения.
        return reply(200, await hughProviders.check(match[1]));
      }
      fail(405, 'Метод не поддерживается');
    }
    if (url.pathname === '/content/publishing-assets') {
      if (request.method !== 'POST') fail(405, 'Метод не поддерживается');
      const session = requireSession(request), code = url.searchParams.get('companyCode');
      if (!code || !Object.hasOwn(COMPANIES, code)) fail(400, 'Выберите компанию');
      if (session.user.role !== 'owner') {
        if (!session.user.companyCodes.includes(code)) fail(403, 'Нет доступа к компании');
        if (!['autoposting.edit','company-information.edit'].some(permission=>session.user.permissions.includes(permission))) fail(403, 'Недостаточно прав');
      }
      requireCsrf(request, session);
      const type = String(request.headers['content-type'] || '').split(';')[0].trim();
      if (!Object.hasOwn(ASSET_TYPES,type)) fail(415, 'Допустимы фотографии JPEG, PNG, WebP и видео MP4, WebM');
      const video = VIDEO_TYPES.has(type);
      const bytes = await readRaw(request, video ? MAX_PUBLISHING_VIDEO : MAX_PUBLISHING_ASSET);
      const valid = type === 'image/jpeg' ? bytes.length >= 4 && bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255 :
        type === 'image/png' ? bytes.length >= 24 && bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])) :
        type === 'image/webp' ? bytes.length >= 16 && bytes.toString('ascii',0,4) === 'RIFF' && bytes.toString('ascii',8,12) === 'WEBP' :
        type === 'video/mp4' ? bytes.length >= 12 && bytes.toString('ascii',4,8) === 'ftyp' :
          bytes.length >= 4 && bytes.subarray(0,4).equals(Buffer.from([0x1a,0x45,0xdf,0xa3]));
      if (!valid) fail(415, video ? 'Файл не соответствует выбранному формату видео' : 'Файл не соответствует выбранному формату фотографии');
      const name = crypto.randomBytes(16).toString('hex') + ASSET_TYPES[type];
      const directory = path.join(ASSETS_DIR,'publishing',code);
      fs.mkdirSync(directory,{recursive:true});
      fs.writeFileSync(path.join(directory,name),bytes,{flag:'wx'});
      // Хеш нужен, чтобы сверить загруженный ролик с пакетом материалов, а не принять заглушку за готовое видео.
      const sha256 = crypto.createHash('sha256').update(bytes).digest('hex');
      return reply(201,{url:`${PUBLISHING_ASSET_ORIGIN}/content/publishing-assets/${code}/${name}`,size:bytes.length,type,sha256});
    }
    if (url.pathname.startsWith('/content/publishing-assets/')) {
      if (!['GET','HEAD'].includes(request.method)) fail(405, 'Метод не поддерживается');
      const match = /^\/content\/publishing-assets\/([a-z0-9_-]{1,64})\/([a-f0-9]{32}\.(jpg|png|webp|mp4|webm))$/.exec(url.pathname);
      if (!match || !Object.hasOwn(COMPANIES,match[1])) fail(404,'Материал не найден');
      const file = path.join(ASSETS_DIR,'publishing',match[1],match[2]);
      if (!fs.existsSync(file)) fail(404,'Материал не найден');
      const size = fs.statSync(file).size;
      // При прямом открытии ссылки браузер строит собственную страницу с <video>, и она подчиняется CSP этого ответа.
      // Без media-src ролик блокируется правилом default-src 'none' (readyState 0). Разрешаем только загрузку медиа
      // с этого же адреса; скрипты, стили, фреймы и формы запрещены по-прежнему, sandbox сохраняется.
      const csp = VIDEO_TYPES.has(ASSET_MIME[match[3]])
        ? `default-src 'none'; media-src 'self' ${PUBLISHING_ASSET_ORIGIN}; sandbox` : "default-src 'none'; sandbox";
      const headers = {'content-type':ASSET_MIME[match[3]],'cache-control':'public, max-age=31536000, immutable','accept-ranges':'bytes',
        'x-content-type-options':'nosniff','content-security-policy':csp,'content-disposition':`inline; filename="${match[2]}"`};
      // Диапазоны нужны плееру: без них перемотка и предпросмотр видео в браузере не работают.
      const range = /^bytes=(\d*)-(\d*)$/.exec(String(request.headers.range || ''));
      let start = 0, end = size - 1, status = 200;
      if (range && VIDEO_TYPES.has(headers['content-type'])) {
        start = range[1] ? Number(range[1]) : Math.max(0, size - Number(range[2] || 0));
        end = range[1] && range[2] ? Math.min(Number(range[2]), size - 1) : end;
        if (!Number.isFinite(start) || !Number.isFinite(end) || start > end || start >= size) {
          response.writeHead(416, {'content-range':`bytes */${size}`}); return response.end();
        }
        status = 206; headers['content-range'] = `bytes ${start}-${end}/${size}`;
      }
      headers['content-length'] = end - start + 1;
      response.writeHead(status, headers);
      if (request.method === 'HEAD') return response.end();
      const stream = fs.createReadStream(file, {start, end}); stream.on('error',()=>response.destroy());
      response.on('close',()=>stream.destroy()); return stream.pipe(response);
    }

    const ownerDocumentKey = parts.length === 3 ? `${parts[1]}/${parts[2]}` : null;
    if (ownerDocumentKey && OWNER_DOCUMENTS.has(ownerDocumentKey)) {
      const session = requireSession(request);
      if (session.user.role !== 'owner') fail(403, 'Доступно только владельцу');
      if (request.method === 'GET') {
        const row = latestStmt.get(ownerDocumentKey);
        if (!row) fail(404, `Документ ${ownerDocumentKey} не найден`);
        return reply(200, row.body, { etag: `"${row.version}"` });
      }
      if (request.method === 'PUT') {
        requireCsrf(request, session);
        const document = await readJson(request);
        OWNER_DOCUMENTS.get(ownerDocumentKey)(document);
        return reply(200, { ok: true, key: ownerDocumentKey,
          ...saveVersion(ownerDocumentKey, document, publicIdentity(session.user).author) });
      }
      fail(405, 'Метод не поддерживается');
    }

    if (url.pathname === '/content/admin/team') {
      const session = requirePermission(request, 'team.manage');
      if (request.method === 'GET') return reply(200, {members: companyTeam.list(session.user.id, url.searchParams.get('companyCode'))});
      if (request.method === 'POST') {
        requireCsrf(request, session);
        return reply(201, companyTeam.create(session.user.id, await readJson(request)));
      }
      fail(405, 'Метод не поддерживается');
    }

    if (url.pathname === '/content/admin/accounts' || url.pathname.startsWith('/content/admin/accounts/')) {
      const session = requireSession(request);
      if (session.user.role !== 'owner' && !session.user.permissions.includes('account.view')) fail(403, 'Недостаточно прав');
      if (request.method !== 'GET') requireCsrf(request, session);
      if (request.method === 'GET' && parts[3] === 'access-options' && parts.length === 4) {
        return reply(200, { companies: Object.entries(COMPANIES).map(([id, company]) => ({ id, ...company })),
          permissions: PERMISSIONS, dependencies: DEPENDENCIES, presets: [PRICE_CLIENT_PRESET] });
      }
      const id = Number(parts[3]);
      if (request.method === 'GET' && parts.length === 3) {
        return reply(200, { accounts: authStore.list().map(authStore.public) });
      }
      if (request.method === 'POST' && parts.length === 3) {
        const body = await readJson(request);
        const account = authStore.create(session.user.id, body, hashPassword(body.password));
        return reply(201, authStore.public(account));
      }
      if (request.method === 'PATCH' && parts.length === 4) {
        if (session.user.role !== 'owner') fail(403, 'Изменять учётные записи может только администратор');
        const before = authStore.getById(id);
        const updated = authStore.updateAccount(session.user.id, id, await readJson(request));
        logAccountMutation('changed', session.user, before, updated);
        return reply(200, authStore.public(updated));
      }
      if (request.method === 'DELETE' && parts.length === 4) {
        if (session.user.role !== 'owner') fail(403, 'Удалять учётные записи может только администратор');
        const before = authStore.getById(id);
        const removed = authStore.remove(session.user.id, id);
        logAccountMutation('deleted', session.user, before, null);
        return reply(200, { ok: true, account: authStore.public(removed) });
      }
      if (request.method === 'PUT' && parts[4] === 'password' && parts.length === 5) {
        const body = await readJson(request);
        if (Object.keys(body).join(',') !== 'password') fail(400, 'Переданы лишние поля');
        return reply(200, authStore.public(authStore.updatePassword(session.user.id, id,
          hashPassword(body.password))));
      }
      if (request.method === 'PUT' && parts[4] === 'access' && parts.length === 5) {
        const body = await readJson(request);
        if (Object.keys(body).sort().join(',') !== 'companies,permissions') fail(400, 'Переданы лишние поля');
        return reply(200, authStore.public(authStore.updateAccess(session.user.id, id,
          body.companies, body.permissions)));
      }
      fail(404, 'Пользователь не найден');
    }

    if (url.pathname === '/content/sites' || url.pathname.startsWith('/content/sites/')) {
      const id = parts[2] ? decodeURIComponent(parts[2]) : null;
      if (request.method === 'GET' && id && parts[3] === 'document') {
        const session = requirePermission(request, 'site_editor.view');
        const site = siteStore.get(session.user, id);
        const row = latestStmt.get(`${id}/site`);
        if (!row) fail(404, 'Документ не найден');
        return reply(200, { site, document: JSON.parse(row.body) });
      }
      const permission = request.method === 'POST' ? 'sites.create'
        : request.method === 'DELETE' ? 'sites.delete' : 'sites.view';
      const session = requirePermission(request, permission);
      if (request.method !== 'GET') requireCsrf(request, session);
      if (request.method === 'GET' && !id) {
        return reply(200, { sites: siteStore.list(session.user, {
          companyCode: url.searchParams.get('companyCode'), state: url.searchParams.get('state'),
        }).map(site=>workspaceFeature.store.enrich(site,session.user)) });
      }
      if (request.method === 'GET' && id) return reply(200,workspaceFeature.store.enrich(siteStore.get(session.user,id),session.user));
      if (request.method === 'POST' && !id) {
        const body = await readJson(request);
        if (Object.keys(body).sort().join(',') !== 'companyCode,name') fail(400, 'Переданы лишние поля');
        const created = siteStore.create(session.user, body);
        return reply(201, { ...created, editorUrl: created.editorUrls.site });
      }
      if (request.method === 'DELETE' && id) {
        siteStore.remove(session.user, id);
        return reply(200, { ok: true });
      }
      fail(404, 'Не найдено');
    }

    // Capability link for recipients: no browser session or private CRM fields are forwarded.
    if (parts[0] === 'public-email-unsubscribe') {
      let result;
      try {
        if (parts.length !== 2 || !EMAIL_UNSUBSCRIBE_TOKEN.test(parts[1]) || !['GET', 'POST'].includes(request.method)) fail(404, 'Ссылка не найдена');
        const chunks = [];
        let size = 0;
        for await (const chunk of request) {
          size += chunk.length;
          if (size > 1024) fail(413, 'Слишком большой запрос');
          chunks.push(chunk);
        }
        result = await publicEmailUnsubscribe({token: parts[1], method: request.method, body: Buffer.concat(chunks).toString('utf8')});
      } catch (error) {
        const status = [404, 413, 502, 503].includes(error.status) ? error.status : 502;
        const message = status === 404 ? 'Ссылка отписки не найдена или недействительна.'
          : status === 413 ? 'Не удалось обработать запрос. Откройте ссылку из письма ещё раз.'
            : 'Отписка временно недоступна. Попробуйте позже.';
        result = {status, html: `<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Отписка</title><main><h1>Отписка от рассылки</h1><p>${message}</p></main></html>`};
      }
      response.writeHead(result.status, {
        'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store',
        'referrer-policy': 'no-referrer', 'x-content-type-options': 'nosniff',
        'content-security-policy': "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'",
      });
      return response.end(result.html);
    }

    // A site's Caddy route selects its company; client query parameters cannot change it.
    if (parts[0] === 'public-company-links') {
      if (request.method !== 'GET' || parts.length !== 2 || !SITES.has(parts[1])) fail(404, 'Не найдено');
      return reply(200, await readCompanyLinks(parts[1]), {'cache-control': 'no-store'});
    }

    // Only the public-site Caddy handlers rewrite to this GET-only route.
    // The cabinet proxies /content/*, never /public-content/*.
    if (parts[0] === 'public-content') {
      if (request.method !== 'GET' || parts.length !== 3 || !SITES.has(parts[1]) || !Object.hasOwn(DOCUMENT_VALIDATORS, parts[2])) {
        fail(404, 'Не найдено');
      }
      const row = latestStmt.get(`${parts[1]}/${parts[2]}`);
      if (!row) fail(404, 'Документ не найден');
      return reply(200, row.body, { etag: `"${row.version}"` });
    }

    // Заявка с сайта: только Caddy-маршрут Palitra переписывает сюда POST /api/orders. Без cookie и ключей.
    if (parts[0] === 'public-orders') {
      if (request.method !== 'POST' || parts.length !== 2 || !Object.hasOwn(ORDER_SITES, parts[1])) fail(404, 'Не найдено');
      if (!/^application\/json\b/i.test(String(request.headers['content-type'] || ''))) fail(415, 'Ожидался JSON');
      let body;
      try { body = JSON.parse((await readRaw(request, ORDER_BODY_LIMIT)).toString('utf8')); } catch (error) { if (error.status === 413) throw error; fail(400, 'Некорректный JSON'); }
      // PALITRA-WEBCHAT-PHASEB: здесь нет проверенного фактического адреса магазина и его cookie — чат сайта не выдаётся.
      // Запрос нового оформления с чатом отклоняется явно (заявка не создаётся, корзина остаётся), прежний — как раньше.
      if (request.headers[CHAT_CSRF_HEADER] !== undefined) {
        return reply(409, { ok: false, code: 'CHAT_CONTEXT_UNSUPPORTED', error: 'Оформление с чатом сайта принимается только на адресе магазина' }, { 'cache-control': 'no-store' });
      }
      try {
        // Та же функция приёма, что у адреса магазина: native submit ровно один раз, без контекста чата.
        const { result } = customerChatNative.submitWithChat({ chatRequest: null,
          submit: () => projectChat.siteOrders.submit({ site: parts[1], body, origin: originOf(request), ip: clientIp(request) }) });
        // Только новая заявка получает одноразовую ссылку в Telegram; сбой ссылки не влияет на принятую заявку.
        if (result.status === 201) {
          try {
            const link = clientDialogs.issueOrderLink({ site: parts[1], orderId: result.body.orderId });
            if (link) result.body.telegram = link;
          } catch (error) { console.error('content: ссылка на клиентский бот не выдана:', error.message); }
        }
        return reply(result.status, result.body, { 'cache-control': 'no-store' });
      } catch (error) {
        if (![400, 403, 409, 429, 503].includes(error.status) && !(error.status === 410 && error.code === 'ORDER_REMOVED')) throw error;
        return reply(error.status, { ok: false, code: error.code || 'VALIDATION', error: error.message, ...(error.itemId ? { itemId: error.itemId } : {}) },
          { 'cache-control': 'no-store', ...(error.status === 429 ? { 'retry-after': '600' } : {}) });
      }
    }

    if (parts[0] !== 'content' || parts.length < 3) fail(404, 'Не найдено');
    if (await salonCompanyApp.handle({request,url,reply,requireSession,requireCsrf,readJson,origin:PALITRA_APP_ORIGIN,orders:projectChat.siteOrders,dialogs:clientDialogs})) return;
    if (!SITES.has(parts[1])) fail(404, 'Неизвестный сайт');
    // PALITRA_MANAGER_ATTENTION_ROUTE: existing crm.view, no writes or side-effectful workflow reads.
    if (parts[1] === 'palitra' && parts[2] === 'manager-attention') {
      const session = requireSession(request); palitraSessionAccess(session, false);
      if (url.pathname !== '/content/palitra/manager-attention') fail(404, 'Не найдено');
      if (request.method !== 'GET') fail(405, 'Доступно только чтение списка клиентов');
      const query = {};
      for (const key of url.searchParams.keys()) {
        if (!['filter','limit','cursor'].includes(key) || url.searchParams.getAll(key).length !== 1) fail(400, 'Некорректные параметры списка клиентов');
        query[key] = url.searchParams.get(key);
      }
      const result = palitraManagerAttention.read(session.user, query);
      const fresh = requireSession(request);
      if (fresh.user.id !== session.user.id || fresh.user.sessionVersion !== session.user.sessionVersion) fail(403, 'Доступ изменился');
      palitraSessionAccess(fresh, false);
      return reply(200, result, {'cache-control':'no-store'});
    }
    // PALITRA_MANAGER_ATTENTION_ROUTE_END
    // PALITRA_RESPONSE_REPORT_ROUTE: same existing crm.view, fresh actor, GET only.
    if (parts[1] === 'palitra' && parts[2] === 'response-report') {
      const session = requireSession(request); palitraSessionAccess(session, false);
      if (url.pathname !== '/content/palitra/response-report') fail(404, 'Не найдено');
      if (request.method !== 'GET') fail(405, 'Доступно только чтение отчёта');
      const query = {};
      for (const key of url.searchParams.keys()) {
        if (!['from','until'].includes(key) || url.searchParams.getAll(key).length !== 1) fail(400, 'Некорректный период отчёта');
        query[key] = url.searchParams.get(key);
      }
      const result = palitraResponseReport.read(session.user,query.from,query.until);
      const fresh = requireSession(request);
      if (fresh.user.id !== session.user.id || fresh.user.sessionVersion !== session.user.sessionVersion) fail(403, 'Доступ изменился');
      palitraSessionAccess(fresh, false);
      return reply(200, result, {'cache-control':'no-store'});
    }
    // PALITRA_RESPONSE_REPORT_ROUTE_END
    if (await palitraMemoHttp(request, url, reply)) return;
    if (await palitraWorkflowHttp(request, url, reply)) return;

    // --- заявки в ЛК: только владелец, только настроенные компании; мутации с CSRF.
    if (parts[2] === 'orders' || parts[2] === 'order-recipient') {
      const session = requireSession(request);
      if (parts[1] === 'palitra' && parts[2] === 'orders') palitraSessionAccess(session, !['GET', 'HEAD'].includes(request.method));
      else if (session.user.role !== 'owner') fail(403, 'Доступно только владельцу');
      if (parts[1] === 'palitra' && !['GET', 'HEAD'].includes(request.method) && request.headers.origin !== PALITRA_APP_ORIGIN) fail(403, 'Запрос с другого адреса запрещён');
      if (request.method !== 'GET') requireCsrf(request, session);
      const orders = projectChat.siteOrders, site = parts[1];
      const headers = { 'cache-control': 'no-store' };
      if (parts[2] === 'orders' && parts.length === 3 && request.method === 'GET') {
        const result = orders.listOrders(site, { limit: url.searchParams.get('limit'), beforeId: url.searchParams.get('beforeId') });
        if (site === 'palitra') result.orders = result.orders.map((row) => ({ ...row, nativeContactFollowup: customerChatNative.contactFollowup(site, row.id, { id: session.user.id, sessionVersion: session.user.sessionVersion }) }));
        return reply(200, result, headers);
      }
      if (parts[2] === 'orders' && parts.length === 5 && parts[4] === 'renotify' && request.method === 'POST') return reply(202, orders.renotify(site, parts[3]), headers);
      if (parts[2] === 'orders' && parts.length === 5 && parts[4] === 'renotify-group' && request.method === 'POST') return reply(202, orders.renotify(site, parts[3], 'group'), headers);
      if (parts[2] === 'orders' && parts.length === 5 && parts[4] === 'checklist') {
        if (request.method === 'GET') return reply(200, orders.checklistOrder(site, parts[3]), headers);
        if (request.method === 'PUT') return reply(200, orders.setChecklist(site, parts[3], site === 'palitra' ? await palitraReadBody(request, session) : await readJson(request),
          { type: 'owner', id: session.user.id, label: session.user.displayName || session.user.login }), headers);
      }
      if (parts[2] === 'order-recipient' && parts.length === 3 && request.method === 'GET') return reply(200, orders.recipientStatus(site), headers);
      if (parts[2] === 'order-recipient' && parts.length === 3 && request.method === 'PUT') return reply(200, orders.setRecipient(site, await readJson(request)), headers);
      if (parts[2] === 'order-recipient' && parts.length === 4 && parts[3] === 'test' && request.method === 'POST') return reply(202, orders.testRecipient(site), headers);
      if (parts[2] === 'order-recipient' && parts.length === 4 && parts[3] === 'transport' && request.method === 'PUT') {
        return reply(200, orders.setTransport(site, await readJson(request), { clientBotReady: clientDialogs.transportReady }), headers);
      }
      // PALITRA-APP-WORKPLACE: статус обработки заявки из приложения (только Palitra). Owner, точный Origin и CSRF —
      // до чтения тела и снова по свежей сессии после него; автор — из свежей сессии, не из тела.
      if (site === 'palitra' && parts[2] === 'orders' && parts.length === 5 && parts[4] === 'work' && request.method === 'PUT') {
        if (request.headers.origin !== PALITRA_APP_ORIGIN) fail(403, 'Запрос с другого адреса запрещён');
        const body = await readJson(request);
        if (!Object.hasOwn(body, 'status') || Object.keys(body).some((key) => !['status', 'expected'].includes(key))) fail(400, 'Нужны только status и expected');
        const fresh = requireSession(request);
        if (fresh.user.id !== session.user.id || fresh.user.sessionVersion !== session.user.sessionVersion) fail(403, 'Доступ изменился');
        palitraSessionAccess(fresh, true);
        requireCsrf(request, fresh);
        const actor = `${fresh.user.role === 'owner' ? 'Владелец' : 'Менеджер'}: ${fresh.user.displayName || fresh.user.login || fresh.user.id}`;
        return reply(200, orders.setWorkStatus(site, parts[3], body.status, actor, body.expected === undefined ? {} : { expected: body.expected }), headers);
      }
      // PALITRA-APP-WORKPLACE: карточка заявки → единственный связанный диалог клиентского бота или null.
      if (site === 'palitra' && parts[2] === 'orders' && parts.length === 5 && parts[4] === 'dialog' && request.method === 'GET') {
        // PALITRA-WEBCHAT-PHASEB: дополнительно — чат сайта этой заявки. Ссылки типизированы: legacy:N и thread:N не смешиваются.
        const legacy = clientDialogs.orderDialog(site, parts[3]);
        const thread = customerChatNative.orderThread(site, parts[3]);
        return reply(200, { ...legacy, dialogRef: legacy.dialogId ? `legacy:${legacy.dialogId}` : null, ...thread }, headers);
      }
      fail(404, 'Не найдено');
    }
    /* PALITRA-WEBCHAT-PHASEB: чаты сайта в приложении владельца. Обычная native-сессия владельца; ответ — точный
       PALITRA_APP_ORIGIN и CSRF до чтения тела, после — свежая сессия того же владельца, его sessionVersion и CSRF ещё раз.
       Проверка владельца в ядре (ownerStillValid) закрыта при отсутствии и повторяется внутри транзакции. */
    if (parts[1] === 'palitra' && parts[2] === 'customer-threads') {
      const session = requireSession(request);
      palitraSessionAccess(session, !['GET', 'HEAD'].includes(request.method));
      const headers = { 'cache-control': 'no-store' };
      const ownerOf = (s) => ({ id: s.user.id, sessionVersion: s.user.sessionVersion });
      if (parts.length === 3 && request.method === 'GET') {
        return reply(200, customerChatNative.owner.list({ owner: ownerOf(session), before: url.searchParams.get('before'), limit: url.searchParams.get('limit') }), headers);
      }
      if (parts.length === 4 && request.method === 'GET') {
        const allowed = new Set(['before', 'limit', 'view', 'adviceAfter']);
        for (const key of url.searchParams.keys()) {
          if (!allowed.has(key) || url.searchParams.getAll(key).length !== 1) fail(400, 'Некорректные параметры переписки');
        }
        const view = url.searchParams.has('view') ? url.searchParams.get('view') : undefined;
        if (view !== undefined && view !== 'conversation-v1') fail(400, 'Неизвестный вид переписки');
        return reply(200, customerChatNative.owner.read({ owner: ownerOf(session), threadId: parts[3], before: url.searchParams.get('before'), limit: url.searchParams.get('limit'), ...(view === undefined ? {} : { view }), ...(url.searchParams.has('adviceAfter') ? { adviceAfter: url.searchParams.get('adviceAfter') } : {}) }), headers);
      }
      if (parts.length === 5 && parts[4] === 'reply' && request.method === 'POST') {
        if (request.headers.origin !== PALITRA_APP_ORIGIN) fail(403, 'Запрос с другого адреса запрещён');
        requireCsrf(request, session);
        const body = await readJson(request);
        if (Object.keys(body).sort().join(',') !== 'requestId,text') fail(400, 'Нужны только requestId и text');
        const fresh = requireSession(request);
        if (fresh.user.id !== session.user.id || fresh.user.sessionVersion !== session.user.sessionVersion) fail(403, 'Доступ изменился');
        palitraSessionAccess(fresh, !['GET', 'HEAD'].includes(request.method));
        requireCsrf(request, fresh);
        const result = customerChatNative.owner.reply({ owner: ownerOf(fresh), threadId: parts[3], requestId: body.requestId, text: body.text });
        return reply(result.duplicate ? 200 : 202, result, headers);
      }
      // PALITRA-WEBCHAT-PHASEE: файл владельца в чат сайта — ровно uploads, uploads/upload:<UUID>, …/bytes, attachments/upload:<UUID>.
      const threadUpload = require('./customer-chat-upload.cjs').parseUploadPath(url.pathname, 'thread');
      if (threadUpload && !url.search) {
        const target = { threadId: threadUpload.targetId, uuid: threadUpload.uuid };
        return await ownerUploadRoute({ request, response, route: threadUpload, session, reply, headers, ops: {
          prepare: (owner, body) => customerChatNative.owner.prepareUpload({ owner, threadId: threadUpload.targetId, body }),
          status: (owner) => customerChatNative.owner.uploadStatus({ owner, ...target }),
          begin: (owner) => customerChatNative.owner.beginUpload({ owner, ...target }),
          finish: (owner, claim, bytes) => customerChatNative.owner.finishUpload({ owner, ...target, claim, bytes }),
          release: (claim, reason) => customerChatNative.owner.releaseUpload(threadUpload.uuid, claim, reason),
          file: (owner) => customerChatNative.owner.uploadFile({ owner, ...target }),
          open: (meta) => customerChatNative.owner.openUpload(meta) } });
      }
      /* PALITRA-WEBCHAT-PHASED1: файл чата сайта владельцу — ровно /content/palitra/customer-threads/<id>/attachments/thread:<id>,
         GET/HEAD. Доступ проверяется по свежей сессии (тот же владелец, роль, версия) до открытия файла и ещё раз перед байтами. */
      const binary = require('./customer-chat-media.cjs');
      const file = binary.parseOwnerBinaryPath(url.pathname);
      if (file && !url.search) {
        if (!['GET', 'HEAD'].includes(request.method)) fail(405, 'Метод не поддерживается');
        const resolve = () => {
          const fresh = requireSession(request);
          if (fresh.user.id !== session.user.id || fresh.user.sessionVersion !== session.user.sessionVersion) fail(403, 'Доступ изменился');
        palitraSessionAccess(fresh, !['GET', 'HEAD'].includes(request.method));
          return customerChatNative.owner.attachment({ owner: ownerOf(fresh), threadId: file.threadId, attachmentId: file.attachmentId });
        };
        return binary.serveProtected({ request, response, resolve, open: (meta) => customerChatNative.owner.openAttachment(meta) });
      }
      fail(404, 'Не найдено');
    }
    // --- клиентский бот и диалоги в ЛК: только владелец, только сайт с настроенным ботом; мутации с CSRF.
    if (parts[2] === 'client-bot' || parts[2] === 'client-dialogs') {
      const session = requireSession(request);
      if (parts[1] === 'palitra' && parts[2] === 'client-dialogs') palitraSessionAccess(session, !['GET', 'HEAD'].includes(request.method));
      else if (session.user.role !== 'owner') fail(403, 'Доступно только владельцу');
      if (parts[1] === 'palitra' && !['GET', 'HEAD'].includes(request.method) && request.headers.origin !== PALITRA_APP_ORIGIN) fail(403, 'Запрос с другого адреса запрещён');
      if(parts[2]==='client-dialogs'&&parts.length===5&&parts[4]==='crm'&&request.method==='POST'){
        requireCsrf(request,session);
        const source=clientDialogs.crmIntake(parts[1],parts[3]);
        const result=await openClientIntake(source,session.user);
        const fresh=requireSession(request);if(fresh.user.id!==session.user.id||fresh.user.sessionVersion!==session.user.sessionVersion)fail(403,'Доступ изменился');palitraSessionAccess(fresh,true);
        return reply(200,result,{'cache-control':'no-store'});
      }
      // PALITRA-APP-WORKPLACE: ответ владельца клиенту из приложения. Точный Origin и CSRF — до чтения тела; после —
      // свежая сессия того же владельца и CSRF; затем синхронная транзакция в client-dialogs. Автор — только из сессии.
      if (parts[1] === 'palitra' && parts[2] === 'client-dialogs' && parts.length === 5 && parts[4] === 'reply' && request.method === 'POST') {
        if (request.headers.origin !== PALITRA_APP_ORIGIN) fail(403, 'Запрос с другого адреса запрещён');
        requireCsrf(request, session);
        const body = await readJson(request);
        const fresh = requireSession(request);
        if (fresh.user.id !== session.user.id || fresh.user.sessionVersion !== session.user.sessionVersion) fail(403, 'Доступ изменился');
        palitraSessionAccess(fresh, true);
        requireCsrf(request, fresh);
        const result = clientDialogs.sendOwnerReply('palitra', parts[3], body, { id: fresh.user.id, sessionVersion: fresh.user.sessionVersion });
        return reply(result.duplicate ? 200 : 202, result, { 'cache-control': 'no-store' });
      }
      // PALITRA-WEBCHAT-PHASEE: файл владельца в прежний диалог — точные адреса этого диалога; гостевого доступа нет.
      const legacyUpload = parts[1] === 'palitra' && parts[2] === 'client-dialogs' ? require('./customer-chat-upload.cjs').parseUploadPath(url.pathname, 'legacy') : null;
      if (legacyUpload && !url.search) {
        const dialogId = legacyUpload.targetId, uuid = legacyUpload.uuid;
        return await ownerUploadRoute({ request, response, route: legacyUpload, session, reply, headers: { 'cache-control': 'no-store' }, ops: {
          prepare: (owner, body) => clientDialogs.prepareOwnerUpload('palitra', dialogId, body, owner),
          status: (owner) => clientDialogs.ownerUploadStatus('palitra', dialogId, uuid, owner),
          begin: (owner) => clientDialogs.beginOwnerUpload('palitra', dialogId, uuid, owner),
          finish: (owner, claim, bytes) => clientDialogs.finishOwnerUpload('palitra', dialogId, uuid, claim, bytes, owner),
          release: (claim, reason) => clientDialogs.releaseOwnerUpload(uuid, claim, reason),
          file: () => clientDialogs.ownerUploadFile('palitra', dialogId, uuid),
          open: (meta) => clientDialogs.openOwnerUpload(meta) } });
      }
      return await clientDialogs.handleCabinet(request, response, url, parts, { session, requireCsrf, send: (res, status, payload, extra) => send(res, status, payload, { ...cors, ...(extra || {}) }) });
    }

    // --- файлы (фоны блоков): /content/:site/assets[/:name]
    if (parts[2] === 'assets') {
      const site = parts[1].replace(/[^\w-]/g, '');
      const dir = path.join(ASSETS_DIR, site);
      if (request.method === 'GET' && parts.length === 4) {
        const file = path.join(dir, path.basename(parts[3]));
        if (!fs.existsSync(file)) fail(404, 'Файл не найден');
        const ext = path.extname(file).toLowerCase();
        const type = ext === '.png' ? 'image/png' : ext === '.webp' ? 'image/webp' : 'image/jpeg';
        response.writeHead(200, { 'content-type': type, 'cache-control': 'public, max-age=31536000, immutable', ...cors });
        return fs.createReadStream(file).pipe(response);
      }
      if (request.method === 'GET' && parts.length === 3) {
        const permission = sessionData(request)?.user.permissions.includes('price.view') ? 'price.view' : 'site_editor.view';
        requireContentAccess(request, permission, site);
        const list = fs.existsSync(dir) ? fs.readdirSync(dir).map((n) => ({ name: n, url: `/api/assets/${n}`, size: fs.statSync(path.join(dir, n)).size })) : [];
        return reply(200, { site, files: list });
      }
      if (request.method === 'POST' && parts.length === 3) {
        // Price editors can upload product photos without receiving site-editor permissions.
        const permission = sessionData(request)?.user.permissions.includes('price.edit') ? 'price.edit' : 'site_editor.edit';
        const author = requireContentAccess(request, permission, site, true).author;
        const type = (request.headers['content-type'] || '').split(';')[0].trim();
        if (!ASSET_TYPES[type]) fail(415, 'Допустимы только JPEG, PNG и WebP');
        const body = await readRaw(request, MAX_ASSET);
        if (!body.length) fail(400, 'Пустой файл');
        fs.mkdirSync(dir, { recursive: true });
        const original = decodeURIComponent(String(request.headers['x-filename'] || 'image')).replace(/\.[^.]+$/, '');
        const name = `${Date.now().toString(36)}-${safeAssetName(original)}${ASSET_TYPES[type]}`;
        fs.writeFileSync(path.join(dir, name), body);
        return reply(200, { ok: true, name, url: `/api/assets/${name}`, size: body.length, author });
      }
      fail(404, 'Не найдено');
    }

    if (parts[1] === 'palitra-push-private') fail(404, 'Не найдено');
    const key = `${parts[1]}/${parts[2]}`;
    const tail = parts.slice(3);

    // GET /content/:site/:doc — документ кабинета проверяет проект и право просмотра
    if (request.method === 'GET' && tail.length === 0) {
      requireContentAccess(request, parts[2] === 'price' ? 'price.view' : 'site_editor.view', parts[1]);
      const row = latestStmt.get(key);
      if (!row) fail(404, `Документ ${key} не найден`);
      // Только palitra/price: заголовок обещает проверку If-Match в PUT ниже (пакет 12–18, ставится вместе с ним).
      if (palitraPrice.isPalitraPrice(parts)) return reply(200, row.body, { etag: `"${row.version}"`, [palitraPrice.CAS_HEADER]: palitraPrice.CAS_HEADER_VALUE });
      return reply(200, row.body, { etag: `"${row.version}"` });
    }

    // GET /content/:site/:doc/history
    if (request.method === 'GET' && tail[0] === 'history' && tail.length === 1) {
      requireContentAccess(request, parts[2] === 'price' ? 'price.view' : 'site_editor.view', parts[1]);
      return reply(200, { key, versions: historyStmt.all(key, HISTORY_LIMIT) });
    }

    // GET /content/:site/:doc/version/:n
    if (request.method === 'GET' && tail[0] === 'version' && tail.length === 2) {
      requireContentAccess(request, parts[2] === 'price' ? 'price.view' : 'site_editor.view', parts[1]);
      const row = byVersionStmt.get(key, Number.parseInt(tail[1], 10));
      if (!row) fail(404, 'Версия не найдена');
      return reply(200, row.body);
    }

    // PUT /content/:site/:doc — новая версия (по ключу)
    if (request.method === 'PUT' && tail.length === 0) {
      const author = requireContentAccess(request,
        parts[2] === 'price' ? 'price.edit' : 'site_editor.edit', parts[1], true).author;
      const doc = await readJson(request);
      // Только palitra/price: форма документа → 422, версия If-Match проверяется внутри BEGIN IMMEDIATE (409), strict выключен.
      if (palitraPrice.isPalitraPrice(parts)) {
        // Права перепроверяются синхронно после чтения тела, непосредственно перед записью.
        const current = requireContentAccess(request, 'price.edit', parts[1], true).author;
        const problems = palitraPrice.validatePriceProblems(doc);
        if (problems.length) fail(422, 'Документ не прошёл проверку', problems.slice(0, 50));
        const saved = palitraPrice.saveWithCas(db, key, doc, current, request.headers['if-match'], { strict: false });
        return reply(200, { ok: true, key, ...saved });
      }
      const validator = DOCUMENT_VALIDATORS[parts[2]];
      if (!validator) fail(404, 'Неизвестный тип документа');
      validator(doc);
      const saved = saveVersion(key, doc, author);
      return reply(200, { ok: true, key, ...saved });
    }

    // POST /content/:site/:doc/restore/:n — откат (по ключу)
    if (request.method === 'POST' && tail[0] === 'restore' && tail.length === 2) {
      const author = requireContentAccess(request,
        parts[2] === 'price' ? 'price.edit' : 'site_editor.edit', parts[1], true).author;
      const row = byVersionStmt.get(key, Number.parseInt(tail[1], 10));
      if (!row) fail(404, 'Версия не найдена');
      const saved = saveVersion(key, JSON.parse(row.body), `${author} (откат к ${row.version})`);
      return reply(200, { ok: true, key, restoredFrom: row.version, ...saved });
    }

    fail(404, 'Не найдено');
  } catch (error) {
    const status = error.status || 500;
    if (status === 401 || status === 403) logAuthorizationDenial(request, error);
    if (status >= 500) console.error(error);
    reply(status, { error: error.message, details: error.details || undefined });
  }
});

let economyTimer;
server.listen(PORT, () => {
  console.log(`content: слушает порт ${PORT}, база ${DATABASE_PATH}`);
  projectChat.startWorker();
  taskDispatchWorker.start();
  if(process.env.CONTENT_PLAN_WORKER_ENABLED==='1')contentPlanRunner.start();
  const monitor=()=>hughProviders.monitorEconomy(projectChat.fallback.status()).catch(()=>{});
  economyTimer=setInterval(()=>void monitor(),600000);economyTimer.unref();void monitor();
});

function shutdownContent() {
  clearInterval(economyTimer);
  projectChat.stopWorker();
  taskDispatchWorker.stop();
  const contentPlanStopped=contentPlanRunner.stop();
  server.close(async () => {
    await contentPlanStopped;
    salonCompanyApp.close();
    db.close();
    process.exit(0);
  });
}

process.on('SIGTERM', shutdownContent);
process.on('SIGINT', shutdownContent);
