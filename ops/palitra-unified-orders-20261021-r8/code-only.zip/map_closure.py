"""Closed native source/static mapping. No basename/route guesses or live reads."""
import copy,hashlib,json
from manifest_inputs import need,digest,relative,read_pin
from static_extension import STATIC_ONLY,FACTS_SHA,validate_facts,validate_consumer
encoded=lambda v:json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
sha=lambda v:hashlib.sha256(encoded(v)).hexdigest()
def close(proof,components,overrides,extension=None):
    need(proof.get('schema')=='palitra-unified-native-map/v1' and proof.get('image')=='sha256:951db09e9e6c4781350bbced7e7a9e4ef099077a368e38a6b1fac40e0a4a6a22' and proof.get('chainFiles')==49,'EXACT_CURRENT_IMAGE_CHAIN_MAP_REQUIRED')
    source=proof['source'];statics=proof['static'];historical=proof['release36Source'];tree=proof['appTree']
    need(len(source)==240 and len(statics)==43 and len(historical)==211 and set(historical)<=set(source),'EXACT_211_240_43_DOMAINS_REQUIRED')
    need(set(proof['staticModes'])==set(statics) and type(overrides) is dict,'CLOSED_STATIC_MODES_AND_EXPLICIT_OVERRIDES_REQUIRED')
    for name,pin in source.items():
        need(relative(name) and digest(pin),'EXACT_SOURCE_MAP_ROW_REQUIRED');row=tree.get(name,{})
        need(row.get('type')=='file' and row.get('sha256')==pin and row.get('uid')==row.get('gid')==0 and row.get('nlink')==1 and row.get('mode') in (0o600,0o644),'FULL_SOURCE_MAP_TREE_FACTS_REQUIRED')
    historical_prefix='/var/lib/docker/volumes/synapse_content_data/_data/projects/palitra-love/sites/site-44bbe13f1bad5e005b2a/versions/'
    for name,pin in statics.items():
        historical_name=name[len(historical_prefix):] if name.startswith(historical_prefix) else None
        historic_ok=historical_name is not None and len(historical_name.split('/'))==3 and digest(historical_name.split('/')[0]) and '/'.join(historical_name.split('/')[1:]) in ('assets/order.js','assets/storefront.js')
        need((name.startswith('/opt/synapse/sites/') or historic_ok) and digest(pin) and proof['staticModes'][name] in (0o600,0o644),'EXACT_STATIC_HASH_MODE_REQUIRED')
    for name,pin in historical.items():need(relative(name) and digest(pin),'EXACT_RELEASE36_MAP_ROW_REQUIRED')
    baseline_statics=dict(statics);baseline_modes=dict(proof['staticModes']);modes=dict(baseline_modes);statics=dict(statics)
    extra=validate_facts(extension) if extension is not None else {}
    need(not (set(extra)&set(statics)) and not any(p.rsplit('/',1)[-1] in source for p in extra),'STATIC_EXTENSION_MUST_NOT_REPLACE_BASELINE_OR_IMAGE_SOURCE')
    statics.update({p:r['sha256'] for p,r in extra.items()});modes.update({p:r['mode'] for p,r in extra.items()})
    runtime={};private={};managed=[];consumers=[];used=set();extension_used=set()
    for group,component in components.items():
        for index,row in enumerate(component['records']):
            key=group+':'+str(index);raw=read_pin(row['input']);before=row['before']['sha256'] if row['before'] else None
            if group=='managed-site':managed.append(copy.deepcopy(row));continue
            specified=row['runtimeTarget'];matches=[n for n,p in source.items() if before is not None and p==before]
            override=overrides.get(key)
            if override is not None:
                need(set(override)=={'runtimeTargets','staticTargets'},'EXACT_REVIEWED_OVERRIDE_REQUIRED');targets=override['runtimeTargets'];used.add(key)
                need(type(targets) is list and len(targets)==len(set(targets)) and all(relative(n) for n in targets),'UNIQUE_RUNTIME_CONSUMERS_REQUIRED')
                if not targets:
                    target=validate_consumer(key,row,override['staticTargets']);need(target in extra,'OBSERVED_STATIC_EXTENSION_REQUIRED');extension_used.add(target)
                else:need(key not in STATIC_ONLY or not extra,'PROVEN_STATIC_ONLY_ASSET_MUST_NOT_ENTER_IMAGE')
            elif specified:targets=[specified]
            else:
                need(len(matches)==1,'AMBIGUOUS_OR_UNMAPPED_RUNTIME_REQUIRES_EXPLICIT_OVERRIDE_'+key.replace(':','_'));targets=matches
            if before is None:need(all(n not in source for n in targets) and row['newSourceMode'] in (0o600,0o644),'EXACT_SOURCE_ADDITIONS_REQUIRED')
            else:need(all(source.get(n)==before for n in targets),'REVIEWED_CURRENT_BYTES_MUST_MATCH_NATIVE_MAP')
            static_targets=override['staticTargets'] if override else row['staticTargets']
            if not static_targets and override is None:
                hits=[n for n,p in statics.items() if before is not None and p==before]
                need(len(hits)<=1,'AMBIGUOUS_STATIC_REQUIRES_EXPLICIT_OVERRIDE_'+key.replace(':','_'));static_targets=hits
            for target in targets:
                mode=tree[target]['mode'] if target in source else row['newSourceMode']
                item={'target':target,'input':row['input'],'beforeSha256':before,'sha256':row['input']['sha256'],'bytes':len(raw),'mode':mode,'consumers':[key]}
                if target in runtime:
                    old=runtime[target];need({k:v for k,v in old.items() if k not in ('input','consumers')}=={k:v for k,v in item.items() if k not in ('input','consumers')},'CONFLICTING_ALIAS_PAYLOAD_REFUSED');old['consumers'].append(key)
                else:runtime[target]=item
            for target in static_targets:
                need(statics.get(target)==before and before is not None,'EXISTING_STATIC_REPLACEMENT_ONLY')
                item={'target':target,'input':row['input'],'beforeSha256':before,'sha256':row['input']['sha256'],'bytes':len(raw),'mode':modes[target]}
                if target in private:need({k:v for k,v in private[target].items() if k!='input'}=={k:v for k,v in item.items() if k!='input'},'CONFLICTING_STATIC_ALIAS_REFUSED')
                else:private[target]=item
            consumers.append({'key':key,'runtimeTargets':targets,'staticTargets':static_targets})
    need(set(overrides)==used,'UNUSED_OR_FOREIGN_MAPPING_OVERRIDE_REFUSED')
    need(extension_used==set(extra),'EXACT_SIX_STATIC_ONLY_CONSUMERS_REQUIRED')
    after_source=dict(source);after_static=dict(statics);after_tree=copy.deepcopy(tree)
    for target,row in runtime.items():
        after_source[target]=row['sha256'];after_tree[target]={'uid':0,'gid':0,'mode':row['mode'],'type':'file','nlink':1,'bytes':row['bytes'],'sha256':row['sha256']}
        # No new directories are fabricated by the mapping reducer.
        parent=target.rsplit('/',1)[0] if '/' in target else ''
        need(after_tree.get(parent,{}).get('type')=='directory','NEW_SOURCE_PARENT_MUST_EXIST_IN_FULL_TREE')
    for target,row in private.items():after_static[target]=row['sha256']
    need(len(managed)==3 and runtime and len(runtime)<=64,'BOUNDED_UNIFIED_MAP_REQUIRED')
    value={'schema':'palitra-unified-map-closure/v1','parentImage':proof['image'],'chainBefore':49,'chainAfter':50,'release36Source':historical,'sourceBefore':source,'sourceAfter':after_source,'staticBefore':statics,'staticAfter':after_static,'staticModes':modes,'staticBaselineBefore':baseline_statics,'staticBaselineModes':baseline_modes,'staticExtensionFacts':extension,'staticExtensionFactsSha256':FACTS_SHA if extension is not None else None,'appTreeBefore':tree,'appTreeAfter':after_tree,'runtimeRecords':list(runtime.values()),'staticRecords':list(private.values()),'managedRecords':managed,'consumers':consumers,'sourceBeforeCount':240,'sourceAfterCount':len(after_source),'staticCount':len(statics)}
    value['closureSha256']=sha(value);return value

def verify(value):
    saved=dict(value);pin=saved.pop('closureSha256');need(digest(pin) and sha(saved)==pin,'EXACT_MAP_CLOSURE_HASH_REQUIRED')
    need(value['sourceBeforeCount']==240 and len(value['sourceBefore'])==240 and len(value['release36Source'])==211 and value['sourceAfterCount']==len(value['sourceAfter']) and len(value['staticBaselineBefore'])==len(value['staticBaselineModes'])==43 and len(value['staticBefore'])==len(value['staticAfter'])==value['staticCount'],'EXACT_CLOSED_MAP_DOMAINS_REQUIRED')
    extras=validate_facts(value['staticExtensionFacts']) if value['staticExtensionFacts'] is not None else {}
    need(value['staticExtensionFactsSha256']==(FACTS_SHA if extras else None),'EXACT_STATIC_EXTENSION_PROVENANCE_REQUIRED')
    expected_static=dict(value['staticBaselineBefore']);expected_modes=dict(value['staticBaselineModes'])
    need(not (set(extras)&set(expected_static)),'STATIC_EXTENSION_BASELINE_OVERLAP_REFUSED')
    expected_static.update({p:r['sha256'] for p,r in extras.items()});expected_modes.update({p:r['mode'] for p,r in extras.items()})
    need(value['staticBefore']==expected_static and value['staticModes']==expected_modes,'STATIC_EXTENSION_UNLISTED_DOMAIN_OR_MODE_REFUSED')
    extra_consumers={p for r in value['consumers'] if not r['runtimeTargets'] for p in r['staticTargets']}
    need(extra_consumers==set(extras),'STATIC_EXTENSION_EXACT_CONSUMER_COVERAGE_REQUIRED')
    need(all(r['target'] not in {p.rsplit('/',1)[-1] for p in extras} for r in value['runtimeRecords']),'STATIC_ONLY_ASSET_MUST_NOT_ENTER_IMAGE')
    expected=dict(value['sourceBefore']);expected.update({r['target']:r['sha256'] for r in value['runtimeRecords']});need(expected==value['sourceAfter'],'SOURCE_MAP_UNLISTED_DELTA_REFUSED')
    expected=dict(value['staticBefore']);expected.update({r['target']:r['sha256'] for r in value['staticRecords']});need(expected==value['staticAfter'],'STATIC_MAP_UNLISTED_DELTA_REFUSED')
    tree=copy.deepcopy(value['appTreeBefore'])
    for row in value['runtimeRecords']:
        need(relative(row['target']) and digest(row['sha256']) and row['mode'] in (0o600,0o644),'EXACT_CLOSED_SOURCE_RECORD_REQUIRED')
        if row['beforeSha256'] is not None:need(value['sourceBefore'].get(row['target'])==row['beforeSha256'] and tree[row['target']]['mode']==row['mode'],'SOURCE_MODE_OR_BEFORE_PIN_CHANGED')
        else:need(row['target'] not in tree,'SOURCE_ADDITION_OVERWRITE_REFUSED')
        tree[row['target']]={'uid':0,'gid':0,'mode':row['mode'],'type':'file','nlink':1,'bytes':row['bytes'],'sha256':row['sha256']}
    need(tree==value['appTreeAfter'],'FULL_TREE_UNLISTED_DELTA_REFUSED');return True
