CREATE TABLE IF NOT EXISTS palitra_staff_message_reads_v1 (
  company_code TEXT NOT NULL CHECK(company_code='palitra-love'),
  actor_user_id INTEGER NOT NULL CHECK(actor_user_id>0),
  source_kind TEXT NOT NULL CHECK(source_kind IN ('thread','legacy')),
  target_id INTEGER NOT NULL CHECK(target_id>0),
  through_message_id INTEGER NOT NULL CHECK(through_message_id>0),
  updated_at TEXT NOT NULL,
  PRIMARY KEY(company_code,actor_user_id,source_kind,target_id)
) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS palitra_attribution_meta_v1 (company_code TEXT PRIMARY KEY CHECK(company_code='palitra-love'),started_at TEXT NOT NULL) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS palitra_attribution_visits_v1 (company_code TEXT NOT NULL CHECK(company_code='palitra-love'),visit_hash TEXT NOT NULL,origin TEXT NOT NULL,proof_hash TEXT NOT NULL UNIQUE,first_json TEXT NOT NULL,last_json TEXT NOT NULL,previous_hash TEXT,created_at TEXT NOT NULL,PRIMARY KEY(company_code,visit_hash)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS palitra_attribution_leads_v1 (company_code TEXT NOT NULL CHECK(company_code='palitra-love'),target_kind TEXT NOT NULL CHECK(target_kind IN ('order','thread','legacy')),target_id INTEGER NOT NULL CHECK(target_id>0),entry_kind TEXT NOT NULL CHECK(entry_kind IN ('site_order','site_chat','telegram')),first_json TEXT,last_json TEXT,visit_hash TEXT,created_at TEXT NOT NULL,PRIMARY KEY(company_code,target_kind,target_id)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS palitra_attribution_pending_v1 (company_code TEXT NOT NULL CHECK(company_code='palitra-love'),thread_id INTEGER NOT NULL CHECK(thread_id>0),visit_hash TEXT NOT NULL,created_at TEXT NOT NULL,PRIMARY KEY(company_code,thread_id)) WITHOUT ROWID;
