"""Pure private post-commit content capture kernel. No CLI/DB open/file writer.

The future native wrapper must pin its whole code, actual R9 receipt, actual
lease, exact existing DB inode/mount, and root0600 EXCL private output. Returning
this dictionary is NEVER Root acceptance or a replacement of old frozen data.
"""
import ast,hashlib,json,re,sqlite3
import schema_migration as M
from post_cleanup_basis import inspect_transaction_receipt,HASH_SEMANTICS
ENGINE_SHA='6bd4b9f29ff1ffd4e553750d43df437444b5651485748e1eeca82163c8259861'
METHODS=frozenset(('require','packed','sha','ident','records','state','row_seal'))
def need(v,c):
    if not v:raise ValueError(c)
def primitives(raw):
    need(type(raw) is bytes and hashlib.sha256(raw).hexdigest()==ENGINE_SHA,'EXACT_FROZEN_R6_READ_PRIMITIVES_REQUIRED')
    tree=ast.parse(raw);nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in METHODS]
    need({n.name for n in nodes}==METHODS,'EXACT_SEVEN_READ_FUNCTIONS_REQUIRED')
    ns={'__builtins__':__builtins__,'hashlib':hashlib,'json':json,'re':re};module=ast.Module(body=nodes,type_ignores=[]);ast.fix_missing_locations(module);exec(compile(module,'<exact-r6-read-only-state>','exec'),ns)
    need('mutate' not in ns and 'execute_reviewed_transaction' not in ns,'NO_OLD_WRITER_COMPILED');return ns
def capture(db,*,engine_bytes,receipt_bytes,receipt_sha256,pre_full_sha256,user_approval_sha256,lease_gate,native_minimum=None):
    need(callable(lease_gate),'ACTUAL_NATIVE_LEASE_GATE_REQUIRED');lease=lease_gate()
    need(isinstance(db,sqlite3.Connection) and not db.in_transaction and db.execute('PRAGMA query_only').fetchone()[0]==1,'EXISTING_READONLY_QUERY_ONLY_CONNECTION_REQUIRED')
    p=primitives(engine_bytes)
    need(type(receipt_bytes) is bytes and len(receipt_bytes)<=16*1024*1024 and hashlib.sha256(receipt_bytes).hexdigest()==receipt_sha256,'ACTUAL_PRIVATE_R9_RECEIPT_REQUIRED');receipt=json.loads(receipt_bytes)
    consistency=inspect_transaction_receipt(receipt,engine_sha256=ENGINE_SHA,pre_full_sha256=pre_full_sha256,user_approval_sha256=user_approval_sha256)
    db.execute('BEGIN')
    try:
        schema,rows=p['state'](db);tables={t:{'count':len(v),'rowMultisetSha256':p['row_seal'](v)} for t,v in sorted(rows.items())}
        whole={'schemaSha256':p['sha'](schema),'tables':tables,'wholeRowsSha256':p['sha'](tables)}
        need(whole['schemaSha256']==consistency['wholeAfter']['schemaSha256'] and set(tables)==set(consistency['wholeAfter']['tables']),'POST_CLEANUP_SCHEMA_CHANGED_BEFORE_MIGRATION')
        # Raw rows are intentionally returned ONLY to the future root-private
        # serializer. Do not print/transmit this object or place it in code repo.
        private={'schema':'palitra-post-cleanup-current-content-capture/v1','status':'PRIVATE_CURRENT_CONTENT_CAPTURE_NOT_ROOT_ACCEPTANCE','runtimeAuthorization':False,'hashSemantics':HASH_SEMANTICS,'cleanupReceiptSha256':receipt_sha256,'transactionEvidenceSha256':consistency['transactionEvidenceSha256'],'wholeCurrent':whole,'transactionWholeAfter':consistency['wholeAfter'],'rawPrivateMinimum':{'schema':schema,'tables':rows},'typedContentSha256':M.seal(db)['sha256'],'captureSemantics':'ONE_EXISTING_READONLY_QUERY_ONLY_TRANSACTION_AFTER_R9_COMMIT','lease':lease,'oldArtifactWrites':0,'reportTrafficRuntimeInspection':False}
        if native_minimum is not None:
            need(callable(native_minimum),'PINNED_NATIVE_CONNECTION_SEAL_CALLBACK_REQUIRED');value=native_minimum(db)
            need(type(value) is dict and set(value)=={'identity','family','content'},'EXACT_NATIVE_MINIMUM_SHAPE_REQUIRED');private['nativeContentMinimum']=value
    finally:db.rollback()
    need(lease_gate()==lease,'POST_CONTENT_CAPTURE_LEASE_CHANGED');return private

def native_connection_minimum(db,factory):
    """Exact inspector's content read seal on the same Root readonly transaction.

    The factory is the separately byte-pinned final compatibility inspector;
    this function does not load/instantiate it or accept an arbitrary SQL body.
    """
    need(db.in_transaction and db.execute('PRAGMA query_only').fetchone()[0]==1,'SAME_EXISTING_READONLY_TRANSACTION_REQUIRED')
    content=factory.databases['content'];before=content.facts();sealer=content.read.__func__.__globals__['connection_seal']
    value=sealer(db);after=content.facts();need(content.identity(before)==content.identity(after),'NATIVE_CONTENT_IDENTITY_CHANGED_DURING_SAME_READ')
    return {'identity':content.identity(after),'family':after,'content':value}
