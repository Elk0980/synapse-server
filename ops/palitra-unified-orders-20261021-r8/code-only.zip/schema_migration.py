"""Explicit five-table migration core. No CLI, request hook, or DB opener.

The native adapter is deliberately absent until final Root inputs and an actual
post-cleanup basis exist. The caller must hold BEGIN IMMEDIATE and an externally
verified one-use migration admission. This function never commits the caller.
"""
import base64,hashlib,json,re,sqlite3,stat,os
from datetime import datetime
from pathlib import Path

NAMES=frozenset(('palitra_staff_message_reads_v1','palitra_attribution_meta_v1','palitra_attribution_visits_v1','palitra_attribution_leads_v1','palitra_attribution_pending_v1'))
META='palitra_attribution_meta_v1'
sha=lambda b:hashlib.sha256(b).hexdigest()
encoded=lambda v:json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def need(value,code):
    if not value:raise ValueError(code)
def quote(value):return '"'+value.replace('"','""')+'"'
def atom(value):
    if value is None:return ['null']
    if isinstance(value,bytes):return ['blob',base64.b64encode(value).decode()]
    if type(value) is int:return ['integer',str(value)]
    if type(value) is float:return ['real',value.hex()]
    need(type(value) is str,'SQLITE_VALUE_TYPE_REQUIRED');return ['text',value]
def seal(db,excluded=frozenset()):
    need(isinstance(db,sqlite3.Connection) and db.in_transaction,'EXISTING_CALLER_TRANSACTION_REQUIRED')
    objects=[list(row) for row in db.execute('SELECT type,name,tbl_name,rootpage,sql FROM sqlite_schema ORDER BY type,name') if row[2] not in excluded]
    need(len(objects)<=4096,'FULL_SCHEMA_BOUND_REFUSED_NO_TRUNCATION');tables={};total_bytes=0;total_rows=0
    for kind,name,table,rootpage,sql in objects:
        if kind!='table':continue
        columns=[list(row) for row in db.execute('PRAGMA table_xinfo('+quote(name)+')')]
        rows=[]
        for row in db.execute('SELECT * FROM '+quote(name)):
            raw=encoded([atom(v) for v in row]);total_bytes+=len(raw);total_rows+=1
            need(total_rows<=500000 and total_bytes<=128*1024*1024,'FULL_BUSINESS_BOUND_REFUSED_NO_TRUNCATION');rows.append(raw.decode())
        tables[name]={'columns':columns,'rows':sorted(rows),'count':len(rows)}
    # Physical rootpage may move while adding tables; preservation concerns the
    # exact old object definitions and every typed business row, not page layout.
    schema=[row[:3]+row[4:] for row in objects]
    value={'objects':schema,'tables':tables,'pragmas':{p:db.execute('PRAGMA '+p).fetchone()[0] for p in ('user_version','application_id','journal_mode')}}
    return {'sha256':sha(encoded(value)),'value':value}
def load_schema(raw,pin):
    need(type(raw) is bytes and sha(raw)==pin,'EXACT_REVIEWED_SCHEMA_BYTES_REQUIRED')
    statements=[s.strip() for s in raw.decode().split(';') if s.strip()]
    names=[]
    for sql in statements:
        m=re.fullmatch(r'CREATE TABLE IF NOT EXISTS ([a-z0-9_]+)\s*\([\s\S]+\) WITHOUT ROWID',sql)
        need(m is not None and m[1] in NAMES,'ONLY_FIVE_EXPLICIT_CREATE_TABLES_ALLOWED');names.append(m[1])
    need(len(names)==5 and frozenset(names)==NAMES,'EXACT_FIVE_NEW_TABLES_REQUIRED')
    return list(zip(names,statements))
BASIS_MODE='LATEST_CURRENT_SNAPSHOT_IN_CALLER_TRANSACTION'

def apply_schema(db,*,schema_bytes,schema_sha256,started_at,historical_content_sha256,verify_admission,verify_floor):
    """Additive migration preserves the full CURRENT caller-locked state.

    Historical raw SHA is provenance, never asserted equal to current rows.
    The unchanged frozen native preserves predicate is checked separately.
    """
    need(callable(verify_admission) and callable(verify_floor),'EXTERNAL_ADMISSION_AND_ORIGINAL_FLOOR_REQUIRED')
    expected={'schema':'palitra-unified-explicit-migration-admission/v2','oneUse':True,'basisMode':BASIS_MODE,'historicalContentSha256':historical_content_sha256,'schemaSha256':schema_sha256,'startedAt':started_at}
    need(type(historical_content_sha256) is str and re.fullmatch('[a-f0-9]{64}',historical_content_sha256),'HISTORICAL_CAPTURE_SHA_REQUIRED')
    admission=verify_admission();need(type(admission) is dict and admission==expected,'EXACT_EXTERNAL_LATEST_CURRENT_ADMISSION_REQUIRED')
    need(type(started_at) is str and re.fullmatch(r'\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z',started_at),'EXACT_STARTED_AT_REQUIRED')
    need(datetime.fromisoformat(started_at.replace('Z','+00:00')).isoformat(timespec='milliseconds').replace('+00:00','Z')==started_at,'VALID_STARTED_AT_REQUIRED')
    need(isinstance(db,sqlite3.Connection) and db.in_transaction,'CALLER_BEGIN_IMMEDIATE_REQUIRED')
    sql=load_schema(schema_bytes,schema_sha256)
    verify_floor(db);before=seal(db)
    need(not (set(before['value']['tables']) & NAMES),'NEW_MIGRATION_ONLY_EXISTING_ANALYTICS_REFUSED_NO_REPLAY')
    db.execute('SAVEPOINT palitra_unified_install_v1')
    try:
        for name,statement in sql:db.execute(statement)
        db.execute('INSERT INTO '+META+'(company_code,started_at) VALUES(?,?)',('palitra-love',started_at))
        after=seal(db);added=set(after['value']['tables'])-set(before['value']['tables'])
        need(added==NAMES,'EXACT_FIVE_ADDITIVE_TABLES_REQUIRED')
        for name in NAMES:
            count=db.execute('SELECT count(*) FROM '+name).fetchone()[0]
            need(count==(1 if name==META else 0),'ONLY_STARTED_AT_ROW_ALLOWED')
        need(db.execute('SELECT company_code,started_at FROM '+META).fetchall()==[('palitra-love',started_at)],'EXACT_ONE_STARTED_AT_ROW_REQUIRED')
        need(verify_admission()==admission,'LATE_MIGRATION_ADMISSION_CHANGED')
        # Final full comparison includes ALL current control and business rows,
        # even changes attempted by a late admission hook. No volatile whitelist.
        protected=seal(db,NAMES)
        need(protected==before,'OLD_CURRENT_SCHEMA_OR_BUSINESS_ROWS_CHANGED')
        need(seal(db)==after,'MIGRATION_RESULT_CHANGED_BEFORE_RELEASE')
        db.execute('RELEASE palitra_unified_install_v1')
        return {'schema':'palitra-unified-explicit-migration-result/v2','status':'SCHEMA_PREPARED_IN_CALLER_TRANSACTION_NOT_COMMITTED','basisMode':BASIS_MODE,'historicalContentSha256':historical_content_sha256,'currentRawBeforeSha256':before['sha256'],'lockedAfterRawSha256':after['sha256'],'protectedCurrentRawSha256':protected['sha256'],'tablesAdded':sorted(NAMES),'rowsAdded':{META:1},'startedAt':started_at,'oldBusinessRowsChanged':0,'callerMustVerifyAndCommit':True}
    except BaseException:
        db.execute('ROLLBACK TO palitra_unified_install_v1');db.execute('RELEASE palitra_unified_install_v1');raise

def consistent_backup(source,private_directory,*,expected_before_sha256,read_gate):
    """Content backup only; the inherited framework must also back up report/traffic.

    Source is an already opened connection in a consistent read transaction.
    This primitive creates a NEW private backup; never restores a live DB.
    """
    need(callable(read_gate),'FRESH_NATIVE_READ_GATE_REQUIRED');token=read_gate()
    need(source.execute('PRAGMA query_only').fetchone()[0]==1,'READONLY_QUERY_ONLY_BACKUP_SOURCE_REQUIRED')
    need(seal(source)['sha256']==expected_before_sha256,'EXACT_CURRENT_BACKUP_BASIS_REQUIRED')
    root=Path(private_directory)
    for p in [root,*root.parents]:need(not p.is_symlink(),'BACKUP_PATH_ALIAS_REFUSED')
    s=root.lstat();need(stat.S_ISDIR(s.st_mode) and s.st_nlink>=1,'PRECREATED_PRIVATE_BACKUP_DIRECTORY_REQUIRED')
    if os.name=='posix':need(s.st_uid==s.st_gid==0 and stat.S_IMODE(s.st_mode)==0o700,'PRIVATE_ROOT_BACKUP_DIRECTORY_REQUIRED')
    target=root/'content-before.sqlite';fd=os.open(target,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600);os.close(fd)
    try:
        destination=sqlite3.connect(target)
        try:source.backup(destination);need(destination.execute('PRAGMA quick_check').fetchall()==[('ok',)],'BACKUP_QUICK_CHECK_FAILED')
        finally:destination.close()
        # journal_mode is connection/backup storage format, not business data;
        # clone is sealed using its own immutable file facts as well.
        clone=sqlite3.connect('file:'+target.as_posix()+'?mode=ro',uri=True);clone.execute('PRAGMA query_only=ON');clone.execute('BEGIN')
        try:
            a=seal(source)['value'];b=seal(clone)['value'];a={**a,'pragmas':{k:v for k,v in a['pragmas'].items() if k!='journal_mode'}};b={**b,'pragmas':{k:v for k,v in b['pragmas'].items() if k!='journal_mode'}}
            need(a==b,'CONSISTENT_BACKUP_FULL_CONTENT_MISMATCH')
        finally:clone.rollback();clone.close()
        need(read_gate()==token and seal(source)['sha256']==expected_before_sha256,'BACKUP_BOUNDARY_CHANGED')
        raw=target.read_bytes();st=target.lstat()
        need(stat.S_ISREG(st.st_mode) and not target.is_symlink() and st.st_nlink==1,'PRIVATE_BACKUP_REGULAR_FILE_REQUIRED')
        if os.name=='posix':need(st.st_uid==st.st_gid==0 and stat.S_IMODE(st.st_mode)==0o600,'PRIVATE_ROOT_BACKUP_FILE_REQUIRED')
        return {'status':'CONSISTENT_PRIVATE_CONTENT_BACKUP_NOT_INSTALL_AUTHORIZATION','sha256':sha(raw),'bytes':len(raw),'contentSha256':expected_before_sha256,'runtimeRestores':0}
    except BaseException:
        # Keep a failed/unknown backup for forensic review; never retry this path.
        raise
