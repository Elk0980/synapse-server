"""Separate fresh Root save action; one original native workspace service call.

This entry never builds, migrates, restarts, grants access or publishes static.
Successful save is NOT public readback or whole-app acceptance. Never replay an
existing/unknown save directory. Root owns both the lease and final receipt.
"""
import argparse,json,os,re,stat,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
from native_entry import load_package,ROOT,NAME,need,sha
from manifest_inputs import read_pin
from install_protocol import Admission,require_native_plan,validate_bindings
from private_files import PrivateFiles,encoded,exact,read
from forward_guard import load_inspector
DATA=Path('/var/lib/docker/volumes/synapse_content_data/_data')

def main(argv=None):
    p=argparse.ArgumentParser();p.add_argument('--manifest-sha',required=True);p.add_argument('--action',type=Path,required=True);p.add_argument('--action-sha',required=True);a=p.parse_args(argv)
    directory=Path(__file__).resolve().parent;package,manifest=load_package(directory,a.manifest_sha)
    action=Admission({'path':str(a.action),'sha256':a.action_sha},a.manifest_sha,'save');auth=action.check();binding=auth['bindings'];validate_bindings('save',binding)
    def private_json(ref):
        target=exact(ref['path']);s=target.lstat();need(ROOT in target.parents and target.suffix=='.json' and s.st_uid==s.st_gid==0 and stat.S_IMODE(s.st_mode)==0o600,'ROOT600_PRIVATE_SAVE_PROOF_REQUIRED');return read_pin(ref,json_document=True)
    plan=private_json(binding['managedAdoptionPlan']);require_native_plan(plan,package);need(plan['transport']=='native-workspace-service','SERVICE_TRANSPORT_REQUIRED')
    pending=private_json(binding['pendingNativeAdoption'])
    need(pending.get('schema')=='palitra-unified-pending-native-adoption/v1' and pending.get('status')=='RUNTIME_CODE_SCHEMA_READY_REQUIRES_NATIVE_WORKSPACE_ADOPTION' and pending.get('packageSha256')==a.manifest_sha and pending.get('mapSha256')==package['map']['closureSha256'] and pending.get('runtimeAcceptance') is False and sha(encoded(pending))==binding['pendingNativeAdoptionSha256'],'EXACT_COMPLETED_APPLY_REQUIRED_BEFORE_NATIVE_SAVE')
    need(pending.get('managedAdoptionPlanSha256')==binding['managedAdoptionPlan']['sha256'] and pending.get('managedAdoptionTransport')=='native-workspace-service' and pending.get('managedAdoptionBaseRevision')==plan['baseRevision'],'SAME_EXACT_SERVICE_PLAN_REQUIRED')
    need(pending['child'].get('oneCopyLayer') is True and re.fullmatch('sha256:[a-f0-9]{64}',pending['child'].get('image','')) and pending.get('migration',{}).get('nativeCommitStatus')=='SCHEMA_COMMITTED_WITH_PROTECTED_CONTENT_PRESERVED','APPLIED_CHILD_AND_SCHEMA_RECEIPT_REQUIRED')
    need(binding['compatibilityInspectorManifestSha256']==package['compatibilityInspectorManifest']['sha256'],'SAVE_INSPECTOR_PIN_CHANGED')
    inspector_path=Path(binding['inspectorDirectory']);need(inspector_path.parent==ROOT,'EXACT_SAVE_INSPECTOR_DIRECTORY_REQUIRED');inspector,pins=load_inspector(inspector_path,binding['compatibilityInspectorManifestSha256'])
    old=read_pin({'path':str(inspector.MANAGED_PATH),'sha256':inspector.C.MANAGED_SHA},json_document=True)
    need(plan['baseRevision']==old['current260']['revision'],'EXACT_CURRENT260_SAVE_BASE_REQUIRED')
    def gate():
        action.check();load_package(directory,a.manifest_sha);need(inspector.M.lease(auth['lease']['pid'])==auth['lease']['startTicks'],'FRESH_NATIVE_SAVE_LEASE_CHANGED')
        for ref in binding.values():
            if type(ref) is dict and set(ref)=={'path','sha256'}:private_json(ref)
        r=subprocess.run(['docker','inspect','--format','{{.Image}}','synapse-content-1'],capture_output=True,timeout=20)
        need(r.returncode==0 and not r.stderr and r.stdout.decode().strip()==pending['child']['image'],'EXACT_APPLIED_CHILD_MUST_SERVE_NATIVE_SAVE')
    gate();area=ROOT/(NAME+'-save');data_area=DATA/(NAME+'-save');need(not area.exists() and not data_area.exists(),'SAVE_ATTEMPT_EXISTS_NO_REPLAY');area.mkdir(mode=0o700);private=PrivateFiles(area)
    payloads={}
    for index,row in enumerate(package['map']['managedRecords']):
        raw=read(directory/'native-adoption'/str(index));need(sha(raw)==row['input']['sha256'] and len(raw)<=2*1024*1024,'EXACT_THREE_STAGED_SAVE_BYTES_REQUIRED');text=raw.decode('utf-8');need(text.encode()==raw,'LOSSLESS_UTF8_SAVE_REQUIRED');payloads[row['managedPath']]=text
    probe=read(directory/'native-adoption-probe.cjs');script=read(directory/'native-workspace-service.cjs')
    input={'schema':'palitra-unified-native-service-input/v1','namespace':NAME,'packageSha256':a.manifest_sha,'planSha256':binding['managedAdoptionPlan']['sha256'],'pendingSha256':binding['pendingNativeAdoptionSha256'],'action':auth,'old':old,'plan':plan,'payloads':payloads,'probeSource':probe.decode(),'probeSha256':sha(probe)}
    raw=encoded(input);need(len(raw)<=9*1024*1024,'BOUNDED_NATIVE_SAVE_INPUT');gate()
    private.json(area/'SAVE_STARTED.json',{'status':'STARTED_UNKNOWN_NO_RETRY','transport':'native-workspace-service','rootActionSha256':a.action_sha,'packageSha256':a.manifest_sha,'automaticRetry':False,'automaticRestore':False})
    invocation=script.decode()+"\nlet raw=fs.readFileSync(0);need(raw.length<=9*1024*1024,'SERVICE_INPUT_BOUND');run(JSON.parse(raw)).then(v=>process.stdout.write(JSON.stringify(v))).catch(e=>{process.stdout.write(JSON.stringify({status:'REFUSED_OR_UNKNOWN_NO_AUTOMATIC_RETRY',code:/^[A-Z][A-Z0-9_]{0,120}$/.test(e.message)?e.message:e.name}));process.exitCode=2;});"
    # STARTED precedes the only invocation. Unknown completion is never retried.
    result=subprocess.run(['docker','exec','-i','synapse-content-1','node','--disable-warning=ExperimentalWarning','-e',invocation],input=raw,capture_output=True,timeout=300)
    private.json(area/'NATIVE_CALL_META.json',{'returncode':result.returncode,'stdoutSha256':sha(result.stdout),'stderrSha256':sha(result.stderr),'automaticRetry':False})
    need(result.returncode==0 and not result.stderr and len(result.stdout)<=32768,'NATIVE_SAVE_REFUSED_OR_UNKNOWN_NO_RETRY');value=json.loads(result.stdout)
    need(value.get('status')=='NATIVE_SERVICE_SAVED_REQUIRES_ROOT_PUBLIC_READBACK' and value.get('runtimeAcceptance') is False and value.get('currentVersion')==261,'NATIVE_SERVICE_SAVE_OUTCOME_REQUIRED');gate()
    def data_ref(ref,name,limit):
        need(type(ref) is dict and set(ref)=={'path','sha256'} and ref['path']=='/data/'+NAME+'-save/'+name,'EXACT_NATIVE_PRIVATE_SAVE_REFERENCE');target=data_area/name;s=exact(target).lstat();need(s.st_uid==s.st_gid==0 and stat.S_IMODE(s.st_mode)==0o600 and sha(read(target,limit))==ref['sha256'],'EXACT_NATIVE_SAVE_PRIVATE_RESULT_REQUIRED');return {'path':str(target),'sha256':ref['sha256']}
    outcome_ref=data_ref(value['outcome'],'NATIVE_SAVE_OUTCOME.json',4*1024*1024);backup_ref=data_ref(value['backup'],'content.sqlite',256*1024*1024);outcome=json.loads(read(outcome_ref['path']))
    need(outcome['packageSha256']==a.manifest_sha and outcome['planSha256']==binding['managedAdoptionPlan']['sha256'] and outcome['pendingSha256']==binding['pendingNativeAdoptionSha256'] and outcome['full141FactsSha256']==value['full141FactsSha256'],'EXACT_NATIVE_SAVE_RESULT_BINDINGS');private.guard();gate()
    proof={**value,'outcome':outcome_ref,'backup':backup_ref,'transport':'native-workspace-service','rootActionSha256':a.action_sha,'packageSha256':a.manifest_sha,'automaticRetry':False,'automaticRestore':False,'runtimeAcceptance':False}
    private.json(area/'SAVED_REQUIRES_PUBLIC_READBACK.json',proof);print(json.dumps(proof));return 0

if __name__=='__main__':
    try:raise SystemExit(main())
    except Exception as e:print(json.dumps({'status':'REFUSED_OR_UNKNOWN_NO_AUTOMATIC_RETRY','code':str(e) if type(e) is ValueError and re.fullmatch('[A-Z][A-Z0-9_]{0,120}',str(e)) else type(e).__name__,'automaticRetry':False,'automaticRestore':False}));raise SystemExit(2)
