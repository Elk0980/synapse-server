"""Fail-closed order model for the future pinned native adapter. No defaults.

This model executes injected test/native interface only; this draft provides no
native writer adapter and no apply CLI. Unknown step never replays or rolls back.
"""
ORDER=('fresh_lease_queue','full_post_cleanup_basis','verify_managed_native_import_contract','private_consistent_backups','build_one_copy_child','verify_child_full_tree','begin_content_immediate','last_full_runtime_cas','explicit_five_table_migration','verify_full_business_preservation','commit_schema','one_content_up','managed_native_adoption','private_static_atomic_publish','full_installed_readback','public_current_and_old_query_readback','old_new_open_session_acceptance')
def run_reviewed_plan(adapter,*,enabled=False):
    if enabled is not True:raise ValueError('DRAFT_DISABLED_EXPLICIT_ENABLE_REQUIRED')
    if adapter is None:raise ValueError('EXACT_NATIVE_ADAPTER_NOT_AVAILABLE')
    completed=[]
    for name in ORDER:
        adapter.assert_fresh_admission_and_lease()
        adapter.write_exclusive_or_phase_unknown(name,tuple(completed))
        # Missing operation raises; an UNKNOWN marker remains and prohibits replay.
        result=getattr(adapter,name)()
        adapter.record_verified_step(name,result)
        completed.append(name)
    return {'status':'MODEL_COMPLETED_REQUIRES_ACTUAL_NATIVE_PROOF','completed':completed,'automaticRetry':False,'automaticRollback':False}

def rollback_contract():
    return {'automatic':False,'codeOnly':True,'dropNewTables':False,'restoreOldLiveDatabase':False,'preserveStartedAt':True,'preserveUnreadMarkers':True,'preserveStatistics':True,'separateFreshRootReviewRequired':True}
