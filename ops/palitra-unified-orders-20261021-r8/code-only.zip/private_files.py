"""Bounded exact private files and atomic static replacement. No service calls."""
import hashlib,json,os,stat
from pathlib import Path
from manifest_inputs import need,digest,NAMESPACE
sha=lambda b:hashlib.sha256(b).hexdigest()
encoded=lambda v:json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()

def exact(path,missing=False):
    p=Path(path);need(p.is_absolute(),'ABSOLUTE_NATIVE_PATH_REQUIRED')
    for x in [p,*p.parents]:need(not x.is_symlink(),'NATIVE_PATH_ALIAS_REFUSED')
    if not missing:need(p.exists(),'EXISTING_NATIVE_PATH_REQUIRED')
    return p
def root_owned(s):
    if os.name=='posix':need(s.st_uid==s.st_gid==0,'ROOT_OWNED_NATIVE_FILE_REQUIRED')
def identity(s):return [s.st_dev,s.st_ino,s.st_uid,s.st_gid,stat.S_IMODE(s.st_mode),s.st_size,s.st_mtime_ns,s.st_ctime_ns]
def read_identity(s):
    value=identity(s)
    # NTFS exposes creation-time caching differently for lstat and an open fd.
    # Local Windows tests retain inode/mode/mtime/size checks; native entry is
    # Linux-only, where the full ctime predicate below remains mandatory.
    return value[:-1] if os.name=='nt' else value
def read(path,limit=16*1024*1024):
    p=exact(path);s=p.lstat();root_owned(s)
    need(stat.S_ISREG(s.st_mode) and s.st_nlink==1 and s.st_size<=limit,'BOUNDED_SINGLE_LINK_FILE_REQUIRED')
    fd=os.open(p,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0))
    try:
        with os.fdopen(fd,'rb',closefd=False) as f:raw=f.read(limit+1)
        need(read_identity(s)==read_identity(os.fstat(fd))==read_identity(p.lstat()) and len(raw)==s.st_size,'FILE_CHANGED_DURING_NATIVE_READ')
    finally:os.close(fd)
    return raw
def sync(path):
    if os.name!='posix':return
    fd=os.open(path,os.O_RDONLY|getattr(os,'O_DIRECTORY',0))
    try:os.fsync(fd)
    finally:os.close(fd)

class PrivateFiles:
    def __init__(self,root):
        self.root=exact(root);s=self.root.lstat();root_owned(s)
        need(stat.S_ISDIR(s.st_mode) and (os.name!='posix' or stat.S_IMODE(s.st_mode)==0o700),'PRIVATE_ROOT_DIRECTORY_REQUIRED')
        self.root_identity=identity(s)[:5]
    def guard(self):
        s=exact(self.root).lstat();need(identity(s)[:5]==self.root_identity,'PRIVATE_DIRECTORY_REPLACED')
    def path(self,path,missing=False):
        self.guard();p=exact(path,missing);need(p!=self.root and self.root in p.parents,'OWN_PRIVATE_NAMESPACE_ONLY');return p
    @staticmethod
    def mode(path):return stat.S_IMODE(exact(path).lstat().st_mode)
    def mkdir(self,path,mode=0o700):
        p=self.path(path,True);need(mode in (0o700,0o755) and p.parent.exists(),'EXACT_NEW_PRIVATE_DIRECTORY_REQUIRED')
        p.mkdir(mode=mode);root_owned(p.lstat());sync(p.parent)
    def write(self,path,raw,mode=0o600):
        p=self.path(path,True);need(type(raw) is bytes and len(raw)<=32*1024*1024 and mode in (0o600,0o644),'EXACT_BOUNDED_PRIVATE_WRITE_REQUIRED')
        fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|getattr(os,'O_NOFOLLOW',0),mode)
        try:
            with os.fdopen(fd,'wb',closefd=False) as f:f.write(raw);f.flush();os.fsync(f.fileno())
            need(os.fstat(fd).st_nlink==1,'NEW_PRIVATE_FILE_SINGLE_LINK_REQUIRED')
        finally:os.close(fd)
        sync(p.parent);need(read(p,32*1024*1024)==raw,'EXACT_PRIVATE_WRITE_READBACK_REQUIRED');return p
    def json(self,path,value):return self.write(path,encoded(value))

class SealedBackupSource:
    """Read-only handle to one exact accepted apply directory. No writer API."""
    def __init__(self,root,expected_identity):
        self.root=exact(root);need(type(expected_identity) is list and len(expected_identity)==5,'EXACT_SEALED_BACKUP_DIRECTORY_IDENTITY_REQUIRED');self.identity=list(expected_identity);self.guard()
    def guard(self):
        s=exact(self.root).lstat();root_owned(s)
        need(stat.S_ISDIR(s.st_mode) and identity(s)[:5]==self.identity and (os.name!='posix' or stat.S_IMODE(s.st_mode)==0o700),'SEALED_APPLY_BACKUP_DIRECTORY_REPLACED')
    def path(self,path):
        self.guard();p=exact(path);need(p.parent==self.root,'ONLY_EXACT_SEALED_BACKUP_DIRECTORY_ALLOWED');s=p.lstat();root_owned(s)
        need(stat.S_ISREG(s.st_mode) and s.st_nlink==1 and (os.name!='posix' or stat.S_IMODE(s.st_mode)==0o600),'ROOT600_SEALED_BACKUP_REQUIRED');return p

class StaticFiles:
    def __init__(self,private,records,lease):
        need(callable(lease),'STATIC_LEASE_GUARD_REQUIRED');self.private=private;self.lease=lease
        self.records={r['target']:r for r in records};need(len(self.records)==len(records),'UNIQUE_STATIC_TARGETS_REQUIRED')
        for target,row in self.records.items():
            need(target.startswith('/opt/synapse/sites/') and '..' not in Path(target).parts and digest(row['beforeSha256']) and digest(row['sha256']) and row['mode'] in (0o600,0o644),'EXACT_EXISTING_STATIC_RECORD_REQUIRED')
        self.backups={};self.published=set();self.backup_source=private
    def bind_sealed_backups(self,source_root,directory_identity,backups):
        need(not self.backups and not self.published,'FRESH_FINISH_BACKUP_BINDING_REQUIRED')
        source=SealedBackupSource(source_root,directory_identity)
        need(type(backups) is dict and set(backups)==set(self.records),'EXACT_SEALED_STATIC_BACKUP_DOMAIN_REQUIRED')
        for index,target in enumerate(sorted(self.records)):
            row=backups[target];expected=source.root/('static-'+str(index)+'.before')
            need(type(row) is dict and set(row)=={'path','sha256','identity'} and Path(row['path'])==expected and row['sha256']==self.records[target]['beforeSha256'] and type(row['identity']) is list and len(row['identity'])==8,'EXACT_SEALED_APPLY_STATIC_BACKUP_REQUIRED')
            need(sha(read(source.path(expected)))==row['sha256'],'SEALED_APPLY_BACKUP_BYTES_CHANGED')
        source.guard();self.backup_source=source;self.backups=backups;self.backup_guard()
    def facts(self,target,pin):
        p=exact(target);s=p.lstat();root_owned(s)
        need(stat.S_ISREG(s.st_mode) and s.st_nlink==1 and stat.S_IMODE(s.st_mode)==self.records[target]['mode'] and sha(read(p))==pin,'EXACT_STATIC_BYTES_MODE_REQUIRED')
        return identity(s)
    def backup(self):
        self.lease();need(not self.backups,'ONE_STATIC_BACKUP_GENERATION_REQUIRED')
        for index,(target,row) in enumerate(sorted(self.records.items())):
            ident=self.facts(target,row['beforeSha256']);raw=read(target);name='static-'+str(index)+'.before'
            self.private.write(self.private.root/name,raw)
            need(self.facts(target,row['beforeSha256'])==ident,'STATIC_CHANGED_DURING_BACKUP')
            self.backups[target]={'path':str(self.private.root/name),'sha256':sha(raw),'identity':ident}
        self.lease();return self.backups
    def backup_guard(self):
        need(set(self.backups)==set(self.records),'EXACT_STATIC_BACKUP_COVERAGE_REQUIRED')
        for row in self.backups.values():need(sha(read(self.backup_source.path(row['path'])))==row['sha256'],'STATIC_BACKUP_CHANGED')
        self.backup_source.guard()
    def publish(self,target,payload):
        self.lease();self.backup_guard();need(target in self.records and target not in self.published,'ONE_EXACT_STATIC_PUBLICATION_REQUIRED')
        row=self.records[target];need(type(payload) is bytes and len(payload)==row['bytes'] and sha(payload)==row['sha256'],'EXACT_REVIEWED_STATIC_PAYLOAD_REQUIRED')
        need(self.facts(target,row['beforeSha256'])==self.backups[target]['identity'],'STATIC_CHANGED_BEFORE_PUBLICATION')
        p=exact(target);temporary=p.with_name('.'+p.name+'.'+NAMESPACE+'.pending')
        fd=os.open(exact(temporary,True),os.O_CREAT|os.O_EXCL|os.O_WRONLY|getattr(os,'O_NOFOLLOW',0),row['mode'])
        try:
            with os.fdopen(fd,'wb',closefd=False) as f:f.write(payload);f.flush();os.fsync(f.fileno())
        finally:os.close(fd)
        need(sha(read(temporary))==row['sha256'] and stat.S_IMODE(temporary.lstat().st_mode)==row['mode'],'EXACT_PENDING_STATIC_REQUIRED')
        self.lease();need(self.facts(target,row['beforeSha256'])==self.backups[target]['identity'],'LATE_STATIC_CHANGED_BEFORE_REPLACE')
        os.replace(temporary,p);sync(p.parent);self.published.add(target);self.facts(target,row['sha256']);self.lease()
