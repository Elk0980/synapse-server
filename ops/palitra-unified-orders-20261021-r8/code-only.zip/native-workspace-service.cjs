'use strict';
// One official store.save call. No HTTP, auth grants, SQL business writer,
// manual version writes, retry, restore, or public-acceptance claim.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {performance}=require('node:perf_hooks');
const SITE='site-44bbe13f1bad5e005b2a',COMPANY='palitra-love',NS='palitra-unified-orders-20261021-r8';
const STORE='a28a415413a831ab9d1d4f2fa4655f00971f4ce7d88f2681077119401d4a1b96';
const AUTH='b0dde548b7f252591858607604708d4d96847968e90f0147a50881c6a9ca074a';
const PRICE='79d62dd78fc00347758c248a2b733e407bdacccf6094fe0a8f3e69f01c7a5943';
const NAMES=['assets/order.js','assets/palitra-attribution.js','assets/storefront.js'];
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const need=(v,c)=>{if(!v)throw Error(c);};
function canonical(v){
  if(typeof v==='bigint')return '{"__sqlite_bigint__":'+JSON.stringify(v.toString())+'}';
  if(v instanceof Uint8Array)return '{"__sqlite_blob_hex__":'+JSON.stringify(Buffer.from(v).toString('hex'))+'}';
  return Array.isArray(v)?'['+v.map(canonical).join(',')+']':v&&typeof v==='object'?'{'+Object.keys(v).sort().map(k=>JSON.stringify(k)+':'+canonical(v[k])).join(',')+'}':JSON.stringify(v);
}
const same=(a,b,c)=>need(canonical(a)===canonical(b),c);
function safe(p,missing=false){
  need(path.isAbsolute(p)&&path.normalize(p)===p,'CANONICAL_NATIVE_PATH_REQUIRED');
  for(let q=missing?path.dirname(p):p;;q=path.dirname(q)){const s=fs.lstatSync(q);need(!s.isSymbolicLink()&&s.uid===0&&s.gid===0,'ROOT_NATIVE_PATH_REQUIRED');if(q===path.dirname(q))break;}
  return p;
}
function read(p,limit=32*1024*1024){
  safe(p);const a=fs.lstatSync(p);need(a.isFile()&&a.nlink===1&&a.size<=limit,'REGULAR_BOUNDED_NATIVE_FILE');
  const fd=fs.openSync(p,fs.constants.O_RDONLY|fs.constants.O_NOFOLLOW|fs.constants.O_NONBLOCK);
  try{const b=fs.fstatSync(fd),raw=fs.readFileSync(fd),z=fs.fstatSync(fd),q=fs.lstatSync(p);for(const k of ['dev','ino','uid','gid','mode','size','nlink','mtimeMs','ctimeMs'])need(a[k]===b[k]&&a[k]===z[k]&&a[k]===q[k],'NATIVE_READ_RACE');need(raw.length===a.size,'NATIVE_READ_SIZE');return raw;}finally{fs.closeSync(fd);}
}
function write(root,name,value){
  const raw=Buffer.from(canonical(value)),p=path.join(root,name);need(raw.length<=4*1024*1024&&path.dirname(p)===root,'PRIVATE_SMALL_PROOF_ONLY');
  const fd=fs.openSync(safe(p,true),fs.constants.O_WRONLY|fs.constants.O_CREAT|fs.constants.O_EXCL|fs.constants.O_NOFOLLOW,0o600);
  try{fs.writeFileSync(fd,raw);fs.fsyncSync(fd);}finally{fs.closeSync(fd);}
  need(read(p).equals(raw),'PRIVATE_PROOF_READBACK');return {path:p,sha256:sha(raw)};
}
function checkInput(input){
  need(input&&input.schema==='palitra-unified-native-service-input/v1'&&input.namespace===NS,'EXACT_SERVICE_INPUT');
  const {plan,old,action,payloads}=input;
  need(plan.transport==='native-workspace-service'&&plan.status==='ROOT_REVIEWED_NATIVE_SERVICE_PLAN_NOT_PUBLICATION'&&plan.serviceMethod==='originalWorkspaceStore.save'&&plan.serviceSourceSha256===STORE&&plan.saveCalls===1&&plan.existingOwnerLogin==='vladislav'&&plan.existingPermission==='site_editor.edit'&&plan.runtimeAuthorization===false&&plan.parentVersion===260&&plan.rawRuntimeFileWrites===0&&plan.priceUnchanged===true,'EXACT_SERVICE_PLAN');
  same(Object.keys(plan.changedFiles).sort(),NAMES,'EXACT_THREE_SERVICE_INPUTS');same(Object.keys(payloads).sort(),NAMES,'EXACT_THREE_PAYLOADS');
  need(plan.baseRevision===old.current260.revision&&old.current260.version===260&&old.current260.fileCount===140&&old.current260.mismatches.length===0,'EXACT_SERVICE_BASE260');
  same(plan.newTrackerMetadata,{uid:0,gid:0,mode:0o600,nlink:1,regular:true,canonical:true},'HONEST_NATIVE_SERVICE600_METADATA');
  need(old.current260.files['data/price.json'].sha256===PRICE,'EXACT_PRICE');
  // Original store.save creates every copied file0600/directory0700. Refuse
  // incompatible metadata BEFORE any write instead of chmodding old versions.
  need(Object.values(old.current260.files).every(v=>v.uid===0&&v.gid===0&&v.mode===0o600&&v.nlink===1&&v.regular===true&&v.canonical===true),'STORE_CANNOT_PRESERVE_EXISTING_FILE_METADATA');
  need(Object.values(old.current260.directories).every(v=>v.uid===0&&v.gid===0&&v.mode===0o700),'STORE_CANNOT_PRESERVE_EXISTING_DIRECTORY_METADATA');
  let total=0;const files=NAMES.map(name=>{const content=payloads[name];need(typeof content==='string'&&!content.includes('\u0000'),'TEXT_SERVICE_PAYLOAD');const raw=Buffer.from(content);need(raw.length>0&&raw.length<=2*1024*1024&&(total+=raw.length)<=8*1024*1024&&sha(raw)===plan.changedFiles[name],'EXACT_REVIEWED_SERVICE_BYTES');return {path:name,content};});
  need(action.mode==='save'&&action.namespace===NS&&action.status==='ROOT_AUTHORIZED_ONE_ATTEMPT'&&action.runtimeAuthorization===true&&action.packageSha256===input.packageSha256&&action.bindings.managedAdoptionPlan.sha256===input.planSha256&&action.bindings.pendingNativeAdoptionSha256===input.pendingSha256,'EXACT_SERVICE_ROOT_ACTION');
  need(action.createdAtUnix<=Date.now()/1000&&Date.now()/1000<action.expiresAtUnix&&action.expiresAtUnix-action.createdAtUnix<=1800,'FRESH_SERVICE_ROOT_ACTION');
  return files;
}
function sqlRowHash(row){
  const typed={};
  for(const [name,value] of Object.entries(row)){
    if(value===null)typed[name]=['null'];
    else if(typeof value==='bigint')typed[name]=['integer',value.toString()];
    else if(typeof value==='number'){
      const bits=Buffer.alloc(8);bits.writeDoubleBE(value);typed[name]=['real64',bits.toString('hex')];
    }else if(typeof value==='string')typed[name]=['text',value];
    else if(value instanceof Uint8Array)typed[name]=['blob',Buffer.from(value).toString('hex')];
    else throw Error('EXACT_SQLITE_TYPED_VALUE_REQUIRED');
  }
  return sha(canonical(typed));
}
function databaseFacts(db){
  const schema=db.prepare("SELECT type,name,tbl_name,sql FROM sqlite_master WHERE sql IS NOT NULL ORDER BY type,name").all();
  const tables={};let count=0;
  for(const r of schema.filter(r=>r.type==='table')){
    const hashes=[];const q='SELECT * FROM "'+r.name.replaceAll('"','""')+'"';const st=db.prepare(q);st.setReadBigInts(true);
    for(const row of st.iterate()){need(++count<=2000000,'DATABASE_ROW_BOUND');hashes.push(sqlRowHash(row));}
    hashes.sort();tables[r.name]={count:hashes.length,sha256:sha(canonical(hashes)),hashes};
  }
  const seq=tables.sqlite_sequence?db.prepare('SELECT name,seq FROM sqlite_sequence ORDER BY name'):null;
  if(seq)seq.setReadBigInts(true);const sequenceRows=seq?seq.all():[];
  return {schemaSha256:sha(canonical(schema)),tables,sequenceRows};
}
function checkDatabaseDelta(before,after,db,user,revision){
  same(before.schemaSha256,after.schemaSha256,'SERVICE_SCHEMA_CHANGED');same(Object.keys(before.tables).sort(),Object.keys(after.tables).sort(),'SERVICE_TABLE_SET_CHANGED');
  const mutable=new Set(['managed_sites','site_workspaces','site_workspace_revisions','sqlite_sequence']);const changed=[];
  for(const name of Object.keys(before.tables))if(!mutable.has(name)&&before.tables[name].sha256!==after.tables[name].sha256)changed.push(name);
  need(changed.length===1,'ONLY_ONE_NATIVE_AUDIT_APPEND_ALLOWED');
  const table=changed[0],a=before.tables[table],b=after.tables[table];need(b.count===a.count+1,'NATIVE_AUDIT_APPEND_COUNT');
  const old=new Map();for(const h of a.hashes)old.set(h,(old.get(h)||0)+1);let extra;
  const st=db.prepare('SELECT * FROM "'+table.replaceAll('"','""')+'"');st.setReadBigInts(true);
  for(const row of st.iterate()){const h=sqlRowHash(row);if(old.get(h)){old.set(h,old.get(h)-1);continue;}need(!extra,'ONLY_ONE_NATIVE_AUDIT_ROW');extra=row;}
  need([...old.values()].every(v=>v===0)&&extra,'NATIVE_AUDIT_OLD_ROWS_PRESERVED');
  const values=Object.values(extra);need(values.includes('SITE_FILES_SAVED')&&values.some(v=>v===BigInt(user.id)),'ACTUAL_NATIVE_AUDIT_ACTOR_ACTION');
  const expected={siteId:SITE,companyCode:COMPANY,revision,files:NAMES};
  need(values.some(v=>{if(typeof v!=='string')return false;try{return canonical(JSON.parse(v))===canonical(expected);}catch{return false;}}),'ACTUAL_NATIVE_AUDIT_EXACT_THREE_PATHS');
  const oldSeq=new Map(before.sequenceRows.map(r=>[r.name,r.seq])),newSeq=new Map(after.sequenceRows.map(r=>[r.name,r.seq]));
  need(oldSeq.size===before.sequenceRows.length&&newSeq.size===after.sequenceRows.length,'DUPLICATE_SQLITE_SEQUENCE_NAME_REFUSED');
  const sequenceNames=new Set([...oldSeq.keys(),...newSeq.keys()]);
  for(const name of sequenceNames){
    if(name!==table){same(oldSeq.get(name),newSeq.get(name),'UNRELATED_SQLITE_SEQUENCE_CHANGED');continue;}
    if(oldSeq.get(name)===newSeq.get(name))continue;
    const pk=db.prepare('PRAGMA table_info("'+table.replaceAll('"','""')+'")').all().filter(r=>r.pk);
    need(pk.length===1&&pk[0].type.toUpperCase()==='INTEGER','NATIVE_AUDIT_INTEGER_PK_REQUIRED');
    const id=extra[pk[0].name],oldValue=oldSeq.get(name),newValue=newSeq.get(name);
    need(typeof id==='bigint'&&typeof newValue==='bigint'&&newValue===id&&(oldValue===undefined||typeof oldValue==='bigint'&&oldValue<id),'ONLY_EXACT_NATIVE_AUDIT_SEQUENCE_ADVANCE');
  }
  return {schemaUnchanged:true,protectedTablesUnchanged:true,allCurrentControlRowsProtected:true,auditRowsAdded:1,auditTableSha256:sha(table),auditAfterSha256:b.sha256};
}
// A caller-side observer of the exact existing synchronous save transaction.
// It forwards each literal control statement unchanged. It does not emulate a
// transaction or alter the original store implementation/business SQL.
function transactionObserver(db,onBegin,onCommit){
  let armed=false,state='UNARMED',begins=0,commits=0,proof;
  const facade={prepare:sql=>db.prepare(sql),exec(sql){
    if(!armed)return db.exec(sql); // constructor executes under query_only.
    if(sql==='BEGIN IMMEDIATE'){
      need(state==='READY'&&begins===0,'NATIVE_SAVE_TRANSACTION_ALREADY_CONSUMED');begins++;state='BEGINNING';
      db.exec(sql);
      try{onBegin();state='LOCKED';return;}catch(e){db.exec('ROLLBACK');state='FAILED';throw e;}
    }
    if(sql==='COMMIT'){
      need(state==='LOCKED'&&commits===0,'EXACT_NATIVE_SAVE_COMMIT_BOUNDARY');
      proof=onCommit();db.exec(sql);commits++;state='COMMITTED';return;
    }
    if(sql==='ROLLBACK'){
      need(state==='LOCKED'||state==='BEGINNING','EXACT_NATIVE_SAVE_ROLLBACK_BOUNDARY');
      const value=db.exec(sql);state='FAILED';return value;
    }
    throw Error('ONLY_ORIGINAL_SAVE_TRANSACTION_CONTROL_ALLOWED');
  }};
  return {db:facade,arm(){need(!armed&&state==='UNARMED','ONE_NATIVE_SAVE_OBSERVER_REQUIRED');armed=true;state='READY';},result(){need(state==='COMMITTED'&&begins===1&&commits===1,'ONE_REAL_NATIVE_COMMITTED_TRANSACTION_REQUIRED');return proof;}};
}
function checkWorkspaceRows(before,rows,user,revision){
  const expected=structuredClone(before),site=expected.managed.find(r=>r.id===SITE),ws=expected.workspaces.find(r=>r.site_id===SITE);
  need(site&&ws,'CURRENT_NATIVE_SITE_ROWS_REQUIRED');site.updated_at=rows.managed.find(r=>r.id===SITE).updated_at;ws.current_revision=revision;
  const added=rows.revisions.filter(r=>r.site_id===SITE&&r.revision===revision);
  need(added.length===1&&added[0].version===261&&added[0].author_id===user.id,'ONE_NATIVE_REVISION_AUTHOR');
  expected.revisions.push(added[0]);expected.revisions.sort((a,b)=>a.site_id.localeCompare(b.site_id)||a.version-b.version);
  same(rows,expected,'ONLY_NATIVE_WORKSPACE_ROWS_MAY_CHANGE');
}
async function run(input){
  const files=checkInput(input);need(process.platform==='linux'&&process.getuid()===0&&process.getgid()===0,'ROOT_LINUX_NATIVE_ONLY');
  need(sha(read('/app/site-workspaces.js',2*1024*1024))===STORE&&sha(read('/app/auth-store.js',2*1024*1024))===AUTH,'ORIGINAL_NATIVE_SERVICE_CODE_REQUIRED');
  const {DatabaseSync,backup}=require('node:sqlite');
  const {createAuthStore,COMPANIES}=require('/app/auth-store.js'),{createWorkspaceStore}=require('/app/site-workspaces.js');
  const probe=input.probeSource;need(typeof probe==='string'&&sha(Buffer.from(probe))===input.probeSha256,'EXACT_READONLY_PROBE_SOURCE');
  // The probe has no entry action; compile its exports in a private module.
  const module={exports:{}};new Function('require','module','exports',probe)(require,module,module.exports);const inspector=module.exports;
  const area='/data/'+NS+'-save';safe('/data');need(!fs.existsSync(area),'SERVICE_ATTEMPT_EXISTS_NO_REPLAY');
  let db=new DatabaseSync(safe('/data/content.sqlite'),{readOnly:true});let backupFacts,baseRow,baseRevision,actor;
  function workspace(db){const row=db.prepare('SELECT m.id,m.company_code,m.publication_status,w.current_revision FROM managed_sites m JOIN site_workspaces w ON w.site_id=m.id WHERE m.id=?').get(SITE);same(row,input.old.workspace,'EXACT_SERVICE_WORKSPACE_POINTER');const rev=db.prepare('SELECT version,manifest_json FROM site_workspace_revisions WHERE site_id=? AND revision=?').get(SITE,row.current_revision);need(rev.version===260&&sha(rev.manifest_json)===input.old.current260.manifestSha256,'EXACT_SERVICE_REVISION260');return {row,rev};}
  function selectedRows(db){return {managed:db.prepare('SELECT * FROM managed_sites ORDER BY id').all(),workspaces:db.prepare('SELECT * FROM site_workspaces ORDER BY site_id').all(),revisions:db.prepare('SELECT * FROM site_workspace_revisions ORDER BY site_id,version').all()};}
  function existingAuth(db){const row=db.prepare('SELECT id FROM auth_users WHERE login=?').get('vladislav');need(row,'ACTUAL_EXISTING_OWNER');const service=createAuthStore(db),user=service.getById(row.id);need(user.login==='vladislav'&&user.role==='owner'&&user.companyCodes.includes(COMPANY)&&user.permissions.includes('site_editor.edit'),'ACTUAL_EXISTING_OWNER_EDIT_PERMISSION');return {service,user};}
  let backupRef;
  try{
    db.exec('BEGIN');const current=workspace(db);baseRow=current.row;baseRevision=current.rev;actor=existingAuth(db).user;
    const actual=inspector.inventory(input.old.current260.root,JSON.parse(current.rev.manifest_json),140);same(actual.files,input.old.current260.files,'EXACT_ALL140_BEFORE_FILES');same(actual.directories,input.old.current260.directories,'EXACT_BEFORE_DIRECTORIES');
    backupFacts=databaseFacts(db);fs.mkdirSync(area,{mode:0o700});safe(area);
    const backupPath=area+'/content.sqlite';const reserved=fs.openSync(safe(backupPath,true),fs.constants.O_WRONLY|fs.constants.O_CREAT|fs.constants.O_EXCL|fs.constants.O_NOFOLLOW,0o600);fs.closeSync(reserved);await backup(db,backupPath);fs.chmodSync(backupPath,0o600);const check=new DatabaseSync(safe(backupPath),{readOnly:true});try{need(check.prepare('PRAGMA quick_check').get().quick_check==='ok','NATIVE_CONSISTENT_BACKUP_REQUIRED');same(databaseFacts(check),backupFacts,'BACKUP_MUST_MATCH_ITS_CONSISTENT_SNAPSHOT');}finally{check.close();}
    backupRef={path:backupPath,sha256:sha(read(backupPath,256*1024*1024))};
    write(area,'BEFORE.json',{schema:'palitra-unified-native-service-before/v1',packageSha256:input.packageSha256,planSha256:input.planSha256,pendingSha256:input.pendingSha256,revision:baseRow.current_revision,version:260,backup:backupRef,databaseFactsSha256:sha(canonical(backupFacts)),files140FactsSha256:actual.factsSha256});
    db.exec('ROLLBACK');
  }finally{db.close();}
  db=new DatabaseSync(safe('/data/content.sqlite'));
  try{
    checkInput(input);workspace(db);
    // Existing constructors are invoked with query_only: only preexisting
    // CREATE IF NOT EXISTS no-ops are possible; hidden auth/config DML refuses.
    db.exec('PRAGMA query_only=ON');
    const {service,user}=existingAuth(db);same(user,actor,'OWNER_OR_PERMISSIONS_CHANGED');
    let lockedBefore,lockedRows,lockedActor,lockedStarted;
    const observer=transactionObserver(db,()=>{
      lockedStarted=performance.now();lockedBefore=databaseFacts(db);lockedRows=selectedRows(db);
      same(lockedBefore.schemaSha256,backupFacts.schemaSha256,'SERVICE_SCHEMA_CHANGED_BEFORE_SAVE');
      workspace(db);lockedActor=existingAuth(db).user;same(lockedActor,user,'FRESH_LOCKED_OWNER_PERMISSIONS_CHANGED');
    },()=>{
      // All reads use the SAME connection while original BEGIN holds its lock.
      const freshActor=existingAuth(db).user;same(freshActor,lockedActor,'FINAL_OWNER_PERMISSIONS_CHANGED');
      const revision=db.prepare('SELECT current_revision FROM site_workspaces WHERE site_id=?').get(SITE).current_revision;
      checkWorkspaceRows(lockedRows,selectedRows(db),user,revision);
      const after=databaseFacts(db),protectedProof=checkDatabaseDelta(lockedBefore,after,db,user,revision);
      need(performance.now()-lockedStarted<=30000,'BOUNDED_NATIVE_SAVE_LOCK_DEADLINE_EXCEEDED');
      return {...protectedProof,basisMode:'LATEST_CURRENT_SNAPSHOT_IN_ORIGINAL_SAVE_TRANSACTION',lockedBeforeDatabaseFactsSha256:sha(canonical(lockedBefore)),lockedAfterDatabaseFactsSha256:sha(canonical(after)),lockMillisecondsBeforeCommit:Math.round(performance.now()-lockedStarted)};
    });
    const store=createWorkspaceStore({db:observer.db,root:'/data/projects',sources:{},companies:COMPANIES,audit:service.audit});
    db.exec('PRAGMA query_only=OFF');observer.arm();
    write(area,'SAVE_STARTED.json',{status:'STARTED_UNKNOWN_NO_RETRY',method:'originalWorkspaceStore.save',transport:'native-workspace-service',packageSha256:input.packageSha256,planSha256:input.planSha256,pendingSha256:input.pendingSha256,baseRevision:baseRow.current_revision,saveCalls:1,automaticRetry:false});
    const saved=store.save(user,SITE,{baseRevision:baseRow.current_revision,files,message:'Палитра: единые заказы, источник клиента и непрочитанные сообщения'});
    need(saved.siteId===SITE&&saved.version===261&&saved.revision!==baseRow.current_revision,'EXACT_ONE_FORWARD_NATIVE_SAVE');
    const protectedProof=observer.result();
    same(existingAuth(db).user,user,'FINAL_OWNER_PERMISSIONS_CHANGED');need(sha(read('/app/site-workspaces.js'))===STORE&&sha(read('/app/auth-store.js'))===AUTH,'FINAL_NATIVE_SERVICE_CODE_CHANGED');
    const readback=inspector.capture({old:input.old,plan:input.plan});need(readback.currentRevision===saved.revision&&readback.currentVersion===261,'EXACT_SERVICE_AND_FRESH_READBACK');
    const outcome={schema:'palitra-unified-native-service-save-outcome/v1',status:'NATIVE_SERVICE_SAVED_REQUIRES_ROOT_PUBLIC_READBACK',transport:'native-workspace-service',serviceMethod:'originalWorkspaceStore.save',saveCalls:1,existingOwner:true,permissionsUnchanged:true,serviceCodeUnchanged:true,baseRevision:baseRow.current_revision,currentRevision:saved.revision,currentVersion:saved.version,packageSha256:input.packageSha256,planSha256:input.planSha256,pendingSha256:input.pendingSha256,filesBefore:140,filesAfter:141,other137Unchanged:true,priceUnchanged:true,rawRuntimeFileWrites:0,changedFiles:input.plan.changedFiles,full141FactsSha256:readback.full141FactsSha256,backup:backupRef,backupSnapshotDatabaseFactsSha256:sha(canonical(backupFacts)),transactionObserver:'readonly-original-exec-boundaries',protectedProof,automaticRetry:false,automaticRestore:false,runtimeAcceptance:false};
    const ref=write(area,'NATIVE_SAVE_OUTCOME.json',outcome);return {status:outcome.status,outcome:ref,backup:backupRef,currentVersion:saved.version,currentRevision:saved.revision,full141FactsSha256:readback.full141FactsSha256,runtimeAcceptance:false};
  }finally{db.close();}
}
module.exports={checkInput,checkDatabaseDelta,databaseFacts,sqlRowHash,canonical,transactionObserver,checkWorkspaceRows,run};
