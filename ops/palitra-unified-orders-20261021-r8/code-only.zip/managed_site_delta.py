"""Exact managed-site delta review. Never writes server files or calls save.

Publication belongs to the normal native workspace UI or separately reviewed
native artifact import. This module only verifies the complete140→141 map.
"""
from manifest_inputs import need,digest,read_pin
PRICE='79d62dd78fc00347758c248a2b733e407bdacccf6094fe0a8f3e69f01c7a5943'
REPLACEMENTS=frozenset(('assets/order.js','assets/storefront.js'))
ADDITION='assets/palitra-attribution.js'
def validate(before,after,records):
    need(type(before) is dict and len(before)==140 and type(after) is dict and len(after)==141,'EXACT_MANAGED140_TO141_FULL_MAP_REQUIRED')
    need(set(after)-set(before)=={ADDITION} and not(set(before)-set(after)),'ONLY_NEW_TRACKER_MANAGED_ADDITION_ALLOWED')
    for name,row in {**before,**after}.items():need(type(row) is dict and set(row)=={'sha256','bytes'} and digest(row['sha256']) and type(row['bytes']) is int and 0<row['bytes']<=32*1024*1024,'EXACT_MANAGED_MANIFEST_RECORD_REQUIRED')
    need({n for n in before if before[n]!=after[n]}==REPLACEMENTS,'ONLY_TWO_APPROVED_MANAGED_REPLACEMENTS_ALLOWED')
    need(before['data/price.json']==after['data/price.json'] and after['data/price.json']['sha256']==PRICE,'AGREED_PRICE_BYTES_MUST_REMAIN_EXACT')
    need(type(records) is dict and set(records)==REPLACEMENTS|{ADDITION},'EXACT_THREE_MANAGED_REVIEW_INPUTS_REQUIRED')
    for name,ref in records.items():
        raw=read_pin(ref);need(after[name]=={'sha256':ref['sha256'],'bytes':len(raw)},'EXACT_REVIEWED_NATIVE_WORKSPACE_BYTES_REQUIRED')
    return {'status':'LOCAL_NATIVE_WORKSPACE_DELTA_REVIEW_ONLY','runtimeAuthorization':False,'runtimeRawWritesAllowed':False,'manifestBefore':140,'manifestAfter':141,'priceChanged':False,'requiresActualNativeSaveReadback':True}
