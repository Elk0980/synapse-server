"""Verify the R9 evidence boundary without accepting a new runtime basis.

R9 transaction receipt is not independent Root acceptance. This is code/input
validation only; the actual new private content capture and its forward minimum
must be reviewed and pinned separately after real commit. Old minima/backups
are never rewritten by this module.
"""
import hashlib,json
from manifest_inputs import need,digest
encoded=lambda v:json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
sha=lambda v:hashlib.sha256(encoded(v)).hexdigest()
HASH_SEMANTICS='R6_CANONICAL_JSON_BLOB_SHA256_SORTED_ROW_HASH_MULTISET_V1'
EXCLUSIONS=['documents:selected-deletes-and-new-tombstones','sqlite_sequence:documents-row-only']
def table_seals(value):
    need(type(value) is dict and value,'FULL_TABLE_SEALS_REQUIRED')
    for name,row in value.items():need(type(name) is str and type(row) is dict and set(row)=={'count','rowMultisetSha256'} and type(row['count']) is int and row['count']>=0 and digest(row['rowMultisetSha256']),'EXACT_TABLE_SEAL_REQUIRED')
    return value
def inspect_transaction_receipt(receipt,*,engine_sha256,pre_full_sha256,user_approval_sha256):
    need(receipt.get('status')=='CLEANUP_COMMITTED_REQUIRES_ROOT_READONLY_ACCEPTANCE' and receipt.get('runtimeAcceptance') is False and receipt.get('automaticRetry') is False and receipt.get('automaticRestore') is False,'ACTUAL_R9_COMMITTED_RECEIPT_REQUIRED')
    e=receipt.get('transactionEvidence');need(type(e) is dict and sha(e)==receipt.get('transactionEvidenceSha256'),'EXACT_TRANSACTION_EVIDENCE_HASH_REQUIRED')
    need(e.get('schema')=='palitra-cleanup-transaction-evidence/v1' and e.get('captureSemantics')=='SAME_WRITER_CONNECTION_POSTMUTATION_BEFORE_COMMIT' and e.get('hashSemantics')==HASH_SEMANTICS and e.get('engineExactPostcheckCompleted') is True and e.get('runtimeAcceptance') is False,'EXACT_R9_TRANSACTION_CAPTURE_SEMANTICS_REQUIRED')
    need(digest(engine_sha256) and e.get('engineSha256')==engine_sha256,'EXACT_FROZEN_CLEANUP_ENGINE_REQUIRED')
    for key,pin in [('preFullInspectionSha256',pre_full_sha256),('userApprovalSha256',user_approval_sha256)]:need(digest(pin) and e.get('bindings',{}).get(key)==pin,'PRE_FULL_OR_ACTION_TIME_APPROVAL_CHANGED')
    for key in ('backupSha256','previewSha256','dryrunSha256'):need(digest(e.get('bindings',{}).get(key)),'EXACT_PRIVATE_CLEANUP_BINDINGS_REQUIRED')
    old=e['wholeBefore'];new=e['wholeAfter'];need(set(old)==set(new)=={'schemaSha256','tables','wholeRowsSha256'} and digest(old['schemaSha256']) and old['schemaSha256']==new['schemaSha256'],'CLEANUP_SCHEMA_PRESERVATION_REQUIRED')
    before=table_seals(old['tables']);after=table_seals(new['tables']);need(set(before)==set(after) and old['wholeRowsSha256']==sha(before) and new['wholeRowsSha256']==sha(after),'EXACT_WHOLE_ROWS_HASH_REQUIRED')
    p=e['protectedRows'];need(p.get('exact') is True and p.get('excludedExplicitDeltas')==EXCLUSIONS and table_seals(p['before'])==table_seals(p['after']),'EXACT_PROTECTED_RAW_ROWS_REQUIRED')
    need(set(p['before'])==set(before),'FULL_PROTECTED_TABLE_DOMAIN_REQUIRED')
    deleted=table_seals(e['selectedDeleted']);need(set(deleted)<=set(before),'ONLY_EXISTING_SELECTED_TABLES_ALLOWED')
    tomb=e['tombstonesAdded'];need(set(tomb)=={'count','rowMultisetSha256','keySetSha256'} and type(tomb['count']) is int and tomb['count']>=0 and digest(tomb['rowMultisetSha256']) and digest(tomb['keySetSha256']),'EXACT_TOMBSTONE_DELTA_REQUIRED')
    for name,row in before.items():
        lost=deleted.get(name,{}).get('count',0);wanted=row['count']-lost+(tomb['count'] if name=='documents' else 0)
        need(wanted>=0 and after[name]['count']==wanted,'EXACT_SELECTED_COUNT_DELTA_REQUIRED')
        if lost==0 and name not in ('documents','sqlite_sequence'):need(after[name]==row,'UNSELECTED_RAW_TABLE_CHANGED')
    return {'status':'R9_TRANSACTION_INPUT_CONSISTENT_NOT_POST_CLEANUP_ACCEPTANCE','transactionEvidenceSha256':sha(e),'wholeBefore':old,'wholeAfter':new,'requiresIndependentRootPostCommitCapture':True,'runtimeAuthorization':False}

def require_accepted_basis(value,*,actual_receipt_sha256,actual_post_capture_sha256):
    # Exact external references, not a claim that a locally invented JSON is
    # runtime evidence. The native installer adapter must read/pin actual files.
    need(type(value) is dict and value.get('schema')=='palitra-post-cleanup-content-basis/v1' and value.get('status')=='ROOT_ACCEPTED_POST_CLEANUP_CONTENT_BASIS_NOT_INSTALL_AUTHORIZATION' and value.get('runtimeAuthorization') is False,'INDEPENDENT_ROOT_POST_CLEANUP_BASIS_REQUIRED')
    need(digest(actual_receipt_sha256) and value.get('cleanupReceiptSha256')==actual_receipt_sha256 and digest(actual_post_capture_sha256) and value.get('postReadonlyContentCaptureSha256')==actual_post_capture_sha256,'ACTUAL_POST_COMMIT_PRIVATE_REFERENCES_REQUIRED')
    need(value.get('contentMinimumMode')=='NEW_FORWARD_ACCEPTED_MINIMUM_OLD_ARTIFACTS_IMMUTABLE' and value.get('reportTrafficRuntimeMinimumMode')=='UNCHANGED_OLD_GUARDS' and value.get('oldArtifactWrites')==0,'ONLY_FORWARD_CONTENT_BASIS_CHANGE_ALLOWED')
    return {'status':'LOCAL_BASIS_REFERENCES_ONLY_NATIVE_VALIDATION_STILL_REQUIRED','runtimeAuthorization':False}
