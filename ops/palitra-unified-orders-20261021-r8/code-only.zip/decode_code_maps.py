"""Offline receiver for exact visible exporter frames; never accepts OCR guesses."""
import base64,hashlib,json,re,zlib
sha=lambda b:hashlib.sha256(b).hexdigest()
def need(v,c):
    if not v:raise ValueError(c)
def decode(text):
    need(type(text) is str and len(text)<=16*1024*1024,'BOUNDED_VISIBLE_CODE_MAP_TRANSFER_REQUIRED')
    binding=None;chunks={};pages=set()
    for line in text.splitlines():
        line=line.strip()
        if not line:continue
        if line.startswith('{'):
            h=json.loads(line);need(h.get('schema')=='palitra-code-map-transfer/v1' and set(h)=={'schema','sha256','rawBytes','compressedSha256','compressedBytes','chunks','chunkChars','page','pages'},'EXACT_CODE_MAP_HEADER_REQUIRED')
            same={k:v for k,v in h.items() if k!='page'};need(binding is None or same==binding,'MIXED_CAPTURE_FRAMES_REFUSED');binding=same;pages.add(h['page']);continue
        match=re.fullmatch(r'([0-9]{4,6}):([A-Za-z0-9+/=]{1,480})',line);need(match is not None,'UNRECOGNIZED_TRANSFER_LINE_NO_GUESS')
        i=int(match[1]);value=match[2];need(i not in chunks or chunks[i]==value,'CONFLICTING_DUPLICATE_CHUNK');chunks[i]=value
    need(binding is not None and binding['chunkChars']==480 and type(binding['chunks']) is int and 1<=binding['chunks']<=16384 and set(chunks)==set(range(binding['chunks'])),'MISSING_OR_FOREIGN_TRANSFER_CHUNKS')
    need(type(binding['pages']) is int and binding['pages']==(binding['chunks']+15)//16 and pages==set(range(binding['pages'])),'MISSING_TRANSFER_PAGE_HEADER')
    packed=base64.b64decode(''.join(chunks[i] for i in range(binding['chunks'])),validate=True)
    need(len(packed)==binding['compressedBytes'] and sha(packed)==binding['compressedSha256'] and 0<binding['rawBytes']<=16*1024*1024,'COMPRESSED_CAPTURE_PIN_OR_BOUND_CHANGED')
    stream=zlib.decompressobj();raw=stream.decompress(packed,binding['rawBytes']+1)
    need(stream.eof and not stream.unused_data and not stream.unconsumed_tail and len(raw)==binding['rawBytes'] and sha(raw)==binding['sha256'],'RAW_CAPTURE_PIN_OR_SIZE_CHANGED')
    value=json.loads(raw);need(value.get('schema')=='palitra-unified-native-map/v1' and value.get('runtimeAuthorization') is False and value.get('runtimeWrites')==value.get('databaseOpenCount')==0,'CODE_ONLY_CAPTURE_REQUIRED')
    return value,{'sha256':sha(raw),'rawBytes':len(raw),'compressedSha256':sha(packed),'pages':len(pages)}
