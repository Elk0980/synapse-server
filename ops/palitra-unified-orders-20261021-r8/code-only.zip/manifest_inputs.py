"""Exact declarative unified installer input verifier. No service operations.

It deliberately cannot freeze while product inputs or post-cleanup proofs are
missing. Managed-site consumers are a separate native workspace adoption lane.
"""
import hashlib,json,re,stat
from pathlib import Path,PurePosixPath
IMAGE='sha256:951db09e9e6c4781350bbced7e7a9e4ef099077a368e38a6b1fac40e0a4a6a22'
RECEIPT='34ce6389ef04a5db158d5b1a27734e2d09c919df28b35a9dad4561af48d42892'
HISTORICAL_R2_INSPECTOR='cf1034436451d042da76f8f58307a2a1d5f8d290ea5c55de97a8c5fba790259a'
NAMESPACE='palitra-unified-orders-20261021-r8'
GROUPS=frozenset(('frontend','root-entry-frontend','attribution-backend','unread-backend','root-merged-backend','managed-site'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def need(v,c):
    if not v:raise ValueError(c)
def digest(v):return type(v) is str and re.fullmatch('[a-f0-9]{64}',v) is not None
def relative(name):
    return type(name) is str and 0<len(name)<512 and '\\' not in name and ':' not in name and not name.startswith('/') and all(p not in ('','.','..') for p in name.split('/'))
def read_pin(ref,*,json_document=False):
    need(type(ref) is dict and set(ref)=={'path','sha256'} and digest(ref['sha256']),'EXACT_ARTIFACT_REFERENCE_REQUIRED')
    p=Path(ref['path']);need(p.is_absolute() and all(not x.is_symlink() for x in [p,*p.parents]),'ARTIFACT_ALIAS_OR_RELATIVE_REFUSED')
    before=p.lstat();need(stat.S_ISREG(before.st_mode) and before.st_nlink==1 and before.st_size<=16*1024*1024,'BOUNDED_ARTIFACT_REQUIRED');raw=p.read_bytes();after=p.lstat()
    identity=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
    need(identity(before)==identity(after) and len(raw)==before.st_size,'ARTIFACT_CHANGED_DURING_READ');need(sha(raw)==ref['sha256'],'EXACT_ARTIFACT_SHA_REQUIRED')
    return json.loads(raw) if json_document else raw
def reviewed_components(config):
    need(config['runtimeAuthorization'] is False and config['schema']=='palitra-unified-installer-input/v1' and config['namespace']==NAMESPACE,'EXACT_DISABLED_UNIFIED_INPUT_REQUIRED')
    need(config['status']=='FINAL_ROOT_REVIEWED_INPUTS_NOT_RUNTIME_AUTHORIZATION','FINAL_REVIEWED_INPUTS_PENDING')
    components=config['components'];need(type(components) is dict and set(components)==GROUPS,'EXACT_SIX_COMPONENT_GROUPS_REQUIRED')
    all_records=[]
    for group,obj in components.items():
        need(type(obj) is dict and set(obj)=={'review','records'} and type(obj['records']) is list and obj['records'],'EXACT_COMPONENT_RECORDS_REQUIRED')
        review=read_pin(obj['review'],json_document=True)
        if group=='frontend':need(review.get('frozen') is True and review.get('wholeAppHelpScopeCompleted') is True,'FINAL_FRONTEND_FREEZE_REQUIRED')
        if group=='root-entry-frontend':need(review.get('staffTracker') is False and review.get('entryQuerySuffix')==config.get('assetVersion') and type(config.get('assetVersion')) is str,'ROOT_STAFF_ENTRY_NO_TRACKER_EXACT_QUERY_REVIEW_REQUIRED')
        reviewed_rows=review.get('files',review.get('sources',[]));need(type(reviewed_rows) is list and reviewed_rows,'EXACT_PRODUCT_REVIEW_RECORDS_REQUIRED')
        allowed={str(Path(r['path']).resolve()):r['sha256'] for r in reviewed_rows}
        for index,row in enumerate(obj['records']):
            need(type(row) is dict and set(row)=={'input','before','runtimeTarget','staticTargets','managedPath','newSourceMode'},'EXACT_DEPLOYMENT_RECORD_REQUIRED')
            raw=read_pin(row['input']);need(0<len(raw)<=2*1024*1024,'BOUNDED_PRODUCT_BYTES_REQUIRED')
            need(allowed.get(str(Path(row['input']['path']).resolve()))==row['input']['sha256'],'PAYLOAD_NOT_EXACT_REVIEWED_COMPONENT')
            if row['before'] is not None:read_pin(row['before'])
            if group=='managed-site':
                need(row['runtimeTarget'] is None and row['staticTargets']==[] and row['newSourceMode'] is None and relative(row['managedPath']),'MANAGED_SITE_ONLY_NATIVE_WORKSPACE_ADOPTION')
            else:
                from static_extension import STATIC_ONLY,validate_consumer
                key=group+':'+str(index)
                if key in STATIC_ONLY:
                    validate_consumer(key,row,row['staticTargets'])
                else:need(relative(row['runtimeTarget']) and row['managedPath'] is None,'EXPLICIT_RUNTIME_TARGET_REQUIRED')
                need(type(row['staticTargets']) is list and len(set(row['staticTargets']))==len(row['staticTargets']) and all(type(p) is str and p.startswith('/opt/synapse/sites/') and '..' not in PurePosixPath(p).parts for p in row['staticTargets']),'EXPLICIT_PROVEN_STATIC_PATHS_REQUIRED')
                need(row['newSourceMode'] in (0o600,0o644) if row['before'] is None else row['newSourceMode'] is None,'NEW_SOURCE_MODE_OR_EXISTING_SOURCE_REQUIRED')
            all_records.append((group,row))
    runtime=[r for g,r in all_records if g!='managed-site' and r['runtimeTarget'] is not None];managed=[r for g,r in all_records if g=='managed-site']
    targets={}
    for r in runtime:targets.setdefault(r['runtimeTarget'],[]).append(r)
    for target,rows in targets.items():
        if len(rows)==1:continue
        # These two reviewed HTML entry filenames are the same canonical native
        # template. No arbitrary backend collision or preferred-fork selection.
        expected=components['frontend']['records'][12:14]
        need(target=='palitra-review-public/palitra-chat.html' and len(rows)==2 and {r['input']['path'] for r in rows}=={r['input']['path'] for r in expected} and len({(r['input']['sha256'],r['before']['sha256'] if r['before'] else None,r['newSourceMode']) for r in rows})==1,'DUPLICATE_RUNTIME_TARGET_REFUSED')
    statics=[p for g,r in all_records if g!='managed-site' for p in r['staticTargets']];need(len(set(statics))==len(statics),'DUPLICATE_STATIC_TARGET_REFUSED')
    need({r['managedPath'] for r in managed}=={'assets/order.js','assets/storefront.js','assets/palitra-attribution.js'},'EXACT_THREE_REVIEWED_MANAGED_CONSUMERS_REQUIRED')
    # Runtime target overlap is explicitly rejected rather than silently choosing
    # the earlier unread server fork over Root's merged server.
    need(len(components['attribution-backend']['records'])==7 and len(components['unread-backend']['records'])==2 and len(components['root-merged-backend']['records'])==2,'EXACT_7_2_2_BACKEND_COMPONENTS_REQUIRED')
    need(len(components['frontend']['records'])==18 and len(components['root-entry-frontend']['records'])==1 and components['root-entry-frontend']['records'][0]['runtimeTarget']=='palitra-orders-public/cabinet.html','EXACT_FROZEN18_PLUS_SEPARATE_ROOT_CABINET_REQUIRED')
    need(not any(r['runtimeTarget']=='server.js' for r in components['unread-backend']['records']),'UNREAD_SERVER_FORK_MUST_NOT_OVERWRITE_MERGED_SERVER')
    return all_records
def basis_references(config):
    basis=config['basis'];need(type(basis) is dict and set(basis)=={'installedImage','installedReceiptSha256','sourceFiles','staticFiles','chainFiles','managedVersion','readonlyInspectorCodePins','acceptedPostCleanupBasis','freshNativeBasis','managedAdoptionPlan','managedAdoptionReceipt'},'EXACT_NEW_BASIS_REFERENCES_REQUIRED')
    need((basis['installedImage'],basis['installedReceiptSha256'],basis['sourceFiles'],basis['staticFiles'],basis['chainFiles'],basis['managedVersion'])==(IMAGE,RECEIPT,240,43,49,260),'EXACT_CURRENT260_PRE_INSTALL_BASIS_REQUIRED')
    # Proof schemas are validated by the separately reviewed native bridge.
    # A local JSON reference alone is never runtime proof or live admission.
    for key in ('acceptedPostCleanupBasis','freshNativeBasis','managedAdoptionPlan'):
        need(basis[key] is not None,'ACTUAL_PROOF_PENDING_'+key);read_pin(basis[key],json_document=True)
    need(basis['managedAdoptionReceipt'] is None,'NEW_ADOPTION_RECEIPT_ONLY_AFTER_CODE_AND_SCHEMA_PUBLICATION')
    need(digest(basis['readonlyInspectorCodePins']) and config.get('compatibilityInspectorManifest') is not None,'FINAL_REVIEWED_COMPATIBILITY_INSPECTOR_PENDING')
    need(config['compatibilityInspectorManifest']['sha256']==basis['readonlyInspectorCodePins'],'EXACT_FINAL_COMPATIBILITY_MANIFEST_REQUIRED');read_pin(config['compatibilityInspectorManifest'],json_document=True)
    need(config['nativeAdapter'] is not None,'POST_CLEANUP_NATIVE_ADAPTER_PENDING')
    read_pin(config['nativeAdapter']);return basis
def validate_final(config):
    records=reviewed_components(config);basis=basis_references(config)
    need(config['rootReview'] is not None,'FINAL_ROOT_REVIEW_PENDING');root_review=read_pin(config['rootReview'],json_document=True)
    need(root_review.get('compatibilityInspectorCodePinsSha256')==basis['readonlyInspectorCodePins'] and root_review.get('nativeAdapterSha256')==config['nativeAdapter']['sha256'],'ROOT_REVIEW_MUST_BIND_FINAL_INSPECTOR_AND_NATIVE_ADAPTER')
    need(root_review.get('managedAdoptionPlanSha256')==basis['managedAdoptionPlan']['sha256'],'ROOT_REVIEW_MUST_BIND_NATIVE_MANAGED_ADOPTION_PLAN')
    return {'status':'LOCAL_INPUT_CLOSURE_ONLY_NOT_RUNTIME_AUTHORIZATION','runtimeAuthorization':False,'records':records,'basis':basis}

if __name__=='__main__':
    print(json.dumps({'status':'INPUT_DRAFT_ONLY_NO_RUNTIME_ENTRY','runtimeAuthorization':False,'runtimeWrites':0}))
