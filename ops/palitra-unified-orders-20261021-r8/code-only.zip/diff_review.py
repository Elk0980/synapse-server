"""Lossless byte pins plus human text diff; no product mutation or normalization.

BASE36 denotes release36 (211 source files), never a count of36files. A partial
changed-file list cannot be labelled the complete historical review.
"""
import difflib,json
from manifest_inputs import need,read_pin,sha,relative,digest
def compare_scoped_trees(base36_pins,current_pins,records):
    """Full historical211/current240 maps; exact text only for candidate touches.

    Untouched historical changes remain explicit as preexisting current facts,
    never restored to36 and never mislabelled byte-unchanged since36.
    """
    need(type(base36_pins) is dict and len(base36_pins)==211,'EXACT_RELEASE36_SOURCE211_MAP_PENDING')
    need(type(current_pins) is dict and len(current_pins)==240 and set(base36_pins)<=set(current_pins),'EXACT_CURRENT240_SOURCE_MAP_PENDING')
    need(all(relative(k) and digest(v) for k,v in {**base36_pins,**current_pins}.items()),'EXACT_FULL_SOURCE_HASH_MAPS_REQUIRED')
    need(type(records) is list and records and len({r['target'] for r in records})==len(records),'CLOSED_REVIEWED_TOUCH_SET_REQUIRED')
    candidate=dict(current_pins);diffs={'BASE36_TO_CANDIDATE':[],'CURRENT_TO_CANDIDATE':[]}
    for row in records:
        need(set(row)=={'target','candidate','current','base36'} and relative(row['target']),'EXACT_SCOPED_DIFF_RECORD_REQUIRED')
        name=row['target'];raw=read_pin(row['candidate']);candidate[name]=sha(raw)
        for label,baseline,field in [('BASE36_TO_CANDIDATE',base36_pins,'base36'),('CURRENT_TO_CANDIDATE',current_pins,'current')]:
            if name in baseline:
                need(row[field] is not None,'CANONICAL_TOUCHED_BASE_BYTES_PENDING_'+field)
                old=read_pin(row[field]);need(sha(old)==baseline[name],'TOUCHED_BYTES_NOT_EXACT_FULL_MAP')
            else:need(row[field] is None,'ADDITIONS_MUST_HAVE_NO_INVENTED_BASE');old=b''
            diffs[label].extend(difflib.unified_diff(old.decode().splitlines(keepends=True),raw.decode().splitlines(keepends=True),fromfile='a/'+label+'/'+name,tofile='b/candidate/'+name))
    touched={r['target'] for r in records};domain=[]
    for name in sorted(candidate):
        domain.append({'target':name,'release36Sha256':base36_pins.get(name),'currentSha256':current_pins.get(name),'candidateSha256':candidate[name],'candidateTouched':name in touched,'preservedCurrent':name not in touched,'preexistingChangeSince36':name in base36_pins and base36_pins[name]!=current_pins[name]})
    need(all(candidate[n]==current_pins[n] for n in set(current_pins)-touched),'UNTOUCHED_CURRENT_SOURCE_CHANGED')
    return {'status':'LOCAL_SCOPED_TEXT_AND_FULL_HASH_MAP_REVIEW_NOT_NATIVE_FRESHNESS','runtimeAuthorization':False,'baseRelease':36,'baseSourceFiles':211,'currentSourceFiles':240,'candidateSourceFiles':len(candidate),'fullSourceRecords':domain,'diffs':{k:''.join(v) for k,v in diffs.items()}}
def compare_maps(base36,current,candidate):
    need(type(base36) is dict and len(base36)==211,'EXACT_RELEASE36_SOURCE211_MAP_PENDING')
    need(type(current) is dict and type(candidate) is dict and candidate,'EXPLICIT_CURRENT_AND_CANDIDATE_MAP_REQUIRED')
    need(set(base36)<=set(candidate) and set(current)<=set(candidate),'UNMODIFIED_BASE_FILES_MUST_REMAIN_EXPLICIT')
    need(all(relative(n) for n in set(base36)|set(current)|set(candidate)),'EXACT_RELATIVE_DIFF_PATHS_REQUIRED')
    output={};pins={}
    for label,baseline in [('BASE36_TO_CANDIDATE',base36),('CURRENT_TO_CANDIDATE',current)]:
        chunks=[];records=[]
        for name in sorted(set(baseline)|set(candidate)):
            before=read_pin(baseline[name]) if name in baseline else b'';after=read_pin(candidate[name])
            records.append({'path':name,'beforeSha256':sha(before) if name in baseline else None,'afterSha256':sha(after),'changed':before!=after,'bytesBefore':len(before),'bytesAfter':len(after)})
            if before==after:continue
            # Decode strictly: no dropped/replaced bytes. Separate hashes retain
            # CRLF/LF differences even if the human viewer normalizes its display.
            chunks.extend(difflib.unified_diff(before.decode('utf-8').splitlines(keepends=True),after.decode('utf-8').splitlines(keepends=True),fromfile='a/'+label+'/'+name,tofile='b/candidate/'+name))
        output[label]=''.join(chunks);pins[label]=records
    return {'status':'LOCAL_FULL_DIFF_ONLY_NOT_NATIVE_FRESHNESS','diffs':output,'records':pins}
