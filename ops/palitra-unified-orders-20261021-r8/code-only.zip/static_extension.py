"""Six proven existing public assets, independent of the image source map.

These files extend tracked static43 to static49. They are never /app additions.
The observation is code-only, not a fresh runtime inspection or Caddy proof.
"""
from pathlib import PurePosixPath
from manifest_inputs import need,read_pin

FACTS_SHA='f4cf8a86cf32510b89cb94b8dc24ea6d12086b31b15258ef9db58f62499bc6c5'
ROOT='/opt/synapse/sites/synapse'
# key -> exact native consumer, public-before SHA, observed native byte count
STATIC_ONLY={
 'frontend:4':(ROOT+'/cabinet/site-photos.js','3692736f889d6c0dbb592fae12980a52ec2fbf571f1ea3e219e612a62632aea8',25961),
 'frontend:5':(ROOT+'/cabinet/site-photos.css','a021fce989773086ea87c93f9b5165d3da58ebaa5d1ea0a32edf5a454772f3bb',5329),
 'frontend:6':(ROOT+'/cabinet/site-photos.html','b9ea20cc031deceb4413daf4279b4d2850fd90f6ac5f8cfacccd87e6324361f6',7331),
 'frontend:7':(ROOT+'/palitra-editor.js','c6b64070bf702e14ad98262fb61b5073659d396a9c7a944d8c6c704496ac160b',88423),
 'frontend:8':(ROOT+'/palitra-editor.css','913e47a484437dcecd2183bb273bfceeb17c37175580ff0e178979d02c33c8fa',22611),
 'frontend:9':(ROOT+'/price-editor-palitra.html','78c59589c84857783c9d99771cda91d4ef791d5e652c80e3f5ff0cb0012b9d7b',5612),
}

def validate_facts(value):
    need(type(value) is dict and set(value)=={'root','rootReal','files'} and value['root']==value['rootReal']==ROOT,'EXACT_STATIC6_CANONICAL_ROOT_REQUIRED')
    need(type(value['files']) is list and len(value['files'])==6,'EXACT_SIX_STATIC_EXTENSION_FILES_REQUIRED')
    expected={target:(pin,size) for target,pin,size in STATIC_ONLY.values()}
    need(len({r.get('path') for r in value['files']})==6 and {r.get('path') for r in value['files']}==set(expected),'EXACT_STATIC6_DOMAIN_REQUIRED')
    for row in value['files']:
        need(set(row)=={'path','parentReal','mode','uid','gid','nlink','bytes','type','sha256'},'CLOSED_STATIC6_FACTS_REQUIRED')
        pin,size=expected[row['path']]
        need(row['parentReal']==str(PurePosixPath(row['path']).parent) and row['mode']==0o644 and row['uid']==row['gid']==0 and row['nlink']==1 and row['type']=='file' and row['sha256']==pin and row['bytes']==size,'EXACT_STATIC6_NATIVE_METADATA_REQUIRED')
    return {r['path']:dict(r) for r in value['files']}

def from_reference(reference):
    need(reference['sha256']==FACTS_SHA,'EXACT_ROOT_OBSERVED_STATIC6_REFERENCE_REQUIRED')
    value=read_pin(reference,json_document=True);validate_facts(value);return value

def validate_consumer(key,row,targets):
    need(key in STATIC_ONLY,'ONLY_SIX_REVIEWED_FRONTEND_STATIC_ONLY_CONSUMERS')
    target,pin,size=STATIC_ONLY[key]
    need(row['runtimeTarget'] is None and row['newSourceMode'] is None and row['managedPath'] is None and row['before'] is not None and row['before']['sha256']==pin and len(read_pin(row['before']))==size and targets==[target],'STATIC_ONLY_MUST_MATCH_EXACT_NATIVE_AND_PUBLIC_BEFORE')
    return target
