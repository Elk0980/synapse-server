"""Pure reverse reducer over byte-pinned completed receipts, never live hashes."""
import hashlib,json,re
from pathlib import PurePosixPath

def need(v,c):
    if not v:raise ValueError(c)
def pin(v):return type(v) is str and re.fullmatch('[a-f0-9]{64}',v) is not None
def blob(raw,digest):
    need(type(raw) is bytes and pin(digest) and hashlib.sha256(raw).hexdigest()==digest,'EXACT_STATIC_RECEIPT_PIN_REQUIRED')
    return json.loads(raw)
def records_from_receipt(receipt,records=None):
    phase=receipt.get('phase','')
    need(type(phase) is str and not any(x in phase for x in ('UNKNOWN','STARTED','PREPARED','BUILT','CONTEXT')),'COMPLETED_STATIC_RECEIPT_REQUIRED')
    need(phase in {'APPLIED_NOT_CUSTOMER_ACCEPTANCE','INCREMENTAL_CONTENT_AND_STATIC_APPLIED_NOT_PUBLIC_PROOF','UI_CONTENT_AND_STATIC_APPLIED_NOT_PUBLIC_PROOF','PHOTO_CONTENT_AND_STATIC_APPLIED_NOT_PUBLIC_PROOF','DARYA_CONTENT_AND_STATIC_APPLIED_NOT_PUBLIC_PROOF'},'EXPLICIT_COMPLETED_STATIC_PHASE_REQUIRED')
    if isinstance(receipt.get('static'),list):
        rows=[]
        for row in receipt['static']:
            need(isinstance(row,dict) and type(row.get('target')) is str and pin(row.get('sha256')) and row.get('written',True) is True,'COMPLETED_EXPLICIT_STATIC_ROW_REQUIRED')
            rows.append({'target':row['target'],'sha256':row['sha256'],'beforeSha256':row.get('baseSha256',row.get('beforeSha256'))})
        return rows
    backups=receipt.get('codeBackups',{}).get('static')
    need(type(backups) is list and records is not None and type(records.get('records')) is list,'PINNED_RECORDS_AND_CODE_BACKUPS_REQUIRED')
    rows=[];used=set()
    for backup in backups:
        target=backup.get('target');before=backup.get('sha256')
        need(type(target) is str and pin(before),'EXACT_STATIC_BACKUP_TARGET_REQUIRED')
        matches=[r for r in records['records'] if r.get('static') is not None and PurePosixPath(target).name==r['static'] and r.get('beforeSha256')==before]
        need(len(matches)==1,'UNAMBIGUOUS_EXPLICIT_STATIC_MAPPING_REQUIRED')
        record=matches[0];need(pin(record.get('sha256')) and record['path'] not in used,'UNIQUE_PINNED_STATIC_RECORD_REQUIRED');used.add(record['path'])
        rows.append({'target':target,'sha256':record['sha256'],'beforeSha256':before})
    need(len(used)==sum(r.get('static') is not None for r in records['records']),'EXACT_STATIC_RECORD_BACKUP_SET_REQUIRED')
    return rows
def fold_static(expected_paths,stages,managed257):
    need(type(expected_paths) is set and len(expected_paths)==43,'EXACT_STATIC43_EXPECTED_PATHS_REQUIRED')
    need(type(managed257) is dict and len(managed257)==2 and set(managed257)<=expected_paths and all(pin(x) for x in managed257.values()),'EXACT_TWO_SEALED_MANAGED257_DRIFTS_REQUIRED')
    out=dict(managed257);prior={};provenance={p:'FROZEN_MANAGED257_SELECTED' for p in managed257}
    need(type(stages) is list and 1<=len(stages)<=49,'BOUNDED_ORDERED_COMPLETED_HISTORY_REQUIRED')
    for index,stage in enumerate(stages):
        receipt=blob(stage['receiptBytes'],stage['receiptSha256']);records=None
        if 'recordsBytes' in stage:
            manifest=blob(stage['manifestBytes'],stage['manifestSha256'])
            need(receipt.get('binding',{}).get('manifestSha256')==stage['manifestSha256'],'RECEIPT_TO_MANIFEST_BINDING_REQUIRED')
            matches=[r for r in manifest['files'] if r.get('path')=='records.json'];need(len(matches)==1,'MANIFEST_RECORDS_PIN_REQUIRED')
            records=blob(stage['recordsBytes'],matches[0]['sha256'])
        for row in records_from_receipt(receipt,records):
            target=row['target']
            if target not in expected_paths or target in managed257:continue
            if target in prior:need(row['sha256']==prior[target],'STATIC_HISTORY_CAS_GAP_OR_DRIFT')
            if target not in out:out[target]=row['sha256'];provenance[target]={'stage':index,'receiptSha256':stage['receiptSha256']}
            before=row['beforeSha256']
            if before is not None:need(pin(before),'EXACT_STATIC_HISTORY_BEFORE_PIN_REQUIRED');prior[target]=before
    need(set(out)==expected_paths,'STATIC43_HISTORY_CLOSURE_INCOMPLETE')
    return {'sha256':out,'provenance':provenance}

def extend_sealed_workspace(expected_paths,baseline_bytes,baseline_sha,stages,managed257):
    """Full explicit Darya binding map, then exact forward replacement CAS.

    The baseline map comes from the immutable completed journal's binding,
    never from running files, path-name guesses, or the current 260 directory.
    """
    baseline=blob(baseline_bytes,baseline_sha)
    need(baseline.get('name')=='palitra-darya-workspace-20261020-r2' and baseline.get('phase')=='APPLIED_NOT_CUSTOMER_ACCEPTANCE','EXACT_COMPLETED_DARYA_STATIC_BASELINE_REQUIRED')
    bindings=baseline.get('inputs',{});out=bindings.get('afterStatic')
    need(type(expected_paths) is set and len(expected_paths)==43 and type(out) is dict and set(out)==expected_paths and all(pin(p) for p in out.values()),'EXACT_SEALED_DARYA_STATIC43_MAP_REQUIRED')
    need(bindings.get('sourceCounts')=={'before':235,'after':239},'EXACT_DARYA_BINDING_COUNTS_REQUIRED')
    need(type(managed257) is dict and len(managed257)==2 and all(out.get(p)==v for p,v in managed257.items()),'SEALED_HISTORICAL257_STATIC_BINDING_CHANGED')
    out=dict(out);provenance={p:{'baselineReceiptSha256':baseline_sha} for p in out}
    need(type(stages) is list and 1<=len(stages)<=49,'BOUNDED_FORWARD_STATIC_HISTORY_REQUIRED')
    for index,stage in enumerate(stages):
        receipt=blob(stage['receiptBytes'],stage['receiptSha256']);manifest=blob(stage['manifestBytes'],stage['manifestSha256'])
        need(receipt.get('binding',{}).get('manifestSha256')==stage['manifestSha256'],'RECEIPT_TO_MANIFEST_BINDING_REQUIRED')
        matches=[r for r in manifest['files'] if r.get('path')=='records.json'];need(len(matches)==1,'MANIFEST_RECORDS_PIN_REQUIRED')
        records=blob(stage['recordsBytes'],matches[0]['sha256'])
        for row in records_from_receipt(receipt,records):
            target=row['target'];need(target in out and target not in managed257 and out[target]==row['beforeSha256'],'EXACT_FORWARD_STATIC_CAS_REQUIRED')
            out[target]=row['sha256'];provenance[target]={'stage':index,'receiptSha256':stage['receiptSha256']}
    need(set(out)==expected_paths and all(out[p]==v for p,v in managed257.items()),'SEALED_STATIC43_HISTORY_CLOSURE_CHANGED')
    return {'sha256':out,'provenance':provenance}
