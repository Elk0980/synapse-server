"""Extract only explicitly allowlisted read primitives from exact frozen code.

No old entry, Native constructor, stable, apply, up, approval or rollback is
compiled. This file does not itself constitute a complete runtime inspector.
"""
import ast, collections, contextlib, copy, functools, hashlib, json, os, re
from pathlib import Path, PurePosixPath
import sqlite3, stat, tempfile, time, types
from datetime import datetime, timezone

NATIVE_SHA='6a25e99e0a604a2ad96fa370c009b068e17cd396709135ec56a15e46b578c250'
REPORT_SHA='08456dc9fcfae875b22c631a461e0cedea5a702b5f8d43ae770de7cff6e78a63'
CONTENT_SHA='d6363b217d69a49751d875b00cf50776593d01160b386190edaac8bf537ab4be'
TRAFFIC_SHA='2b44578d7b7fee9d779fe647c6d3b56eb5aa9d377f89b68f5aaed7230ca1127f'
BACKEND_SHA='5069df0759312e2410bcfb05e94db00583af1cb6d87ab3c8dde62c161e22b8ec'
SELECTED_SHA='60a129b3467068932e0d1ca5529f808a76f36f52027990d71bd19d588149db4b'
GRAPH_SHA='2c57ff64c0074f725c4c1709152076a4a35a67ddc1f1d43a8bcf715d3fa8aa23'
PUSH_SHA='7b761a06694ab713b01b974b1ec3090b75b1c3f05bcd5268533bb8b6181b9be8'
CANONICAL_SHA='256edace89b706966f1e74b2de5787b83b934936f138a8a992713a0c6f211dd7'

def need(v,c):
    if not v:raise ValueError(c)
def source(path,pin):
    p=Path(path)
    for part in [p,*p.parents]:need(not part.is_symlink(),'FROZEN_PRIMITIVE_ALIAS_REFUSED')
    raw=p.read_bytes();need(hashlib.sha256(raw).hexdigest()==pin,'FROZEN_READ_PRIMITIVE_CHANGED')
    return ast.parse(raw,filename=str(p))
def env():
    return {'__builtins__':__builtins__,'collections':collections,'closing':contextlib.closing,'copy':copy,'functools':functools,'hashlib':hashlib,'json':json,'os':os,'Path':Path,'PurePosixPath':PurePosixPath,'re':re,'sqlite3':sqlite3,'stat':stat,'tempfile':tempfile,'time':time,'types':types,'datetime':datetime,'timezone':timezone}
def extract(tree,path,functions=(),assignments=(),classes=None,namespace=None):
    namespace=env() if namespace is None else namespace;nodes=[];found=set();classes=classes or {}
    for node in tree.body:
        if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)) and node.name in functions:nodes.append(node);found.add(node.name)
        elif isinstance(node,ast.Assign) and all(isinstance(t,ast.Name) for t in node.targets):
            names={t.id for t in node.targets}
            if names<=set(assignments):nodes.append(node);found|=names
        elif isinstance(node,ast.ClassDef) and node.name in classes:
            wanted=set(classes[node.name]);members=[m for m in node.body if isinstance(m,ast.FunctionDef) and m.name in wanted]
            need({m.name for m in members}==wanted,'EXACT_READ_METHOD_SET_REQUIRED')
            cls=copy.deepcopy(node);cls.body=members;nodes.append(cls);found.add(node.name)
    need(set(functions)|set(assignments)|set(classes)<=found,'EXACT_READ_SYMBOL_SET_REQUIRED')
    # No top-level Import/Call or old release entry/constructor is executable.
    module=ast.Module(body=nodes,type_ignores=[]);ast.fix_missing_locations(module);exec(compile(module,str(path),'exec'),namespace)
    namespace['__isolated_source__']=ast.unparse(module)
    return namespace
def native_primitives(path):
    constants=['ROOT','NAME','CODE','PARENT','PLATFORM','MANIFEST_TYPES','INDEX_TYPES','DATA','sha','encoded','digest','image','TREE_JS']
    methods=['_image','_parent_image','_platform_image','_tree','_source_modes','_metadata','data_mount','content_data_mount','_runtime']
    return extract(source(path,NATIVE_SHA),path,functions=['need'],assignments=constants,classes={'Native':methods})
def report_primitives(path):
    return extract(source(path,REPORT_SHA),path,functions=['need','encoded','digest','connection_seal','preserves'],classes={'ReportDatabase':['__init__','facts','identity','read','guard','backup_guard']})
def content_primitives(content_path,report_path):
    common=report_primitives(report_path)
    content=extract(source(content_path,CONTENT_SHA),content_path,functions=['need','encoded','digest','quote','atom','schema','connection_seal','preserves'])
    common['connection_seal']=content['connection_seal'];common['preserves']=content['preserves']
    content['_common']=types.SimpleNamespace(ReportDatabase=common['ReportDatabase'])
    return extract(source(content_path,CONTENT_SHA),content_path,classes={'ContentDatabase':['facts','after_guard']},namespace=content)
def traffic_primitives(path):
    return extract(source(path,TRAFFIC_SHA),path,functions=['need','encoded','digest','valid_time','connection_seal','preserves'],assignments=['SQL','SOURCES'],classes={'TrafficDatabase':['__init__','facts','capture','read','guard','backup_guard']},namespace={**env(),'MAX_ROWS':50000,'MAX_FILE_BYTES':128*1024*1024})
def backend_primitives(path):
    return extract(source(path,BACKEND_SHA),path,functions=['need','sha','encoded','digest','image','epoch','exact_path','read','decode'],assignments=['IPV6_NODE_OPTIONS_SHA','HOOKS','CLEAR','LABELS','WORKER_INSPECT','FLAGS_JS','BRIDGE_SHA'],classes={'NativeBackend':['metadata','worker_facts','graph','_resolve_command','db_read','heartbeat']})
def selected_primitives(path):
    return extract(source(path,SELECTED_SHA),path,functions=['need','obj','path'],assignments=['CONTAINERS','FLAGS','ORIGINS','BOT','ALLOWED','ENV'],classes={'Activate':['selected']},namespace={**env(),'Refused':ValueError})
def graph_primitives(path):
    return extract(source(path,GRAPH_SHA),path,assignments=['EXPECTED','GRAPH_PROBE'])
def push_primitives(path):
    return extract(source(path,PUSH_SHA),path,functions=['need'],assignments=['TARGET','KEY_DIRECTORY','FLAG_JS','DB_JS','KEY_JS','HEALTH_JS'],classes={'PushEnable':['flag','mounts','private_meta','binding']})
def canonical_primitives(path):
    return extract(source(path,CANONICAL_SHA),path,functions=['need','canonical_host_config'])
