"""Verified read-only entry. Never imports old release executables."""
import argparse,hashlib,json,os,re,stat,sys
from pathlib import Path
sys.dont_write_bytecode=True
sha=lambda b:hashlib.sha256(b).hexdigest()
def need(v,c):
    if not v:raise ValueError(c)
def read(path):
    for p in [path,*path.parents]:need(not p.is_symlink(),'CODE_ALIAS_REFUSED')
    s=path.lstat();need(stat.S_ISREG(s.st_mode) and s.st_uid==s.st_gid==0 and s.st_nlink==1 and s.st_size<=4*1024*1024,'ROOT_BOUNDED_CODE_REQUIRED')
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
    try:
        raw=os.read(fd,4*1024*1024+1);z=os.fstat(fd);t=path.lstat();facts=lambda x:(x.st_dev,x.st_ino,x.st_size,x.st_mtime_ns,x.st_ctime_ns)
        need(len(raw)==s.st_size and facts(s)==facts(z)==facts(t),'CODE_CHANGED_DURING_READ');return raw
    finally:os.close(fd)
def main():
    need(os.name=='posix' and os.geteuid()==0,'ROOT_LINUX_ONLY');p=argparse.ArgumentParser();p.add_argument('--mode',choices=('full','runtime-cas'),default='full');p.add_argument('--lease-pid',type=int,required=True);p.add_argument('--code-pins-sha',required=True);args=p.parse_args()
    need(args.lease_pid>1 and re.fullmatch('[a-f0-9]{64}',args.code_pins_sha),'EXACT_EXPLICIT_ENTRY_INPUTS_REQUIRED')
    code=Path(__file__).resolve().parent;directory=code.lstat();need(stat.S_ISDIR(directory.st_mode) and directory.st_uid==directory.st_gid==0 and stat.S_IMODE(directory.st_mode)==0o700,'PRIVATE_ROOT_CODE_DIRECTORY_REQUIRED')
    raw=read(code/'readonly-code-pins.json');need(sha(raw)==args.code_pins_sha,'EXACT_REVIEWED_READONLY_PACKAGE_REQUIRED');manifest=json.loads(raw)
    need(set(manifest)=={'schema','status','runtimeAuthorization','files'} and manifest['schema']==1 and manifest['status']=='FROZEN_READONLY_CODE_ONLY_NOT_RUNTIME_ADMISSION' and manifest['runtimeAuthorization'] is False,'EXACT_READONLY_MANIFEST_REQUIRED')
    files=manifest['files'];need(type(files) is dict and 8<=len(files)<=20 and all(re.fullmatch('[a-z0-9][a-z0-9_.-]{0,100}',n) and re.fullmatch('[a-f0-9]{64}',v) for n,v in files.items()),'BOUNDED_CLOSED_CODE_FILES_REQUIRED')
    need({x.name for x in code.iterdir()}==set(files)|{'readonly-code-pins.json'},'EXACT_READONLY_DIRECTORY_CLOSURE_REQUIRED')
    for name,pin in files.items():need(sha(read(code/name))==pin,'EXACT_PINNED_READONLY_CODE_REQUIRED')
    import inspect_readonly
    result=inspect_readonly.main(args.lease_pid,files,args.mode)
    for name,pin in files.items():need(sha(read(code/name))==pin,'LATE_READONLY_CODE_CHANGED')
    result['codeManifestSha256']=args.code_pins_sha
    print(json.dumps(result,separators=(',',':')))
if __name__=='__main__':
    try:main()
    except Exception as error:
        print(json.dumps({'status':'NEW_READONLY_INSPECTION_REFUSED','messageSha256':sha(str(error).encode()),'errorCode':str(error) if re.fullmatch('[A-Z][A-Z0-9_]{0,100}',str(error)) else 'READONLY_DEPENDENCY_REFUSED','runtimeWrites':0,'runtimeAdmission':False}),file=sys.stderr);sys.exit(2)
