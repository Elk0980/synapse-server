'use strict';
// Appended to the exact frozen managed260 probe. No arbitrary source loading.
// One readonly content DB, only workspace pointer SELECT and readonly pragmas.
const FAST_SITE='site-44bbe13f1bad5e005b2a';
const FAST_SQL='SELECT m.id,m.company_code,m.publication_status,w.current_revision FROM managed_sites m JOIN site_workspaces w ON w.site_id=m.id WHERE m.id=?';
function captureFast(proof,options={}){
  const canonicalize=options.canonical||module.exports.canonical;
  const fileInventory=options.inventory||module.exports.inventory;
  const openDatabase=options.openDatabase||(p=>new DatabaseSync(p,{readOnly:true}));
  const digest=options.hash||(value=>hash(canonicalize(value)));
  const check=(v,c)=>{if(!v)throw Error(c);};
  check(proof?.status==='MANAGED260_CAPTURED_NOT_RUNTIME_INSPECTION'&&proof.current260?.version===260&&proof.workspace?.id===FAST_SITE&&proof.workspace.company_code==='palitra-love','EXACT_MANAGED260_FACTS_REQUIRED');
  const database=openDatabase(options.databasePath||'/data/content.sqlite');
  try{
    database.exec('PRAGMA query_only=ON');
    const mode=database.prepare('PRAGMA journal_mode').get();
    check(mode&&Object.keys(mode).join(',')==='journal_mode'&&mode.journal_mode==='wal','EXISTING_WAL_REQUIRED_NO_MODE_CHANGE');
    const query=database.prepare(FAST_SQL);
    const pointer=()=>{const row=query.get(FAST_SITE);check(canonicalize(row)===canonicalize(proof.workspace),'ACTUAL_MANAGED260_POINTER_CHANGED');return row;};
    const before=pointer(),versions=[];
    for(const [key,version] of [['historical257',257],['historical259',259],['current260',260]]){
      const expected=proof[key];check(expected?.version===version&&Object.keys(expected.files||{}).length===140&&Object.keys(expected.manifest||{}).length===140,'EXACT_THREE_CLOSED140_VERSIONS_REQUIRED');
      const first=fileInventory(expected.root,expected.manifest),second=fileInventory(expected.root,expected.manifest);
      const projection=Object.fromEntries(Object.keys(first).map(k=>[k,expected[k]]));
      check(canonicalize(first)===canonicalize(second)&&canonicalize(first)===canonicalize(projection),'MANAGED140_FILE_OR_MANIFEST_FACTS_CHANGED');
      versions.push({version,factsSha256:first.factsSha256,directoriesSha256:first.directoriesSha256});
    }
    check(canonicalize(pointer())===canonicalize(before),'MANAGED260_POINTER_CHANGED_DURING_FILES');
    return {schema:'palitra-managed260-runtime-cas/v1',status:'MANAGED260_FILES_AND_POINTER_CAS_NOT_FULL_INSPECTION',workspaceSha256:digest(before),versions,managedVersion:260,existingWal:true,databaseOpenCount:1,revisionOrDocumentScans:0,runtimeWrites:0};
  }finally{database.close();}
}
module.exports.captureFast=captureFast;
