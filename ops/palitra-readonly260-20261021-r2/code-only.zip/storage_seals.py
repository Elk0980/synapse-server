"""Independent immutable context/code/DB-backup boundary checks.

Only exact byte-pinned completed journals are inputs. No old release methods
execute, and an unrecognised completed format refuses instead of passing.
"""
import hashlib,json,os,re,stat
from pathlib import Path,PurePosixPath

sha=lambda raw:hashlib.sha256(raw).hexdigest()

def need(value,code):
    if not value:raise ValueError(code)

def relative(value):
    return type(value) is str and value and not PurePosixPath(value).is_absolute() and PurePosixPath(value).as_posix()==value and '..' not in PurePosixPath(value).parts

def facts(path,directory=False,mode=None):
    path=Path(path)
    for p in [path,*path.parents]:need(not p.is_symlink(),'SEALED_STORAGE_ALIAS_REFUSED')
    s=path.lstat()
    need((stat.S_ISDIR(s.st_mode) if directory else stat.S_ISREG(s.st_mode) and s.st_nlink==1) and s.st_uid==s.st_gid==0,'ROOT_REGULAR_SEALED_STORAGE_REQUIRED')
    need(mode is None or stat.S_IMODE(s.st_mode)==mode,'SEALED_STORAGE_MODE_CHANGED')
    return s

def bytes_guard(path,pin,read,mode=0o600,size=None):
    before=facts(path,mode=mode);raw=read(path);after=facts(path,mode=mode)
    fields=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
    need(fields(before)==fields(after) and sha(raw)==pin and (size is None or len(raw)==size),'SEALED_STORAGE_BYTES_CHANGED');return raw

def context_guard(root,pins,read):
    """Current uniform completed releases: closed pins plus exact directories."""
    facts(root,True,0o700);need(type(pins) is dict and 3<=len(pins)<=1024 and 'Dockerfile' in pins and 'image.id' in pins,'EXACT_COMPLETED_CONTEXT_PINS_REQUIRED')
    need(all(relative(name) and type(row) is dict and set(row)=={'sha256','mode'} and re.fullmatch('[a-f0-9]{64}',row['sha256']) and row['mode'] in (0o600,0o644) for name,row in pins.items()),'CLOSED_CONTEXT_PIN_SCHEMA_REQUIRED')
    dirs={str(p) for name in pins for p in PurePosixPath(name).parents if str(p)!='.'}
    actual_files=set();actual_dirs=set()
    for p in Path(root).rglob('*'):
        label=p.relative_to(root).as_posix();s=facts(p,directory=p.is_dir())
        if stat.S_ISDIR(s.st_mode):need(label in dirs and stat.S_IMODE(s.st_mode)==0o755,'SEALED_CONTEXT_DIRECTORY_CHANGED');actual_dirs.add(label)
        else:need(label in pins,'UNLISTED_CONTEXT_FILE');actual_files.add(label)
    need(actual_dirs==dirs and actual_files==set(pins),'SEALED_CONTEXT_CLOSURE_CHANGED')
    for name,row in pins.items():bytes_guard(Path(root)/name,row['sha256'],read,row['mode'])

def modern_guard(root,journal,records,read,databases):
    name=journal['name'];need(re.fullmatch('[a-z0-9][a-z0-9-]{0,120}',name),'EXACT_SEALED_NAMESPACE_REQUIRED')
    directory=Path(root)/(name+'-backup');s=facts(directory,True,0o700);backup=journal['codeBackups']
    actual={k:getattr(s,k) for k in ('st_dev','st_ino','st_uid','st_gid','st_mode')}
    need(set(backup)=={'directoryIdentity','sources','static'} and backup['directoryIdentity']==actual,'SEALED_CODE_BACKUP_DIRECTORY_CHANGED')
    source={r['target']:r['beforeSha256'] for r in records};static={str(Path('/opt/synapse/sites/synapse/cabinet/palitra-orders')/r['static']):r['beforeSha256'] for r in records if r.get('static') is not None}
    for kind,expected,prefix in [('sources',source,'source-'),('static',static,'static-')]:
        rows=backup[kind];need(type(rows) is list and len(rows)==len(expected) and {r['target']:r['sha256'] for r in rows}==expected,'SEALED_CODE_BACKUP_CLOSURE_CHANGED')
        for i,row in enumerate(rows):
            p=Path(row['path']);need(p==directory/(prefix+str(i)),'EXACT_SEALED_CODE_BACKUP_PATH_REQUIRED');bytes_guard(p,row['sha256'],read)
    need(set(journal['backups'])=={'content','report','traffic'},'THREE_SEALED_DATABASE_BACKUPS_REQUIRED')
    identity=[s.st_dev,s.st_ino,s.st_uid,s.st_gid,stat.S_IMODE(s.st_mode)]
    for key,stem in [('report','reports'),('content','content'),('traffic','traffic')]:
        row=journal['backups'][key];need(row['bridgeBackupDirectoryIdentity']==identity,'SEALED_DATABASE_BACKUP_DIRECTORY_CHANGED')
        if row.get('status')!='ABSENT':
            p=Path(row['path']);need(p.parent==directory and re.fullmatch(stem+r'(?:-refresh-[1-9][0-9]{0,3})?[.]sqlite',p.name),'EXACT_SEALED_DATABASE_BACKUP_PATH_REQUIRED')
        databases[key].backup_guard(row)
    context_guard(Path(root)/(name+'-context'),journal['contextPins'],read)
    need(read(Path(root)/(name+'-context/image.id')).decode('ascii').strip()==journal['childImage'],'SEALED_CONTEXT_IMAGE_ID_CHANGED')
    for target in static:need(not os.path.lexists(Path(target).with_name('.'+name+'-'+Path(target).name+'.pending')),'SEALED_STATIC_PENDING_EXISTS')

def legacy_workspace_guard(root,journal,records,read,databases):
    """Pinned workspace/notify completed format with explicit static/backups."""
    name=journal['name'];need(re.fullmatch('[a-z0-9][a-z0-9-]{0,120}',name),'EXACT_SEALED_NAMESPACE_REQUIRED')
    context=Path(root)/(name+'-context');facts(context,True,0o700)
    wanted={'Dockerfile':sha(('FROM '+name+'-base\nCOPY app/ /app/\n').encode())}
    wanted.update({'app/'+r['target']:r['sha256'] for r in records});wanted.update({'static/'+str(i):r['sha256'] for i,r in enumerate(journal['static'])})
    dirs={'app','static'}|{str(p) for key in wanted for p in PurePosixPath(key).parents if str(p)!='.'}
    actual={};seen_dirs=set();image_seen=False
    for p in context.rglob('*'):
        label=p.relative_to(context).as_posix();s=facts(p,directory=p.is_dir())
        if p.is_dir():need(label in dirs and stat.S_IMODE(s.st_mode)==(0o700 if label=='static' else 0o755),'SEALED_LEGACY_CONTEXT_DIRECTORY_CHANGED');seen_dirs.add(label)
        elif label=='image.id':need(stat.S_IMODE(s.st_mode) in (0o600,0o644) and read(p).decode('ascii').strip()==journal['childImage'],'SEALED_LEGACY_CONTEXT_IMAGE_CHANGED');image_seen=True
        else:
            need(label in wanted and sha(read(p))==wanted[label],'SEALED_LEGACY_CONTEXT_CHANGED');actual[label]=wanted[label]
    need(image_seen and actual==wanted and seen_dirs==dirs and sha(json.dumps(sorted(actual.items()),separators=(',',':')).encode())==journal['contextSha256'],'SEALED_LEGACY_CONTEXT_CLOSURE_CHANGED')
    for target,row in journal['sourceModes'].items():facts(context/'app'/target,mode=row['mode'])
    directory=Path(root)/(name+'-backup');s=facts(directory,True,0o700);need(journal['backupIdentity']==[s.st_dev,s.st_ino,s.st_uid],'SEALED_LEGACY_BACKUP_DIRECTORY_CHANGED')
    existing={r['target']:r.get('beforeSourceSha256',r.get('beforeSha256')) for r in records if r.get('beforeSourceSha256',r.get('beforeSha256')) is not None}
    need(len(journal['sourceBackups'])==len(existing) and {r['target']:r['baseSha256'] for r in journal['sourceBackups']}==existing,'SEALED_LEGACY_SOURCE_BACKUP_CLOSURE_CHANGED')
    static={str(Path('/opt/synapse/sites/synapse/cabinet/palitra-orders')/r['static']):r for r in records if r.get('static') is not None}
    need(len(journal['static'])==len(static) and {r['target'] for r in journal['static']}==set(static),'SEALED_LEGACY_STATIC_BACKUP_CLOSURE_CHANGED')
    wanted_files={'reports.sqlite','content.sqlite'}
    for key,field,stem in [('report','reportDatabaseBackup','reports'),('content','contentDatabaseBackup','content'),('traffic','trafficDatabaseBackup','traffic')]:
        row=journal[field];databases[key].backup_guard(row)
        if row.get('status')!='ABSENT':need(Path(row['path'])==directory/(stem+'.sqlite'),'SEALED_LEGACY_DB_BACKUP_PATH_CHANGED');wanted_files.add(stem+'.sqlite')
    for row in journal['static']:
        record=static[row['target']];need(row['baseSha256']==record['beforeSha256'] and row['sha256']==record['sha256'] and (row['backup'] is None)==(row['baseSha256'] is None),'SEALED_LEGACY_STATIC_RECORD_CHANGED')
    for row in journal['sourceBackups']+journal['static']:
        if row['backup'] is None:continue
        p=Path(row['backup']);need(p.parent==directory,'SEALED_LEGACY_BACKUP_PATH_CHANGED');wanted_files.add(p.name);bytes_guard(p,row['baseSha256'],read)
    need({p.name for p in directory.iterdir()}==wanted_files,'SEALED_LEGACY_BACKUP_DIRECTORY_CLOSURE_CHANGED')
