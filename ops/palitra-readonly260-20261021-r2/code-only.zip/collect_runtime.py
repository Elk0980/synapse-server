"""New collector core. Never invokes old inspect/Native construction/stable.

Only an independently closed factory may construct this context. The factory
must supply the actual bounded read transport, byte-pinned history and static
reducer. No default/pass-through guards are supplied by this module.
"""
import copy,hashlib,json,re,stat,time
from pathlib import Path

IMAGE='sha256:951db09e9e6c4781350bbced7e7a9e4ef099077a368e38a6b1fac40e0a4a6a22'
MANAGED_SHA='2676eea3de58aa150bcd8782005b6a1f51571f03ceb8dc2ea6f6f1804cace86d'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def need(v,c):
    if not v:raise ValueError(c)
def capture(context):
    """Actual reads, same exact full snapshot shape as the installed journal.

    Mandatory context is intentionally explicit; this is not yet a CLI or an
    admission adapter. An absent factory/history/static closure must refuse.
    """
    required={'native','backend','account','receipt','sourcePins','staticPins','staticModes','managed_guard','history_guard','storage_guard','image_guard','push_guard','database_guard','lease','decode','flagsScript','read','canonical_host_config'}
    need(type(context) is dict and set(context)==required,'EXACT_CLOSED_READONLY_CONTEXT_REQUIRED')
    n,b,a=(context[x] for x in ('native','backend','account'));receipt=context['receipt']
    after=receipt['after'];need(receipt['childImage']==IMAGE and len(context['sourcePins'])==240 and len(context['staticPins'])==len(context['staticModes'])==43,'EXACT_INSTALLED240_43_GUARD_REQUIRED')
    for method in ('__init__','stable','build','up','apply','backup'):
        need(method not in type(n).__dict__,'OLD_NATIVE_WRITER_OR_CONSTRUCTOR_REFUSED')
    context['lease']();context['history_guard']();context['managed_guard']();context['storage_guard']()
    first=snapshot(context);need(first==after,'EXACT_INSTALLED_FULL240_43_49_SNAPSHOT_REQUIRED')
    databases=context['database_guard'](receipt['minimumBeforeUp'])
    context['history_guard']();context['managed_guard']();context['storage_guard']();context['lease']()
    need(snapshot(context)==first,'RUNTIME_CHANGED_DURING_INSPECTION')
    databases=context['database_guard'](databases)
    context['history_guard']();context['managed_guard']();context['lease']()
    need(set(databases)=={'content','report','traffic'},'EXACT_THREE_DATABASE_CHECKS_REQUIRED')
    encoded=lambda value:json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
    seals={key:{'identity':row.get('identity'),'family':row.get('family'),'contentSha256':sha(encoded(row.get('content')))} for key,row in databases.items()}
    for name,table in databases['content']['content'].get('tables',{}).items():
        seals['content'].setdefault('tables',{})[name]={'count':table['count'],'rowMultisetSha256':sha(encoded(table['rows'])),'columnsSha256':sha(encoded(table['columns']))}
    seals['content']['schemaSha256']=databases['content']['content'].get('schemaSha256')
    return {'status':'EXACT_INSTALLED_GUARD_WITH_MANAGED260_READONLY','sourceFiles':240,'staticFiles':43,'chainFiles':49,'managedVersions':[257,259,260],'managedProofSha256':MANAGED_SHA,'currentDatabaseSeals':seals,'databaseCaptureSemantics':'CONSISTENT_PER_DB_READONLY_TRANSACTIONS_NOT_GLOBAL_ATOMIC_SNAPSHOT','runtimeWrites':0,'runtimeAdmission':False}

def snapshot(context,heartbeat=True):
    n,b,a=(context[x] for x in ('native','backend','account'));receipt=context['receipt'];after=receipt['after']
    overlay=Path(after['containers']['content']['files'][-1])
    need(overlay==Path('/opt/synapse/releases/palitra-app-20261015/palitra-clear-orders-guard-20261020-r1-overlay.json'),'EXACT_GUARD49_OVERLAY_REQUIRED')
    metadata=n._metadata(IMAGE,overlay,receipt['plannedConfigHash'])
    worker=b.worker_facts();selected={s:a.selected(s) for s in ('content','chat')}
    flags=context['decode'](n.run(['docker','exec','synapse-content-1','node','-e',context['flagsScript']]))
    need(worker==after['worker'] and selected==after['selected'] and flags==after['l12'],'WORKER_FLAGS_SELECTION_CHANGED')
    if heartbeat:need(b.heartbeat(worker['startedAt'],time.time())['freshAfterWorkerStart'] is True,'FRESH_EXISTING_WORKER_HEARTBEAT_REQUIRED')
    for service,row in metadata.items():need(re.fullmatch(re.escape(service)+r'\s+'+re.escape(row['configHash']),n.run(b._resolve_command(row,service)).decode().strip()) is not None,'RESOLVED_COMPOSE_HASH_CHANGED')
    b.graph(new=True)
    tree=n._tree();need(tree==after['runtime']['appTree'],'FULL_APP_TREE_CHANGED')
    source_modes={}
    for name,pin in context['sourcePins'].items():
        row=tree[name];need(row.get('type')=='file' and row.get('sha256')==pin and row.get('uid')==row.get('gid')==0 and row.get('nlink')==1 and row.get('mode') in (0o600,0o644),'EXACT_FULL240_SOURCE_FACTS_REQUIRED')
        source_modes[name]={k:row[k] for k in ('uid','gid','mode')}
    static_modes={}
    for name,pin in context['staticPins'].items():
        path=Path(name);s=path.lstat();raw=context['read'](path)
        need(stat.S_ISREG(s.st_mode) and not path.is_symlink() and s.st_nlink==1 and s.st_uid==s.st_gid==0 and stat.S_IMODE(s.st_mode)==context['staticModes'][name] and sha(raw)==pin,'FULL43_PRIVATE_STATIC_CHANGED')
        z=path.lstat();need((s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)==(z.st_dev,z.st_ino,z.st_size,z.st_mtime_ns,z.st_ctime_ns),'STATIC_CHANGED_DURING_READ')
        static_modes[name]=stat.S_IMODE(s.st_mode)
    cid=n.run(['docker','inspect','--format','{{.Id}}','synapse-content-1']).decode().strip();need(cid==after['contentCid'],'EXACT_CONTENT_CID_REQUIRED')
    runtime=n._runtime(IMAGE,metadata,cid);runtime['appTree']=tree
    context['image_guard']();context['push_guard']()
    return {'containers':metadata,'worker':worker,'selected':selected,'l12':flags,'contentCid':cid,'sourceModes':source_modes,'staticModes':static_modes,'runtime':runtime}

def runtime_cas(context,managed_cas_guard):
    # Narrow read-only CAS: deliberately no storage/three-DB/heartbeat/health.
    required={'native','backend','account','receipt','sourcePins','staticPins','staticModes','managed_guard','history_guard','storage_guard','image_guard','push_guard','database_guard','lease','decode','flagsScript','read','canonical_host_config'}
    need(type(context) is dict and set(context)==required,'EXACT_CLOSED_READONLY_CONTEXT_REQUIRED')
    need(context['receipt']['childImage']==IMAGE and len(context['sourcePins'])==240 and len(context['staticPins'])==len(context['staticModes'])==43,'EXACT_INSTALLED240_43_GUARD_REQUIRED')
    for method in ('__init__','stable','build','up','apply','backup'):
        need(method not in type(context['native']).__dict__,'OLD_NATIVE_WRITER_OR_CONSTRUCTOR_REFUSED')
    context['lease']();context['history_guard']()
    first=snapshot(context,heartbeat=False)
    need(first==context['receipt']['after'],'EXACT_INSTALLED_FULL240_43_49_SNAPSHOT_REQUIRED')
    managed=managed_cas_guard()
    context['history_guard']();context['lease']()
    need(snapshot(context,heartbeat=False)==first,'RUNTIME_CHANGED_DURING_INSPECTION')
    context['history_guard']();context['lease']()
    need(managed['databaseOpenCount']==1 and managed['existingWal'] is True and managed['revisionOrDocumentScans']==0 and managed['runtimeWrites']==0,'EXACT_NARROW_MANAGED_CAS_REQUIRED')
    return {'status':'EXACT_INSTALLED_GUARD_WITH_MANAGED260_RUNTIME_CAS_R2','sourceFiles':240,'staticFiles':43,'chainFiles':49,'managedVersions':[257,259,260],'managedProofSha256':MANAGED_SHA,'managedPointerCas':managed,'runtimeWrites':0,'runtimeAdmission':False,'fullInspection':False,'databaseCaptureSemantics':'ONE_READONLY_QUERY_ONLY_CONTENT_CONNECTION_EXISTING_WAL_CURRENT_MANAGED_POINTER_ONLY_CALLER_MUST_HOLD_WRITER_TRANSACTION'}
