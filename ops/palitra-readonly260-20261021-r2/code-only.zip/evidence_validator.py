"""Pure validators only. NO CLI/collector/runtime admission/old executable imports.

This cannot be substituted for LIVE_ENTRY_R6.native_inspect. A separately reviewed
fresh runtime collector remains required before any cleanup adapter can use it.
"""
import hashlib, json

IMAGE='sha256:951db09e9e6c4781350bbced7e7a9e4ef099077a368e38a6b1fac40e0a4a6a22'
SHA={'guardReceipt':'34ce6389ef04a5db158d5b1a27734e2d09c919df28b35a9dad4561af48d42892',
     'guardDecision':'e57ab17a927f10629755ac1d22b05f5b4286a859b369d0740c29834fa9428de8',
     'guardAcceptance':'442975bc079ece34d50cbec60eb3b7f4499bd7885fb96faf463623aa41804fc7',
     'guardPreflight':'43fbfab4a8075de2d81b439dc3e6f0a2e11a494c2cab63497e130177c09235c3'}
sha=lambda b:hashlib.sha256(b).hexdigest()
def need(v,c):
    if not v: raise ValueError(c)
def history(raw_artifacts,exact_pins=SHA):
    need(set(raw_artifacts)==set(exact_pins),'EXACT_HISTORICAL_ARTIFACT_SET_REQUIRED')
    for k,pin in exact_pins.items():need(sha(raw_artifacts[k])==pin,'HISTORICAL_ARTIFACT_CHANGED')
    r,d,a,p=(json.loads(raw_artifacts[k]) for k in ['guardReceipt','guardDecision','guardAcceptance','guardPreflight'])
    need(r['phase']=='APPLIED_NOT_CUSTOMER_ACCEPTANCE' and r['childImage']==IMAGE and r['decisionSha256']==exact_pins['guardDecision'],'EXACT_INSTALLED_GUARD_RECEIPT_REQUIRED')
    need(r['binding']==d['binding']==p['binding'] and r['before']==d['before']==p['before'],'HISTORICAL_BINDING_CHANGED')
    need(d['rootAcceptanceSha256']==exact_pins['guardAcceptance'] and d['preflightSha256']==exact_pins['guardPreflight'] and a['preflightSha256']==exact_pins['guardPreflight'],'HISTORICAL_ADMISSION_LINK_CHANGED')
    need(a['nonce']==d['nonce'] and a['oneApply'] is True and a['leasePid']==r['binding']['leasePid'],'HISTORICAL_ONE_APPLY_LINK_CHANGED')
    need(r['runtimeDatabaseWrites']==r['schemaChanges']==0 and r['workerRecreated'] is False and r['automaticRetry'] is False and r['automaticRollback'] is False,'HISTORICAL_EFFECT_SCOPE_CHANGED')
    return r
def runtime_snapshot(receipt,observed):
    expected=receipt['after'];need(observed==expected,'FULL_RUNTIME_SNAPSHOT_CHANGED')
    need(observed['containers']['content']['image']==IMAGE and len(observed['containers']['content']['files'])==len(set(observed['containers']['content']['files']))==49,'FULL_CHAIN49_REQUIRED')
    need(len(observed['sourceModes'])==240 and len(observed['staticModes'])==43,'FULL240_43_REQUIRED')
    tree=observed['runtime']['appTree']
    for name,facts in observed['sourceModes'].items():
        row=tree[name];need(row['type']=='file' and row['nlink']==1 and all(row[k]==facts[k] for k in ('uid','gid','mode')) and row['uid']==row['gid']==0,'FULL_SOURCE_FACTS_CHANGED')
    return True
def database_minima(old,new,content_migration):
    need(set(old)==set(new)=={'content','report','traffic'},'EXACT_THREE_DB_REQUIRED')
    for key in ('content','report'):need(old[key]['identity']==new[key]['identity'],'DB_IDENTITY_CHANGED')
    need(old['content']['content']['schemaSha256']==new['content']['content']['schemaSha256']==content_migration['afterSchemaSha256'] and new['content']['identity']==content_migration['identity'],'CONTENT_SCHEMA_OR_MIGRATION_CHANGED')
    before,after=old['report']['content'],new['report']['content']
    need(before['schemaSha256']==after['schemaSha256'] and set(before['history'])<=set(after['history']) and set(before['imports'])<=set(after['imports']),'REPORT_OLD_HISTORY_LOST')
    need(set(before['cache'])==set(after['cache'])=={'alvi','avokado'},'REPORT_COMPANIES_CHANGED')
    for company,o in before['cache'].items():
        n=after['cache'][company];need(n['revision']>=max(3,o['revision']) and o['rowSha256'] in after['history'] and (n['revision']!=o['revision'] or n==o),'REPORT_REVISION_OR_ROW_CHANGED')
    a,b=old['traffic'],new['traffic'];need(a['directoryIdentity']==b['directoryIdentity'],'TRAFFIC_DIRECTORY_REPLACED')
    if a['status']=='EXISTING':
        need(b['status']=='EXISTING' and a['identity']==b['identity'],'TRAFFIC_DB_REPLACED')
        o,n=a['content'],b['content']
        if o['status']!='EMPTY':need(n['status']=='INITIALIZED' and o['schemaSha256']==n['schemaSha256'] and o['enabledAt']==n['enabledAt'] and n['revision']>=o['revision'] and n['lastAt']>=o['lastAt'] and n['checkedPrefixRevision']==o['revision'] and n['checkedPrefixSha256']==o['eventsSha256'],'TRAFFIC_COUNTER_OR_PREFIX_CHANGED')
    return True
def validate_external_proofs(receipt,managed,observed,db_before,db_after,migration):
    need(managed['status']=='MANAGED260_CAPTURED_NOT_RUNTIME_INSPECTION' and managed['runtimeWrites']==0 and managed['current260']['version']==260,'EXACT_MANAGED260_CAPTURE_REQUIRED')
    runtime_snapshot(receipt,observed);database_minima(db_before,db_after,migration)
    return {'status':'EXTERNAL_PROOFS_VALIDATED_NOT_FRESH_RUNTIME_INSPECTION','sourceFiles':240,'staticFiles':43,'chainFiles':49,'managedVersions':[257,259,260],'runtimeWrites':0,'runtimeAdmission':False,'freshRuntimeCollector':'MISSING_NOT_AUTHORIZED_FOR_CLEANUP'}
