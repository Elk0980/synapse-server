"""Staged code only. Disabled admission cannot open SQLite or invoke native code.

No enabled admission is supplied. Root must review, stage privately, capture the
new installed guard and backup/copy proofs, then obtain action-time confirmation.
"""
import argparse
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import re
import sqlite3
import stat
import subprocess
import sys
import time
import types
from datetime import datetime, timezone

# Own adapter is compiled only after private read+SHA validation in main.
# Importing an unverified sibling must not precede disabled admission checks.
ADAPTER = None
def validate_inspector_result(*args, **kwargs):
    need(ADAPTER is not None,'VERIFIED_ADAPTER_NOT_LOADED')
    return ADAPTER.validate_inspector_result(*args, **kwargs)
def invoke_inspector(*args, **kwargs):
    need(ADAPTER is not None,'VERIFIED_ADAPTER_NOT_LOADED')
    return ADAPTER.invoke_inspector(*args, **kwargs)
def compare_stable(*args, **kwargs):
    need(ADAPTER is not None,'VERIFIED_ADAPTER_NOT_LOADED')
    return ADAPTER.compare_stable(*args, **kwargs)
def capture_epoch(*args, **kwargs):
    need(ADAPTER is not None,'VERIFIED_ADAPTER_NOT_LOADED')
    return ADAPTER.capture_epoch(*args, **kwargs)

ROOT = Path('/opt/synapse/releases/palitra-app-20261015')
DATABASE = Path('/var/lib/docker/volumes/synapse_content_data/_data/content.sqlite')
LOCK = '/opt/synapse/.palitra-app-release.lock'
GUARD = 'palitra-clear-orders-guard-20261020-r1'
GUARD_CODE = ROOT / (GUARD + '-code')
COPY_NAMESPACE = 'palitra-order-cleanup-copy-20261021-r10'
COPY_MANIFEST_SHA = 'cc30b814fa4ec3fc9391d6114ee118bd7afe8639d34829db88f8bdebc1b3aaef'
COPY_CODE_FILES = {
    'COPY_ONLY_MANIFEST.json': COPY_MANIFEST_SHA,
    'LOCAL_CODE_PINS.json': '556cff84fb6c8aff6ee00e3f77c903588f7cd29e217bc11d43ebde3a5c377b85',
    'cleanup_runtime.py': '6bd4b9f29ff1ffd4e553750d43df437444b5651485748e1eeca82163c8259861',
    'copy_prepare.py': '8d96092beec7779de66eba919f6beb95c8bef42b173c4a0ed7db6c69d5dbb748',
    'live_entry.py': '16600560cef5f63f6e799113cebafff2164b3e765472bc4d46c1bdfc8c656935',
    'prepare_preview.py': '69197d0c9e14cd794a9c5e4c45d81f20c49084cea5183cd8192b3a7ca9df5284',
}
PARENT_IMAGE = 'sha256:5409d279f90c3b2a64315e16c11bf9f192094b9234980c1f0b066bb7774d1c58'
ARTIFACTS = frozenset(('guardReceipt', 'guardDecision', 'guardPreflight', 'guardAcceptance',
                      'runtimeInspection', 'copyOnlyReceipt', 'productTests', 'backupProof', 'diskProbe', 'preview', 'dryrun', 'userApproval'))
sha = lambda raw: hashlib.sha256(raw).hexdigest()
digest = lambda s: type(s) is str and re.fullmatch('[a-f0-9]{64}', s) is not None
need = lambda ok, code: None if ok else refuse(code)

def refuse(code):
    raise ValueError(code)

def exact(obj, fields, code):
    need(type(obj) is dict and set(obj) == set(fields), code)

def epoch(value):
    need(type(value) is str and value.endswith('Z'), 'UTC_REQUIRED')
    try:
        result = datetime.fromisoformat(value[:-1] + '+00:00').timestamp()
    except ValueError:
        refuse('UTC_REQUIRED')
    return result

def fresh(value, now, bound=900):
    return 0 <= now - epoch(value) <= bound

def validate_copy_dependency(pins):
    dependency=pins.get('copyPreparation')
    need(type(dependency) is dict and set(dependency)=={'namespace','manifestSha256','files','privateArea'}
         and dependency['namespace']==COPY_NAMESPACE and dependency['manifestSha256']==COPY_MANIFEST_SHA
         and dependency['files']==COPY_CODE_FILES,'EXACT_COPY_R10_CLOSED_SIX_CODE_DEPENDENCY_REQUIRED')
    need(type(dependency['privateArea']) is str
         and Path(dependency['privateArea']).parent==ROOT
         and re.fullmatch(re.escape(COPY_NAMESPACE)+'-[a-f0-9]{32}',Path(dependency['privateArea']).name),
         'EXACT_ROOT_REVIEWED_COPY_R10_PRIVATE_AREA_REQUIRED')

def validate_admission(a, pins, now):
    need(type(a) is dict and a.get('enabled') is True, 'DISABLED_NO_RUNTIME_AUTHORIZATION')
    exact(a, ('schema','enabled','namespace','site','companyCode','serverId','account',
        'entrySha256','codePinsSha256','engineSha256','guardImage','scopeSha256','snapshotSha256',
        'artifacts','lease','nonce','issuedAtUtc','expiresAtUtc','oneApply','userActionTimeConfirmed',
        'inspectorManifestSha256','inspectorAdapterSha256'), 'CLOSED_ADMISSION_REQUIRED')
    need(a['schema'] == 2 and a['site'] == 'palitra' and a['companyCode'] == 'palitra-love'
         and a['serverId'] == 8936001 and a['account'] == 'sa133295', 'EXACT_COMPANY_SERVER_REQUIRED')
    need(type(a['namespace']) is str and re.fullmatch('palitra-order-cleanup-20261021-r11-[a-z0-9-]{8,48}', a['namespace']), 'NEW_CLEANUP_NAMESPACE_REQUIRED')
    inspector=pins.get('inspector')
    need(type(inspector) is dict and inspector.get('enabled') is True
         and digest(inspector.get('manifestSha256')) and digest(inspector.get('entrySha256'))
         and a['inspectorManifestSha256']==inspector['manifestSha256']
         and digest(a['inspectorAdapterSha256']) and a['inspectorAdapterSha256']==pins.get('inspectorAdapterSha256'), 'INSPECTOR_DEPENDENCY_NOT_BOUND')
    validate_copy_dependency(pins)
    need(all(digest(a[k]) for k in ('entrySha256','codePinsSha256','engineSha256','scopeSha256','snapshotSha256'))
         and a['engineSha256'] == pins['engineSha256'], 'EXACT_REVIEWED_CODE_AND_SCOPE_REQUIRED')
    need(type(a['guardImage']) is str and re.fullmatch('sha256:[a-f0-9]{64}', a['guardImage'])
         and a['guardImage'] != PARENT_IMAGE, 'INSTALLED_NEW_GUARD_IMAGE_REQUIRED')
    need(a['oneApply'] is True and a['userActionTimeConfirmed'] is True, 'PERMANENT_ACTION_TIME_CONFIRMATION_REQUIRED')
    need(type(a['nonce']) is str and re.fullmatch('[a-f0-9]{32}', a['nonce']), 'FRESH_NONCE_REQUIRED')
    issued, expiry = epoch(a['issuedAtUtc']), epoch(a['expiresAtUtc'])
    need(0 <= now-issued <= 600 and now < expiry <= issued+600, 'EXPIRED_OR_FUTURE_ADMISSION')
    exact(a['artifacts'], ARTIFACTS, 'CLOSED_PRIVATE_ARTIFACT_SET_REQUIRED')
    for row in a['artifacts'].values():
        exact(row, ('path','sha256'), 'PINNED_PRIVATE_ARTIFACT_REQUIRED')
        need(type(row['path']) is str and digest(row['sha256']), 'PINNED_PRIVATE_ARTIFACT_REQUIRED')
    exact(a['lease'], ('pid','startTicks','lockPath'), 'EXACT_LEASE_BINDING_REQUIRED')
    need(type(a['lease']['pid']) is int and a['lease']['pid'] > 1 and a['lease']['pid'] not in
         (3284416,3308227,3336085,3367042,3401855,3462715,3471272,3471456,3471638) and a['lease']['lockPath'] == LOCK
         and type(a['lease']['startTicks']) is str and re.fullmatch('[1-9][0-9]*', a['lease']['startTicks']), 'FRESH_OWN_LEASE_REQUIRED')

def validate_evidence(a, pins, d, now):
    """Pure crosslinks. All supplied bytes must separately pass private read+SHA."""
    exact(d, ARTIFACTS, 'CLOSED_PRIVATE_ARTIFACT_SET_REQUIRED')
    r, decision, pre, accepted = (d[k] for k in ('guardReceipt','guardDecision','guardPreflight','guardAcceptance'))
    need(r.get('name') == GUARD and r.get('phase') == 'APPLIED_NOT_CUSTOMER_ACCEPTANCE'
         and r.get('childImage') == a['guardImage'] and r.get('automaticRetry') is False
         and r.get('automaticRollback') is False and r.get('runtimeDatabaseWrites') == r.get('schemaChanges') == 0,
         'EXACT_COMPLETED_GUARD_REQUIRED')
    need(r.get('decisionSha256') == a['artifacts']['guardDecision']['sha256']
         and decision.get('preflightSha256') == a['artifacts']['guardPreflight']['sha256']
         and decision.get('rootAcceptanceSha256') == a['artifacts']['guardAcceptance']['sha256']
         and accepted.get('preflightSha256') == decision.get('preflightSha256'), 'GUARD_HISTORY_PIN_CROSSLINK_CHANGED')
    binding = r.get('binding')
    need(type(binding) is dict and binding.get('namespace') == GUARD and binding.get('parentImage') == PARENT_IMAGE
         and binding.get('manifestSha256') == pins['guardManifestSha256'] and binding.get('entrySha256') == pins['guardEntrySha256']
         and decision.get('binding') == pre.get('binding') == binding and decision.get('before') == pre.get('before') == r.get('before')
         and accepted.get('namespace') == GUARD and accepted.get('oneApply') is True
         and accepted.get('nonce') == decision.get('nonce'), 'GUARD_HISTORICAL_BINDING_CHANGED')
    tree = r.get('after', {}).get('runtime', {}).get('appTree', {})
    need(all(tree.get(target, {}).get('sha256') == pin for target, pin in pins['guardSourcePins'].items()), 'FIVE_GUARD_SOURCES_NOT_EXACT')
    inspected = d['runtimeInspection']
    validate_inspector_result(inspected,a,pins,now)
    tests = d['productTests']
    need(tests.get('status') == 'ROOT_REVIEWED_CODE_TESTS_PASSED' and tests.get('sourcePins') == pins['guardSourcePins']
         and tests.get('backendTestsPassed') == 20 and tests.get('actualCatchRouteTestsPassed') == 3
         and tests.get('productTestsPassed') == 29 and tests.get('productionHttp410TestPerformed') is False,
         'EXACT_SOURCE_HTTP410_CODE_TEST_PROOF_REQUIRED')
    for label, status in (('preview','SQLITE_COPY_PREVIEW_NOT_ACCEPTANCE'), ('dryrun','SQLITE_COPY_DRYRUN_ROLLED_BACK_NOT_ACCEPTANCE')):
        doc = d[label]
        need(doc.get('status') == status and doc.get('scopeSha256') == a['scopeSha256']
             and doc.get('snapshotSha256') == a['snapshotSha256'] and doc.get('cleanupAcceptance') is False
             and doc.get('liveApplyEnabled') is False and fresh(doc.get('createdAtUtc'), now), 'PRIVATE_COPY_PROOF_NOT_EXACT_' + label.upper())
    preview, dryrun = d['preview'], d['dryrun']
    counts, target_ids = preview.get('targetCounts'), preview.get('targetInternalIds')
    need(type(counts) is dict and type(target_ids) is dict and counts == dryrun.get('targetCounts')
         and target_ids == dryrun.get('targetInternalIds')
         and preview.get('businessOutboxBeforeAudit') == dryrun.get('businessOutboxBeforeAudit')
         and all(type(n) is int and n >= 0 for n in counts.values())
         and type(counts.get('chat_thread_messages')) is int and type(counts.get('client_dialog_messages')) is int,
         'VERIFIED_PRIVATE_COPY_COUNTS_AND_IDS_REQUIRED')
    audit = preview.get('businessOutboxBeforeAudit', [])
    need(type(audit) is list and all(type(row) is dict and row.get('table') in ('site_order_outbox','client_bot_outbox') and type(row.get('id')) is int and digest(row.get('rowSha256')) and row.get('status') in ('sent','failed','error','uncertain') for row in audit), 'SEALED_BUSINESS_OUTBOX_AUDIT_REQUIRED')
    b = d['backupProof']
    need(b.get('status') == 'VERIFIED_PRIVATE_SQLITE_BACKUP' and b.get('databasePath') == str(DATABASE)
         and digest(b.get('backupSha256')) and type(b.get('backupPath')) is str
         and b.get('scopeSha256') == a['scopeSha256'] and b.get('snapshotSha256') == a['snapshotSha256']
         and b.get('schemaSha256') == d['preview'].get('schemaSha256') == d['dryrun'].get('schemaSha256')
         and b.get('guardImage') == a['guardImage'] and b.get('consistentCommittedWal') is True
         and b.get('quickCheck') == 'ok' and b.get('foreignKeyViolations') == 0
         and b.get('selectedMediaDiskCount') in (None,0) and b.get('privateRoot0600') is True
         and fresh(b.get('createdAtUtc'), now), 'PRIVATE_BACKUP_AND_DISK_SCOPE_NOT_EXACT')
    copy=d['copyOnlyReceipt']
    validate_copy_dependency(pins)
    copy_area=Path(a['artifacts']['copyOnlyReceipt']['path']).parent
    need(copy.get('schema')==1 and type(copy.get('schema')) is int and copy.get('namespace')==COPY_NAMESPACE
         and copy_area==Path(pins['copyPreparation']['privateArea'])
         and Path(a['artifacts']['copyOnlyReceipt']['path'])==copy_area/'COPY_ONLY.json'
         and all(Path(a['artifacts'][key]['path'])==copy_area/name for key,name in
                 [('backupProof','backup-proof.json'),('preview','preview.json'),('dryrun','dryrun.json')])
         and Path(b['backupPath'])==copy_area/'before.sqlite'
         and copy.get('inheritedPrepared')=={'path':str(copy_area/'PREPARED.json'),'status':'PRIVATE_COPY_PREPARED_NOT_ACTION_AUTHORIZATION'}
         and copy.get('fiveGuardSourcePins')==pins['guardSourcePins'] and digest(copy.get('fastRuntimeFingerprint'))
         and copy.get('cleanupAcceptance') is False and copy.get('automaticRetry') is False and copy.get('automaticRestore') is False,
         'EXACT_COPY_R10_RECEIPT_NAMESPACE_AND_PRIVATE_AREA_REQUIRED')
    need(copy.get('status')=='COPY_ONLY_NOT_RUNTIME_AUTHORIZATION' and copy.get('fullGuardAccepted') is False
         and copy.get('nativeInspectExecuted') is False and copy.get('deletionAdmissionCompatible') is False
         and copy.get('liveApplyEnabled') is False and copy.get('runtimeDatabaseWrites')==0
         and copy.get('sourceConnectionTotalChanges')==0 and copy.get('sourceQueryOnlyBeforeAfter') is True
         and copy.get('privateBackupDryrunFullRowsEqual') is True and copy.get('sourceScopeBeforeAfterEqual') is True
         and copy.get('scopeSha256')==a['scopeSha256'] and copy.get('snapshotSha256')==a['snapshotSha256']
         and copy.get('guardImage')==a['guardImage'] and copy.get('databaseIdentity')==b.get('databaseIdentity')
         and all(copy.get(k)==a['artifacts'][k] for k in ('preview','dryrun','backupProof'))
         and fresh(copy.get('createdAtUtc'),now), 'COPY_ONLY_IS_NOT_FULL_RUNTIME_ADMISSION')
    disk = d['diskProbe']
    need(disk.get('status') == 'ROOT_READONLY_SELECTED_MEDIA_DISK_CHECK_PASSED'
         and disk.get('scopeSha256') == a['scopeSha256'] and disk.get('guardImage') == a['guardImage']
         and disk.get('filesOnDiskChecked') is True and disk.get('selectedAttachments') == 0
         and disk.get('selectedUploads') == 0 and disk.get('selectedDiskFiles') == 0
         and fresh(disk.get('capturedAtUtc'),now), 'EXACT_SELECTED_MEDIA_DISK_PROOF_REQUIRED')
    exact(b.get('databaseIdentity'), ('dev','ino','uid','gid','mode'), 'EXACT_LIVE_DB_IDENTITY_REQUIRED')
    need(all(type(v) is int and v >= 0 for v in b['databaseIdentity'].values()) and b['databaseIdentity']['uid']==b['databaseIdentity']['gid']==0 and b['databaseIdentity']['mode']==0o644, 'EXACT_LIVE_DB_IDENTITY_REQUIRED')
    user = d['userApproval']
    need(user.get('status') == 'USER_CONFIRMED_PERMANENT_PALITRA_CLEANUP'
         and user.get('namespace') == a['namespace'] and user.get('nonce') == a['nonce']
         and user.get('scopeSha256') == a['scopeSha256'] and user.get('snapshotSha256') == a['snapshotSha256']
         and user.get('guardImage') == a['guardImage'] and user.get('backupSha256') == b['backupSha256']
         and user.get('dryrunSha256') == a['artifacts']['dryrun']['sha256'] and user.get('permanentDeleteConfirmed') is True
         and user.get('legacyIncluded') is True and user.get('orderIds') == [row['id'] for row in preview.get('orderMap',[])]
         and user.get('threadIds') == [row['id'] for row in preview.get('threadMap',[])] and user.get('webMessages') == counts['chat_thread_messages']
         and user.get('legacyDialogIds') == preview.get('legacyDialogIds') and user.get('legacyMessages') == counts['client_dialog_messages']
         and user.get('businessOutboxIds') == {'site':target_ids.get('site_order_outbox',[]),
                                              'client':target_ids.get('client_bot_outbox',[])}
         and user.get('uncertainBusinessOutboxIncluded') is True and user.get('encryptedPushAuditRetained') is True
         and user.get('previewSha256')==a['artifacts']['preview']['sha256']
         and user.get('runtimeInspectionSha256')==a['artifacts']['runtimeInspection']['sha256'],
         'EXACT_USER_ACTION_TIME_PERMANENT_SCOPE_REQUIRED')
    need(epoch(dryrun['createdAtUtc'])<=capture_epoch(inspected['capturedAtUtc'])<=epoch(user['createdAtUtc']), 'COPY_THEN_FRESH_INSPECT_THEN_CONFIRMATION_REQUIRED')
    times = [epoch(d[k]['createdAtUtc']) for k in ('backupProof','preview','dryrun','userApproval')]
    need(times == sorted(times) and times[-1] <= epoch(a['issuedAtUtc']) and fresh(user['createdAtUtc'], now, 600),
         'BACKUP_PREVIEW_DRYRUN_THEN_CONFIRMATION_REQUIRED')

def private_path(path, directory=False):
    path = Path(path)
    need(path.is_absolute() and path.is_relative_to(ROOT) and '..' not in path.parts, 'EXACT_PRIVATE_RELEASE_PATH_REQUIRED')
    for part in (path, *path.parents):
        need(not part.is_symlink(), 'PRIVATE_PATH_ALIAS_REFUSED')
        if part != path and part.is_relative_to(ROOT):
            parent = part.lstat()
            need(stat.S_ISDIR(parent.st_mode) and parent.st_uid == parent.st_gid == 0
                 and stat.S_IMODE(parent.st_mode) == (0o755 if part == ROOT else 0o700), 'PRIVATE_PARENT_DIRECTORY_REQUIRED')
    s = path.lstat()
    need(s.st_uid == s.st_gid == 0 and stat.S_IMODE(s.st_mode) == ((0o755 if path == ROOT else 0o700) if directory else 0o600)
         and (stat.S_ISDIR(s.st_mode) if directory else stat.S_ISREG(s.st_mode) and s.st_nlink == 1), 'PRIVATE_ROOT_MODE_REQUIRED')
    return path

def private_read(path, pin=None, limit=4*1024*1024):
    path = private_path(path)
    s = path.lstat()
    need(s.st_size <= limit, 'BOUNDED_PRIVATE_FILE_REQUIRED')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'rb') as stream:
        before = os.fstat(stream.fileno()); raw = stream.read(limit+1); after = os.fstat(stream.fileno())
    final = path.lstat()
    fields = ('st_dev','st_ino','st_uid','st_gid','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
    need(len(raw) == s.st_size and all(getattr(s,k) == getattr(before,k) == getattr(after,k) == getattr(final,k) for k in fields), 'PRIVATE_FILE_CHANGED_DURING_READ')
    need(pin is None or digest(pin) and sha(raw) == pin, 'PRIVATE_FILE_SHA_CHANGED')
    return raw

def copy_code_guard(pins, reader, directory_guard, names):
    """Read the exact staged6; never import or execute a copy runner.

    CopyR10's historical receipt has no code-manifest field. Its bytes remain
    unchanged. Root binds that receipt separately; this additional gate checks
    the actual closed staged code rather than inventing a receipt field.
    """
    validate_copy_dependency(pins);code=ROOT/(COPY_NAMESPACE+'-code')
    directory_guard(code,True)
    need(set(names(code))==set(COPY_CODE_FILES),'EXACT_COPY_R10_STAGED_SIX_FILES_REQUIRED')
    raw=reader(code/'COPY_ONLY_MANIFEST.json',COPY_MANIFEST_SHA)
    need(sha(raw)==COPY_MANIFEST_SHA,'EXACT_COPY_R10_MANIFEST_SHA_REQUIRED');manifest=json.loads(raw)
    need(type(manifest) is dict and set(manifest)=={'schema','namespace','status','runtimeAuthorization','fullGuardAccepted','liveApplyEnabled','files'}
         and type(manifest['schema']) is int and manifest['schema']==1 and manifest['namespace']==COPY_NAMESPACE
         and manifest['status']=='CODE_ONLY_NOT_RUNTIME_AUTHORIZATION' and manifest['runtimeAuthorization'] is False
         and manifest['fullGuardAccepted'] is False and manifest['liveApplyEnabled'] is False
         and type(manifest['files']) is dict and set(manifest['files'])==set(COPY_CODE_FILES)-{'COPY_ONLY_MANIFEST.json'},
         'EXACT_COPY_R10_MANIFEST_CONTRACT_REQUIRED')
    for name,row in manifest['files'].items():
        need(type(row) is dict and set(row)=={'bytes','sha256'} and type(row['bytes']) is int and row['bytes']>0
             and row['sha256']==COPY_CODE_FILES[name],'EXACT_COPY_R10_MANIFEST_MEMBER_REQUIRED')
        value=reader(code/name,row['sha256'])
        need(len(value)==row['bytes'] and sha(value)==row['sha256'],'EXACT_COPY_R10_STAGED_MEMBER_BYTES_REQUIRED')
    directory_guard(code,True)
    need(set(names(code))==set(COPY_CODE_FILES) and sha(reader(code/'COPY_ONLY_MANIFEST.json',COPY_MANIFEST_SHA))==COPY_MANIFEST_SHA,
         'COPY_R10_STAGED_PACKAGE_CHANGED_DURING_READ')

def sqlite_file_sha(path):
    path = Path(path)
    before = path.lstat()
    need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and before.st_size <= 2*1024*1024*1024, 'BACKUP_BOUND')
    flags = os.O_RDONLY | getattr(os,'O_NOFOLLOW',0) | getattr(os,'O_NONBLOCK',0)
    fd = os.open(path,flags)
    h = hashlib.sha256()
    with os.fdopen(fd,'rb') as stream:
        first = os.fstat(stream.fileno())
        for chunk in iter(lambda:stream.read(1024*1024),b''):
            h.update(chunk)
        after = os.fstat(stream.fileno())
    final = path.lstat()
    fields = ('st_dev','st_ino','st_size','st_mtime_ns','st_ctime_ns','st_uid','st_gid','st_mode','st_nlink')
    # Windows reports creation/ctime differently through path and open handle.
    # Runtime is POSIX-only and keeps the complete comparison; synthetic copies
    # on Windows still compare each ctime against the same observation surface.
    if os.name == 'nt':
        need(before.st_ctime_ns == final.st_ctime_ns and first.st_ctime_ns == after.st_ctime_ns, 'PRIVATE_BACKUP_CHANGED')
        fields = tuple(k for k in fields if k != 'st_ctime_ns')
    need(all(getattr(before,k) == getattr(first,k) == getattr(after,k) == getattr(final,k) for k in fields), 'PRIVATE_BACKUP_CHANGED')
    return h.hexdigest()

class BoundedCapture(io.StringIO):
    def write(self, value):
        need(self.tell()+len(value) <= 65536, 'NATIVE_INSPECT_OUTPUT_BOUND')
        return super().write(value)

class Runtime:
    def __init__(self, a, pins, entry_path, admission_path, admission_pin):
        self.a, self.pins, self.entry_path = a, pins, entry_path
        self.admission_path, self.admission_pin = admission_path, admission_pin

    def artifacts(self):
        docs = {}
        historical = {'guardReceipt':'journal','guardDecision':'decision','guardPreflight':'preflight','guardAcceptance':'root-acceptance'}
        for key, row in self.a['artifacts'].items():
            if key in historical:
                need(Path(row['path']) == ROOT / (GUARD + '-' + historical[key] + '.json'), 'EXACT_GUARD_HISTORY_PATH_REQUIRED')
            docs[key] = json.loads(private_read(row['path'], row['sha256']))
        return docs

    def lease(self):
        lease = self.a['lease']
        result = subprocess.run(['lslocks','--noheadings','--output','PID,PATH'], check=True, capture_output=True, timeout=10)
        need(len(result.stdout) <= 1024*1024 and not result.stderr, 'BOUNDED_LEASE_OBSERVATION_REQUIRED')
        rows = [r.strip().split(maxsplit=1) for r in result.stdout.decode().splitlines()]
        need([r for r in rows if len(r) == 2 and r[1] == LOCK] == [[str(lease['pid']), LOCK]], 'EXACT_FRESH_OWN_LEASE_NOT_HELD')
        proc = Path('/proc') / str(lease['pid']) / 'stat'
        need(proc.stat().st_size <= 8192, 'PROCESS_STATE_BOUND')
        need(proc.read_text().rsplit(') ',1)[1].split()[19] == lease['startTicks'], 'LEASE_PROCESS_REUSED')

    def native_inspect(self):
        # A separately reviewed R2 collector, never the old installed guard entry.
        result=invoke_inspector(self.a,self.pins,private_read,private_path)
        validate_inspector_result(result,self.a,self.pins,time.time())
        prior=self.artifacts()['runtimeInspection']
        # Both full results independently check current 3DB semantic guards.
        # Their dynamic row seals differ legitimately; the existing engine
        # separately pins content against its exact private backup under BEGIN.
        validate_inspector_result(prior,self.a,self.pins,time.time())
        compare_stable(prior,result)

    def command(self, args):
        result = subprocess.run(args,check=True,capture_output=True,timeout=10)
        need(len(result.stdout)<=4*1024*1024 and not result.stderr,'BOUNDED_FAST_RUNTIME_READ_REQUIRED')
        return json.loads(result.stdout)

    def fast_snapshot(self):
        rows = self.command(['docker','inspect','synapse-content-1'])
        need(type(rows) is list and len(rows)==1,'EXACT_CONTENT_CONTAINER_REQUIRED')
        row=rows[0];state=row.get('State',{});mounts=row.get('Mounts',[])
        need(type(row.get('Id')) is str and re.fullmatch('[a-f0-9]{64}',row['Id'])
             and row.get('Image')==self.a['guardImage'] and state.get('Running') is True
             and state.get('Restarting') is False and state.get('OOMKilled') is False
             and type(row.get('RestartCount')) is int and type(state.get('StartedAt')) is str,'FAST_CONTENT_IMAGE_OR_VERSION_CHANGED')
        data=[r for r in mounts if r.get('Destination')=='/data']
        need(len(data)==1 and data[0].get('Type')=='volume' and data[0].get('Name')=='synapse_content_data'
             and data[0].get('Source')==str(DATABASE.parent) and data[0].get('RW') is True,'FAST_CONTENT_MOUNT_CHANGED')
        targets=sorted(self.pins['guardSourcePins'])
        need(set(targets)=={'server.js','site-orders.js','palitra-orders-public/shell.js',
              'palitra-orders-public/shop.html','palitra-orders-public/cabinet.html'},'EXACT_FIVE_SOURCE_PINS_REQUIRED')
        js="""const f=require('node:fs'),c=require('node:crypto'),out={};
const names=JSON.parse(process.argv[1]);if(f.realpathSync('/app')!=='/app')throw Error('APP_ALIAS');
for(const n of names){const p='/app/'+n,s=f.lstatSync(p);if(!s.isFile()||s.nlink!==1||s.size>2097152)throw Error('SOURCE_BOUND');
 const fd=f.openSync(p,f.constants.O_RDONLY|f.constants.O_NOFOLLOW);try{const a=f.fstatSync(fd),raw=f.readFileSync(fd),z=f.fstatSync(fd),q=f.lstatSync(p);
 for(const k of ['dev','ino','mode','uid','gid','nlink','size','mtimeMs','ctimeMs'])if(s[k]!==a[k]||s[k]!==z[k]||s[k]!==q[k])throw Error('SOURCE_RACE');
 out[n]=c.createHash('sha256').update(raw).digest('hex');}finally{f.closeSync(fd);}}
process.stdout.write(JSON.stringify(out));"""
        need(self.command(['docker','exec','synapse-content-1','node','-e',js,json.dumps(targets)])==self.pins['guardSourcePins'],
             'FAST_FIVE_GUARD_SOURCES_CHANGED')
        stable={k:row.get(k) for k in ('Id','Image','Config','HostConfig','Mounts','ImageManifestDescriptor','RestartCount')}
        stable['Mounts']=sorted(mounts,key=lambda mount:json.dumps(mount,sort_keys=True,separators=(',',':')))
        stable['StartedAt']=state['StartedAt']
        return sha(json.dumps(stable,sort_keys=True,separators=(',',':')).encode())

    def full_guard_read(self):
        self.lease();before=self.fast_snapshot();self.native_inspect();self.lease()
        after=self.fast_snapshot();need(before==after,'RUNTIME_CHANGED_DURING_FULL_INSPECT')
        self.fast_basis=after

    def fast_guard_read(self):
        self.lease();need(self.fast_snapshot()==self.fast_basis,'CONTENT_CID_IMAGE_MOUNT_VERSION_CHANGED')
        row=self.a['artifacts']['guardReceipt']
        need(json.loads(private_read(row['path'],row['sha256'])).get('childImage')==self.a['guardImage'], 'GUARD_RECEIPT_IMAGE_CHANGED')

    def backup(self, proof, engine):
        path = private_path(proof['backupPath'])
        need(not any(Path(str(path)+suffix).exists() for suffix in ('-wal','-shm','-journal')), 'BACKUP_MUST_BE_SELF_CONTAINED')
        need(sqlite_file_sha(path) == proof['backupSha256'], 'PRIVATE_BACKUP_CHANGED')
        db = sqlite3.connect(path.as_uri()+'?mode=ro&immutable=1', uri=True)
        try:
            db.execute('PRAGMA foreign_keys=ON'); db.execute('PRAGMA query_only=ON')
            need(engine.plan(db)['scopeSha256'] == self.a['scopeSha256'], 'BACKUP_SCOPE_NOT_EXACT')
        finally:
            db.close()
        return path

    def private_evidence(self):
        need(json.loads(private_read(self.admission_path, self.admission_pin)) == self.a, 'ADMISSION_CHANGED')
        validate_admission(self.a, self.pins, time.time())
        d = self.artifacts(); validate_evidence(self.a, self.pins, d, time.time())
        need(json.loads(private_read(self.entry_path.parent/'LOCAL_CODE_PINS.json',self.a['codePinsSha256'])) == self.pins,
             'CODE_PINS_CHANGED')
        private_read(self.entry_path, self.a['entrySha256'])
        private_read(self.entry_path.parent / 'cleanup_runtime.py', self.a['engineSha256'])
        private_read(self.entry_path.parent / 'runtime_inspector_adapter.py', self.a['inspectorAdapterSha256'])
        copy_code_guard(self.pins,private_read,private_path,lambda directory:(p.name for p in directory.iterdir()))
        return d

    def current(self, engine):
        d=self.private_evidence();self.full_guard_read()
        return d, self.backup(d['backupProof'], engine)

    def fast_current(self, engine):
        d=self.private_evidence();self.fast_guard_read()
        # Caller has already verified its own BEGIN IMMEDIATE. This separate
        # frozen mode repeats full runtime files/managed/worker/Push CAS and
        # exactly one readonly/query_only actual pointer connection in WAL.
        # It is never represented as a full 3DB inspection.
        result=invoke_inspector(self.a,self.pins,private_read,private_path,mode='runtime-cas')
        validate_inspector_result(result,self.a,self.pins,time.time(),mode='runtime-cas')
        compare_stable(d['runtimeInspection'],result)
        self.fast_guard_read()
        path=private_path(d['backupProof']['backupPath'])
        need(sqlite_file_sha(path)==d['backupProof']['backupSha256'],'PRIVATE_BACKUP_CHANGED')
        return d,path

    def commit_current(self, engine):
        # No new SQLite connection at this gate. The writer transaction already
        # excludes other pointer writers and the engine checks exact post-rows.
        self.private_evidence();self.fast_guard_read()

    def open_database(self, proof):
        for part in (DATABASE, *DATABASE.parents):
            need(not part.is_symlink(), 'DATABASE_ALIAS_REFUSED')
        s = DATABASE.lstat()
        need(stat.S_ISREG(s.st_mode) and s.st_nlink == 1 and not stat.S_IMODE(s.st_mode) & 0o022, 'EXACT_LIVE_DB_FILE_REQUIRED')
        need({'dev':s.st_dev,'ino':s.st_ino,'uid':s.st_uid,'gid':s.st_gid,'mode':stat.S_IMODE(s.st_mode)} == proof['databaseIdentity'], 'LIVE_DB_IDENTITY_CHANGED')
        db = sqlite3.connect(DATABASE.as_uri()+'?mode=rw', uri=True)
        db.execute('PRAGMA foreign_keys=ON'); db.execute('PRAGMA busy_timeout=0')
        return db

    def claim(self, planned):
        path = ROOT / ('palitra-order-cleanup-used-' + self.a['nonce'] + '.json')
        fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW, 0o600)
        with os.fdopen(fd, 'w', encoding='utf-8') as out:
            json.dump({'phase':'APPLY_STARTED_UNKNOWN','namespace':self.a['namespace'],'nonce':self.a['nonce'],
                'admissionSha256':self.admission_pin,'scopeSha256':self.a['scopeSha256'],
                'automaticRetry':False,'automaticRestore':False,
                'businessOutboxBeforeAudit':planned['scope']['businessOutboxBeforeAudit']}, out)
            out.flush(); os.fsync(out.fileno())
        self.sync_directory(path.parent)
        return path

    def sync_directory(self, path):
        fd = os.open(path,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
        try:os.fsync(fd)
        finally:os.close(fd)

    def finish(self, path, result):
        # UNKNOWN file stays immutable. Separate new receipt; never rewrite old journals.
        receipt = Path(str(path) + '.receipt.json')
        raw = json.dumps(result,ensure_ascii=False,sort_keys=True).encode()
        fd = os.open(receipt, os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW, 0o600)
        with os.fdopen(fd,'wb') as out:
            out.write(raw); out.flush(); os.fsync(out.fileno())
        self.sync_directory(receipt.parent)
        private_read(receipt,sha(raw))
        return sha(raw)

def transaction_evidence(a, engine, db, before):
    """Hashes only; called after engine's exact postcheck on the same writer.

    The two explicit post-action deltas are inserted tombstones and documents'
    sequence advance. No preflight heartbeat/counter normalization is used here.
    The persisted receipt is still pending independent Root acceptance.
    """
    need(db.in_transaction is True,'OWN_WRITER_TRANSACTION_REQUIRED_FOR_EVIDENCE')
    schema,after=engine.state(db)
    need(schema==before['_schema'] and set(after)==set(before['_all']),'TRANSACTION_EVIDENCE_SCHEMA_CHANGED')
    tables=lambda rows:{t:{'count':len(v),'rowMultisetSha256':engine.row_seal(v)} for t,v in sorted(rows.items())}
    whole=lambda rows:{'schemaSha256':engine.sha(schema),'tables':tables(rows),'wholeRowsSha256':engine.sha(tables(rows))}
    old=before['_all'];targets=before['scope']['targets'];markers=set(before['scope']['tombstoneKeys'])
    protected_before={t:[r for r in rows if engine.sha(r) not in set(targets.get(t,[]))] for t,rows in old.items()}
    protected_after={t:list(rows) for t,rows in after.items()}
    protected_after['documents']=[r for r in protected_after['documents'] if r['key'] not in markers]
    for snapshot in (protected_before,protected_after):
        snapshot['sqlite_sequence']=[r for r in snapshot['sqlite_sequence'] if r['name']!='documents']
    pb,pa=tables(protected_before),tables(protected_after)
    need(pb==pa,'TRANSACTION_EVIDENCE_PROTECTED_ROWS_CHANGED')
    inserted=[r for r in after['documents'] if r['key'] in markers]
    need(len(inserted)==len(markers) and {r['key'] for r in inserted}==markers,'TRANSACTION_EVIDENCE_TOMBSTONES_CHANGED')
    for table,selected in before['_rows'].items():
        deleted=set(targets[table]);remaining=[r for r in old[table] if engine.sha(r) not in deleted]
        observed=[r for r in after[table] if table!='documents' or r['key'] not in markers]
        need(engine.row_seal(remaining)==engine.row_seal(observed),'TRANSACTION_EVIDENCE_DELETE_DELTA_CHANGED')
    return {'schema':'palitra-cleanup-transaction-evidence/v1',
        'captureSemantics':'SAME_WRITER_CONNECTION_POSTMUTATION_BEFORE_COMMIT',
        'hashSemantics':'R6_CANONICAL_JSON_BLOB_SHA256_SORTED_ROW_HASH_MULTISET_V1',
        'engineSha256':a['engineSha256'],'scopeSha256':a['scopeSha256'],'snapshotSha256':a['snapshotSha256'],
        'wholeBefore':whole(old),'wholeAfter':whole(after),
        'protectedRows':{'before':pb,'after':pa,'exact':True,
                         'excludedExplicitDeltas':['documents:selected-deletes-and-new-tombstones','sqlite_sequence:documents-row-only']},
        'selectedDeleted':tables(before['_rows']),
        'tombstonesAdded':{'count':len(inserted),'rowMultisetSha256':engine.row_seal(inserted),'keySetSha256':engine.sha(sorted(markers))},
        'sequences':{'beforeSha256':engine.row_seal(old['sqlite_sequence']),'afterSha256':engine.row_seal(after['sqlite_sequence']),
                     'documentsBefore':next((r['seq'] for r in old['sqlite_sequence'] if r['name']=='documents'),None),
                     'documentsAfter':next((r['seq'] for r in after['sqlite_sequence'] if r['name']=='documents'),None)},
        'bindings':{'backupSha256':None,**{k:a['artifacts'][v]['sha256'] for k,v in (
            ('previewSha256','preview'),('dryrunSha256','dryrun'),('preFullInspectionSha256','runtimeInspection'),('userApprovalSha256','userApproval'))}},
        'engineExactPostcheckCompleted':True,'runtimeAcceptance':False}

def run_once(a, pins, engine, runtime):
    validate_admission(a, pins, time.time())
    d, backup_path = runtime.current(engine)
    db = runtime.open_database(d['backupProof'])
    try:
        planned = engine.plan(db)
        need(planned['scopeSha256'] == a['scopeSha256'] and planned['scope']['snapshotSha256'] == a['snapshotSha256'], 'LIVE_SCOPE_CHANGED_BEFORE_CLAIM')
        actual = engine.public(planned,'LIVE_METADATA_CAS_ONLY')
        need(all(actual[key] == d['preview'].get(key) == d['dryrun'].get(key)
                 for key in ('targetCounts','targetInternalIds','businessOutboxBeforeAudit')),
             'LIVE_PREVIEW_COUNTS_IDS_AUDIT_CHANGED')
        validate_admission(a,pins,time.time())
        claim = runtime.claim(planned)  # EXCL one-use before the first mutation.
        evidence_before=None;post_evidence=None
        def last_gate(current):
            nonlocal evidence_before
            need(current['scopeSha256'] == a['scopeSha256'], 'LAST_SCOPE_CHANGED')
            need(db.in_transaction is True and 'managed_sites' in current['_all'], 'OWN_WRITER_TRANSACTION_AND_MANAGED_POINTER_REQUIRED')
            pointer_before=engine.row_seal(current['_all']['managed_sites'])
            runtime.fast_current(engine)  # runtime/pointer CAS, never full 3DB scan
            fresh_plan=engine.plan(db)
            need(fresh_plan['scopeSha256']==a['scopeSha256'] and engine.row_seal(fresh_plan['_all']['managed_sites'])==pointer_before,'OWN_CONNECTION_POINTER_OR_CONTENT_CHANGED_DURING_RUNTIME_CAS')
            evidence_before=fresh_plan
        def commit_gate():
            nonlocal post_evidence
            validate_admission(a,pins,time.time())
            need(evidence_before is not None,'TRANSACTION_EVIDENCE_BEFORE_MISSING')
            post_evidence=transaction_evidence(a,engine,db,evidence_before)
            post_evidence['bindings']['backupSha256']=d['backupProof']['backupSha256']
            runtime.commit_current(engine)  # existing file/container check; no new DB open
            runtime.lease()
        planned = engine.execute_reviewed_transaction(db, 'palitra-love/order-contact-followup/v1/',
            a['scopeSha256'], backup_path, datetime.now(timezone.utc).isoformat(), last_gate, commit_gate)
        # Commit is already irreversible. Failure below remains UNKNOWN and NEVER retries.
        runtime.lease()
        result = engine.public(planned, 'CLEANUP_COMMITTED_REQUIRES_ROOT_READONLY_ACCEPTANCE')
        result.update(admissionSha256=runtime.admission_pin, guardImage=a['guardImage'],
                      namespace=a['namespace'],nonce=a['nonce'],automaticRetry=False,automaticRestore=False,
                      runtimeAcceptance=False,pending=['ROOT_READONLY_POSTCOMMIT_ACCEPTANCE'])
        need(post_evidence is not None,'COMMITTED_EVIDENCE_UNKNOWN_NO_RETRY')
        result['transactionEvidence']=post_evidence
        result['transactionEvidenceSha256']=engine.sha(post_evidence)
        receipt_sha = runtime.finish(claim,result)
        need(digest(receipt_sha),'OWN_CLEANUP_RECEIPT_NOT_VERIFIED')
        result['receiptSha256'] = receipt_sha
        return result
    finally:
        db.close()

def main():
    global ADAPTER
    p = argparse.ArgumentParser()
    p.add_argument('--admission', required=True); p.add_argument('--admission-sha', required=True)
    p.add_argument('--apply', action='store_true')
    args = p.parse_args()
    # Disabled default is checked before engine/native/SQLite construction.
    need(args.apply is True, 'EXPLICIT_APPLY_FLAG_REQUIRED')
    need(os.name == 'posix' and os.geteuid() == 0, 'POSIX_ROOT_ONLY')
    a = json.loads(private_read(args.admission, args.admission_sha))
    need(a.get('enabled') is True, 'DISABLED_NO_RUNTIME_AUTHORIZATION')
    need(type(a.get('namespace')) is str and re.fullmatch('palitra-order-cleanup-20261021-r11-[a-z0-9-]{8,48}',a['namespace']), 'NEW_CLEANUP_NAMESPACE_REQUIRED')
    code = ROOT / (a['namespace']+'-code')
    private_path(ROOT,True); private_path(code,True)
    need(Path(__file__) == code/'live_entry.py' and Path(args.admission) == ROOT/(a['namespace']+'-admission.json'), 'EXACT_STAGED_ENTRY_ADMISSION_PATH_REQUIRED')
    pins = json.loads(private_read(code/'LOCAL_CODE_PINS.json', a['codePinsSha256']))
    need(pins['status'] == 'LOCAL_STAGED_CODE_ONLY_NOT_RUNTIME_AUTHORIZATION' and pins['guardName'] == GUARD, 'EXACT_LOCAL_CODE_PINS_REQUIRED')
    validate_admission(a,pins,time.time())
    need({p.name for p in code.iterdir()}=={'LOCAL_CODE_PINS.json','live_entry.py','cleanup_runtime.py','runtime_inspector_adapter.py'},'CLOSED_RUNTIME_CODE_DIRECTORY_REQUIRED')
    private_read(code/'live_entry.py',a['entrySha256'])
    adapter_path=code/'runtime_inspector_adapter.py'
    adapter_raw=private_read(adapter_path,a['inspectorAdapterSha256'])
    ADAPTER=types.ModuleType('reviewed_runtime_inspector_adapter');ADAPTER.__file__=str(adapter_path)
    exec(compile(adapter_raw,str(adapter_path),'exec'),ADAPTER.__dict__)
    raw = private_read(code/'cleanup_runtime.py',a['engineSha256'])
    engine = types.ModuleType('reviewed_cleanup_runtime'); engine.__file__ = str(code/'cleanup_runtime.py')
    exec(compile(raw,engine.__file__,'exec'),engine.__dict__)
    runtime = Runtime(a,pins,code/'live_entry.py',args.admission,args.admission_sha)
    print(json.dumps(run_once(a,pins,engine,runtime),ensure_ascii=False,sort_keys=True))

if __name__ == '__main__':
    sys.dont_write_bytecode = True
    try:
        main()
    except BaseException as error:
        # Lost/SystemExit/partial stdout/SQLite/OS/timeout are all refusal/UNKNOWN.
        value = str(error) if type(error) is ValueError and re.fullmatch('[A-Z][A-Z0-9_]{0,120}',str(error)) else 'REFUSED_OR_UNKNOWN_NO_RETRY'
        print(json.dumps({'status':'REFUSED_OR_UNKNOWN_NO_RETRY','code':value,'runtimeAcceptance':False,
                          'automaticRetry':False,'automaticRestore':False}))
        raise SystemExit(2)
