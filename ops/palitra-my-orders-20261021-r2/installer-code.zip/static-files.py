"""Closed replacement-only static publication; no restoration or automatic retry."""
import hashlib,os,stat
from pathlib import Path

sha=lambda raw:hashlib.sha256(raw).hexdigest()
def need(ok,code):
    if not ok:raise ValueError(code)

class StaticFiles:
    def __init__(self,a,files,lease,code,root,name,records,cabinet):
        self.a,self.files,self.lease=a,files,lease
        self.code,self.root,self.name=Path(code),Path(root),name
        self.records={str(Path(cabinet)/r['static']):dict(r) for r in records if r['static'] is not None}
        need(len(self.records)==2,'EXACT_TWO_STATIC_REPLACEMENTS_REQUIRED')
    def metadata(self,path,mode=None):
        path=self.a.exact_path(Path(path));s=path.lstat()
        need(stat.S_ISREG(s.st_mode) and s.st_uid==s.st_gid==0 and s.st_nlink==1
             and stat.S_IMODE(s.st_mode) in (0o600,0o644),'ROOT_REGULAR_SINGLE_LINK_STATIC_REQUIRED')
        need(mode is None or stat.S_IMODE(s.st_mode)==mode,'EXACT_STATIC_MODE_REQUIRED')
        return {k:getattr(s,k) for k in ('st_dev','st_ino','st_uid','st_gid','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns')}
    def directory(self,dest):
        need(Path(dest)==self.root/(self.name+'-backup'),'EXACT_OWN_CODE_BACKUP_DIRECTORY_REQUIRED')
        path=self.a.exact_path(Path(dest));s=path.lstat()
        need(stat.S_ISDIR(s.st_mode) and s.st_uid==s.st_gid==0 and stat.S_IMODE(s.st_mode)==0o700,'PRIVATE_ROOT_CODE_BACKUP_DIRECTORY_REQUIRED')
        return {k:getattr(s,k) for k in ('st_dev','st_ino','st_uid','st_gid','st_mode')}
    def pending(self,target):
        need(str(target) in self.records,'CLOSED_STATIC_TARGET_REQUIRED')
        return Path(target).with_name('.'+self.name+'-'+Path(target).name+'.pending')
    def absent_pending(self):
        need(not any(os.path.lexists(self.pending(target)) for target in self.records),'OWN_STATIC_PENDING_EXISTS_NO_RETRY')
    def backups(self,dest,source_records,source_bytes):
        self.lease();identity=self.directory(dest);self.absent_pending()
        result={'directoryIdentity':identity,'sources':[],'static':[]}
        for i,row in enumerate(sorted(source_records,key=lambda r:r['target'])):
            raw=source_bytes(row['target']);need(sha(raw)==row['beforeSha256'],'EXACT_SOURCE_BACKUP_BYTES_REQUIRED')
            path=Path(dest)/('source-'+str(i));self.files.write(path,raw,0o600)
            result['sources'].append({'target':row['target'],'path':str(path),'sha256':row['beforeSha256']})
        for i,(target,row) in enumerate(sorted(self.records.items())):
            meta=self.metadata(target);raw=self.a.read(Path(target))
            need(self.metadata(target)==meta and sha(raw)==row['beforeSha256'],'STATIC_BACKUP_BASE_CHANGED')
            path=Path(dest)/('static-'+str(i));self.files.write(path,raw,0o600)
            result['static'].append({'target':target,'path':str(path),'sha256':row['beforeSha256'],'identityBefore':meta})
        self.guard(result,source_records);return result
    def guard(self,state,source_records):
        self.lease();dest=self.root/(self.name+'-backup')
        need(type(state) is dict and set(state)=={'directoryIdentity','sources','static'}
             and state['directoryIdentity']==self.directory(dest),'CODE_BACKUP_DIRECTORY_CHANGED')
        wanted={r['target']:r['beforeSha256'] for r in source_records}
        need(type(state['sources']) is list and len(state['sources'])==len(wanted)
             and {r['target']:r['sha256'] for r in state['sources']}==wanted,'EXACT_SOURCE_BACKUP_CLOSURE_REQUIRED')
        need(type(state['static']) is list and len(state['static'])==2
             and {r['target']:r['sha256'] for r in state['static']}=={t:r['beforeSha256'] for t,r in self.records.items()},'EXACT_STATIC_BACKUP_CLOSURE_REQUIRED')
        for kind in ('sources','static'):
            for i,row in enumerate(state[kind]):
                path=Path(row['path']);prefix='source-' if kind=='sources' else 'static-'
                need(path==dest/(prefix+str(i)),'EXACT_CODE_BACKUP_PATH_REQUIRED')
                before=self.metadata(path,0o600);raw=self.a.read(path)
                need(self.metadata(path,0o600)==before and sha(raw)==row['sha256'],'CODE_BACKUP_BYTES_CHANGED')
        return True
    def publish(self,target,state,source_records):
        target=str(target);need(target in self.records,'CLOSED_STATIC_TARGET_REQUIRED')
        self.guard(state,source_records);row=self.records[target]
        backup=next(r for r in state['static'] if r['target']==target)
        need(self.metadata(target)==backup['identityBefore'] and sha(self.a.read(Path(target)))==row['beforeSha256'],'LATE_STATIC_IDENTITY_OR_BYTES_CHANGED')
        raw=self.a.read(self.code/row['path']);need(len(raw)==row['bytes'] and sha(raw)==row['sha256'],'EXACT_STATIC_PAYLOAD_REQUIRED')
        pending=self.pending(target);need(not os.path.lexists(pending),'OWN_STATIC_PENDING_EXISTS_NO_RETRY')
        mode=stat.S_IMODE(backup['identityBefore']['st_mode'])
        self.files.write(pending,raw,mode)
        self.lease();pmeta=self.metadata(pending,mode)
        need(sha(self.a.read(pending))==row['sha256'] and self.metadata(pending,mode)==pmeta,'STATIC_PENDING_CHANGED')
        need(self.metadata(target)==backup['identityBefore'] and sha(self.a.read(Path(target)))==row['beforeSha256'],'LAST_STATIC_CAS_CHANGED')
        self.lease();os.replace(pending,self.a.exact_path(Path(target)))
        need(sha(self.a.read(Path(target)))==row['sha256'] and self.metadata(target,mode)['st_size']==row['bytes'],'PUBLISHED_STATIC_READBACK_CHANGED')
        return target
