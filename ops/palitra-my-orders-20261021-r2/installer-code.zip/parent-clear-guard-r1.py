"""Read-only historical seam for the completed, inspected Clear Guard R1.

Accepts only the exact completed journal. Never adopts UNKNOWN, replays an
admission, snapshots the old running parent, applies, approves or restores data.
Pins were generated from ROOT_OUTCOME_CLEAR_GUARD_R1.json and the frozen merged R4 bytes.
"""
import copy, hashlib, json, re, types
from pathlib import Path, PurePosixPath
ROOT = Path('/opt/synapse/releases/palitra-app-20261015')
PARENT_NAME = 'palitra-clear-orders-guard-20261020-r1'
PARENT_IMAGE = 'sha256:951db09e9e6c4781350bbced7e7a9e4ef099077a368e38a6b1fac40e0a4a6a22'
PARENT_LEASE_PID = 3401855
NATIVE_SHA = '6a25e99e0a604a2ad96fa370c009b068e17cd396709135ec56a15e46b578c250'
CONTROLLER_SHA = '94bf585d81ef259c846f67b30cdd20495fbdae24b10f482541f05c343e3ae8e3'
MANIFEST_SHA = '86abb1a09c3244fe58cd7dceca40faf379c7d058a22c71e78fb543056d7c5282'
ENTRY_SHA = '283e6211887e7b50d4aa134a97d86de04d160f818fff0284a722de692aa20e9c'
PARENT_SEAM_SHA = 'f5bb203ffd3eba2b917a17911a302772f65f2099c5075e004e277602472dcdd8'
JOURNAL_SHA = '34ce6389ef04a5db158d5b1a27734e2d09c919df28b35a9dad4561af48d42892'
DECISION_SHA = 'e57ab17a927f10629755ac1d22b05f5b4286a859b369d0740c29834fa9428de8'
ACCEPTANCE_SHA = '442975bc079ece34d50cbec60eb3b7f4499bd7885fb96faf463623aa41804fc7'
PREFLIGHT_SHA = '43fbfab4a8075de2d81b439dc3e6f0a2e11a494c2cab63497e130177c09235c3'
RELEASED = (3161783, 3196874, 3200094, 3202295, 3204327, 3205870, 3207300, 3208973, 3210573, 3213993, 3215428, 3221971, 3222059, 3231260, 3239627, 3242810, 3263438, 3284416, 3308227, 3336085, 3367042, 3401855)
PARENT_CODE = ROOT / (PARENT_NAME + '-code')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
encoded = lambda value: json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
digest = lambda value: type(value) is str and re.fullmatch('[a-f0-9]{64}',value) is not None


def need(ok,code):
    if not ok: raise ValueError(code)


def module(raw,path):
    result=types.ModuleType('sealed_merged_r4_'+path.stem);result.__file__=str(path)
    exec(compile(raw,str(path),'exec'),result.__dict__);return result


def canonical_host_config(host):
    """Only the ordering of distinct textual Binds is semantically irrelevant.

    Every binding's source, target, options and every other HostConfig field stay
    in the full canonical serialization. Other arrays are deliberately untouched.
    """
    need(type(host) is dict,'HOST_CONFIG_OBJECT_REQUIRED')
    value=copy.deepcopy(host);binds=value.get('Binds')
    need(type(binds) is list and 1<=len(binds)<=64
         and all(type(row) is str and 0<len(row)<=8192 for row in binds)
         and len(set(binds))==len(binds),'UNIQUE_EXACT_TEXTUAL_BINDINGS_REQUIRED')
    # Docker's bind order is irrelevant only when each mount destination is
    # unique. Docker sources may be absolute paths or exact named volumes.
    parts=[row.split(':') for row in binds]
    need(all(len(row) in (2,3) and (row[0].startswith('/') or re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*',row[0]) is not None)
             and row[1].startswith('/') and row[1]!='/'
             and (len(row)==2 or len(row[2])>0) for row in parts)
         and len({row[1] for row in parts})==len(parts),'UNIQUE_ABSOLUTE_BIND_DESTINATIONS_REQUIRED')
    value['Binds']=sorted(binds)
    return value


def load_current_clear_guard_r1(pid):
    need(type(pid) is int and pid>1 and pid not in RELEASED,'FRESH_LABEL_ACTUAL_PID_REQUIRED')
    for path in [PARENT_CODE/'company-app.py',PARENT_CODE,*PARENT_CODE.parents]:
        need(not path.is_symlink(),'PARENT_CLEAR_GUARD_R1_CODE_ALIAS_REFUSED')
    raw=(PARENT_CODE/'company-app.py').read_bytes()
    need(sha(raw)==ENTRY_SHA,'EXACT_FROZEN_CLEAR_GUARD_R1_ENTRY_REQUIRED')
    entry=module(raw,PARENT_CODE/'company-app.py')
    need(entry.FROZEN is True and entry.CODE==PARENT_CODE and entry.MANIFEST_SHA==MANIFEST_SHA,
         'EXACT_CLEAR_GUARD_R1_ENTRY_NAMESPACE_REQUIRED')
    read=entry.read
    pins={PARENT_CODE/'company-app.py':ENTRY_SHA,PARENT_CODE/'native.py':NATIVE_SHA,
          PARENT_CODE/'controller.py':CONTROLLER_SHA,PARENT_CODE/'manifest.json':MANIFEST_SHA,
          PARENT_CODE/'parent-request-groups-r2.py':PARENT_SEAM_SHA,
          ROOT/(PARENT_NAME+'-journal.json'):JOURNAL_SHA,
          ROOT/(PARENT_NAME+'-decision.json'):DECISION_SHA,
          ROOT/(PARENT_NAME+'-root-acceptance.json'):ACCEPTANCE_SHA,
          ROOT/(PARENT_NAME+'-preflight.json'):PREFLIGHT_SHA}
    values={}
    for path,pin in pins.items():
        raw=read(path);need(digest(pin) and sha(raw)==pin,'EXACT_COMPLETED_CLEAR_GUARD_R1_HISTORY_REQUIRED')
        values[path]=raw
    manifest=json.loads(values[PARENT_CODE/'manifest.json'])
    need(manifest['name']==PARENT_NAME and manifest['FROZEN'] is True
         and manifest['status']=='LOCAL_FROZEN_CODE_ONLY' and manifest['runtimeAuthorization'] is False
         and manifest['sourceFiles']==240 and manifest['sourceBefore']==240 and manifest['sourceAfter']==240 and manifest['staticFiles']==43
         and manifest['chainBefore']==48 and manifest['chainAfter']==49
         and manifest['runtimePayloadFiles']==5 and manifest['staticChanges']==2 and manifest['additions']==0,
         'EXACT_FROZEN_CLEAR_GUARD_R1_MANIFEST_REQUIRED')
    found=set()
    for row in manifest['files']:
        name=row['path']
        need(type(name) is str and not PurePosixPath(name).is_absolute()
             and PurePosixPath(name).as_posix()==name and '..' not in PurePosixPath(name).parts
             and name not in found,'CLEAR_GUARD_R1_MANIFEST_PATH_REQUIRED')
        found.add(name);raw=read(PARENT_CODE/name)
        need(sha(raw)==row['sha256'] and len(raw)==row['bytes'],'EXACT_CLEAR_GUARD_R1_MANIFEST_CLOSURE_REQUIRED')
        pins[PARENT_CODE/name]=row['sha256']
    need(found=={'payload/site-orders.js', 'rollback-plan.py', 'static-files.py', 'payload/server.js', 'controller.py', 'payload/palitra-orders-public/shop.html', 'parent-request-groups-r2.py', 'native.py', 'content-db.py', 'payload/palitra-orders-public/cabinet.html', 'traffic-db.py', 'report-db.py', 'records.json', 'payload/palitra-orders-public/shell.js'},'EXACT_COMPLETED_CLEAR_GUARD_R1_16_FILE_CLOSURE_REQUIRED')
    nmod=module(values[PARENT_CODE/'native.py'],PARENT_CODE/'native.py')
    cmod=module(values[PARENT_CODE/'controller.py'],PARENT_CODE/'controller.py')
    old=nmod.Native(pid);release=cmod.Release(old,MANIFEST_SHA,ENTRY_SHA)
    state=json.loads(values[ROOT/(PARENT_NAME+'-journal.json')])
    decision=json.loads(values[ROOT/(PARENT_NAME+'-decision.json')])
    preflight=json.loads(values[ROOT/(PARENT_NAME+'-preflight.json')])
    acceptance=json.loads(values[ROOT/(PARENT_NAME+'-root-acceptance.json')])
    expected_binding=dict(release.binding(),leasePid=PARENT_LEASE_PID)
    need(state['schema']==1 and state['name']==PARENT_NAME
         and state['phase']=='APPLIED_NOT_CUSTOMER_ACCEPTANCE'
         and state['decisionSha256']==DECISION_SHA and state['childImage']==PARENT_IMAGE,
         'EXACT_COMPLETED_CLEAR_GUARD_R1_REQUIRED_NO_UNKNOWN_ADOPTION')
    need(state['binding']==decision['binding']==preflight['binding']==expected_binding
         and state['before']==decision['before']==preflight['before']
         and decision['rootAcceptanceSha256']==ACCEPTANCE_SHA
         and decision['preflightSha256']==PREFLIGHT_SHA
         and preflight['runtimeAuthorization'] is False and preflight['runtimeWrites']==0
         and acceptance['preflightSha256']==PREFLIGHT_SHA
         and acceptance['leasePid']==PARENT_LEASE_PID and acceptance['oneApply'] is True
         and type(acceptance['nonce']) is str and re.fullmatch('[a-f0-9]{32}',acceptance['nonce'])
         and acceptance['nonce']==decision['nonce']
         and acceptance['expiresAtUtc']==decision['expiresAtUtc'],
         'EXACT_CLEAR_GUARD_R1_HISTORICAL_ADMISSION_LINKS_REQUIRED')
    need(all(acceptance.get(key)==expected_binding[key] for key in
             ('namespace','manifestSha256','entrySha256','codeAcceptanceSha256','nativeBasisSha256',
              'leasePid','parentImage','payloadScopeSha256','uiReviewSha256','htmlReviewSha256')),
         'EXACT_CLEAR_GUARD_R1_HISTORICAL_BINDING_REQUIRED')
    need(state['automaticRetry'] is False and state['automaticRollback'] is False
         and state['runtimeDatabaseWrites']==state['schemaChanges']==0
         and state['workerRecreated'] is False and state['staticChanges']==2
         and state['written']==release.static_targets and len(old.records)==5
         and len(old.static_files.records)==2 and all(r['beforeSha256'] is not None and r['target']!='palitra-order-memo.cjs' for r in old.records),'EXACT_CLEAR_GUARD_R1_CODE_ONLY_EFFECT_REQUIRED')
    overlay=release.paths['overlay'];overlay_pin=state['overlaySha256'];pins[overlay]=overlay_pin
    need(digest(overlay_pin) and sha(read(overlay))==overlay_pin,'EXACT_CLEAR_GUARD_R1_OVERLAY_REQUIRED')
    need(json.loads(read(overlay))=={'services':{'content':{'image':PARENT_IMAGE}}},
         'EXACT_CLEAR_GUARD_R1_CONTENT_ONLY_OVERLAY_REQUIRED')
    base=copy.deepcopy(state['after']);content=base['containers']['content']
    chain=state['before']['containers']['content']['files']+[str(overlay)]
    expected_content=copy.deepcopy(state['before']['containers']['content'])
    expected_content.update(image=PARENT_IMAGE,files=chain,configFiles=','.join(chain),
        filePins={**expected_content['filePins'],str(overlay):overlay_pin},configHash=state['plannedConfigHash'])
    need(len(chain)==len(set(chain))==49 and content==expected_content
         and base['containers']['chat']==state['before']['containers']['chat']
         and type(base['contentCid']) is str and bool(base['contentCid'])
         and base['contentCid']!=state['before']['contentCid']
         and all(base[key]==state['before'][key] for key in
                 ('worker','selected','l12','sourceModes','staticModes')),
         'EXACT_CLEAR_GUARD_R1_FULL240_43_49_REQUIRED')
    need({k:v for k,v in base['runtime'].items() if k!='appTree'}
         =={k:v for k,v in state['before']['runtime'].items() if k!='appTree'},
         'EXACT_CLEAR_GUARD_R1_PROTECTED_RUNTIME_REQUIRED')
    child=state['childProof']
    need(child['image']==PARENT_IMAGE and child['parentImage']==nmod.PARENT
         and child['sourceFiles']==240 and child['oneCopyLayer'] is True
         and child['changedTargets']==sorted(r['target'] for r in old.records)
         and child['appTreeSha256']==sha(encoded(base['runtime']['appTree'])),
         'EXACT_CLEAR_GUARD_R1_CHILD_PROOF_REQUIRED')
    binding=child['platformImageBinding']
    need(binding['target']==PARENT_IMAGE and binding['platform']=='linux/amd64'
         and type(binding['manifestDigest']) is str
         and re.fullmatch('sha256:[a-f0-9]{64}',binding['manifestDigest']) is not None,
         'EXACT_CLEAR_GUARD_R1_PARENT_PLATFORM_REQUIRED')
    source=dict(old.current.source)
    for row in old.records:source[row['target']]=row['sha256']
    static={**old.current.static,**{target:row['sha256'] for target,row in old.static_files.records.items()}}
    need(len(source)==240 and len(static)==43 and len(base['sourceModes'])==240
         and len(base['staticModes'])==43
         and all(base['runtime']['appTree'][target]['sha256']==pin for target,pin in source.items()),
         'EXACT_CLEAR_GUARD_R1_SOURCE_STATIC_MAP_REQUIRED')
    need(source.get('palitra-order-memo.cjs')==old.current.memo_source_sha256
         and base['runtime']['appTree']['palitra-order-memo.cjs']==state['before']['runtime']['appTree']['palitra-order-memo.cjs'],
         'EXACT_CURRENT_MEMO_RETAINED_IN_COMPLETED_PARENT')
    def stable():
        old.stable()
        for path,pin in pins.items():need(sha(read(path))==pin,'SEALED_COMPLETED_CLEAR_GUARD_R1_HISTORY_CHANGED')
        old.code_backup_guard(state['codeBackups'])
        release.context_guard(state['contextPins'],True)
        old.backup_guard(state['backups'])
    stable()
    need(old.verify_child(PARENT_IMAGE,state['before'])==child,'EXACT_CLEAR_GUARD_R1_INDEPENDENT_CHILD_PROOF_REQUIRED')
    # Fresh read-only minima after the completed up; no historical admission replay.
    minimum_after=old.checkpoint(state['minimumBeforeUp'])
    stable()
    return old.a,old.b,old.prior,types.SimpleNamespace(
        base=base,source=source,static=static,stable=stable,cabinet=old.current.cabinet,
        managed_guard=old.current.managed_guard,
        content_migration=copy.deepcopy(old.current.content_migration),
        report_minimum=copy.deepcopy(minimum_after['report']),
        traffic_minimum=copy.deepcopy(minimum_after['traffic']),
        parent_release=PARENT_NAME,parent_receipt=JOURNAL_SHA,parent_decision=DECISION_SHA,
        memo_source_sha256=source['palitra-order-memo.cjs'],parent_image=PARENT_IMAGE,parent_chain_count=49,parent_platform_manifest=binding['manifestDigest'])
