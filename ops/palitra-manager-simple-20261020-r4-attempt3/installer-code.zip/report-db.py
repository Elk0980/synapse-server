"""Read-only live SQLite checks and online backup; never restores a live DB."""
import hashlib
from contextlib import closing
import json
import os
from pathlib import Path
import sqlite3
import stat
import time


def need(value, code):
    if not value:
        raise ValueError(code)


def encoded(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode('utf-8')


def digest(value):
    return hashlib.sha256(value).hexdigest()


def connection_seal(db):
    """Store hashes, never report bodies, actor IDs or request IDs in journals."""
    tables = {r[0] for r in db.execute("SELECT name FROM sqlite_schema WHERE type='table' AND name NOT LIKE 'sqlite_%'")}
    need(tables == {'salon_report_cache_v1', 'salon_report_history_v1', 'salon_report_import_v1'}, 'EXACT_REPORT_SCHEMA_TABLES_REQUIRED')
    schema = list(db.execute("SELECT type,name,tbl_name,sql FROM sqlite_schema ORDER BY type,name"))
    result = {'schemaSha256': digest(encoded(schema)), 'cache': {}, 'history': [], 'imports': []}
    for table, columns, key in (
        ('salon_report_cache_v1', 'company,revision,body,sha256,captured_at,received_at', 'cache'),
        ('salon_report_history_v1', 'company,revision,body,sha256,captured_at,received_at', 'history'),
        ('salon_report_import_v1', 'actor_id,request_id,request_sha,receipt', 'imports'),
    ):
        rows = db.execute('SELECT ' + columns + ' FROM ' + table).fetchmany(100001)
        need(len(rows) <= 100000, 'BOUNDED_REPORT_ROWS_REQUIRED')
        for row in rows:
            row_hash = digest(encoded(row))
            if key == 'cache':
                company, revision = row[:2]
                need(company in ('alvi', 'avokado') and type(revision) is int and revision >= 2, 'PRESERVED_SOURCE2_OR_NEWER_REQUIRED')
                need(company not in result[key], 'UNIQUE_REPORT_COMPANY_REQUIRED')
                result[key][company] = {'revision': revision, 'rowSha256': row_hash}
            else:
                result[key].append(row_hash)
    need(set(result['cache']) == {'alvi', 'avokado'}, 'BOTH_REPORT_COMPANIES_REQUIRED')
    result['history'].sort()
    result['imports'].sort()
    need(len(result['history']) == len(set(result['history'])) and len(result['imports']) == len(set(result['imports'])), 'UNIQUE_REPORT_ROW_HASHES_REQUIRED')
    need(all(r['rowSha256'] in result['history'] for r in result['cache'].values()), 'CURRENT_REPORT_HISTORY_REQUIRED')
    return result


def preserves(before, after):
    need(type(before) is dict and type(after) is dict and before['schemaSha256'] == after['schemaSha256'], 'REPORT_SCHEMA_CHANGED')
    need(set(before['history']) <= set(after['history']) and set(before['imports']) <= set(after['imports']), 'REPORT_HISTORY_OR_IMPORT_LOST')
    need(set(before['cache']) == set(after['cache']) == {'alvi', 'avokado'}, 'REPORT_COMPANIES_CHANGED')
    for company, old in before['cache'].items():
        new = after['cache'][company]
        need(new['revision'] >= old['revision'] and old['rowSha256'] in after['history'], 'REPORT_SOURCE_REVISION_REGRESSED')
        need(new['revision'] != old['revision'] or new == old, 'SAME_REPORT_REVISION_CHANGED')
    return True


class ReportDatabase:
    def __init__(self, path, exact_path, file_ops, mount_guard):
        self.path, self.exact_path, self.files, self.mount_guard = Path(path), exact_path, file_ops, mount_guard

    def facts(self):
        self.mount_guard()
        result = {}
        for key, suffix in (('db', ''), ('wal', '-wal'), ('shm', '-shm')):
            p = self.exact_path(Path(str(self.path) + suffix), key != 'db')
            if not os.path.lexists(p):
                result[key] = None
                continue
            s = p.lstat()
            need(stat.S_ISREG(s.st_mode) and not p.is_symlink() and s.st_nlink == 1 and s.st_uid == s.st_gid == 0
                 and self.files.mode(p) == 0o600, 'PRIVATE_SINGLE_LINK_REPORT_GROUP_REQUIRED')
            need(s.st_size <= 512 * 1024 * 1024, 'BOUNDED_REPORT_DB_REQUIRED')
            result[key] = {'device': s.st_dev, 'inode': s.st_ino, 'uid': s.st_uid, 'mode': 0o600, 'bytes': s.st_size}
        need(result['db'] is not None, 'EXISTING_REPORT_DB_REQUIRED')
        return result

    @staticmethod
    def identity(facts):
        return {k: facts['db'][k] for k in ('device', 'inode', 'uid', 'mode')}

    def read(self):
        before = self.facts()
        uri = self.path.as_uri() + '?mode=ro'
        with closing(sqlite3.connect(uri, uri=True, timeout=5)) as db:
            db.execute('PRAGMA query_only=ON')
            db.execute('BEGIN')
            value = connection_seal(db)
            db.rollback()
        after = self.facts()
        need(self.identity(before) == self.identity(after), 'REPORT_DB_REPLACED_DURING_READ')
        return {'identity': self.identity(after), 'content': value, 'family': after}

    def guard(self, sealed):
        value = self.read()
        need(value['identity'] == sealed['identity'], 'REPORT_DB_IDENTITY_CHANGED')
        preserves(sealed['content'], value['content'])
        return value

    def backup(self, destination, minimum):
        """Online SQLite backup includes committed WAL; source is mode=ro."""
        destination = self.exact_path(Path(destination), True)
        need(not os.path.lexists(destination), 'NEW_REPORT_BACKUP_REQUIRED')
        before = self.guard(minimum)
        self.files.write(destination, b'', 0o600)
        deadline = time.monotonic() + 60

        def progress(status, remaining, total):
            need(time.monotonic() <= deadline, 'BOUNDED_SQLITE_BACKUP_TIME_REQUIRED')

        uri = self.path.as_uri() + '?mode=ro'
        with closing(sqlite3.connect(uri, uri=True, timeout=5)) as src, closing(sqlite3.connect(str(destination), timeout=5)) as out:
            src.execute('PRAGMA query_only=ON')
            src.execute('BEGIN')
            captured = connection_seal(src)
            preserves(minimum['content'], captured)
            src.backup(out, pages=256, progress=progress, sleep=0.02)
            out.execute('PRAGMA journal_mode=DELETE')
            need(out.execute('PRAGMA quick_check').fetchall() == [('ok',)], 'REPORT_BACKUP_INTEGRITY_REQUIRED')
            need(connection_seal(out) == captured, 'REPORT_BACKUP_SNAPSHOT_MISMATCH')
            src.rollback()
        after = self.facts()
        need(self.identity(before['family']) == self.identity(after), 'REPORT_DB_REPLACED_DURING_BACKUP')
        row = {'path': str(destination), 'sha256': digest(destination.read_bytes()), 'bytes': destination.stat().st_size,
               'identity': before['identity'], 'content': captured, 'familyBefore': before['family'], 'familyAfter': after}
        self.backup_guard(row)
        self.guard(row)
        return row

    def backup_guard(self, row):
        p = self.exact_path(Path(row['path']))
        s = p.lstat()
        need(stat.S_ISREG(s.st_mode) and s.st_nlink == 1 and s.st_uid == s.st_gid == 0 and self.files.mode(p) == 0o600
             and s.st_size == row['bytes'] and digest(p.read_bytes()) == row['sha256'], 'SEALED_PRIVATE_REPORT_BACKUP_CHANGED')
        for suffix in ('-wal', '-shm', '-journal'):
            need(not os.path.lexists(str(p) + suffix), 'CLOSED_REPORT_BACKUP_SIDECARS_REQUIRED')
        with closing(sqlite3.connect(p.as_uri() + '?mode=ro&immutable=1', uri=True, timeout=5)) as db:
            db.execute('PRAGMA query_only=ON')
            need(db.execute('PRAGMA quick_check').fetchall() == [('ok',)] and connection_seal(db) == row['content'], 'SEALED_REPORT_BACKUP_CONTENT_CHANGED')
        return True
