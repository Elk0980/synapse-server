"""No live SQLite opens: stable private DB+WAL clone, online backup, append seals."""
from contextlib import closing
import hashlib
import json
import os
from pathlib import Path
import re
import sqlite3
import stat
import tempfile
import time

SQL = [
    "CREATE TABLE app_entry_meta_v1(singleton INTEGER PRIMARY KEY CHECK(singleton=1),schema_version INTEGER NOT NULL CHECK(schema_version=1),enabled_at TEXT NOT NULL,revision INTEGER NOT NULL CHECK(revision>=0),last_at TEXT NOT NULL)",
    "CREATE TABLE app_entry_events_v1(company_code TEXT NOT NULL CHECK(company_code IN ('alvi','avokado')),request_id TEXT NOT NULL,payload_sha256 TEXT NOT NULL,source TEXT NOT NULL,created_at TEXT NOT NULL,revision INTEGER NOT NULL UNIQUE,PRIMARY KEY(company_code,request_id))",
    "CREATE INDEX app_entry_period_v1 ON app_entry_events_v1(company_code,created_at,source)",
]
SOURCES = {'2gis', 'telegram', 'vk', 'instagram', 'youtube', 'tiktok', 'max', 'yandex_maps', 'yandex', 'google', 'whatsapp', 'other', 'unknown'}
MAX_ROWS, MAX_FILE_BYTES = 50000, 128 * 1024 * 1024

def need(value, code):
    if not value:
        raise ValueError(code)

def encoded(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode()

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def sync_directory(path):
    fd = os.open(path, os.O_RDONLY | getattr(os, 'O_DIRECTORY', 0))
    try: os.fsync(fd)
    finally: os.close(fd)

def valid_time(value):
    from datetime import datetime
    if not isinstance(value, str) or re.fullmatch(r'\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z', value) is None:
        return False
    try:
        return datetime.fromisoformat(value.replace('Z', '+00:00')).isoformat(timespec='milliseconds').replace('+00:00', 'Z') == value
    except ValueError:
        return False

def connection_seal(db, prefix=None):
    schema = list(db.execute("SELECT type,name,tbl_name,sql FROM sqlite_schema WHERE name NOT LIKE 'sqlite_%' ORDER BY name"))
    need(db.execute('PRAGMA quick_check').fetchall() == [('ok',)], 'TRAFFIC_SQLITE_INTEGRITY')
    if not schema:
        return {'status': 'EMPTY', 'schemaSha256': digest(encoded([])), 'revision': 0}
    expected = sorted([('index' if sql.startswith('CREATE INDEX') else 'table', re.split('[ (]', sql)[2],
                        'app_entry_events_v1' if sql.startswith('CREATE INDEX') else re.split('[ (]', sql)[2], sql) for sql in SQL], key=lambda row: row[1])
    need(schema == expected, 'EXACT_CLOSED_TRAFFIC_SCHEMA_REQUIRED')
    metadata = list(db.execute('SELECT singleton,schema_version,enabled_at,revision,last_at FROM app_entry_meta_v1'))
    need(len(metadata) == 1, 'TRAFFIC_METADATA_REQUIRED')
    singleton, version, enabled, revision, last = metadata[0]
    now = time.strftime('%Y-%m-%dT%H:%M:%S', time.gmtime()) + '.999Z'
    need(singleton == version == 1 and type(revision) is int and 0 <= revision <= MAX_ROWS and valid_time(enabled) and valid_time(last)
         and enabled <= last <= now, 'VALID_TRAFFIC_METADATA_REQUIRED')
    rows = db.execute('SELECT company_code,request_id,payload_sha256,source,created_at,revision FROM app_entry_events_v1 ORDER BY revision LIMIT ?',
                      (MAX_ROWS + 1,)).fetchall()
    need(len(rows) == revision, 'TRAFFIC_REVISION_REQUIRED')
    columns = ['company_code', 'request_id', 'payload_sha256', 'source', 'created_at', 'revision']
    events, seen, previous = [], set(), enabled
    for n, row in enumerate(rows, 1):
        company, request_id, payload_sha, source, at, event_revision = row
        need(company in ('alvi', 'avokado') and isinstance(request_id, str) and re.fullmatch(r'[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}', request_id)
             and source in SOURCES and payload_sha == digest(encoded({'source': source})) and valid_time(at)
             and previous <= at <= last and event_revision == n and (company, request_id) not in seen, 'VALID_IMMUTABLE_TRAFFIC_EVENT_REQUIRED')
        seen.add((company, request_id)); previous = at; events.append(dict(zip(columns, row)))
    need(previous == last, 'TRAFFIC_LAST_EVENT_TIME_REQUIRED')
    prefix = revision if prefix is None else prefix
    need(type(prefix) is int and 0 <= prefix <= revision, 'TRAFFIC_PREFIX_REGRESSION')
    return {'status': 'INITIALIZED', 'schemaSha256': digest(encoded(schema)), 'revision': revision, 'enabledAt': enabled, 'lastAt': last,
            'eventsSha256': digest(encoded(events)), 'checkedPrefixRevision': prefix, 'checkedPrefixSha256': digest(encoded(events[:prefix]))}

def preserves(before, after):
    need(before['directoryIdentity'] == after['directoryIdentity'], 'TRAFFIC_DIRECTORY_REPLACED')
    if before['status'] == 'ABSENT':
        return True
    need(after['status'] == 'EXISTING' and before['identity'] == after['identity'], 'TRAFFIC_DATABASE_REPLACED_OR_REMOVED')
    old, new = before['content'], after['content']
    if old['status'] == 'EMPTY':
        return True
    need(new['status'] == 'INITIALIZED' and old['schemaSha256'] == new['schemaSha256'] and old['enabledAt'] == new['enabledAt']
         and new['revision'] >= old['revision'] and new['lastAt'] >= old['lastAt']
         and new['checkedPrefixRevision'] == old['revision'] and new['checkedPrefixSha256'] == old['eventsSha256'], 'TRAFFIC_OLD_EVENTS_OR_SCHEMA_CHANGED')
    return True

class TrafficDatabase:
    def __init__(self, path, exact_path, file_ops, mount_guard, temp_root):
        self.path, self.exact_path, self.files, self.mount_guard, self.temp_root = Path(path), exact_path, file_ops, mount_guard, Path(temp_root)
        need(self.path.name == 'app-entry-stats.sqlite', 'EXACT_TRAFFIC_BASENAME_REQUIRED')

    def facts(self):
        self.mount_guard()
        directory = self.exact_path(self.path.parent); d = directory.lstat()
        need(stat.S_ISDIR(d.st_mode) and d.st_uid == d.st_gid == 0 and not stat.S_IMODE(d.st_mode) & 0o022, 'ROOT_TRAFFIC_DIRECTORY_REQUIRED')
        for ancestor in directory.parents:
            a = self.exact_path(ancestor).lstat()
            need(stat.S_ISDIR(a.st_mode) and a.st_uid == a.st_gid == 0 and not stat.S_IMODE(a.st_mode) & 0o022, 'ROOT_TRAFFIC_ANCESTRY_REQUIRED')
        result = {'directoryIdentity': [d.st_dev, d.st_ino, d.st_uid, d.st_gid, stat.S_IMODE(d.st_mode)], 'family': {}}
        for key, suffix in [('db', ''), ('wal', '-wal'), ('shm', '-shm'), ('journal', '-journal')]:
            p = self.exact_path(Path(str(self.path) + suffix), True)
            if not os.path.lexists(p):
                result['family'][key] = None; continue
            s = p.lstat()
            need(stat.S_ISREG(s.st_mode) and not p.is_symlink() and s.st_nlink == 1 and s.st_uid == s.st_gid == 0
                 and self.files.mode(p) == 0o600 and s.st_size <= MAX_FILE_BYTES, 'PRIVATE_SINGLELINK_TRAFFIC_GROUP_REQUIRED')
            raw = p.read_bytes(); need(len(raw) == s.st_size, 'TRAFFIC_GROUP_READ_RACE')
            result['family'][key] = {'identity': [s.st_dev, s.st_ino, s.st_uid, s.st_gid, 0o600], 'bytes': s.st_size,
                                     'mtimeNs': s.st_mtime_ns, 'ctimeNs': s.st_ctime_ns, 'sha256': digest(raw)}
        need(result['family']['db'] is not None or all(v is None for v in result['family'].values()), 'ORPHAN_TRAFFIC_SIDECAR_REQUIRED_ABSENT')
        need(result['family']['journal'] is None or result['family']['journal']['bytes'] == 0, 'HOT_TRAFFIC_JOURNAL_REFUSED')
        return result

    def capture(self, prefix=None, destination=None):
        before = self.facts()
        if before['family']['db'] is None:
            need(before == self.facts(), 'TRAFFIC_ABSENCE_CHANGED_DURING_READ')
            return {'status': 'ABSENT', 'directoryIdentity': before['directoryIdentity'], 'family': before['family']}
        with tempfile.TemporaryDirectory(prefix='r11-traffic-read-', dir=self.temp_root) as temporary:
            directory = Path(temporary); d = directory.lstat()
            need(d.st_uid == d.st_gid == 0 and self.files.mode(directory) == 0o700, 'PRIVATE_TRAFFIC_CLONE_DIRECTORY_REQUIRED')
            clone = directory / 'snapshot.sqlite'
            for key, suffix in [('db', ''), ('wal', '-wal')]:
                if before['family'][key] is None: continue
                raw = Path(str(self.path) + suffix).read_bytes()
                need(digest(raw) == before['family'][key]['sha256'], 'TRAFFIC_GROUP_CHANGED_WHILE_COPYING')
                self.files.write(Path(str(clone) + suffix), raw, 0o600)
            need(before == self.facts(), 'TRAFFIC_GROUP_CHANGED_DURING_PRIVATE_CLONE')
            with closing(sqlite3.connect(str(clone), timeout=5)) as src:
                src.execute('PRAGMA query_only=ON'); src.execute('BEGIN')
                content = connection_seal(src, prefix)
                if content['status'] == 'INITIALIZED':
                    need(src.execute('PRAGMA journal_mode').fetchone() == ('wal',), 'LIVE_TRAFFIC_WAL_MODE_REQUIRED')
                if destination is not None:
                    destination = self.exact_path(Path(destination), True)
                    need(not os.path.lexists(destination), 'NEW_TRAFFIC_BACKUP_REQUIRED')
                    self.files.write(destination, b'', 0o600)
                    deadline = time.monotonic() + 30
                    def progress(status, remaining, total):
                        need(time.monotonic() <= deadline, 'BOUNDED_TRAFFIC_BACKUP_REQUIRED')
                    with closing(sqlite3.connect(str(destination), timeout=5)) as out:
                        src.backup(out, pages=256, progress=progress, sleep=0.02)
                        out.execute('PRAGMA journal_mode=DELETE')
                        need(connection_seal(out) == connection_seal(src), 'TRAFFIC_CONSISTENT_BACKUP_CONTENT_REQUIRED')
                    with destination.open('r+b') as f: os.fsync(f.fileno())
                    sync_directory(destination.parent)
                src.rollback()
            after = self.facts()
            need(before == after, 'TRAFFIC_GROUP_CHANGED_DURING_CAPTURE')
        return {'status': 'EXISTING', 'directoryIdentity': after['directoryIdentity'], 'identity': after['family']['db']['identity'],
                'content': content, 'family': after['family']}

    def read(self, prefix=None):
        return self.capture(prefix)

    def guard(self, sealed):
        prefix = sealed['content']['revision'] if sealed['status'] == 'EXISTING' and sealed['content']['status'] == 'INITIALIZED' else None
        current = self.read(prefix); preserves(sealed, current); return current

    def backup(self, destination, minimum):
        current = self.guard(minimum)
        if current['status'] == 'ABSENT':
            return {**current, 'path': None, 'sha256': None, 'bytes': 0}
        prefix = minimum['content']['revision'] if minimum['status'] == 'EXISTING' and minimum['content']['status'] == 'INITIALIZED' else None
        captured = self.capture(prefix=prefix, destination=destination)
        preserves(minimum, captured)
        self.guard(minimum)
        row = {**captured, 'path': str(destination), 'sha256': digest(Path(destination).read_bytes()), 'bytes': Path(destination).stat().st_size}
        self.backup_guard(row); return row

    def backup_guard(self, row):
        if row['status'] == 'ABSENT':
            need(row.get('path') is None and row.get('sha256') is None and row.get('bytes') == 0, 'SEALED_TRAFFIC_ABSENCE_REQUIRED'); return True
        p = self.exact_path(Path(row['path'])); s = p.lstat()
        need(stat.S_ISREG(s.st_mode) and not p.is_symlink() and s.st_nlink == 1 and s.st_uid == s.st_gid == 0 and self.files.mode(p) == 0o600
             and s.st_size == row['bytes'] and digest(p.read_bytes()) == row['sha256'], 'SEALED_PRIVATE_TRAFFIC_BACKUP_CHANGED')
        need(all(not os.path.lexists(str(p) + suffix) for suffix in ('-wal', '-shm', '-journal')), 'SEALED_TRAFFIC_BACKUP_SIDECARS_REQUIRED')
        with closing(sqlite3.connect(p.as_uri() + '?mode=ro&immutable=1', uri=True, timeout=5)) as db:
            need(connection_seal(db, row['content'].get('checkedPrefixRevision')) == row['content'], 'SEALED_TRAFFIC_BACKUP_CONTENT_CHANGED')
        return True
