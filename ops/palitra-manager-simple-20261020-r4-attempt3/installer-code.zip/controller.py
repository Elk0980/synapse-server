"""Five-source/three-static successor; explicit admission; never restores live data."""
import copy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import time

NAME = 'palitra-manager-simple-20261020-r4-attempt3'
ROOT = Path('/opt/synapse/releases/palitra-app-20261015')
CODE = ROOT / (NAME + '-code')
PARENT = 'sha256:0d8a86b8ace8ea919c389aa07cef2ce71e527fd618f2e7acf290c6b2ede9032c'
TARGET = 'company-app/customer-report-cache.cjs'
BEFORE = '3fca5842514e2ba770ea19b94183002a437cae9b065358537055fa3772d23d92'
AFTER = '5fb7f5ca7f897d04bd2c4907ad8422122209fa1df37d2a8a52b5fcdb4fbf7e70'
CODE_ACCEPTANCE = 'b8fa5a307d7a6202fa793bd0b2d7c827d2a280d34a567473493ab5adfb9d8aa2'  # Root code-only merged product review.
UI_REVIEW = 'db87e4e2d364e44484a582e6af803c67e5c574bacc8ebd2fdfe7e161106845a5'
CACHE_REVIEW = 'b9076fb16468c03c2d113d440fe211fb5052091cd049b3bec9ba1972e911848e'
BASIS = 'a846136b3a12060b11450050dc39cf1e73a715761511de7b63957fa9464a3530'  # Bounded current facts only; strict full preflight is required before runtime admission.
TAG = 'synapse-' + NAME + '-content'


def need(value, code):
    if not value:
        raise ValueError(code)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def digest(value):
    return type(value) is str and re.fullmatch('[a-f0-9]{64}', value) is not None


def encoded(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()


def utc(value):
    need(type(value) is str and re.fullmatch(r'\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z', value), 'EXACT_UTC_REQUIRED')
    result = datetime.fromisoformat(value.replace('Z', '+00:00'))
    need(result.isoformat(timespec='milliseconds').replace('+00:00', 'Z') == value, 'EXACT_UTC_REQUIRED')
    return result.timestamp()


class Release:
    def __init__(self, native, manifest_sha, entry_sha, clock=time.time):
        need(digest(manifest_sha) and digest(entry_sha) and digest(CODE_ACCEPTANCE) and digest(BASIS), 'CLOSED_PRODUCT_BASIS_AND_CODE_PINS_REQUIRED')
        self.n, self.manifest_sha, self.entry_sha, self.clock = native, manifest_sha, entry_sha, clock
        self.a, self.files = native.a, native.files
        self.records = list(native.records)
        self.static_targets = sorted(native.static_files.records, key=lambda target: (Path(target).name == 'cabinet.html', target))
        need(len(self.records) == 5 and len(self.static_targets) == 3, 'CLOSED_FIVE_SOURCE_THREE_STATIC_SCOPE_REQUIRED')
        self.paths = {key: ROOT / (NAME + '-' + key + ('.json' if key in ('preflight', 'decision', 'journal', 'overlay', 'root-acceptance') else ''))
                      for key in ('preflight', 'decision', 'journal', 'overlay', 'context', 'backup', 'root-acceptance')}

    def binding(self):
        return {'schema': 1, 'namespace': NAME, 'manifestSha256': self.manifest_sha,
                'entrySha256': self.entry_sha, 'codeAcceptanceSha256': CODE_ACCEPTANCE,
                'nativeBasisSha256': BASIS, 'parentImage': PARENT, 'target': TARGET,
                'beforeSha256': BEFORE, 'afterSha256': AFTER, 'leasePid': self.n.pid,
                'payloadScopeSha256': self.n.scope_sha, 'uiReviewSha256': UI_REVIEW, 'cacheReviewSha256': CACHE_REVIEW}

    def untouched(self):
        self.n.lease()
        self.n.stable()
        self.n.static_files.absent_pending()
        need(not any(os.path.lexists(self.paths[k]) for k in ('journal', 'context', 'backup', 'overlay')), 'OWN_ATTEMPT_EXISTS_NO_RETRY')

    def preflight(self):
        self.untouched()
        need(not os.path.lexists(self.paths['preflight']) and not os.path.lexists(self.paths['decision']), 'NEW_PREFLIGHT_NAMESPACE_REQUIRED')
        before = self.n.snapshot()
        minimum = self.n.checkpoint()
        need(self.n.snapshot() == before, 'BASE_CHANGED_DURING_PREFLIGHT')
        value = {'schema': 1, 'binding': self.binding(), 'before': before, 'minimum': minimum,
                 'createdAt': self.clock(), 'runtimeWrites': 0, 'runtimeAuthorization': False}
        self.a.write_new(self.paths['preflight'], value)
        return {'status': 'FRESH_PREFLIGHT_NOT_AUTHORIZATION', 'sha256': sha(self.a.read(self.paths['preflight']))}

    def acceptance(self, pin):
        need(digest(pin), 'EXPLICIT_NEW_ROOT_ACCEPTANCE_REQUIRED')
        value = self.a.pinned(self.paths['root-acceptance'], pin, True)
        keys = {'schema', 'namespace', 'manifestSha256', 'entrySha256', 'codeAcceptanceSha256',
                'nativeBasisSha256', 'preflightSha256', 'leasePid', 'parentImage', 'expiresAtUtc', 'nonce', 'oneApply',
                'payloadScopeSha256', 'uiReviewSha256', 'cacheReviewSha256'}
        need(type(value) is dict and set(value) == keys and value['schema'] == 1 and value['oneApply'] is True,
             'CLOSED_ACTION_TIME_ACCEPTANCE_REQUIRED')
        for key in keys & self.binding().keys():
            need(value[key] == self.binding()[key], 'ROOT_ACCEPTANCE_BINDING_CHANGED')
        need(digest(value['preflightSha256']) and type(value['nonce']) is str
             and re.fullmatch('[a-f0-9]{32}', value['nonce']), 'EXACT_PREFLIGHT_NONCE_REQUIRED')
        need(self.clock() < utc(value['expiresAtUtc']) <= self.clock() + 900, 'FRESH_ROOT_ACCEPTANCE_REQUIRED')
        return value

    def approve(self, acceptance_pin):
        self.untouched()
        need(not os.path.lexists(self.paths['decision']), 'NEW_DECISION_REQUIRED')
        accepted = self.acceptance(acceptance_pin)
        before = self.a.pinned(self.paths['preflight'], accepted['preflightSha256'], True)
        need(before['binding'] == self.binding() and before['runtimeAuthorization'] is False,
             'EXACT_FRESH_PREFLIGHT_REQUIRED')
        need(0 <= self.clock() - before['createdAt'] <= 900 and self.n.snapshot() == before['before'], 'STALE_PREFLIGHT_CAS')
        minimum = self.n.checkpoint(before['minimum'])
        decision = {'schema': 1, 'binding': self.binding(), 'rootAcceptanceSha256': acceptance_pin,
                    'preflightSha256': accepted['preflightSha256'], 'before': before['before'], 'minimum': minimum,
                    'expiresAtUtc': accepted['expiresAtUtc'], 'nonce': accepted['nonce']}
        self.a.write_new(self.paths['decision'], decision)
        return {'status': 'NEW_DECISION_NOT_APPLIED', 'sha256': sha(self.a.read(self.paths['decision']))}

    def decision(self, pin):
        need(digest(pin), 'EXPLICIT_NEW_DECISION_REQUIRED')
        value = self.a.pinned(self.paths['decision'], pin, True)
        need(type(value) is dict and set(value) == {'schema', 'binding', 'rootAcceptanceSha256', 'preflightSha256',
             'before', 'minimum', 'expiresAtUtc', 'nonce'} and value['schema'] == 1
             and value['binding'] == self.binding(), 'EXACT_DECISION_BINDING_REQUIRED')
        accepted = self.acceptance(value['rootAcceptanceSha256'])
        need(value['preflightSha256'] == accepted['preflightSha256'] and value['nonce'] == accepted['nonce']
             and value['expiresAtUtc'] == accepted['expiresAtUtc'], 'DECISION_ACCEPTANCE_CHANGED')
        proof = self.a.pinned(self.paths['preflight'], value['preflightSha256'], True)
        need(proof['binding'] == self.binding() and proof['before'] == value['before'], 'DECISION_PREFLIGHT_CHANGED')
        self.n.checkpoint(proof['minimum'])
        return value

    def update(self, state, phase, **values):
        self.n.lease()
        state.update(values, phase=phase)
        self.a.replace(self.paths['journal'], state)

    def context(self, modes):
        need(type(modes) is dict and all(r['target'] in modes and type(modes[r['target']]['mode']) is int
             and modes[r['target']]['mode'] in (0o600, 0o644) for r in self.records), 'EXACT_PARENT_SOURCE_MODES_REQUIRED')
        path = self.paths['context']
        self.files.directory(path, 0o700)
        directories = {'app'} | {'app/' + str(p) for r in self.records for p in Path(r['target']).parents if str(p) != '.'}
        for name in sorted(directories, key=lambda n: (n.count('/'), n)):
            self.files.directory(path / name, 0o755)
        result = {}
        for row in self.records:
            raw = self.a.read(CODE / row['path'])
            need(len(raw) == row['bytes'] and sha(raw) == row['sha256'], 'EXACT_CANDIDATE_PAYLOAD_REQUIRED')
            name = 'app/' + row['target']; mode = modes[row['target']]['mode']
            self.files.write(path / name, raw, mode)
            result[name] = {'sha256': row['sha256'], 'mode': mode}
        dockerfile = ('FROM ' + PARENT + '\nCOPY app/ /app/\n').encode()
        self.files.write(path / 'Dockerfile', dockerfile, 0o600)
        result['Dockerfile'] = {'sha256': sha(dockerfile), 'mode': 0o600}
        return result

    def context_guard(self, pins, built=False):
        expected = set(pins) | ({'image.id'} if built else set())
        root = self.paths['context']
        directories = {'app'} | {'app/' + str(p) for r in self.records for p in Path(r['target']).parents if str(p) != '.'}
        found_files, found_dirs = set(), set()
        for path in root.rglob('*'):
            need(not path.is_symlink(), 'CONTEXT_ALIAS_REFUSED')
            label = path.relative_to(root).as_posix()
            (found_dirs if path.is_dir() else found_files).add(label)
        need(found_files == expected and found_dirs == directories, 'CLOSED_CONTEXT_REQUIRED')
        for name, row in pins.items():
            need(sha(self.a.read(root / name)) == row['sha256'] and self.files.mode(root / name) == row['mode'], 'BUILD_CONTEXT_CHANGED')
        if built:
            need(self.files.mode(root / 'image.id') in (0o600,0o644), 'PRIVATE_CONTEXT_IID_REQUIRED')

    def apply(self, decision_pin, enabled=False):
        need(enabled is True, 'EXPLICIT_APPLY_FLAG_REQUIRED')
        self.untouched()
        d = self.decision(decision_pin)
        before = self.n.snapshot()
        need(before == d['before'], 'LAST_BASE_CAS_CHANGED')
        minimum = self.n.checkpoint(d['minimum'])
        state = {'schema': 1, 'name': NAME, 'binding': self.binding(), 'decisionSha256': decision_pin,
                 'before': before, 'minimum': minimum, 'phase': 'APPLY_STARTED_UNKNOWN',
                 'automaticRetry': False, 'automaticRollback': False, 'runtimeDatabaseWrites': 0,
                 'schemaChanges': 0, 'staticChanges': 3, 'workerRecreated': False, 'written': []}
        self.a.write_new(self.paths['journal'], state)
        self.files.directory(self.paths['backup'], 0o700)
        code_backups = self.n.code_backups(self.paths['backup'], before)
        self.update(state, 'CODE_BACKUPS_SEALED_NOT_PUBLISHED', codeBackups=code_backups)
        pins = self.context(before['sourceModes'])
        self.update(state, 'BUILD_STARTED_UNKNOWN', contextPins=pins)
        self.context_guard(pins)
        self.n.lease()
        child = self.n.build(self.paths['context'], TAG)
        need(self.a.read(self.paths['context'] / 'image.id').decode('ascii').strip() == child, 'EXACT_BUILT_IID_REQUIRED')
        iid_mode=self.files.mode(self.paths['context']/'image.id')
        need(iid_mode in (0o600,0o644),'EXACT_PRIVATE_CONTEXT_IID_MODE_REQUIRED')
        pins['image.id'] = {'sha256': sha(self.a.read(self.paths['context'] / 'image.id')), 'mode': iid_mode}
        self.context_guard(pins, True)
        need(child != PARENT and type(child) is str and re.fullmatch('sha256:[a-f0-9]{64}', child), 'NEW_CHILD_IMAGE_REQUIRED')
        child_proof = self.n.verify_child(child, before)
        self.update(state, 'CHILD_VERIFIED_NOT_APPLIED', childImage=child, childProof=child_proof)
        need(self.n.snapshot() == before, 'BASE_CHANGED_AFTER_BUILD')
        self.n.checkpoint(minimum)
        self.a.write_new(self.paths['overlay'], {'services': {'content': {'image': child}}})
        overlay_pin = sha(self.a.read(self.paths['overlay']))
        # This is the final compose plan. Every current backup follows it.
        plan = self.n.plan(before, self.paths['overlay'])
        need(digest(plan), 'EXACT_FINAL_PLAN_REQUIRED')
        backups = self.n.backup(self.paths['backup'], minimum)
        self.update(state, 'CURRENT_BACKUPS_AFTER_FINAL_PLAN', plannedConfigHash=plan,
                    overlaySha256=overlay_pin, backups=backups)
        self.n.backup_guard(backups)
        self.n.code_backup_guard(code_backups)
        for target in self.static_targets:
            self.update(state, 'STATIC_STARTED_UNKNOWN', staticTargetUnknown=target)
            self.acceptance(d['rootAcceptanceSha256']); self.n.lease()
            self.n.publish_static(target, code_backups)
            state['written'].append(target)
            self.update(state, 'STATIC_PUBLISHED_NOT_UP', staticTargetUnknown=None)
        self.context_guard(pins, True)
        need(sha(self.a.read(self.paths['overlay'])) == overlay_pin, 'OVERLAY_CAS_CHANGED')
        need(self.n.snapshot(changed=frozenset(state['written'])) == before, 'LAST_FULL_BASE_CAS_CHANGED')
        late = self.n.checkpoint(minimum)
        # If an absent traffic store appeared late, back it up before up as well.
        if backups['traffic'].get('status') == 'ABSENT' and late['traffic'].get('status') != 'ABSENT':
            backups = self.n.backup(self.paths['backup'], late, refresh=True)
            self.n.backup_guard(backups)
        self.decision(decision_pin)
        self.n.code_backup_guard(code_backups)
        self.n.lease()
        need(self.n.snapshot(changed=frozenset(state['written'])) == before and sha(self.a.read(self.paths['overlay'])) == overlay_pin, 'FINAL_NATIVE_CAS_CHANGED')
        late = self.n.checkpoint(late)
        need(not (backups['traffic'].get('status') == 'ABSENT'
                  and late['traffic'].get('status') != 'ABSENT'), 'LATE_TRAFFIC_REQUIRES_NEW_BACKUP_NO_UP')
        self.update(state, 'CONTENT_UP_STARTED_UNKNOWN', backups=backups, minimumBeforeUp=late)
        # Recheck only the pinned admission and clock after all slow guards/journal I/O.
        self.n.lease()
        self.acceptance(d['rootAcceptanceSha256'])
        # No build/up operation is automatically retried, even after lost output.
        self.n.up(before, self.paths['overlay'])
        after = self.n.snapshot(child, self.paths['overlay'], plan, changed=frozenset(state['written']))
        for key in ('worker', 'selected', 'l12', 'sourceModes', 'staticModes'):
            need(after.get(key) == before.get(key), 'POST_UP_PROTECTED_FACT_CHANGED')
        need({k: v for k, v in after.get('runtime', {}).items() if k != 'appTree'}
             == {k: v for k, v in before.get('runtime', {}).items() if k != 'appTree'},
             'POST_UP_NORMALIZED_RUNTIME_CHANGED')
        self.n.checkpoint(late)
        self.n.backup_guard(backups)
        need(after['contentCid'] != before['contentCid'], 'NEW_CONTENT_ID_REQUIRED')
        self.update(state, 'APPLIED_NOT_CUSTOMER_ACCEPTANCE', after=after, finishedAt=self.clock())
        return {'status': state['phase'], 'receiptSha256': sha(self.a.read(self.paths['journal'])),
                'contentImage': child, 'sourceFiles': 239, 'staticFiles': 43, 'chainFiles': 43,
                'runtimeDatabaseWrites': 0, 'workerRecreated': False, 'automaticRetry': False}

    def inspect(self, receipt_pin):
        need(digest(receipt_pin), 'EXPLICIT_OWN_RECEIPT_REQUIRED')
        state = self.a.pinned(self.paths['journal'], receipt_pin, True)
        expected_binding = dict(self.binding(), leasePid=state.get('binding', {}).get('leasePid'))
        need(state.get('name') == NAME and state.get('phase') == 'APPLIED_NOT_CUSTOMER_ACCEPTANCE'
             and state.get('binding') == expected_binding and type(expected_binding['leasePid']) is int,
             'EXACT_OWN_COMPLETED_JOURNAL_REQUIRED')
        self.n.lease()
        d = self.a.pinned(self.paths['decision'], state['decisionSha256'], True)
        accepted = self.a.pinned(self.paths['root-acceptance'], d['rootAcceptanceSha256'], True)
        preflight = self.a.pinned(self.paths['preflight'], d['preflightSha256'], True)
        need(d['binding'] == state['binding'] == preflight['binding'] and d['before'] == preflight['before'] == state['before']
             and accepted['namespace'] == NAME and accepted['oneApply'] is True
             and accepted['manifestSha256'] == self.manifest_sha and accepted['entrySha256'] == self.entry_sha
             and accepted['codeAcceptanceSha256'] == CODE_ACCEPTANCE and accepted['nativeBasisSha256'] == BASIS
             and accepted['preflightSha256'] == d['preflightSha256'] and accepted['nonce'] == d['nonce']
             and accepted['leasePid'] == state['binding']['leasePid'] and accepted['parentImage'] == PARENT
             and all(accepted.get(k) == state['binding'][k] for k in ('payloadScopeSha256', 'uiReviewSha256', 'cacheReviewSha256')),
             'OWN_HISTORICAL_ADMISSION_CHANGED')
        need(state.get('automaticRetry') is False and state.get('automaticRollback') is False
             and state.get('runtimeDatabaseWrites') == state.get('schemaChanges') == 0 and state.get('staticChanges') == 3
             and state.get('workerRecreated') is False, 'ONE_CODE_ONLY_EFFECT_REQUIRED')
        need(state.get('written') == self.static_targets, 'EXACT_THREE_STATIC_CABINET_LAST_REQUIRED')
        self.n.code_backup_guard(state['codeBackups'])
        self.context_guard(state['contextPins'], True)
        need(sha(self.a.read(self.paths['overlay'])) == state['overlaySha256'], 'OWN_OVERLAY_CHANGED')
        actual = self.n.snapshot(state['childImage'], self.paths['overlay'], state['plannedConfigHash'], changed=frozenset(state['written']))
        need(actual == state['after'], 'OWN_COMPLETED_RUNTIME_CHANGED')
        self.n.checkpoint(state['minimumBeforeUp'])
        self.n.backup_guard(state['backups'])
        return {'status': 'OWN_COMPLETED_READONLY_NOT_CUSTOMER_ACCEPTANCE', 'sourceFiles': 239,
                'staticFiles': 43, 'chainFiles': 43, 'runtimeWrites': 0}
