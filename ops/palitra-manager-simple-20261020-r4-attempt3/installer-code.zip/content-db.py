"""R7 schema-only SQLite migration. Never restores live DB or activates workers."""
import collections
from contextlib import closing
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sqlite3
import stat
import time

TABLES = frozenset('project_chat_work_' + n for n in ('connections','jobs','replies','events','connection_events'))
INDEX = 'project_chat_work_next'

def need(value, code):
    if not value: raise ValueError(code)
def encoded(value):
    return json.dumps(value,ensure_ascii=False,separators=(',',':')).encode()
def digest(value): return hashlib.sha256(value).hexdigest()
def quote(name): return '"' + name.replace('"','""') + '"'
def atom(value):
    if value is None: return ['null']
    if isinstance(value,bytes): return ['blob',value.hex()]
    if isinstance(value,float): return ['real',value.hex()]
    return [type(value).__name__,value]
def schema(db):
    return [list(r) for r in db.execute("SELECT type,name,tbl_name,sql FROM sqlite_schema ORDER BY type,name")]
def connection_seal(db):
    rows=schema(db); result={'schema':rows,'schemaSha256':digest(encoded(rows)),'tables':{}}
    for kind,name,table,sql in rows:
        if kind!='table': continue
        hashes=collections.Counter(); count=0
        for row in db.execute('SELECT * FROM '+quote(name)):
            count+=1; need(count<=1000000,'CONTENT_ROWS_EXCEED_BOUND')
            hashes[digest(encoded([atom(v) for v in row]))]+=1
        result['tables'][name]={'columns':[list(r) for r in db.execute('PRAGMA table_xinfo('+quote(name)+')')],'rows':[list(r) for r in sorted(hashes.items())],'count':count}
    return result

def validate_migration(value, frozen=False):
    need(type(value) is dict and set(value)=={'schema','status','beforeSchemaSha256','objects','activation'} and value['schema']==1 and value['activation'] is False,'EXACT_CONTENT_MIGRATION_REQUIRED')
    need(type(value['objects']) is list and len(value['objects'])==6,'EXACT_FIVE_TABLES_ONE_INDEX_REQUIRED')
    if frozen:
        need(value['status']=='FROZEN' and isinstance(value['beforeSchemaSha256'],str) and re.fullmatch('[0-9a-f]{64}',value['beforeSchemaSha256']),'MIGRATION_NOT_FROZEN')
    found=set()
    for row in value['objects']:
        need(type(row) is dict and set(row)=={'type','name','table','sql'},'CLOSED_MIGRATION_OBJECT_REQUIRED')
        kind,name,table,sql=(row[k] for k in ('type','name','table','sql'))
        need(kind in ('table','index') and name not in found and type(sql) is str,'CLOSED_MIGRATION_OBJECT_REQUIRED');found.add(name)
        need((kind=='table' and name in TABLES and table==name) or (kind=='index' and name==INDEX and table=='project_chat_work_jobs'),'EXACT_WORK_SCHEMA_NAMES_REQUIRED')
        match=re.match(r'CREATE (TABLE|INDEX) IF NOT EXISTS (\w+)(?: ON (\w+))?',sql)
        need(match and match.group(1).lower()==kind and match.group(2)==name and (kind=='table' or match.group(3)==table),'EXACT_CREATE_STATEMENT_REQUIRED')
        need(';' not in sql and not re.search(r'\b(?:INSERT|UPDATE|DELETE|DROP|ALTER|ATTACH|DETACH|TRIGGER|VIRTUAL|SELECT)\b',sql,re.I),'SCHEMA_ONLY_STATEMENT_REQUIRED')
    need(found==set(TABLES)|{INDEX},'EXACT_WORK_SCHEMA_SET_REQUIRED')
    return value

def preserve_transaction(before,after,definition):
    old={(r[0],r[1]):r for r in before['schema']};new={(r[0],r[1]):r for r in after['schema']}
    need(all(new.get(k)==v for k,v in old.items()),'OLD_CONTENT_SCHEMA_CHANGED')
    wanted={(r['type'],r['name']) for r in definition['objects']}
    added=set(new)-set(old)
    need(wanted<=added and all(k in wanted or (k[0]=='index' and new[k][2] in TABLES and new[k][3] is None and k[1].startswith('sqlite_autoindex_')) or (k==('table','sqlite_sequence') and k not in old) for k in added),'UNLISTED_ADDITIVE_SCHEMA_CHANGED')
    for name,value in before['tables'].items(): need(after['tables'].get(name)==value,'OLD_CONTENT_ROWS_CHANGED_INSIDE_MIGRATION')
    need(all(after['tables'][n]['count']==0 for n in TABLES),'NEW_WORK_TABLES_MUST_BE_EMPTY_NO_ACTIVATION')
    need('actor_session_version' in [r[1] for r in after['tables']['project_chat_work_jobs']['columns']],'SESSION_VERSION_COLUMN_REQUIRED')
    return True

# Reuse only the unchanged, byte-pinned R6 backup implementation in an isolated module.
_spec=importlib.util.spec_from_file_location('r7_private_db_common',Path(__file__).with_name('report-db.py'))
_common=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(_common)
_common.connection_seal=connection_seal
# Across user writes compare schema only; row equality is checked within migration transaction.
def preserves(before,after):
    need(before['schemaSha256']==after['schemaSha256'],'CONTENT_SCHEMA_CHANGED_OUTSIDE_MIGRATION');return True
_common.preserves=preserves

class ContentDatabase(_common.ReportDatabase):
    # Fresh R6 native fact: content DB/WAL/SHM are root:root 0644.
    # Preserve that mode exactly; newly created backups remain root-only 0600.
    def facts(self):
        self.mount_guard();result={}
        for key,suffix in (('db',''),('wal','-wal'),('shm','-shm')):
            p=self.exact_path(Path(str(self.path)+suffix),key!='db')
            if not os.path.lexists(p):result[key]=None;continue
            s=p.lstat()
            need(stat.S_ISREG(s.st_mode) and not p.is_symlink() and s.st_nlink==1 and s.st_uid==s.st_gid==0 and self.files.mode(p)==0o644,'EXACT_INSTALLED_CONTENT_GROUP_REQUIRED')
            need(s.st_size<=512*1024*1024,'BOUNDED_CONTENT_DB_REQUIRED')
            result[key]={'device':s.st_dev,'inode':s.st_ino,'uid':s.st_uid,'mode':0o644,'bytes':s.st_size}
        need(result['db'] is not None,'EXISTING_CONTENT_DB_REQUIRED')
        return result
    def configure(self,definition,lease_guard):
        self.definition=validate_migration(definition,True);self.lease_guard=lease_guard;return self
    def migrate(self,backup):
        validate_migration(self.definition,True);self.backup_guard(backup);self.guard(backup);self.lease_guard()
        before_family=self.facts()
        with closing(sqlite3.connect(self.path.as_uri()+'?mode=rw',uri=True,timeout=5)) as db:
            db.execute('PRAGMA foreign_keys=ON');db.execute('BEGIN IMMEDIATE')
            try:
                self.lease_guard();before=connection_seal(db)
                need(before['schemaSha256']==self.definition['beforeSchemaSha256'],'EXACT_PREMIGRATION_SCHEMA_REQUIRED')
                need(not (TABLES|{INDEX}) & {r[1] for r in before['schema']},'WORK_SCHEMA_ALREADY_EXISTS_NO_REPLAY')
                for row in self.definition['objects']: db.execute(row['sql'])
                after=connection_seal(db);preserve_transaction(before,after,self.definition)
                need(db.execute('PRAGMA foreign_key_check').fetchall()==[],'CONTENT_FOREIGN_KEYS_INVALID')
                need(db.execute('PRAGMA quick_check').fetchall()==[('ok',)],'CONTENT_MIGRATION_INTEGRITY_REQUIRED')
                self.lease_guard();need(self.identity(before_family)==self.identity(self.facts()),'CONTENT_REPLACED_DURING_MIGRATION')
                db.commit()
            except BaseException:
                db.rollback();raise
        return {'identity':self.identity(before_family),'beforeSchemaSha256':before['schemaSha256'],'afterSchemaSha256':after['schemaSha256'],'content':after,'schemaObjects':6,'legacyRowWrites':0,'activationRows':0}
    def after_guard(self,migration):
        live=self.read();need(live['identity']==migration['identity'],'CONTENT_DB_IDENTITY_CHANGED')
        need(live['content']['schemaSha256']==migration['afterSchemaSha256'],'CONTENT_SCHEMA_CHANGED_AFTER_MIGRATION')
        return live
