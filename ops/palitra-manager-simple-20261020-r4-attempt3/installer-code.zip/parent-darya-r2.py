"""Completed Darya R2 historical seam; never invokes an old live snapshot/apply path."""
import copy,hashlib,os,re,stat,types
from pathlib import Path
ROOT=Path('/opt/synapse/releases/palitra-app-20261015')
PARENT_NAME='palitra-darya-workspace-20261020-r2'
PARENT_IMAGE='sha256:0d8a86b8ace8ea919c389aa07cef2ce71e527fd618f2e7acf290c6b2ede9032c'
PARENT_HELPER='3ab2d48f02418be290dad21fa9b57ca945c03231523f864ebe8c2d547d31e5c0'
PARENT_ENTRY='9f525765313b1fa8d92bbde5815de8b02f1877dd22896cc0e04bc10a3c155e24'
PARENT_RECEIPT='18ba2aff5b3b62a27de5c0c6bc9be8c0532a30e8a057b4e43b830e45324d510c'
PARENT_WRITER=3161783
BEFORE_CACHE='3fca5842514e2ba770ea19b94183002a437cae9b065358537055fa3772d23d92'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
digest=lambda value:type(value) is str and re.fullmatch('[a-f0-9]{64}',value) is not None
def need(ok,code):
    if not ok:raise ValueError(code)
def load_module(raw,path):
    m=types.ModuleType('exact_completed_darya_r2');m.__file__=str(path)
    exec(compile(raw,str(path),'exec'),m.__dict__);return m
def historical_backups(accepted,state):
    """Validate archived bytes only; fresh live database prefixes belong to Native.checkpoint."""
    a=accepted.a;directory=a.exact_path(accepted.paths['backup']);s=directory.stat()
    need(stat.S_ISDIR(s.st_mode) and s.st_uid==0 and stat.S_IMODE(s.st_mode)==0o700
         and state['backupIdentity']==[s.st_dev,s.st_ino,s.st_uid],'PRIVATE_PARENT_BACKUP_DIRECTORY_CHANGED')
    need(len(state['sourceBackups'])==len(accepted.existing_sources)
         and {r['target']:r['baseSha256'] for r in state['sourceBackups']}=={k:v['beforeSourceSha256'] for k,v in accepted.existing_sources.items()}
         and len(state['static'])==len(accepted.static_records)
         and {r['target'] for r in state['static']}==set(accepted.static_records),'EXACT_PARENT_BACKUP_INVENTORY_REQUIRED')
    for row in state['static']:
        record=accepted.static_records[row['target']]
        need(row['baseSha256']==record['beforeSha256'] and row['sha256']==record['sha256']
             and (row['backup'] is None)==(record['beforeSha256'] is None),'PARENT_STATIC_BACKUP_RECORD_CHANGED')
    accepted.db.backup_guard(state['reportDatabaseBackup']);accepted.contentdb.backup_guard(state['contentDatabaseBackup']);accepted.traffic.backup_guard(state['trafficDatabaseBackup'])
    need(Path(state['reportDatabaseBackup']['path'])==directory/'reports.sqlite' and Path(state['contentDatabaseBackup']['path'])==directory/'content.sqlite','EXACT_PARENT_DB_BACKUP_PATHS_REQUIRED')
    wanted={'reports.sqlite','content.sqlite'}
    if state['trafficDatabaseBackup']['status']=='EXISTING':
        need(Path(state['trafficDatabaseBackup']['path'])==directory/'traffic.sqlite','EXACT_PARENT_TRAFFIC_BACKUP_PATH_REQUIRED');wanted.add('traffic.sqlite')
    for row in state['sourceBackups']+state['static']:
        if row['backup'] is None:continue
        path=Path(row['backup']);need(path.parent==directory,'PARENT_BACKUP_BOUNDARY_REQUIRED');wanted.add(path.name)
        a.exact_path(path);info=path.stat()
        need(stat.S_ISREG(info.st_mode) and info.st_uid==0 and accepted.files.mode(path)==0o600
             and sha(a.read(path))==row['baseSha256'],'PRIVATE_PARENT_BACKUP_CHANGED')
    need({p.name for p in directory.iterdir()}==wanted,'CLOSED_PARENT_BACKUP_DIRECTORY_REQUIRED')
def load_current_darya_r2(pid):
    need(type(pid) is int and pid>1 and pid not in (3161783,3196874,3200094,3202295,3204327,3205870,3207300,3208973,3210573),'FRESH_CACHE_ACTUAL_PID_REQUIRED')
    folder=ROOT/(PARENT_NAME+'-code');helper=folder/'release-native.py';entry=folder/'company-app.py'
    for path in [*reversed(helper.parents),helper,entry]:need(not path.is_symlink(),'HISTORICAL_DARYA_ALIAS_REFUSED')
    raw=helper.read_bytes();need(sha(raw)==PARENT_HELPER and sha(entry.read_bytes())==PARENT_ENTRY,'EXACT_FROZEN_DARYA_CODE_REQUIRED')
    original=load_module(raw,helper)
    need(original.FROZEN is True and original.NAME==PARENT_NAME and original.CODE==folder,'EXACT_DARYA_FROZEN_NAMESPACE_REQUIRED')
    a,b,prior,old=original.load_current_notify_r2(pid)
    accepted=original.Release(a,b,prior,old,pid,inspection_pin=PARENT_RECEIPT)
    need(accepted.pid==pid and accepted.writer_pid==PARENT_WRITER,'DARYA_HISTORICAL_WRITER_AND_ACTUAL_PID_REQUIRED')
    state=a.pinned(accepted.paths['journal'],PARENT_RECEIPT,True)
    need(type(state) is dict and state.get('name')==PARENT_NAME and state.get('phase')=='APPLIED_NOT_CUSTOMER_ACCEPTANCE'
         and state.get('inputs')==accepted.binding() and state.get('before')==accepted.base and state.get('childImage')==PARENT_IMAGE
         and state.get('attentionReadOnlyValidated') is True and digest(state.get('attentionPreflightSha256'))
         and state.get('responseReadOnlyValidated') is True and digest(state.get('responsePreflightSha256')) and digest(state.get('responsePostBootSha256'))
         and state.get('featureBootObservationAppendMaximum')==1 and state.get('featureObservationRowsAppended') in (0,1)
         and state.get('workerRecreated') is False and state.get('automaticRetry') is False and state.get('automaticCodeRollback') is False
         and state.get('contentSchemaObjectsCreated')==0 and state.get('contentLegacyRowWrites')==state.get('activationRowsCreated')==0
         and state.get('mainDbRowDirectWrites')==state.get('queueEdits')==state.get('oldJournalWrites')==0,'EXACT_COMPLETED_DARYA_RECEIPT_REQUIRED')
    decision_pin=state.get('decisionSha256');need(digest(decision_pin),'EXACT_DARYA_DECISION_PIN_REQUIRED')
    decision=a.pinned(accepted.paths['decision'],decision_pin,True)
    need(type(decision) is dict and set(decision)=={'schema','name','inputs','before','observedAtUtc','sourceModes','staticModes','rootAcceptanceSha256','reportDatabaseBefore','reportDatabaseContentBefore','contentDatabaseBefore','trafficDatabaseBefore','serviceUsers'}
         and decision['schema']==1 and decision['name']==PARENT_NAME and decision['inputs']==accepted.binding()
         and decision['before']==accepted.base and original.private_report_db(decision['reportDatabaseBefore'])
         and decision['sourceModes']==state['sourceModes'],'EXACT_SEALED_DARYA_DECISION_REQUIRED')
    accepted.acceptance(decision['rootAcceptanceSha256'])
    expected=copy.deepcopy(accepted.base);content=expected['containers']['content'];overlay=str(accepted.paths['overlay']);chain=content['files']+[overlay]
    need(len(chain)==len(set(chain))==42 and sha(a.read(accepted.paths['overlay']))==state['overlaySha256'],'EXACT_SEALED_DARYA_CHAIN42_REQUIRED')
    content.update(image=PARENT_IMAGE,files=chain,configFiles=','.join(chain),filePins={**content['filePins'],overlay:state['overlaySha256']},configHash=state['plannedConfigHash'])
    need(type(state.get('after')) is dict and type(state['after'].get('contentCid')) is str and state['after']['contentCid']
         and state['after']['contentCid']!=accepted.base['contentCid'],'EXACT_DARYA_AFTER_CID_REQUIRED')
    expected['contentCid']=state['after']['contentCid']
    need(state['after']==expected and len(accepted.source)==239 and len(accepted.static)==43 and len(accepted.records)==11
         and len(accepted.static_records)==7 and len(state['written'])==7 and set(state['written'])==set(accepted.static_records)
         and Path(state['written'][-1]).name=='cabinet.html','EXACT_DARYA_FULL239_43_42_REQUIRED')
    need(accepted.source.get('company-app/customer-report-cache.cjs')==BEFORE_CACHE
         and state['contentMigration']==old.content_migration,'EXACT_DARYA_CACHE_AND_POST_SCHEMA_REQUIRED')
    accepted.observation_guard(state['responseObservationBefore'],state['responseObservationAfter'],boot=True)
    need(state['featureObservationRowsAppended']==(1 if state['responseObservationBefore']['status']=='ABSENT' else 0),'EXACT_DARYA_OBSERVATION_RECEIPT_REQUIRED')
    def stable():
        # The inherited seam checks old artifacts plus the four unchanged registry modules.
        # Never call accepted.snapshot/baseline/inspect/decision/apply/approve/stable.
        accepted.current.stable()
        need(sha(a.read(helper))==PARENT_HELPER and sha(a.read(entry))==PARENT_ENTRY
             and a.pinned(accepted.paths['journal'],PARENT_RECEIPT,True)==state
             and a.pinned(accepted.paths['decision'],decision_pin,True)==decision
             and accepted.binding()==state['inputs'],'SEALED_DARYA_HISTORY_CHANGED')
        for path,pin in accepted.pins.items():need(sha(a.read(Path(path)))==pin,'SEALED_DARYA_CODE_OR_PROOF_CHANGED')
        for row in accepted.records.values():need(sha(a.read(original.CODE/'payload'/row['name']))==row['sha256'],'SEALED_DARYA_PAYLOAD_CHANGED')
        accepted.acceptance(decision['rootAcceptanceSha256']);historical_backups(accepted,state)
        need(accepted.context_proof(state,True)==state['contextSha256'],'SEALED_DARYA_CONTEXT_CHANGED')
    stable()
    return a,b,prior,types.SimpleNamespace(base=copy.deepcopy(state['after']),source=dict(accepted.source),static=dict(accepted.static),
        stable=stable,cabinet=accepted.cabinet,managed_guard=accepted.managed_guard,content_migration=copy.deepcopy(state['contentMigration']),
        report_minimum=copy.deepcopy(state['reportDatabaseBackup']),traffic_minimum=copy.deepcopy(state['trafficDatabaseBackup']),
        parent_release=PARENT_NAME,parent_receipt=PARENT_RECEIPT,parent_decision=decision_pin,parent_image=PARENT_IMAGE,parent_chain_count=42)
