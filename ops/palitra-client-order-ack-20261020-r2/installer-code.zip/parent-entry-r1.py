"""Read-only historical seam for the separately accepted installed client R1.

The old UNKNOWN journal is never promoted, replayed or rewritten. Its separate
Root audit, exact code, backups, context and child proof form this parent basis.
"""
import copy, hashlib, json, re, types
from pathlib import Path
ROOT = Path('/opt/synapse/releases/palitra-app-20261015')
PARENT_NAME = 'palitra-client-order-entry-20261020-r1'
PARENT_CODE = ROOT / (PARENT_NAME + '-code')
PARENT_IMAGE = 'sha256:c2f110af73c127fadceba6b60e5225311835aea404a4bb10125b9e80b958f622'
NATIVE_SHA = '0b17f6acdb64c45a48bb2dcb5286b26acee653473b8df3da8a3998ee0e0ed75d'
CONTROLLER_SHA = '55a9371cafdb152290a8108e17a383799fc184c320c08be2d676bd439cd8ffb1'
MANIFEST_SHA = '2b4469cd2444ec5a6a276efad592ac4fa2e892b2f977756132bf8db1bd4bd553'
ENTRY_SHA = 'c122a3952eefa2e305eb49b0eb20a5ef18b1181185d15f06cd51a3f1980c3c8b'
AUDIT_SHA = 'b2520bdbc12fe90ba8bc8b3c42105c38bcdde16870bdf142ac8f2275a90744ae'
JOURNAL_SHA = '754961b8765093933ee442bf4df40495a61a4472264192dee9baf5174cf2e667'
DECISION_SHA = '15c7a3790ccbac3c8abd770841d2c3c812cde2ab6706ea1080b2990766108829'
ACCEPTANCE_SHA = '824c08c670564bbbca560807f90c8109a05b8443153beb1dd532732a7e4da326'
PREFLIGHT_SHA = '10eb7779947875302250db506e7edb15cd0c5a9fba3237f42c66eb488ccbdfe5'
RELEASED = (3161783,3196874,3200094,3202295,3204327,3205870,3207300,3208973,3210573,3213993,3215428,3221971,3222059,3231260,3239627,3242810)
sha = lambda raw: hashlib.sha256(raw).hexdigest()
encoded = lambda value: json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
digest = lambda value: type(value) is str and re.fullmatch('[a-f0-9]{64}',value) is not None
def need(ok,code):
    if not ok: raise ValueError(code)
def module(raw,path):
    result=types.ModuleType('sealed_entry_r1_'+path.stem);result.__file__=str(path)
    exec(compile(raw,str(path),'exec'),result.__dict__);return result
def canonical_host_config(host):
    """Only the ordering of distinct textual Binds is semantically irrelevant.

    Every binding's source, target, options and every other HostConfig field stay
    in the full canonical serialization. Other arrays are deliberately untouched.
    """
    need(type(host) is dict,'HOST_CONFIG_OBJECT_REQUIRED')
    value=copy.deepcopy(host);binds=value.get('Binds')
    need(type(binds) is list and 1<=len(binds)<=64
         and all(type(row) is str and 0<len(row)<=8192 for row in binds)
         and len(set(binds))==len(binds),'UNIQUE_EXACT_TEXTUAL_BINDINGS_REQUIRED')
    # Docker's bind order is irrelevant only when each mount destination is
    # unique. Docker sources may be absolute paths or exact named volumes.
    parts=[row.split(':') for row in binds]
    need(all(len(row) in (2,3) and (row[0].startswith('/') or re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*',row[0]) is not None)
             and row[1].startswith('/') and row[1]!='/'
             and (len(row)==2 or len(row[2])>0) for row in parts)
         and len({row[1] for row in parts})==len(parts),'UNIQUE_ABSOLUTE_BIND_DESTINATIONS_REQUIRED')
    value['Binds']=sorted(binds)
    return value
def load_current_entry_r1(pid):
    need(type(pid) is int and pid>1 and pid not in RELEASED,'FRESH_ACK_ACTUAL_PID_REQUIRED')
    for path in [PARENT_CODE/'company-app.py',PARENT_CODE,*PARENT_CODE.parents]:need(not path.is_symlink(),'PARENT_ENTRY_CODE_ALIAS_REFUSED')
    raw=(PARENT_CODE/'company-app.py').read_bytes();need(sha(raw)==ENTRY_SHA,'EXACT_FROZEN_PARENT_ENTRY_REQUIRED')
    entry=module(raw,PARENT_CODE/'company-app.py');need(entry.FROZEN is True and entry.CODE==PARENT_CODE and entry.MANIFEST_SHA==MANIFEST_SHA,'EXACT_PARENT_ENTRY_NAMESPACE_REQUIRED')
    read=entry.read
    pins={PARENT_CODE/'company-app.py':ENTRY_SHA,PARENT_CODE/'native.py':NATIVE_SHA,PARENT_CODE/'controller.py':CONTROLLER_SHA,PARENT_CODE/'manifest.json':MANIFEST_SHA,
          ROOT/(PARENT_NAME+'-root-post-up-audit.json'):AUDIT_SHA,ROOT/(PARENT_NAME+'-journal.json'):JOURNAL_SHA,ROOT/(PARENT_NAME+'-decision.json'):DECISION_SHA,
          ROOT/(PARENT_NAME+'-root-acceptance.json'):ACCEPTANCE_SHA,ROOT/(PARENT_NAME+'-preflight.json'):PREFLIGHT_SHA}
    values={}
    for path,pin in pins.items():
        raw=read(path);need(sha(raw)==pin,'EXACT_PARENT_ENTRY_HISTORY_REQUIRED');values[path]=raw
    manifest=json.loads(values[PARENT_CODE/'manifest.json'])
    need(manifest['name']==PARENT_NAME and manifest['FROZEN'] is True and manifest['status']=='LOCAL_FROZEN_CODE_ONLY'
         and manifest['runtimeAuthorization'] is False,'EXACT_FROZEN_PARENT_MANIFEST_REQUIRED')
    for row in manifest['files']:
        name=row['path'];need(type(name) is str and not Path(name).is_absolute() and '..' not in Path(name).parts,'PARENT_MANIFEST_PATH_REQUIRED')
        raw=read(PARENT_CODE/name);need(sha(raw)==row['sha256'] and len(raw)==row['bytes'],'EXACT_PARENT_MANIFEST_CLOSURE_REQUIRED');pins[PARENT_CODE/name]=row['sha256']
    nmod=module(values[PARENT_CODE/'native.py'],PARENT_CODE/'native.py');cmod=module(values[PARENT_CODE/'controller.py'],PARENT_CODE/'controller.py')
    old=nmod.Native(pid);release=cmod.Release(old,MANIFEST_SHA,ENTRY_SHA)
    state=json.loads(values[ROOT/(PARENT_NAME+'-journal.json')]);decision=json.loads(values[ROOT/(PARENT_NAME+'-decision.json')]);preflight=json.loads(values[ROOT/(PARENT_NAME+'-preflight.json')]);acceptance=json.loads(values[ROOT/(PARENT_NAME+'-root-acceptance.json')]);audit=json.loads(values[ROOT/(PARENT_NAME+'-root-post-up-audit.json')])
    need(state['name']==PARENT_NAME and state['phase']=='CONTENT_UP_STARTED_UNKNOWN' and state['decisionSha256']==DECISION_SHA
         and state['childImage']==PARENT_IMAGE,'EXACT_RETAINED_PARENT_GUARD_STOP_REQUIRED')
    expected_binding=dict(release.binding(),leasePid=3242810)
    need(state['binding']==decision['binding']==preflight['binding']==expected_binding and state['before']==decision['before']==preflight['before']
         and decision['rootAcceptanceSha256']==ACCEPTANCE_SHA and decision['preflightSha256']==PREFLIGHT_SHA
         and acceptance['preflightSha256']==PREFLIGHT_SHA and acceptance['leasePid']==3242810
         and acceptance['nonce']==decision['nonce'] and acceptance['oneApply'] is True,'EXACT_PARENT_HISTORICAL_ADMISSION_LINKS_REQUIRED')
    need(all(acceptance.get(key)==expected_binding[key] for key in ('namespace','manifestSha256','entrySha256','codeAcceptanceSha256','nativeBasisSha256','leasePid','parentImage','payloadScopeSha256','uiReviewSha256','htmlReviewSha256')),'EXACT_PARENT_ADMISSION_BINDING_REQUIRED')
    need(audit['schema']==1 and audit['namespace']==PARENT_NAME and audit['status']=='INSTALLED_ACCEPTED_BY_SUPPLEMENTAL_RUNTIME_AUDIT_NOT_CUSTOMER_ACCEPTANCE'
         and audit['originalJournalUnchanged'] is True and audit['originalJournalPhase']=='CONTENT_UP_STARTED_UNKNOWN'
         and audit['originalGuardStop']=='POST_UP_NORMALIZED_RUNTIME_CHANGED' and audit['originalGuardResultRetained'] is True
         and audit['noRepeatOfApplyBuildUp'] is True and audit['runtimeAuthorization'] is False
         and audit['leasePid']==3242810 and audit['childImage']==PARENT_IMAGE
         and audit['sourceFiles']==239 and audit['staticFiles']==43 and audit['chainFiles']==43
         and audit['runtimeDatabaseWrites']==audit['schemaChanges']==audit['runtimeMutations']==0
         and audit['schemasDataAndPrefixesPreserved'] is True and audit['workerAuthPushPricePreserved'] is True,'EXACT_ACCEPTED_SUPPLEMENTAL_PARENT_AUDIT_REQUIRED')
    need(audit['inputPins']=={str(path):pin for path,pin in pins.items() if path!=ROOT/(PARENT_NAME+'-root-post-up-audit.json')},'EXACT_PARENT_AUDIT_INPUT_CLOSURE_REQUIRED')
    need(state['automaticRetry'] is False and state['automaticRollback'] is False and state['runtimeDatabaseWrites']==state['schemaChanges']==0
         and state['workerRecreated'] is False and state['staticChanges']==3 and state['written']==release.static_targets
         and audit['databaseBackups']==state['backups'] and audit['codeBackups']==state['codeBackups'] and audit['contextPins']==state['contextPins']
         and audit['minimumBeforeUp']==state['minimumBeforeUp'],'EXACT_PARENT_CODE_ONLY_EFFECT_REQUIRED')
    overlay=release.paths['overlay'];overlay_pin=state['overlaySha256'];pins[overlay]=overlay_pin
    need(sha(read(overlay))==overlay_pin,'EXACT_PARENT_OVERLAY_REQUIRED')
    base=copy.deepcopy(audit['after']);content=base['containers']['content'];chain=state['before']['containers']['content']['files']+[str(overlay)]
    expected_content=copy.deepcopy(state['before']['containers']['content']);expected_content.update(image=PARENT_IMAGE,files=chain,configFiles=','.join(chain),filePins={**expected_content['filePins'],str(overlay):overlay_pin},configHash=state['plannedConfigHash'])
    need(len(chain)==len(set(chain))==43 and content==expected_content and base['containers']['chat']==state['before']['containers']['chat']
         and base['contentCid']==audit['runningContentId'] and base['contentCid']!=state['before']['contentCid']
         and all(base[key]==state['before'][key] for key in ('worker','selected','l12','sourceModes','staticModes')),'EXACT_PARENT_FULL239_43_43_REQUIRED')
    host=audit['hostBindOrderProof'];actual=host['actualHostConfig'];prior=host['reconstructedPriorHostConfig'];order=host['permutation']
    need(host['status']=='EXACT_FULL_PRIOR_HOST_CONFIG_REPRODUCED' and host['field']=='Binds' and host['count']==9
         and host['sameNineBindingsOnlyOrderChanged'] is True and host['allOtherHostConfigFieldsByteEquivalent'] is True
         and len(actual['Binds'])==len(set(actual['Binds']))==9 and len(order)==9 and set(order)==set(range(9))
         and prior==dict(actual,Binds=[actual['Binds'][i] for i in order])
         and sha(encoded(actual))==host['actualHostConfigSha256']==base['runtime']['hostConfigSha256']
         and sha(encoded(prior))==host['beforeHostConfigSha256']==state['before']['runtime']['hostConfigSha256'],'EXACT_PARENT_NINE_BIND_ORDER_PROOF_REQUIRED')
    expected_runtime={k:v for k,v in state['before']['runtime'].items() if k not in ('appTree','hostConfigSha256')}
    need(expected_runtime=={k:v for k,v in base['runtime'].items() if k not in ('appTree','hostConfigSha256')}
         and audit['runtimeDifferenceProof']=={'different':['hostConfigSha256'],'otherFiveRuntimeHashesEqual':True},'EXACT_OTHER_PARENT_RUNTIME_FACTS_REQUIRED')
    child=state['childProof'];need(child==audit['childProof'] and child['image']==PARENT_IMAGE and child['sourceFiles']==239
         and child['changedTargets']==sorted(r['target'] for r in old.records)
         and child['appTreeSha256']==sha(encoded(base['runtime']['appTree'])),'EXACT_PARENT_CHILD_PROOF_REQUIRED')
    binding=child['platformImageBinding'];need(binding['target']==PARENT_IMAGE and binding['platform']=='linux/amd64' and type(binding['manifestDigest']) is str
         and re.fullmatch('sha256:[a-f0-9]{64}',binding['manifestDigest']) is not None,'EXACT_ACCEPTED_PARENT_PLATFORM_REQUIRED')
    source=dict(old.current.source)
    for row in old.records:source[row['target']]=row['sha256']
    static={**old.current.static,**{target:row['sha256'] for target,row in old.static_files.records.items()}}
    need(len(source)==239 and len(static)==43 and len(base['sourceModes'])==239 and len(base['staticModes'])==43
         and all(base['runtime']['appTree'][target]['sha256']==pin for target,pin in source.items()),'EXACT_PARENT_SOURCE_MAP_REQUIRED')
    # New attempt uses the deterministic full HostConfig serialization, changing
    # solely the ordering of distinct Binds. The old audit/journal stay byte exact.
    base['runtime']['hostConfigSha256']=sha(encoded(canonical_host_config(actual)))
    def stable():
        old.stable()
        for path,pin in pins.items():need(sha(read(path))==pin,'SEALED_PARENT_ENTRY_HISTORY_CHANGED')
        old.code_backup_guard(state['codeBackups']);release.context_guard(state['contextPins'],True);old.backup_guard(state['backups'])
    stable()
    need(old.verify_child(PARENT_IMAGE,state['before'])==child,'EXACT_PARENT_INDEPENDENT_CHILD_PROOF_REQUIRED')
    return old.a,old.b,old.prior,types.SimpleNamespace(base=base,source=source,static=static,stable=stable,cabinet=old.current.cabinet,
        managed_guard=old.current.managed_guard,content_migration=copy.deepcopy(old.current.content_migration),
        report_minimum=copy.deepcopy(audit['minimumAfterAudit']['report']),traffic_minimum=copy.deepcopy(audit['minimumAfterAudit']['traffic']),
        parent_release=PARENT_NAME,parent_receipt=AUDIT_SHA,parent_decision=DECISION_SHA,parent_image=PARENT_IMAGE,parent_chain_count=43,
        parent_platform_manifest=binding['manifestDigest'])
