'use strict';
// One official store.save call. No HTTP, auth grants, SQL business writer,
// manual version writes, retry, restore, or public-acceptance claim.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const SITE='site-44bbe13f1bad5e005b2a',COMPANY='palitra-love',NS='palitra-unified-orders-20261021-r7';
const STORE='a28a415413a831ab9d1d4f2fa4655f00971f4ce7d88f2681077119401d4a1b96';
const AUTH='b0dde548b7f252591858607604708d4d96847968e90f0147a50881c6a9ca074a';
const PRICE='79d62dd78fc00347758c248a2b733e407bdacccf6094fe0a8f3e69f01c7a5943';
const NAMES=['assets/order.js','assets/palitra-attribution.js','assets/storefront.js'];
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const need=(v,c)=>{if(!v)throw Error(c);};
function canonical(v){
  if(typeof v==='bigint')return '{"__sqlite_bigint__":'+JSON.stringify(v.toString())+'}';
  if(v instanceof Uint8Array)return '{"__sqlite_blob_hex__":'+JSON.stringify(Buffer.from(v).toString('hex'))+'}';
  return Array.isArray(v)?'['+v.map(canonical).join(',')+']':v&&typeof v==='object'?'{'+Object.keys(v).sort().map(k=>JSON.stringify(k)+':'+canonical(v[k])).join(',')+'}':JSON.stringify(v);
}
const same=(a,b,c)=>need(canonical(a)===canonical(b),c);
function safe(p,missing=false){
  need(path.isAbsolute(p)&&path.normalize(p)===p,'CANONICAL_NATIVE_PATH_REQUIRED');
  for(let q=missing?path.dirname(p):p;;q=path.dirname(q)){const s=fs.lstatSync(q);need(!s.isSymbolicLink()&&s.uid===0&&s.gid===0,'ROOT_NATIVE_PATH_REQUIRED');if(q===path.dirname(q))break;}
  return p;
}
function read(p,limit=32*1024*1024){
  safe(p);const a=fs.lstatSync(p);need(a.isFile()&&a.nlink===1&&a.size<=limit,'REGULAR_BOUNDED_NATIVE_FILE');
  const fd=fs.openSync(p,fs.constants.O_RDONLY|fs.constants.O_NOFOLLOW|fs.constants.O_NONBLOCK);
  try{const b=fs.fstatSync(fd),raw=fs.readFileSync(fd),z=fs.fstatSync(fd),q=fs.lstatSync(p);for(const k of ['dev','ino','uid','gid','mode','size','nlink','mtimeMs','ctimeMs'])need(a[k]===b[k]&&a[k]===z[k]&&a[k]===q[k],'NATIVE_READ_RACE');need(raw.length===a.size,'NATIVE_READ_SIZE');return raw;}finally{fs.closeSync(fd);}
}
function write(root,name,value){
  const raw=Buffer.from(canonical(value)),p=path.join(root,name);need(raw.length<=4*1024*1024&&path.dirname(p)===root,'PRIVATE_SMALL_PROOF_ONLY');
  const fd=fs.openSync(safe(p,true),fs.constants.O_WRONLY|fs.constants.O_CREAT|fs.constants.O_EXCL|fs.constants.O_NOFOLLOW,0o600);
  try{fs.writeFileSync(fd,raw);fs.fsyncSync(fd);}finally{fs.closeSync(fd);}
  need(read(p).equals(raw),'PRIVATE_PROOF_READBACK');return {path:p,sha256:sha(raw)};
}
function checkInput(input){
  need(input&&input.schema==='palitra-unified-native-service-input/v1'&&input.namespace===NS,'EXACT_SERVICE_INPUT');
  const {plan,old,action,payloads}=input;
  need(plan.transport==='native-workspace-service'&&plan.status==='ROOT_REVIEWED_NATIVE_SERVICE_PLAN_NOT_PUBLICATION'&&plan.serviceMethod==='originalWorkspaceStore.save'&&plan.serviceSourceSha256===STORE&&plan.saveCalls===1&&plan.existingOwnerLogin==='vladislav'&&plan.existingPermission==='site_editor.edit'&&plan.runtimeAuthorization===false&&plan.parentVersion===260&&plan.rawRuntimeFileWrites===0&&plan.priceUnchanged===true,'EXACT_SERVICE_PLAN');
  same(Object.keys(plan.changedFiles).sort(),NAMES,'EXACT_THREE_SERVICE_INPUTS');same(Object.keys(payloads).sort(),NAMES,'EXACT_THREE_PAYLOADS');
  need(plan.baseRevision===old.current260.revision&&old.current260.version===260&&old.current260.fileCount===140&&old.current260.mismatches.length===0,'EXACT_SERVICE_BASE260');
  same(plan.newTrackerMetadata,{uid:0,gid:0,mode:0o600,nlink:1,regular:true,canonical:true},'HONEST_NATIVE_SERVICE600_METADATA');
  need(old.current260.files['data/price.json'].sha256===PRICE,'EXACT_PRICE');
  // Original store.save creates every copied file0600/directory0700. Refuse
  // incompatible metadata BEFORE any write instead of chmodding old versions.
  need(Object.values(old.current260.files).every(v=>v.uid===0&&v.gid===0&&v.mode===0o600&&v.nlink===1&&v.regular===true&&v.canonical===true),'STORE_CANNOT_PRESERVE_EXISTING_FILE_METADATA');
  need(Object.values(old.current260.directories).every(v=>v.uid===0&&v.gid===0&&v.mode===0o700),'STORE_CANNOT_PRESERVE_EXISTING_DIRECTORY_METADATA');
  let total=0;const files=NAMES.map(name=>{const content=payloads[name];need(typeof content==='string'&&!content.includes('\u0000'),'TEXT_SERVICE_PAYLOAD');const raw=Buffer.from(content);need(raw.length>0&&raw.length<=2*1024*1024&&(total+=raw.length)<=8*1024*1024&&sha(raw)===plan.changedFiles[name],'EXACT_REVIEWED_SERVICE_BYTES');return {path:name,content};});
  need(action.mode==='save'&&action.namespace===NS&&action.status==='ROOT_AUTHORIZED_ONE_ATTEMPT'&&action.runtimeAuthorization===true&&action.packageSha256===input.packageSha256&&action.bindings.managedAdoptionPlan.sha256===input.planSha256&&action.bindings.pendingNativeAdoptionSha256===input.pendingSha256,'EXACT_SERVICE_ROOT_ACTION');
  need(action.createdAtUnix<=Date.now()/1000&&Date.now()/1000<action.expiresAtUnix&&action.expiresAtUnix-action.createdAtUnix<=1800,'FRESH_SERVICE_ROOT_ACTION');
  return files;
}
function databaseFacts(db){
  const schema=db.prepare("SELECT type,name,tbl_name,sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%' ORDER BY type,name").all();
  const tables={};let count=0;
  for(const r of schema.filter(r=>r.type==='table')){
    const hashes=[];const q='SELECT * FROM "'+r.name.replaceAll('"','""')+'"';const st=db.prepare(q);st.setReadBigInts(true);
    for(const row of st.iterate()){need(++count<=2000000,'DATABASE_ROW_BOUND');hashes.push(sha(canonical(row)));}
    hashes.sort();tables[r.name]={count:hashes.length,sha256:sha(canonical(hashes)),hashes};
  }
  return {schemaSha256:sha(canonical(schema)),tables};
}
function checkDatabaseDelta(before,after,db,user,revision){
  same(before.schemaSha256,after.schemaSha256,'SERVICE_SCHEMA_CHANGED');same(Object.keys(before.tables).sort(),Object.keys(after.tables).sort(),'SERVICE_TABLE_SET_CHANGED');
  const mutable=new Set(['managed_sites','site_workspaces','site_workspace_revisions']);const changed=[];
  for(const name of Object.keys(before.tables))if(!mutable.has(name)&&before.tables[name].sha256!==after.tables[name].sha256)changed.push(name);
  need(changed.length===1,'ONLY_ONE_NATIVE_AUDIT_APPEND_ALLOWED');
  const table=changed[0],a=before.tables[table],b=after.tables[table];need(b.count===a.count+1,'NATIVE_AUDIT_APPEND_COUNT');
  const old=new Map();for(const h of a.hashes)old.set(h,(old.get(h)||0)+1);let extra;
  const st=db.prepare('SELECT * FROM "'+table.replaceAll('"','""')+'"');st.setReadBigInts(true);
  for(const row of st.iterate()){const h=sha(canonical(row));if(old.get(h)){old.set(h,old.get(h)-1);continue;}need(!extra,'ONLY_ONE_NATIVE_AUDIT_ROW');extra=row;}
  need([...old.values()].every(v=>v===0)&&extra,'NATIVE_AUDIT_OLD_ROWS_PRESERVED');
  const values=Object.values(extra);need(values.includes('SITE_FILES_SAVED')&&values.some(v=>v===BigInt(user.id)),'ACTUAL_NATIVE_AUDIT_ACTOR_ACTION');
  const expected={siteId:SITE,companyCode:COMPANY,revision,files:NAMES};
  need(values.some(v=>{if(typeof v!=='string')return false;try{return canonical(JSON.parse(v))===canonical(expected);}catch{return false;}}),'ACTUAL_NATIVE_AUDIT_EXACT_THREE_PATHS');
  return {schemaUnchanged:true,protectedTablesUnchanged:true,auditRowsAdded:1,auditTableSha256:sha(table),auditAfterSha256:b.sha256};
}
async function run(input){
  const files=checkInput(input);need(process.platform==='linux'&&process.getuid()===0&&process.getgid()===0,'ROOT_LINUX_NATIVE_ONLY');
  need(sha(read('/app/site-workspaces.js',2*1024*1024))===STORE&&sha(read('/app/auth-store.js',2*1024*1024))===AUTH,'ORIGINAL_NATIVE_SERVICE_CODE_REQUIRED');
  const {DatabaseSync,backup}=require('node:sqlite');
  const {createAuthStore,COMPANIES}=require('/app/auth-store.js'),{createWorkspaceStore}=require('/app/site-workspaces.js');
  const probe=input.probeSource;need(typeof probe==='string'&&sha(Buffer.from(probe))===input.probeSha256,'EXACT_READONLY_PROBE_SOURCE');
  // The probe has no entry action; compile its exports in a private module.
  const module={exports:{}};new Function('require','module','exports',probe)(require,module,module.exports);const inspector=module.exports;
  const area='/data/'+NS+'-save';safe('/data');need(!fs.existsSync(area),'SERVICE_ATTEMPT_EXISTS_NO_REPLAY');
  let db=new DatabaseSync(safe('/data/content.sqlite'),{readOnly:true});let before,baseRow,baseRevision,baseAllRows,actor;
  function workspace(db){const row=db.prepare('SELECT m.id,m.company_code,m.publication_status,w.current_revision FROM managed_sites m JOIN site_workspaces w ON w.site_id=m.id WHERE m.id=?').get(SITE);same(row,input.old.workspace,'EXACT_SERVICE_WORKSPACE_POINTER');const rev=db.prepare('SELECT version,manifest_json FROM site_workspace_revisions WHERE site_id=? AND revision=?').get(SITE,row.current_revision);need(rev.version===260&&sha(rev.manifest_json)===input.old.current260.manifestSha256,'EXACT_SERVICE_REVISION260');return {row,rev};}
  function selectedRows(db){return {managed:db.prepare('SELECT * FROM managed_sites ORDER BY id').all(),workspaces:db.prepare('SELECT * FROM site_workspaces ORDER BY site_id').all(),revisions:db.prepare('SELECT * FROM site_workspace_revisions ORDER BY site_id,version').all()};}
  function existingAuth(db){const row=db.prepare('SELECT id FROM auth_users WHERE login=?').get('vladislav');need(row,'ACTUAL_EXISTING_OWNER');const service=createAuthStore(db),user=service.getById(row.id);need(user.login==='vladislav'&&user.role==='owner'&&user.companyCodes.includes(COMPANY)&&user.permissions.includes('site_editor.edit'),'ACTUAL_EXISTING_OWNER_EDIT_PERMISSION');return {service,user};}
  let backupRef;
  try{
    const current=workspace(db);baseRow=current.row;baseRevision=current.rev;actor=existingAuth(db).user;
    const actual=inspector.inventory(input.old.current260.root,JSON.parse(current.rev.manifest_json),140);same(actual.files,input.old.current260.files,'EXACT_ALL140_BEFORE_FILES');same(actual.directories,input.old.current260.directories,'EXACT_BEFORE_DIRECTORIES');
    before=databaseFacts(db);baseAllRows=selectedRows(db);fs.mkdirSync(area,{mode:0o700});safe(area);
    const backupPath=area+'/content.sqlite';await backup(db,backupPath);fs.chmodSync(backupPath,0o600);const check=new DatabaseSync(safe(backupPath),{readOnly:true});try{need(check.prepare('PRAGMA quick_check').get().quick_check==='ok','NATIVE_CONSISTENT_BACKUP_REQUIRED');same(databaseFacts(check),before,'BACKUP_MUST_MATCH_BEFORE_DATABASE');}finally{check.close();}
    backupRef={path:backupPath,sha256:sha(read(backupPath,256*1024*1024))};
    write(area,'BEFORE.json',{schema:'palitra-unified-native-service-before/v1',packageSha256:input.packageSha256,planSha256:input.planSha256,pendingSha256:input.pendingSha256,revision:baseRow.current_revision,version:260,backup:backupRef,databaseFactsSha256:sha(canonical(before)),files140FactsSha256:actual.factsSha256});
  }finally{db.close();}
  db=new DatabaseSync(safe('/data/content.sqlite'));
  try{
    checkInput(input);workspace(db);same(databaseFacts(db),before,'LAST_NATIVE_DATABASE_CAS_CHANGED');same(selectedRows(db),baseAllRows,'LAST_NATIVE_ROWS_CHANGED');
    const {service,user}=existingAuth(db);same(user,actor,'OWNER_OR_PERMISSIONS_CHANGED');
    const store=createWorkspaceStore({db,root:'/data/projects',sources:{},companies:COMPANIES,audit:service.audit});
    same(databaseFacts(db),before,'NATIVE_CONSTRUCTOR_CHANGED_EXISTING_DATA');
    write(area,'SAVE_STARTED.json',{status:'STARTED_UNKNOWN_NO_RETRY',method:'originalWorkspaceStore.save',transport:'native-workspace-service',packageSha256:input.packageSha256,planSha256:input.planSha256,pendingSha256:input.pendingSha256,baseRevision:baseRow.current_revision,saveCalls:1,automaticRetry:false});
    const saved=store.save(user,SITE,{baseRevision:baseRow.current_revision,files,message:'Палитра: единые заказы, источник клиента и непрочитанные сообщения'});
    need(saved.siteId===SITE&&saved.version===261&&saved.revision!==baseRow.current_revision,'EXACT_ONE_FORWARD_NATIVE_SAVE');
    const rows=selectedRows(db),expected=structuredClone(baseAllRows);
    const site=expected.managed.find(r=>r.id===SITE),ws=expected.workspaces.find(r=>r.site_id===SITE);site.updated_at=rows.managed.find(r=>r.id===SITE).updated_at;ws.current_revision=saved.revision;
    const added=rows.revisions.filter(r=>r.site_id===SITE&&r.revision===saved.revision);need(added.length===1&&added[0].version===261&&added[0].author_id===user.id,'ONE_NATIVE_REVISION_AUTHOR');expected.revisions.push(added[0]);expected.revisions.sort((a,b)=>a.site_id.localeCompare(b.site_id)||a.version-b.version);same(rows,expected,'ONLY_NATIVE_WORKSPACE_ROWS_MAY_CHANGE');
    const protectedProof=checkDatabaseDelta(before,databaseFacts(db),db,user,saved.revision);
    same(existingAuth(db).user,user,'FINAL_OWNER_PERMISSIONS_CHANGED');need(sha(read('/app/site-workspaces.js'))===STORE&&sha(read('/app/auth-store.js'))===AUTH,'FINAL_NATIVE_SERVICE_CODE_CHANGED');
    const readback=inspector.capture({old:input.old,plan:input.plan});need(readback.currentRevision===saved.revision&&readback.currentVersion===261,'EXACT_SERVICE_AND_FRESH_READBACK');
    const outcome={schema:'palitra-unified-native-service-save-outcome/v1',status:'NATIVE_SERVICE_SAVED_REQUIRES_ROOT_PUBLIC_READBACK',transport:'native-workspace-service',serviceMethod:'originalWorkspaceStore.save',saveCalls:1,existingOwner:true,permissionsUnchanged:true,serviceCodeUnchanged:true,baseRevision:baseRow.current_revision,currentRevision:saved.revision,currentVersion:saved.version,packageSha256:input.packageSha256,planSha256:input.planSha256,pendingSha256:input.pendingSha256,filesBefore:140,filesAfter:141,other137Unchanged:true,priceUnchanged:true,rawRuntimeFileWrites:0,changedFiles:input.plan.changedFiles,full141FactsSha256:readback.full141FactsSha256,backup:backupRef,protectedProof,automaticRetry:false,automaticRestore:false,runtimeAcceptance:false};
    const ref=write(area,'NATIVE_SAVE_OUTCOME.json',outcome);return {status:outcome.status,outcome:ref,backup:backupRef,currentVersion:saved.version,currentRevision:saved.revision,full141FactsSha256:readback.full141FactsSha256,runtimeAcceptance:false};
  }finally{db.close();}
}
module.exports={checkInput,checkDatabaseDelta,databaseFacts,canonical,run};
