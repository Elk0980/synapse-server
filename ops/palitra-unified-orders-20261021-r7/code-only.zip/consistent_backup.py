"""Explicit new private SQLite backup writer for the frozen read-only classes.

Does not attach a missing method, compile an old writer or change a source DB.
Existing read/guard/backup_guard and their actual connection_seal remain the
authority. ABSENT traffic stays absent; no placeholder SQLite DB is created.
"""
import hashlib,os,sqlite3,stat,tempfile,time
from contextlib import closing
from pathlib import Path
from manifest_inputs import need
from private_files import exact,sync,read_identity

LIMIT=512*1024*1024
def file_sha(path,limit=LIMIT):
    p=exact(path);a=p.lstat();need(stat.S_ISREG(a.st_mode) and a.st_nlink==1 and a.st_size<=limit,'BOUNDED_PRIVATE_BACKUP_FILE_REQUIRED')
    fd=os.open(p,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0)|getattr(os,'O_BINARY',0));h=hashlib.sha256();total=0
    try:
        while True:
            raw=os.read(fd,1024*1024)
            if not raw:break
            total+=len(raw);need(total<=limit,'BACKUP_BYTES_EXCEED_BOUND');h.update(raw)
        b=os.fstat(fd);z=p.lstat()
        # Existing platform reader keeps full native ctime/owner/mode checks;
        # only local NTFS uses its documented creation-time cache predicate.
        need(read_identity(a)==read_identity(b)==read_identity(z) and total==a.st_size,'BACKUP_CHANGED_WHILE_HASHING')
        need(os.name!='posix' or a.st_uid==a.st_gid==0 and stat.S_IMODE(a.st_mode)==0o600,'ROOT600_PRIVATE_BACKUP_REQUIRED')
    finally:os.close(fd)
    return h.hexdigest(),total

def sealer(db,key):
    expected={'report':'ReportDatabase','content':'ContentDatabase','traffic':'TrafficDatabase'}
    need(key in expected and type(db).__name__==expected[key],'EXACT_FROZEN_DATABASE_CLASS_REQUIRED')
    # For Content, ReportDatabase.read's globals were deliberately rebound by
    # the frozen inspector to content_functions.connection_seal. Preserve that
    # real binding; do not select a report schema for the generic content DB.
    function=db.read.__func__.__globals__.get('connection_seal')
    need(callable(function) and function.__name__=='connection_seal','ACTUAL_FROZEN_CONNECTION_SEAL_REQUIRED')
    need(db.backup_guard.__func__.__globals__.get('connection_seal') is function,'READ_AND_BACKUP_GUARD_SEAL_MUST_MATCH')
    return function

def unchanged(db,expected,key):
    value=db.guard(expected)
    if key=='traffic':
        need(value==expected,'TRAFFIC_CHANGED_SINCE_APPROVED_BACKUP_BASIS')
        if expected['status']=='ABSENT':
            need(value.get('identity') is None and value.get('content') is None and set(value['family'])=={'db','wal','shm','journal'} and all(v is None for v in value['family'].values()),'TRAFFIC_ABSENT_FAMILY_MUST_STAY_ABSENT')
    else:need(value['identity']==expected['identity'] and value['content']==expected['content'],'DATABASE_CHANGED_SINCE_APPROVED_BACKUP_BASIS')
    return value

def sqlite_snapshot(source,destination,seal,expected,private,lease):
    # Destination is reserved EXCL by the only private writer before sqlite
    # opens it. Source is existing read-only (or an own private traffic clone).
    uri=Path(source).as_uri()+'?mode=ro'
    with closing(sqlite3.connect(uri,uri=True,timeout=5)) as src:
        src.execute('PRAGMA query_only=ON');src.execute('BEGIN')
        need(src.execute('PRAGMA quick_check').fetchall()==[('ok',)],'SOURCE_SQLITE_INTEGRITY_REQUIRED')
        value=seal(src);need(value==expected,'LATE_SOURCE_CONTENT_CHANGED_BEFORE_BACKUP')
        lease();private.guard();private.write(destination,b'',0o600)
        deadline=time.monotonic()+30
        def progress(status,remaining,total):
            need(time.monotonic()<=deadline,'BOUNDED_CONSISTENT_BACKUP_REQUIRED');private.guard();lease()
        with closing(sqlite3.connect(str(destination),timeout=5)) as out:
            src.backup(out,pages=256,progress=progress,sleep=0.02)
            out.execute('PRAGMA journal_mode=DELETE')
            need(out.execute('PRAGMA quick_check').fetchall()==[('ok',)] and seal(out)==value and seal(src)==value,'EXACT_CONSISTENT_BACKUP_CONTENT_REQUIRED')
        src.rollback()
    with Path(destination).open('r+b') as fd:fd.flush();os.fsync(fd.fileno())
    sync(Path(destination).parent)
    need(all(not os.path.lexists(str(destination)+suffix) for suffix in ('-wal','-shm','-journal')),'CLOSED_PRIVATE_BACKUP_SIDECARS_REQUIRED')
    return value

def copy_traffic_source(db,facts,temporary,private):
    # Traffic's frozen reader clones DB+WAL because opening an untouched live
    # WAL family could create SHM. Use an own temporary clone for this writer as
    # well. Never open or write the live traffic DB through sqlite.
    for key,suffix in (('db',''),('wal','-wal')):
        row=facts['family'][key]
        if row is None:continue
        source=exact(str(db.path)+suffix);destination=Path(temporary)/('snapshot.sqlite'+suffix)
        a=source.lstat();need(a.st_size==row['bytes'] and row['bytes']<=128*1024*1024,'EXACT_TRAFFIC_CLONE_BOUND')
        src=os.open(source,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0)|getattr(os,'O_BINARY',0));dest=os.open(destination,os.O_WRONLY|os.O_CREAT|os.O_EXCL|getattr(os,'O_NOFOLLOW',0)|getattr(os,'O_BINARY',0),0o600)
        h=hashlib.sha256();total=0
        try:
            with os.fdopen(dest,'wb',closefd=False) as out:
                while True:
                    raw=os.read(src,1024*1024)
                    if not raw:break
                    total+=len(raw);need(total<=row['bytes'],'TRAFFIC_GREW_DURING_CLONE');h.update(raw);out.write(raw)
                out.flush();os.fsync(out.fileno())
            b=os.fstat(src);z=source.lstat()
            need(read_identity(a)==read_identity(b)==read_identity(z),'TRAFFIC_FILE_IDENTITY_CHANGED_DURING_BACKUP_CLONE')
            need(total==row['bytes'],'TRAFFIC_FILE_SIZE_CHANGED_DURING_BACKUP_CLONE')
            need(h.hexdigest()==row['sha256'],'TRAFFIC_FILE_HASH_CHANGED_DURING_BACKUP_CLONE')
        finally:os.close(dest);os.close(src)
    private.guard();need(db.facts()==facts,'TRAFFIC_FAMILY_CHANGED_AFTER_CLONE')

def backup_one(db,key,destination,minimum,private,guard,lease):
    guard();lease();private.guard();destination=private.path(destination,True)
    need(destination.parent==private.root and destination.name==key+'-before.sqlite' and not os.path.lexists(destination),'NEW_EXACT_PRIVATE_DATABASE_BACKUP_REQUIRED')
    seal=sealer(db,key);current=unchanged(db,minimum,key)
    if key=='traffic' and current['status']=='ABSENT':
        guard();lease();unchanged(db,current,key)
        row={'status':'ABSENT','path':None,'sha256':None,'bytes':0,'directoryIdentity':current['directoryIdentity'],'family':current['family']}
        db.backup_guard(row);return row
    if key=='traffic':
        prefix=current['content'].get('checkedPrefixRevision')
        actual_seal=lambda connection:seal(connection,prefix)
        facts=db.facts();need(facts=={'directoryIdentity':current['directoryIdentity'],'family':current['family']},'EXACT_TRAFFIC_FAMILY_BEFORE_BACKUP')
        with tempfile.TemporaryDirectory(prefix='r7-traffic-clone-',dir=private.root) as temporary:
            need(private.root.resolve() in Path(temporary).resolve().parents,'OWN_PRIVATE_TRAFFIC_TEMP_ONLY')
            copy_traffic_source(db,facts,temporary,private)
            content=sqlite_snapshot(Path(temporary)/'snapshot.sqlite',destination,actual_seal,current['content'],private,lease)
            need(db.facts()==facts,'TRAFFIC_FAMILY_CHANGED_DURING_BACKUP')
    else:content=sqlite_snapshot(exact(db.path),destination,seal,current['content'],private,lease)
    guard();lease();unchanged(db,current,key);pin,size=file_sha(destination)
    row={'status':'EXISTING','path':str(destination),'sha256':pin,'bytes':size,'content':content}
    db.backup_guard(row);guard();lease();unchanged(db,current,key);return row

def backup_three(databases,minimum,private,guard,lease):
    need(set(databases)==set(minimum)=={'report','content','traffic'} and callable(guard) and callable(lease),'EXACT_THREE_DATABASE_BACKUP_DOMAIN_REQUIRED')
    result={}
    for key in ('report','content','traffic'):
        result[key]=backup_one(databases[key],key,private.root/(key+'-before.sqlite'),minimum[key],private,guard,lease)
    # A late change to an earlier DB cannot hide behind completion of a later
    # backup. Do not build/migrate/up on an inconsistent three-DB basis.
    for key in ('report','content','traffic'):unchanged(databases[key],minimum[key],key);databases[key].backup_guard(result[key])
    guard();lease();return result
