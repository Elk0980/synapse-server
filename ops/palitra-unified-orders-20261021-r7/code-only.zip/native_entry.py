"""New disabled-by-default native entry. Only a fresh external Root action admits.

No old cleanup entry is imported. No flags enable or replay an old attempt.
All code is checked before imports; all JSON reports omit private business data.
"""
import argparse,hashlib,json,os,re,stat,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('/opt/synapse/releases/palitra-app-20261015')
NAME='palitra-unified-orders-20261021-r7'
sha=lambda b:hashlib.sha256(b).hexdigest()
def need(v,c):
    if not v:raise ValueError(c)
def load_package(directory,manifest_sha,*,require_native=True):
    need(re.fullmatch('[a-f0-9]{64}',manifest_sha or '') is not None,'EXPLICIT_REVIEWED_PACKAGE_SHA_REQUIRED')
    directory=Path(directory)
    if require_native:need(os.name=='posix' and os.geteuid()==0 and directory==ROOT/(NAME+'-code'),'EXACT_ROOT_NATIVE_NAMESPACE_REQUIRED')
    def read(path):
        for p in [path,*path.parents]:need(not p.is_symlink(),'PACKAGE_ALIAS_REFUSED')
        s=path.lstat();need(stat.S_ISREG(s.st_mode) and s.st_nlink==1 and s.st_size<=16*1024*1024,'BOUNDED_REGULAR_PACKAGE_FILE_REQUIRED')
        if require_native:need(s.st_uid==s.st_gid==0 and stat.S_IMODE(s.st_mode)==0o600,'ROOT600_PACKAGE_FILE_REQUIRED')
        raw=path.read_bytes();z=path.lstat();need((s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)==(z.st_dev,z.st_ino,z.st_size,z.st_mtime_ns,z.st_ctime_ns) and len(raw)==s.st_size,'PACKAGE_CHANGED_DURING_READ');return raw
    raw=read(directory/'code-manifest.json');need(sha(raw)==manifest_sha,'EXACT_CODE_MANIFEST_REQUIRED');manifest=json.loads(raw)
    need(manifest.get('schema')=='palitra-unified-native-code-manifest/v1' and manifest.get('runtimeAuthorization') is False and manifest.get('mutableRuntimeFiles')==[] and manifest.get('namespace')==NAME,'CODE_ONLY_CLOSED_PACKAGE_REQUIRED')
    files=manifest['files'];need(type(files) is dict and 15<=len(files)<=256,'BOUNDED_CLOSED_PACKAGE_REQUIRED')
    expected_dirs={p.as_posix() for name in files for p in Path(name).parents if str(p)!='.'};actual_dirs=set()
    for path in directory.rglob('*'):
        need(not path.is_symlink(),'UNLISTED_PACKAGE_DIRECTORY_ALIAS_REFUSED')
        if path.is_dir():actual_dirs.add(path.relative_to(directory).as_posix())
    need(actual_dirs==expected_dirs,'PACKAGE_DIRECTORY_CLOSURE_CHANGED')
    actual={p.relative_to(directory).as_posix() for p in directory.rglob('*') if not p.is_dir()}
    need(actual==set(files)|{'code-manifest.json'},'PACKAGE_FILE_CLOSURE_CHANGED')
    for name,pin in files.items():
        need(type(name) is str and not name.startswith('/') and '\\' not in name and ':' not in name and all(p not in ('','.','..') for p in name.split('/')),'PACKAGE_RELATIVE_PATH_REQUIRED');need(sha(read(directory/name))==pin,'PACKAGE_CODE_OR_PAYLOAD_CHANGED')
    return json.loads(read(directory/'package.json')),manifest

def main(argv=None):
    p=argparse.ArgumentParser();p.add_argument('--mode',choices=('apply','finish','accept'),required=True);p.add_argument('--manifest-sha',required=True);p.add_argument('--action',type=Path,required=True);p.add_argument('--action-sha',required=True);a=p.parse_args(argv)
    directory=Path(__file__).resolve().parent;package,manifest=load_package(directory,a.manifest_sha)
    from manifest_inputs import read_pin,IMAGE,NAMESPACE,digest
    from install_protocol import Admission,Controller,require_native_plan,validate_bindings
    from private_files import PrivateFiles,encoded,exact,read
    from forward_guard import load_inspector,factory_type
    from native_adapter import Driver
    from post_cleanup_basis import require_accepted_basis,inspect_transaction_receipt
    from post_content_capture import ENGINE_SHA
    action=Admission({'path':str(a.action),'sha256':a.action_sha},a.manifest_sha,a.mode);auth=action.check();bindings=auth['bindings']
    validate_bindings(a.mode,bindings)
    def private_json(ref):
        p=exact(ref['path']);need(ROOT in p.parents and p.suffix=='.json','PRIVATE_RELEASE_JSON_PROOF_REQUIRED');s=p.lstat();need(s.st_uid==s.st_gid==0 and stat.S_IMODE(s.st_mode)==0o600,'ROOT600_PRIVATE_PROOF_REQUIRED');return read_pin(ref,json_document=True)
    plan=private_json(bindings['managedAdoptionPlan']);require_native_plan(plan,package);package['_managedAdoptionPlan']=plan
    need(bindings['compatibilityInspectorManifestSha256']==package['compatibilityInspectorManifest']['sha256'],'ACTION_MUST_BIND_FINAL_INSPECTOR')
    # The real server paths are separately bound by Root; Windows authoring
    # paths from local package provenance are never opened at runtime.
    inspector_path=Path(bindings['inspectorDirectory']);need(inspector_path.parent==ROOT,'EXACT_STAGED_READONLY_INSPECTOR_DIRECTORY_REQUIRED')
    inspector,pins=load_inspector(inspector_path,package['compatibilityInspectorManifest']['sha256'])
    if a.mode=='apply':
        receipt=private_json(bindings['cleanupReceipt']);capture=private_json(bindings['postCapture']);accepted=private_json(bindings['acceptedPostCleanupBasis'])
        require_accepted_basis(accepted,actual_receipt_sha256=bindings['cleanupReceipt']['sha256'],actual_post_capture_sha256=bindings['postCapture']['sha256'])
        inspect_transaction_receipt(receipt,engine_sha256=ENGINE_SHA,pre_full_sha256=bindings['preFullInspectionSha256'],user_approval_sha256=bindings['cleanupUserApprovalSha256'])
        need(capture.get('schema')=='palitra-post-cleanup-current-content-capture/v1' and capture.get('cleanupReceiptSha256')==bindings['cleanupReceipt']['sha256'] and capture.get('transactionWholeAfter')==receipt['transactionEvidence']['wholeAfter'] and capture.get('runtimeAuthorization') is False and capture.get('typedContentSha256')==bindings['beforeContentSha256'],'ACTUAL_ROOT_POSTCOMMIT_CAPTURE_REQUIRED')
        native_minimum=private_json(bindings['acceptedNativeMinimum'])
        need(capture.get('nativeContentMinimum')==native_minimum,'SAME_READ_CAPTURE_MUST_BIND_NATIVE_CONTENT_MINIMUM')
        need(accepted.get('nativeContentMinimumSha256')==bindings['acceptedNativeMinimum']['sha256'] and accepted.get('typedContentSha256')==bindings['beforeContentSha256'],'ROOT_ACCEPTED_NATIVE_AND_TYPED_MINIMUM_REFERENCES_REQUIRED')
        need(bindings['schemaSha256']==package['schemaFile']['sha256'],'ACTION_SCHEMA_PIN_CHANGED')
        pending=None
    elif a.mode=='finish':
        pending=private_json(bindings['pendingNativeAdoption']);need(bindings['pendingNativeAdoptionSha256']==sha(encoded(pending)),'EXACT_PENDING_DOCUMENT_BINDING_REQUIRED');native_minimum=pending['minimum']['content']
    else:
        installed=private_json(bindings['installedPendingAcceptance']);native_minimum=installed['minimum']['content']
    factory=factory_type(inspector)(auth['lease']['pid'],pins,native_minimum,finish=a.mode!='apply')
    need(factory.ticks==auth['lease']['startTicks'],'ACTUAL_LEASE_START_CHANGED')
    # No runtime data area is created before all action/basis/code references.
    private_root=ROOT/(NAME+'-'+a.mode)
    need(not private_root.exists(),'OWN_ATTEMPT_EXISTS_NO_REPLAY');private_root.mkdir(mode=0o700);private=PrivateFiles(private_root)
    def guard():
        action.check();load_package(directory,a.manifest_sha)
        for ref in bindings.values():
            if type(ref) is dict and set(ref)=={'path','sha256'}:private_json(ref)
    payloads={target:{'path':str(directory/row['path']),'sha256':row['sha256']} for target,row in package['payloads'].items()}
    package['schemaFile']={'path':str(directory/package['schemaFile']['path']),'sha256':package['schemaFile']['sha256']};package['beforeContentSha256']=bindings.get('beforeContentSha256')
    driver=Driver(factory,package['map'],private,read(directory/'historical-native-read-source.py'),payloads,guard);controller=Controller(action,driver,package,private)
    if a.mode=='apply':result=controller.apply()
    else:
        managed_receipt=private_json(bindings['nativeAdoptionReceipt'])
        need(managed_receipt['planSha256']==bindings['managedAdoptionPlan']['sha256'],'SAME_EXACT_NATIVE_PLAN_THROUGH_ALL_ACTIONS_REQUIRED')
        script=read(directory/'native-adoption-probe.cjs').decode()
        invocation=script+"\nconst raw=fs.readFileSync(0);need(raw.length<=1048576,'INPUT_BOUND');process.stdout.write(JSON.stringify(capture(JSON.parse(raw))));"
        def managed_guard():
            guard();factory.lease();raw=encoded({'old':factory.managed,'plan':plan});need(len(raw)<=1024*1024,'BOUNDED_ADOPTION_GUARD_INPUT')
            r=subprocess.run(['docker','exec','-i','synapse-content-1','node','--disable-warning=ExperimentalWarning','-e',invocation],input=raw,capture_output=True,timeout=90)
            need(r.returncode==0 and not r.stderr and len(r.stdout)<=32768,'NATIVE141_READBACK_REFUSED');v=json.loads(r.stdout)
            need(v.get('status')=='EXACT_NATIVE141_READONLY_NOT_INSTALL_ACCEPTANCE' and v.get('runtimeWrites')==0 and v.get('historicalUnchanged') is True and v.get('currentVersion')==managed_receipt['currentVersion'] and v.get('currentRevision')==managed_receipt['currentRevision'] and v.get('full141FactsSha256')==managed_receipt['full141FactsSha256'],'EXACT_NATIVE141_RECEIPT_AND_FRESH_READBACK_REQUIRED');guard();factory.lease();return v
        if a.mode=='finish':result=controller.finish(pending,managed_receipt,managed_guard)
        else:result=controller.accept(installed,managed_receipt,managed_guard,lambda:private_json(bindings['wholeAppAcceptance']))
    # Never print minimum, journal snapshots, action receipts or private rows.
    print(json.dumps({'status':result.get('status'),'runtimeAcceptance':result.get('runtimeAcceptance',False),'automaticRetry':False,'automaticRestore':False}));return 0
if __name__=='__main__':
    try:raise SystemExit(main())
    except Exception as e:print(json.dumps({'status':'REFUSED_OR_UNKNOWN_NO_AUTOMATIC_RETRY','code':str(e) if type(e) is ValueError and re.fullmatch('[A-Z][A-Z0-9_]{0,120}',str(e)) else type(e).__name__,'automaticRetry':False,'automaticRestore':False}));raise SystemExit(2)
