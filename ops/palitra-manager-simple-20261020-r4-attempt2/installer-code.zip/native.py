"""Strict native bridge. Construction/commands run only after a separate Root admission.

No entrypoint, authorization, migration, import, initializer or data restore is provided.
Controller owns UNKNOWN journaling and ordering of plan, backups and the one up.
"""
import copy,functools,hashlib,json,os,re,stat,time,types
from pathlib import Path,PurePosixPath
ROOT=Path('/opt/synapse/releases/palitra-app-20261015')
NAME='palitra-manager-simple-20261020-r4-attempt2';CODE=ROOT/(NAME+'-code')
PARENT='sha256:0d8a86b8ace8ea919c389aa07cef2ce71e527fd618f2e7acf290c6b2ede9032c'
PLATFORM='linux/amd64'
PARENT_PLATFORM_MANIFEST='sha256:c45209facd8769b57b19934d79a34d1c34dced38ade73c700a533a034e88f221'
MANIFEST_TYPES=frozenset(('application/vnd.oci.image.manifest.v1+json','application/vnd.docker.distribution.manifest.v2+json'))
INDEX_TYPES=frozenset(('application/vnd.oci.image.index.v1+json','application/vnd.docker.distribution.manifest.list.v2+json'))
TARGET='company-app/customer-report-cache.cjs'
SCOPE_SHA='66e914eae4db1f20625ae17eafd123d07dc204230f0df4d92b029563bc349421'
STATIC_SHA='acbf42b367a1ed30788c603cd05adcff2fabef3c4036c087ff6811b9f02e4891'
BEFORE='3fca5842514e2ba770ea19b94183002a437cae9b065358537055fa3772d23d92'
AFTER='5fb7f5ca7f897d04bd2c4907ad8422122209fa1df37d2a8a52b5fcdb4fbf7e70'
PARENT_SEAM_SHA='fa34b575513cc735244cfa3c949ea745d8b5667ea7f3740b9f863c921adcd20b'
REPORT_SHA='08456dc9fcfae875b22c631a461e0cedea5a702b5f8d43ae770de7cff6e78a63'
CONTENT_SHA='d6363b217d69a49751d875b00cf50776593d01160b386190edaac8bf537ab4be'
TRAFFIC_SHA='2b44578d7b7fee9d779fe647c6d3b56eb5aa9d377f89b68f5aaed7230ca1127f'
DATA=Path('/var/lib/docker/volumes/synapse_content_data/_data')
LOCK='/opt/synapse/.palitra-app-release.lock'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encoded=lambda value:json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
digest=lambda value:type(value) is str and re.fullmatch('[a-f0-9]{64}',value) is not None
image=lambda value:type(value) is str and re.fullmatch('sha256:[a-f0-9]{64}',value) is not None
def need(ok,code):
    if not ok:raise ValueError(code)
def scrub(method):
    @functools.wraps(method)
    def safe(*args,**kwargs):
        try:return method(*args,**kwargs)
        except Exception as error:
            if type(error) is ValueError and re.fullmatch('[A-Z][A-Z0-9_]{0,100}',str(error)):raise
            raise ValueError('NATIVE_BRIDGE_REFUSED_OR_UNKNOWN_NO_RETRY') from None
    return safe
def module(raw,path):
    result=types.ModuleType('exact_cache_bridge_dependency');result.__file__=str(path)
    exec(compile(raw,str(path),'exec'),result.__dict__);return result


def load_scope(raw):
    doc=json.loads(raw)
    need(type(doc) is dict and set(doc)=={'schema','name','htmlClosureAccepted','records'} and doc['schema']==1 and doc['name']==NAME
         and type(doc['htmlClosureAccepted']) is bool and type(doc['records']) is list,'CLOSED_REPLACEMENT_SCOPE_REQUIRED')
    expected={'palitra-orders-public/'+name:'payload/product/'+name for name in ('shell.js','shell.css','cabinet.html','shop.html')}
    expected[TARGET]='payload/backend/company-app/customer-report-cache.cjs'
    rows=doc['records'];need(len(rows)==5 and {r.get('target'):r.get('path') for r in rows if type(r) is dict}==expected,'EXACT_FIVE_REPLACEMENT_TARGETS_REQUIRED')
    for row in rows:
        need(type(row) is dict and set(row)=={'path','target','static','beforeSha256','sha256','bytes'}
             and digest(row['beforeSha256']) and digest(row['sha256']) and row['beforeSha256']!=row['sha256']
             and type(row['bytes']) is int and 0<row['bytes']<=1048576
             and row['static']==(Path(row['target']).name if row['target'] in {'palitra-orders-public/'+n for n in ('shell.js','shell.css','cabinet.html')} else None),'CLOSED_REPLACEMENT_ROW_REQUIRED')
    return rows,doc['htmlClosureAccepted']

# Whole /app, including untracked runtime modules. Links are recorded, never followed.
# No inode/mtime is exported: those are only compared during each nofollow read.
TREE_JS=r"""'use strict';const f=require('node:fs'),c=require('node:crypto');const ROOT='/app';
if(f.realpathSync(ROOT)!==ROOT)throw Error('APP_ROOT_ALIAS');let count=0,total=0;const out={};
const safe=n=>Number.isSafeInteger(n)&&n>=0,hash=x=>c.createHash('sha256').update(x).digest('hex');
function walk(p,rel){if(++count>50000||rel.length>2048)throw Error('TREE_BOUND');const s=f.lstatSync(p);
 if(![s.uid,s.gid,s.mode&511,s.nlink,s.size].every(safe))throw Error('STAT_TYPES');
 const row={uid:s.uid,gid:s.gid,mode:s.mode&4095};
 if(s.isSymbolicLink()){if(s.nlink!==1)throw Error('LINK_COUNT');const link=f.readlinkSync(p);if(link.length>4096)throw Error('LINK_BOUND');out[rel]={...row,type:'symlink',nlink:1,linkSha256:hash(link)};return;}
 if(s.isDirectory()){out[rel]={...row,type:'directory'};const names=f.readdirSync(p).sort();for(const n of names){if(n==='.'||n==='..'||n.includes('/')||n.includes('\\'))throw Error('ENTRY_NAME');walk(p+'/'+n,rel?rel+'/'+n:n);}return;}
 if(!s.isFile()||s.nlink!==1||s.size>67108864||(total+=s.size)>1073741824)throw Error('REGULAR_BOUNDED_FILE');
 let fd;try{fd=f.openSync(p,f.constants.O_RDONLY|f.constants.O_NOFOLLOW|f.constants.O_NONBLOCK);const a=f.fstatSync(fd);
  if(!a.isFile()||a.dev!==s.dev||a.ino!==s.ino||a.size!==s.size||a.nlink!==1)throw Error('OPEN_RACE');
  const h=c.createHash('sha256'),buf=Buffer.alloc(65536);let bytes=0,n;while((n=f.readSync(fd,buf,0,buf.length,null))>0){bytes+=n;if(bytes>s.size)throw Error('READ_BOUND');h.update(buf.subarray(0,n));}
  const z=f.fstatSync(fd),q=f.lstatSync(p);for(const k of ['dev','ino','size','mtimeMs','ctimeMs','uid','gid','mode','nlink'])if(s[k]!==z[k]||s[k]!==q[k])throw Error('FILE_CHANGED');
  if(bytes!==s.size)throw Error('READ_SIZE');out[rel]={...row,type:'file',nlink:1,bytes,sha256:h.digest('hex')};
 }finally{if(fd!==undefined)f.closeSync(fd);}}
walk(ROOT,'');process.stdout.write(JSON.stringify(out));"""

class Native:
    @scrub
    def __init__(self,pid):
        need(type(pid) is int and pid>1 and pid not in (3161783,3196874,3200094,3202295,3204327,3205870,3207300,3208973,3210573,3213993),'FRESH_CACHE_ACTUAL_PID_REQUIRED')
        path=CODE/'parent-darya-r2.py'
        for part in [path,*path.parents]:need(not part.is_symlink(),'BRIDGE_CODE_ALIAS_REFUSED')
        raw=path.read_bytes();need(digest(PARENT_SEAM_SHA) and sha(raw)==PARENT_SEAM_SHA,'EXACT_PARENT_SEAM_REQUIRED')
        self.a,self.b,self.prior,self.current=module(raw,path).load_current_darya_r2(pid)
        self.pid=pid;self._bind_run();self.files=self.prior.FileOps();self.base=copy.deepcopy(self.current.base)
        scope=self.a.read(CODE/'records.json');need(sha(scope)==SCOPE_SHA,'EXACT_REPLACEMENT_SCOPE_REQUIRED')
        self.records,self.html_closed=load_scope(scope);self.scope_sha=SCOPE_SHA
        need(len(self.current.source)==239 and len(self.current.static)==43 and len(self.base['containers']['content']['files'])==42
             and self.base['containers']['content']['image']==PARENT and self.current.source.get(TARGET)==BEFORE,'EXACT_PARENT239_43_42_REQUIRED')
        self._pins={'parent-darya-r2.py':PARENT_SEAM_SHA,'report-db.py':REPORT_SHA,'content-db.py':CONTENT_SHA,'traffic-db.py':TRAFFIC_SHA}
        self._pins.update({'records.json':SCOPE_SHA,'static-files.py':STATIC_SHA})
        self._pins.update({r['path']:r['sha256'] for r in self.records})
        self._pins['native.py']=sha(self.a.read(CODE/'native.py'))
        raw=self.a.read(CODE/'static-files.py');need(sha(raw)==STATIC_SHA,'EXACT_STATIC_HELPER_REQUIRED')
        self.static_files=module(raw,CODE/'static-files.py').StaticFiles(self.a,self.files,self.lease,CODE,ROOT,NAME,self.records,self.current.cabinet)
        need(all(self.current.source.get(r['target'])==r['beforeSha256'] for r in self.records),'EXACT_FIVE_PARENT_SOURCE_PINS_REQUIRED')
        need(all(self.current.static.get(t)==r['beforeSha256'] for t,r in self.static_files.records.items()),'EXACT_THREE_PARENT_STATIC_PINS_REQUIRED')
        modules={}
        for name,pin in [('report-db.py',REPORT_SHA),('content-db.py',CONTENT_SHA),('traffic-db.py',TRAFFIC_SHA)]:
            raw=self.a.read(CODE/name);need(sha(raw)==pin,'EXACT_DATABASE_HELPER_REQUIRED');modules[name]=module(raw,CODE/name)
        self.report=modules['report-db.py'].ReportDatabase(DATA/'salon-reports.sqlite',self.a.exact_path,self.files,self.data_mount)
        self.content=modules['content-db.py'].ContentDatabase(DATA/'content.sqlite',self.a.exact_path,self.files,self.content_data_mount)
        self.traffic=modules['traffic-db.py'].TrafficDatabase(DATA/'app-entry-stats.sqlite',self.a.exact_path,self.files,self.content_data_mount,ROOT)
        self._parent_tree_cache=None;self._parent_image_cache=None;self._build_started=False;self._up_started=False
        self.b.lease=self.lease;self.stable();self.lease()
    def _bind_run(self):
        self._raw_run=self.b.run
        self.b.run=self.run
    @scrub
    def run(self,args):
        try:raw=self._raw_run(args)
        except Exception:raise ValueError('NATIVE_COMMAND_REFUSED_OR_UNKNOWN_NO_RETRY') from None
        need(type(raw) is bytes and len(raw)<=32*1024*1024,'BOUNDED_NATIVE_OUTPUT_REQUIRED');return raw
    @scrub
    def lease(self):
        raw=self.run(['lslocks','--noheadings','--output','PID,PATH']);need(len(raw)<=1048576,'BOUNDED_LEASE_REQUIRED')
        rows=[r.strip().split(maxsplit=1) for r in raw.decode().splitlines()]
        need([r for r in rows if len(r)==2 and r[1]==LOCK]==[[str(self.pid),LOCK]],'EXACT_OWN_FRESH_LEASE_REQUIRED')
    @scrub
    def stable(self):
        self.current.stable()
        for name,pin in self._pins.items():need(sha(self.a.read(CODE/name))==pin,'BRIDGE_OR_GUARD_CODE_CHANGED')
    def _image(self,target):
        need(image(target),'EXACT_IMAGE_ID_REQUIRED')
        rows=self.a.decode(self.run(['docker','image','inspect',target]))
        need(type(rows) is list and len(rows)==1 and rows[0].get('Id')==target and type(rows[0].get('Config')) is dict,'EXACT_IMAGE_FACTS_REQUIRED');return rows[0]
    def _parent_image(self):
        if self._parent_image_cache is None:self._parent_image_cache=self._image(PARENT)
        return copy.deepcopy(self._parent_image_cache)
    def _platform_image(self,target,full):
        # Select independently by exact full target and pinned platform, never by
        # the running container's label/descriptor or a mutable tag.
        need(image(target) and type(full) is dict and full.get('Id')==target,'EXACT_FULL_PLATFORM_IMAGE_TARGET_REQUIRED')
        descriptor=full.get('Descriptor');rootfs=full.get('RootFS')
        need(type(descriptor) is dict and descriptor.get('digest')==target
             and descriptor.get('mediaType') in MANIFEST_TYPES|INDEX_TYPES,'EXACT_FULL_IMAGE_DESCRIPTOR_REQUIRED')
        need(full.get('Os')=='linux' and full.get('Architecture')=='amd64' and full.get('Variant','')=='',
             'EXACT_FULL_LINUX_AMD64_PLATFORM_REQUIRED')
        need(type(full.get('Config')) is dict and type(rootfs) is dict and rootfs.get('Type')=='layers'
             and type(rootfs.get('Layers')) is list and all(image(layer) for layer in rootfs['Layers']),
             'EXACT_FULL_PLATFORM_CONFIG_AND_LAYERS_REQUIRED')
        rows=self.a.decode(self.run(['docker','image','inspect','--platform',PLATFORM,target]))
        need(type(rows) is list and len(rows)==1 and type(rows[0]) is dict,'ONE_SELECTED_PLATFORM_IMAGE_REQUIRED')
        selected=rows[0];chosen=selected.get('Descriptor')
        need(image(selected.get('Id')) and type(chosen) is dict and chosen.get('digest')==selected['Id']
             and chosen.get('mediaType') in MANIFEST_TYPES,'EXACT_SELECTED_IMAGE_MANIFEST_REQUIRED')
        need(selected.get('Os')=='linux' and selected.get('Architecture')=='amd64'
             and selected.get('Variant','')==full.get('Variant','')=='', 'EXACT_SELECTED_LINUX_AMD64_PLATFORM_REQUIRED')
        need(type(selected.get('Config')) is dict and selected['Config']==full['Config']
             and type(selected.get('RootFS')) is dict and selected['RootFS']==rootfs,
             'SELECTED_PLATFORM_CONFIG_AND_LAYERS_MUST_MATCH_FULL_TARGET')
        if target==PARENT:need(selected['Id']==PARENT_PLATFORM_MANIFEST,'EXACT_KNOWN_DARYA_PLATFORM_MANIFEST_REQUIRED')
        else:need(selected['Id']!=PARENT_PLATFORM_MANIFEST,'CHILD_PLATFORM_MANIFEST_MUST_DIFFER_FROM_PARENT')
        return {'target':target,'platform':PLATFORM,'manifestDigest':selected['Id'],'mediaType':chosen['mediaType']}
    def _tree(self,target=None):
        args=['docker','exec','synapse-content-1','node','-e',TREE_JS] if target is None else ['docker','run','--rm','--network=none','--read-only','--cap-drop=ALL','--security-opt=no-new-privileges','--entrypoint=node',target,'-e',TREE_JS]
        value=self.a.decode(self.run(args));need(type(value) is dict and '' in value and len(value)<=50000,'BOUNDED_FULL_APP_TREE_REQUIRED')
        for name,row in value.items():
            need(type(name) is str and type(row) is dict and row.get('type') in ('file','directory','symlink')
                 and (name=='' or not PurePosixPath(name).is_absolute() and PurePosixPath(name).as_posix()==name and '..' not in PurePosixPath(name).parts)
                 and all(type(row.get(k)) is int and row[k]>=0 for k in ('uid','gid','mode')) and row['mode']<=0o7777,'EXACT_APP_TREE_FACTS_REQUIRED')
            keys={'uid','gid','mode','type'}|({'nlink','bytes','sha256'} if row['type']=='file' else {'nlink','linkSha256'} if row['type']=='symlink' else set())
            need(set(row)==keys,'CLOSED_APP_TREE_ROW_REQUIRED')
            if row['type']!='directory':need(type(row['nlink']) is int and row['nlink']==1,'SINGLE_LINK_APP_ENTRY_REQUIRED')
            if row['type']=='file':need(type(row['bytes']) is int and 0<=row['bytes']<=67108864 and digest(row['sha256']),'BOUNDED_APP_FILE_HASH_REQUIRED')
            if row['type']=='symlink':need(digest(row['linkSha256']),'EXACT_APP_LINK_HASH_REQUIRED')
        return value
    def _parent_tree(self):
        if self._parent_tree_cache is None:
            value=self._tree(PARENT);self._source_modes(value,False);self._parent_tree_cache=value
        return copy.deepcopy(self._parent_tree_cache)
    def _payload(self,target=TARGET):
        rows=[r for r in self.records if r['target']==target];need(len(rows)==1,'CLOSED_PAYLOAD_TARGET_REQUIRED');row=rows[0]
        raw=self.a.read(CODE/row['path']);need(len(raw)==row['bytes'] and sha(raw)==row['sha256'],'EXACT_CLOSED_PAYLOAD_REQUIRED');return raw
    def _expected_tree(self,child):
        value=self._parent_tree()
        if child:
            for row in self.records:value[row['target']]={**value[row['target']],'sha256':row['sha256'],'bytes':len(self._payload(row['target']))}
        return value
    def _source_modes(self,tree,child):
        result={};expected=dict(self.current.source)
        for row in self.records:expected[row['target']]=row['sha256'] if child else row['beforeSha256']
        for name,pin in expected.items():
            row=tree.get(name,{})
            need(row.get('type')=='file' and row.get('sha256')==pin and row.get('uid')==row.get('gid')==0
                 and row.get('nlink')==1 and row.get('mode') in (0o600,0o644),'FULL239_ROOT_SOURCE_FACTS_REQUIRED')
            result[name]={k:row[k] for k in ('uid','gid','mode')}
        need(len(result)==239,'FULL239_SOURCE_COUNT_REQUIRED');return result
    def _metadata(self,target,overlay,config_hash):
        expected=copy.deepcopy(self.base['containers']['content'])
        if target!=PARENT:
            need(image(target) and digest(config_hash) and Path(overlay)==ROOT/(NAME+'-overlay.json'),'EXACT_OWN_CHILD_OVERLAY_REQUIRED')
            raw=self.a.read(self.a.exact_path(Path(overlay)))
            need(self.a.decode(raw)=={'services':{'content':{'image':target}}},'CONTENT_IMAGE_ONLY_OVERLAY_REQUIRED')
            files=expected['files']+[str(overlay)];need(len(files)==len(set(files))==43,'EXACT_CHILD_CHAIN43_REQUIRED')
            expected.update(image=target,files=files,configFiles=','.join(files),filePins={**expected['filePins'],str(overlay):sha(raw)},configHash=config_hash)
        else:need(overlay is None and config_hash is None,'NO_PARENT_OVERLAY_ARGUMENTS_ALLOWED')
        actual=self.a.decode(self.run(['docker','inspect','--format',self.a.LABELS,'synapse-content-1']))
        need(type(actual) is dict and actual.get('configFiles')==expected['configFiles'],'EXACT_ADMITTED_COMPOSE_CHAIN_REQUIRED')
        actual.update(files=list(expected['files']),filePins={p:sha(self.a.read(self.a.exact_path(Path(p)))) for p in expected['files']})
        need(actual==expected and self.b.metadata('chat')==self.base['containers']['chat'],'FULL_CONTENT_CHAT_METADATA_CHANGED')
        return {'content':actual,'chat':copy.deepcopy(self.base['containers']['chat'])}
    def data_mount(self):
        mounts=self.a.decode(self.run(['docker','inspect','--format','{{json .Mounts}}','synapse-content-1']))
        need(type(mounts) is list and 1<=len(mounts)<=64 and all(type(row) is dict
             and type(row.get('Destination')) is str and 0<len(row['Destination'])<=4096 for row in mounts),
             'BOUNDED_CANONICAL_MOUNTS_REQUIRED')
        destinations=[row['Destination'] for row in mounts]
        need(len(destinations)==len(set(destinations)),'UNIQUE_MOUNT_DESTINATION_REQUIRED')
        rows=[r for r in mounts if r.get('Destination')=='/data'] if type(mounts) is list else []
        need(len(rows)==1 and rows[0].get('Type')=='volume' and rows[0].get('Name')=='synapse_content_data'
             and rows[0].get('Source')==str(DATA) and rows[0].get('RW') is True,'EXACT_CURRENT_DATA_VOLUME_REQUIRED')
        return sha(encoded(sorted(mounts,key=lambda row:row['Destination'])))
    def content_data_mount(self):
        self.data_mount();need(self.run(['docker','exec','synapse-content-1','node','-e',"process.stdout.write(process.env.DATABASE_PATH||'/data/content.sqlite')"])==b'/data/content.sqlite','EXACT_CURRENT_CONTENT_DATABASE_PATH_REQUIRED')
    def _runtime(self,target,metadata,cid):
        rows=self.a.decode(self.run(['docker','inspect','synapse-content-1']))
        need(type(rows) is list and len(rows)==1 and rows[0].get('Image')==target,'EXACT_RUNNING_IMAGE_REQUIRED');row=rows[0]
        need(type(row.get('Id')) is str and row['Id'].startswith(cid),'EXACT_RUNNING_CONTAINER_ID_REQUIRED')
        parent=self._parent_image();child=self._image(target)
        need(child['Config']==parent['Config'],'IMAGE_CONFIG_MUST_REMAIN_BYTE_EQUIVALENT')
        binding=self._platform_image(target,child)
        descriptor=row.get('ImageManifestDescriptor')
        need(type(descriptor) is dict and descriptor.get('digest')==binding['manifestDigest']
             and descriptor.get('mediaType')==binding['mediaType'],'CONTAINER_MANIFEST_MUST_MATCH_INDEPENDENT_PLATFORM_IMAGE')
        if 'platform' in descriptor:
            platform=descriptor['platform'];need(type(platform) is dict and platform.get('os')=='linux'
                and platform.get('architecture')=='amd64' and platform.get('variant','')=='','CONTAINER_DESCRIPTOR_PLATFORM_CHANGED')
        current=copy.deepcopy(row['Config']);pairs=current.get('Env',[])
        need(type(pairs) is list and all(type(v) is str and '=' in v for v in pairs),'EXACT_RUNTIME_ENV_FORMAT_REQUIRED')
        actual=dict(v.split('=',1) for v in pairs);need(len(actual)==len(pairs),'DUPLICATE_RUNTIME_ENV_REFUSED')
        args=['docker','compose']+[v for p in metadata['content']['files'] for v in ('-f',p)]+['config','--format','json']
        effective=self.a.decode(self.run(args))['services']['content']
        need(effective.get('image')==target,'EXACT_EFFECTIVE_CONTENT_IMAGE_REQUIRED')
        expected=dict(v.split('=',1) for v in parent['Config'].get('Env',[]));expected.update({k:str(v) for k,v in effective.get('environment',{}).items()});expected={k:v.replace('$$','$') for k,v in expected.items()}
        need(actual==expected,'EXACT_EFFECTIVE_ENVIRONMENT_REQUIRED');current['Env']=actual
        labels=current.get('Labels',{});need(type(labels) is dict,'EXACT_COMPOSE_LABELS_REQUIRED')
        for key,wanted in [('com.docker.compose.config-hash',metadata['content']['configHash']),('com.docker.compose.image',binding['manifestDigest']),('com.docker.compose.project.config_files',metadata['content']['configFiles'])]:
            need(labels.get(key)==wanted,'EXACT_RUNTIME_COMPOSE_LABEL_REQUIRED');labels[key]='<controlled-content-transition>'
        need(current.get('Image')==target,'EXACT_RUNTIME_CONFIG_IMAGE_REQUIRED');current['Image']='<controlled-content-transition>'
        if current.get('Hostname')==row['Id'][:12]:current['Hostname']='<docker-default-cid>'
        public_effective=copy.deepcopy(effective);public_effective['image']='<controlled-content-transition>'
        return {'imageConfigSha256':sha(encoded(parent['Config'])),'containerConfigSha256':sha(encoded(current)),
                'hostConfigSha256':sha(encoded(row['HostConfig'])),'effectiveConfigSha256':sha(encoded(public_effective)),
                'environmentSha256':sha(encoded(actual)),'mountsSha256':self.data_mount()}
    @scrub
    def snapshot(self,image=PARENT,overlay=None,config_hash=None,changed=frozenset()):
        need(globals()['image'](image),'EXACT_SNAPSHOT_IMAGE_REQUIRED');self.stable();self.lease()
        need(type(changed) is frozenset and changed<=set(self.static_files.records),'EXACT_WRITTEN_STATIC_SUBSET_REQUIRED')
        need(image==PARENT or changed==set(self.static_files.records),'FULL_CHILD_STATIC_PUBLICATION_REQUIRED')
        expected_static={**self.current.static,**{t:self.static_files.records[t]['sha256'] for t in changed}}
        first=self._metadata(image,overlay,config_hash);worker=self.b.worker_facts();selected={s:self.b.a.selected(s) for s in ('content','chat')}
        flags=self.a.decode(self.run(['docker','exec','synapse-content-1','node','-e',self.a.FLAGS_JS]))
        need(worker==self.base['worker'] and selected==self.base['selected'] and flags==self.base['l12'],'WORKER_FLAGS_SELECTION_CHANGED')
        need(self.b.heartbeat(worker['startedAt'],time.time())['freshAfterWorkerStart'] is True,'FRESH_EXISTING_WORKER_HEARTBEAT_REQUIRED')
        for service,row in first.items():need(re.fullmatch(re.escape(service)+r'\s+'+re.escape(row['configHash']),self.run(self.b._resolve_command(row,service)).decode().strip()) is not None,'RESOLVED_COMPOSE_HASH_CHANGED')
        self.b.graph(new=True);self.b.push_guard();self.current.managed_guard.guard()
        child=image!=PARENT;tree=self._tree();need(tree==self._expected_tree(child),'FULL_APP_UNCHANGED_EXCEPT_CACHE_REQUIRED')
        modes=self._source_modes(tree,child);static_modes={}
        for name,pin in expected_static.items():
            path=self.a.exact_path(Path(name));info=path.lstat()
            need(stat.S_ISREG(info.st_mode) and info.st_nlink==1 and info.st_uid==info.st_gid==0 and stat.S_IMODE(info.st_mode) in (0o600,0o644)
                 and sha(self.a.read(path))==pin,'FULL43_PRIVATE_STATIC_CHANGED');static_modes[name]=stat.S_IMODE(info.st_mode)
        cid=self.b.photo.cid();need(type(cid) is str and cid and (child or cid==self.base['contentCid']),'EXACT_PARENT_OR_CHILD_CID_REQUIRED')
        runtime=self._runtime(image,first,cid);runtime['appTree']=tree
        need(first==self._metadata(image,overlay,config_hash) and worker==self.b.worker_facts() and selected=={s:self.b.a.selected(s) for s in ('content','chat')}
             and cid==self.b.photo.cid() and tree==self._tree() and {k:v for k,v in runtime.items() if k!='appTree'}==self._runtime(image,first,cid),'CONCURRENT_NATIVE_SNAPSHOT_CHANGED')
        for name,pin in expected_static.items():
            path=self.a.exact_path(Path(name));info=path.lstat()
            need(stat.S_ISREG(info.st_mode) and info.st_nlink==1 and info.st_uid==info.st_gid==0
                 and stat.S_IMODE(info.st_mode)==static_modes[name] and sha(self.a.read(path))==pin,'LATE_FULL43_STATIC_CHANGED')
        self.stable();self.lease()
        return {'containers':first,'worker':worker,'selected':selected,'l12':flags,'contentCid':cid,'sourceModes':modes,'staticModes':static_modes,'runtime':runtime}
    @scrub
    def checkpoint(self,previous=None):
        self.stable();self.lease()
        report=self.report.guard(previous['report'] if previous else self.current.report_minimum)
        need(all(type(r['revision']) is int and r['revision']>=3 for r in report['content']['cache'].values()),'BOTH_REPORT_REVISIONS3_OR_NEWER_REQUIRED')
        content=self.content.guard(previous['content']) if previous else self.content.read();self.content.after_guard(self.current.content_migration)
        traffic=self.traffic.guard(previous['traffic'] if previous else self.current.traffic_minimum)
        self.lease();return {'report':report,'content':content,'traffic':traffic}
    @scrub
    def backup(self,dest,minimum,refresh=False):
        need(type(refresh) is bool and Path(dest)==ROOT/(NAME+'-backup'),'EXACT_OWN_BACKUP_DIRECTORY_REQUIRED')
        directory=self.a.exact_path(Path(dest));s=directory.lstat()
        need(stat.S_ISDIR(s.st_mode) and s.st_uid==s.st_gid==0 and stat.S_IMODE(s.st_mode)==0o700,'PRIVATE_ROOT_BACKUP_DIRECTORY_REQUIRED')
        current=self.checkpoint(minimum);suffix=''
        if refresh:
            for generation in range(1,1001):
                suffix='-refresh-'+str(generation)
                if all(not os.path.lexists(directory/(stem+suffix+'.sqlite')) for stem in ('reports','content','traffic')):break
            else:raise ValueError('BOUNDED_FRESH_BACKUP_NAMES_EXHAUSTED')
        paths={key:directory/(stem+suffix+'.sqlite') for key,stem in [('report','reports'),('content','content'),('traffic','traffic')]}
        need(all(not os.path.lexists(p) for p in paths.values()),'NEW_BACKUPS_REQUIRED_NO_OVERWRITE')
        identity=[s.st_dev,s.st_ino,s.st_uid,s.st_gid,stat.S_IMODE(s.st_mode)]
        result={key:{**getattr(self,key).backup(paths[key],current[key]),'bridgeBackupDirectoryIdentity':identity} for key in ('report','content','traffic')}
        self.backup_guard(result);self.checkpoint(current);return result
    @scrub
    def backup_guard(self,backups):
        need(type(backups) is dict and set(backups)=={'report','content','traffic'},'CLOSED_THREE_DATABASE_BACKUPS_REQUIRED')
        directory=self.a.exact_path(ROOT/(NAME+'-backup'));s=directory.lstat()
        need(stat.S_ISDIR(s.st_mode) and s.st_uid==s.st_gid==0 and stat.S_IMODE(s.st_mode)==0o700,'PRIVATE_ROOT_BACKUP_DIRECTORY_REQUIRED')
        identity=[s.st_dev,s.st_ino,s.st_uid,s.st_gid,stat.S_IMODE(s.st_mode)]
        for key,stem in [('report','reports'),('content','content'),('traffic','traffic')]:
            row=backups[key]
            need(row.get('bridgeBackupDirectoryIdentity')==identity,'BACKUP_DIRECTORY_IDENTITY_CHANGED')
            if key=='traffic' and row.get('status')=='ABSENT':getattr(self,key).backup_guard(row);continue
            path=Path(row['path']);need(path.parent==ROOT/(NAME+'-backup') and re.fullmatch(stem+r'(?:-refresh-[1-9][0-9]{0,3})?[.]sqlite',path.name),'EXACT_OWN_DATABASE_BACKUP_PATH_REQUIRED')
            getattr(self,key).backup_guard(row)
        return True
    @scrub
    def verify_child(self,image,before):
        need(globals()['image'](image) and image!=PARENT and before['runtime']['appTree']==self._parent_tree(),'EXACT_CHILD_AND_PARENT_TREE_REQUIRED')
        parent=self._parent_image();child=self._image(image);layers=parent['RootFS']['Layers'];new=child['RootFS']['Layers']
        need(type(layers) is list and type(new) is list and new[:len(layers)]==layers and len(new)==len(layers)+1,'EXACT_ONE_COPY_LAYER_REQUIRED')
        need(child['Config']==parent['Config'],'EXACT_CHILD_IMAGE_CONFIG_REQUIRED')
        platform_binding=self._platform_image(image,child)
        tree=self._tree(image);need(tree==self._expected_tree(True),'EXACT_FULL_CHILD_FIVE_DELTA_REQUIRED')
        need(self._source_modes(tree,True)==before['sourceModes'],'PRESERVED_ALL239_SOURCE_MODES_REQUIRED')
        return {'image':image,'parentImage':PARENT,'oneCopyLayer':True,'imageConfigSha256':sha(encoded(child['Config'])),'appTreeSha256':sha(encoded(tree)),'sourceFiles':239,'changedTargets':sorted(r['target'] for r in self.records),'platformImageBinding':platform_binding}
    @scrub
    def build(self,context,tag):
        need(self.html_closed is True,'HTML_CONSUMERS_NOT_CLOSED')
        need(not self._build_started and Path(context)==ROOT/(NAME+'-context') and tag=='synapse-'+NAME+'-content','ONE_EXACT_BUILD_REQUIRED')
        self.stable();self.lease();directory=self.a.exact_path(Path(context));info=directory.lstat()
        need(stat.S_ISDIR(info.st_mode) and info.st_uid==info.st_gid==0 and stat.S_IMODE(info.st_mode)==0o700,'PRIVATE_REGULAR_CONTEXT_DIRECTORY_REQUIRED')
        expected_files={'Dockerfile'}|{'app/'+r['target'] for r in self.records}
        expected_dirs={'app'}|{'app/'+str(p) for row in self.records for p in PurePosixPath(row['target']).parents if str(p)!='.'}
        found_files=set();found_dirs=set()
        for path in directory.rglob('*'):
            label=path.relative_to(directory).as_posix();checked=self.a.exact_path(path);s=checked.lstat()
            need(s.st_uid==s.st_gid==0 and not stat.S_ISLNK(s.st_mode),'ROOT_CONTEXT_NO_ALIASES_REQUIRED')
            if stat.S_ISDIR(s.st_mode):
                need(label in expected_dirs and stat.S_IMODE(s.st_mode)==0o755,'EXACT_CONTEXT_DIRECTORY_REQUIRED');found_dirs.add(label)
            else:
                need(stat.S_ISREG(s.st_mode) and s.st_nlink==1 and label in expected_files,'CLOSED_REGULAR_CONTEXT_REQUIRED');found_files.add(label)
                if label=='Dockerfile':need(stat.S_IMODE(s.st_mode)==0o600,'PRIVATE_CONTEXT_DOCKERFILE_REQUIRED')
                else:
                    row=next(r for r in self.records if label=='app/'+r['target'])
                    need(stat.S_IMODE(s.st_mode)==self._parent_tree()[row['target']]['mode'] and sha(self.a.read(path))==row['sha256'],'EXACT_CONTEXT_PAYLOAD_MODE_AND_HASH_REQUIRED')
        need(found_files==expected_files and found_dirs==expected_dirs,'CLOSED_FIVE_FILE_BUILD_CONTEXT_REQUIRED')
        dockerfile=('FROM '+PARENT+'\nCOPY app/ /app/\n').encode()
        need(self.a.read(directory/'Dockerfile')==dockerfile,'EXACT_ONE_COPY_CONTEXT_REQUIRED')
        need(self.run(['docker','image','ls','--quiet',tag]).strip()==b'','NEW_CHILD_TAG_REQUIRED_NO_REPLAY')
        self._build_started=True
        self.run(['docker','build','--network=none','--pull=false','--tag',tag,'--iidfile',str(directory/'image.id'),str(directory)])
        iid=self.a.exact_path(directory/'image.id');info=iid.lstat()
        need(stat.S_ISREG(info.st_mode) and info.st_uid==info.st_gid==0 and info.st_nlink==1 and stat.S_IMODE(info.st_mode) in (0o600,0o644),'ROOT_REGULAR_CONTEXT_IID_REQUIRED')
        target=self.a.read(iid).decode().strip()
        need(image(target) and target!=PARENT and self.run(['docker','image','inspect','--format','{{.Id}}',tag]).decode().strip()==target,'EXACT_NEW_BUILT_IMAGE_REQUIRED');return target
    @scrub
    def plan(self,before,overlay):
        self.lease();need(Path(overlay)==ROOT/(NAME+'-overlay.json'),'EXACT_OWN_PLAN_OVERLAY_REQUIRED')
        try:result=self.b.plan(before,'content',Path(overlay))
        except Exception:raise ValueError('CONTENT_PLAN_REFUSED') from None
        need(digest(result),'EXACT_CONTENT_COMPOSE_PLAN_REQUIRED');return result
    @scrub
    def up(self,before,overlay):
        need(self.html_closed is True,'HTML_CONSUMERS_NOT_CLOSED')
        need(not self._up_started and Path(overlay)==ROOT/(NAME+'-overlay.json'),'ONE_EXACT_UP_REQUIRED')
        self.lease();self._up_started=True
        try:return self.b.up(before,'content',Path(overlay))
        except Exception:raise ValueError('CONTENT_UP_REFUSED_OR_UNKNOWN_NO_RETRY') from None

    @scrub
    def source_bytes(self,target):
        need(target in {r['target'] for r in self.records},'CLOSED_SOURCE_BACKUP_TARGET_REQUIRED')
        script="const f=require('node:fs'),p='/app/'+process.argv[1],s=f.lstatSync(p);if(!s.isFile()||s.isSymbolicLink()||s.nlink!==1||s.uid!==0||s.gid!==0||s.size>1048576)throw Error('SOURCE_TYPE');const fd=f.openSync(p,f.constants.O_RDONLY|f.constants.O_NOFOLLOW|f.constants.O_NONBLOCK);try{const a=f.fstatSync(fd),b=f.readFileSync(fd),z=f.fstatSync(fd);for(const k of ['dev','ino','mode','uid','gid','nlink','size','mtimeMs','ctimeMs'])if(s[k]!==a[k]||s[k]!==z[k])throw Error('SOURCE_CHANGED');if(b.length!==s.size)throw Error('SOURCE_SIZE');process.stdout.write(b.toString('base64'));}finally{f.closeSync(fd)}"
        import base64
        raw=self.run(['docker','run','--rm','--network=none','--read-only','--cap-drop=ALL','--security-opt=no-new-privileges','--entrypoint=node',PARENT,'-e',script,target])
        need(len(raw)<=2*1024*1024,'BOUNDED_SOURCE_BACKUP_REQUIRED');value=base64.b64decode(raw,validate=True)
        need(sha(value)==next(r['beforeSha256'] for r in self.records if r['target']==target),'EXACT_PARENT_SOURCE_BACKUP_REQUIRED');return value
    @scrub
    def code_backups(self,dest,before):
        return self.static_files.backups(dest,self.records,self.source_bytes)
    @scrub
    def code_backup_guard(self,state):
        return self.static_files.guard(state,self.records)
    @scrub
    def publish_static(self,target,state):
        return self.static_files.publish(target,state,self.records)
