/* Palitra Love Заказы — хост рабочего подключения к существующему Synapse.

   Открывается только на разрешённых адресах: кабинет https://synapse.synapsebusiness.ru (whoami cookie + CSRF)
   и магазин https://palitra-love.ru (сессия аккаунта /api/draft-account/session, portal через штатный crm-session.js,
   чат сайта /api/customer-chat/*). Новой авторизации нет: только существующие относительные маршруты моста.

   Сеть, CRM и чат включены после проверки Root. Изменение флагов требует отдельного проверенного выпуска
   (свободное окно общего сервера, origin/CSP, PALITRA_APP_ORIGIN). Адрес, роль, localStorage и данные макета флаги
   не меняют. Проверки разрешённого адреса, сессии и CSRF выполняются перед каждым запросом.
   CSRF/токены живут только в замыкании этого файла и в штатном crm-session.js; в state оболочки, URL и манифест не идут. */
'use strict';
(() => {
  const B = window.SynapseBridge;
  const FLAGS = Object.freeze({ network: true, crm: true, e1Native: true });
  const CABINET = B.ORIGINS.synapse, SHOP = B.ORIGINS.shop;
  const origin = window.location.origin;
  /* Точка входа задаётся страницей: shop.html (data-entry="shop", data-auth="site", штатный crm-session.js до этого файла)
     или cabinet.html (data-entry="cabinet", без инициализации магазина). Страница работает только на «своём» адресе. */
  const root = document.documentElement;
  const entry = root.dataset.entry === 'shop' || root.dataset.entry === 'cabinet' ? root.dataset.entry : '';
  const allowed = (entry === 'cabinet' && origin === CABINET) || (entry === 'shop' && origin === SHOP && root.dataset.auth === 'site');
  let cabinetCsrf = '', accountCsrf = '', chatCsrf = '';
  const listeners = [];
  let activeCompany = 'palitra-love';

  // PALITRA_MANAGER_ATTENTION_VALIDATOR: read-only data, never grants or action capabilities.
  function validateManagerAttention(data, query) {
    const bad = () => { throw new Error('Сервер не подтвердил список клиентов. Обновите список.'); };
    const plain = v => v && typeof v === 'object' && !Array.isArray(v);
    const date = v => typeof v === 'string' && /^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$/.test(v) && Number.isFinite(Date.parse(v)) && new Date(v).toISOString() === v;
    const count = v => Number.isSafeInteger(v) && v >= 0;
    if (!plain(data) || data.schema !== 'palitra-manager-attention/v1' || data.companyCode !== 'palitra-love' ||
        data.scopeKey !== 'palitra' || data.filter !== query.filter || !date(data.asOf) || data.partial !== false ||
        !plain(data.counts) || !['total','attention','unanswered','firstContact'].every(k => count(data.counts[k])) ||
        data.counts.attention > data.counts.total || data.counts.unanswered + data.counts.firstContact !== data.counts.attention ||
        !Array.isArray(data.items) || data.items.length > query.limit ||
        !(data.nextCursor === null || typeof data.nextCursor === 'string' && /^[A-Za-z0-9_-]{1,512}$/.test(data.nextCursor))) bad();
    const keys = new Set(), ref = (v,p) => v === null || typeof v === 'string' && new RegExp('^'+p+':[1-9]\\d*$').test(v) && Number.isSafeInteger(Number(v.split(':')[1]));
    const refs = (v,p) => Array.isArray(v) && v.every((r,i) => r !== null && ref(r,p) && (i === 0 || Number(v[i-1].split(':')[1]) < Number(r.split(':')[1])));
    for (const item of data.items) {
      if (!plain(item) || typeof item.key !== 'string' || !/^(order|thread|legacy):[1-9]\d*$/.test(item.key) || keys.has(item.key) ||
          !['order','web-thread','legacy-dialog'].includes(item.kind) || !ref(item.orderRef,'native-order') || !ref(item.threadRef,'thread') || !ref(item.dialogRef,'legacy') ||
          !refs(item.threadRefs,'thread') || !refs(item.dialogRefs,'legacy') || item.threadRef !== (item.threadRefs[0] || null) || item.dialogRef !== (item.dialogRefs[0] || null) ||
          (item.reason === 'unanswered' ? ![...item.threadRefs,...item.dialogRefs].includes(item.attentionRef) : item.attentionRef !== null) ||
          item.orderRef === null && item.threadRef === null && item.dialogRef === null ||
          typeof item.customerLabel !== 'string' || item.customerLabel.length > 100 ||
          ![null,'unanswered','first-contact'].includes(item.reason) || item.reason === 'first-contact' && item.orderRef === null || query.filter === 'attention' && item.reason === null ||
          !date(item.basisAt) || Date.parse(item.basisAt) > Date.parse(data.asOf) || !count(item.ageSeconds) ||
          item.ageSeconds !== Math.floor((Date.parse(data.asOf)-Date.parse(item.basisAt))/1000) ||
          ![null,'customer-first-reply'].includes(item.deadlineKind) ||
          !(item.dueAt === null && item.deadlineKind === null || date(item.dueAt) && item.deadlineKind === 'customer-first-reply' && item.reason === 'first-contact') ||
          !['stored','uninitialized'].includes(item.workflowState) || (item.workflowState === 'uninitialized' ? item.stage !== null : item.stage === null) ||
          !(item.stage === null || plain(item.stage) && typeof item.stage.id === 'string' && item.stage.id.length <= 100 && typeof item.stage.label === 'string' && item.stage.label.length <= 100 && (item.stage.since === null || date(item.stage.since) && Date.parse(item.stage.since)<=Date.parse(data.asOf)))) bad();
      if (item.kind === 'order' && item.key !== item.orderRef?.replace('native-order:','order:') ||
          item.kind === 'web-thread' && (item.key !== item.threadRef || item.orderRef !== null) ||
          item.kind === 'legacy-dialog' && (item.key !== item.dialogRef || item.orderRef !== null)) bad();
      keys.add(item.key);
    }
    if (data.nextCursor !== null && data.items.length === 0 || data.items.length > (query.filter === 'all' ? data.counts.total : data.counts.attention)) bad();
    return data;
  }
  // PALITRA_MANAGER_ATTENTION_VALIDATOR_END

  // PALITRA_RESPONSE_REPORT_VALIDATOR: observation facts only, no capabilities.
  function validateResponseReport(data) {
    const bad = () => { throw new Error('Сервер не подтвердил статистику ответов. Обновите отчёт.'); };
    const plain = v => v && typeof v === 'object' && !Array.isArray(v);
    const date = v => typeof v === 'string' && /^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$/.test(v) && Number.isFinite(Date.parse(v)) && new Date(v).toISOString() === v;
    const count = v => Number.isSafeInteger(v) && v >= 0;
    const seconds = v => typeof v === 'number' && Number.isFinite(v) && v >= 0;
    const stat = v => plain(v) && count(v.sampleCount) && (v.sampleCount === 0 ? v.medianSeconds === null && v.meanSeconds === null : seconds(v.medianSeconds) && seconds(v.meanSeconds));
    if (!plain(data) || data.schema !== 'palitra-response-report/v1' || data.companyCode !== 'palitra-love' || !date(data.asOf) ||
        !(data.observationStartedAt === null || date(data.observationStartedAt) && Date.parse(data.observationStartedAt) <= Date.parse(data.asOf)) ||
        !plain(data.range) || !date(data.range.until) || Date.parse(data.range.until) > Date.parse(data.asOf) || typeof data.range.truncatedAtStart !== 'boolean' ||
        !(data.range.from === null && (data.observationStartedAt === null || data.coverage?.period === 'before_observation') || date(data.range.from) && data.observationStartedAt !== null && Date.parse(data.range.from) >= Date.parse(data.observationStartedAt) && Date.parse(data.range.from) < Date.parse(data.range.until)) ||
        !plain(data.coverage) || data.coverage.status !== (data.observationStartedAt === null ? 'not_started' : 'observing') || data.coverage.beforeObservation !== 'excluded' || data.coverage.period !== (data.observationStartedAt === null ? 'not_started' : data.range.from === null ? 'before_observation' : 'observed') ||
        data.coverage.canonicalTelegramSentAt !== 'latest-confirmed-delivery-update' || data.coverage.legacyTelegramSentAt !== 'outbox-finished-at' ||
        !Array.isArray(data.channels) || data.channels.length !== 6) bad();
    const ids = ['site','telegram','vk','instagram','youtube','tiktok'];
    for (let i=0;i<ids.length;i++) {
      const row=data.channels[i];
      if (!plain(row) || row.id !== ids[i] || !['connected','not_connected','unobserved'].includes(row.status) || !stat(row.first) || !stat(row.subsequent) ||
          !plain(row.waiting) || !count(row.waiting.count) ||
          !(row.waiting.count === 0 ? row.waiting.oldestSince === null && row.waiting.oldestSeconds === null : data.observationStartedAt !== null && date(row.waiting.oldestSince) && Date.parse(row.waiting.oldestSince) >= Date.parse(data.observationStartedAt) && Date.parse(row.waiting.oldestSince)<=Date.parse(data.asOf) && row.waiting.oldestSeconds === Math.floor((Date.parse(data.asOf)-Date.parse(row.waiting.oldestSince))/1000)) ||
          !plain(row.beforeObservationWaiting) || !count(row.beforeObservationWaiting.count) ||
          !(row.beforeObservationWaiting.count === 0 ? row.beforeObservationWaiting.oldestSince === null : data.observationStartedAt !== null && date(row.beforeObservationWaiting.oldestSince) && Date.parse(row.beforeObservationWaiting.oldestSince)<Date.parse(data.observationStartedAt))) bad();
      if (data.observationStartedAt === null && (row.first.sampleCount || row.subsequent.sampleCount || row.waiting.count || row.beforeObservationWaiting.count)) bad();
    }
    return data;
  }
  // PALITRA_RESPONSE_REPORT_VALIDATOR_END

  // PALITRA_CONTENT_TASKS_VALIDATOR: existing calendar, never a second task store.
  function validateContentTasks(data,from,to) {
    const bad = () => { throw new Error('Сервер не подтвердил контент-план Палитры. Обновите список.'); };
    const plain = v => v && typeof v === 'object' && !Array.isArray(v);
    const day = v => typeof v === 'string' && /^\d{4}-\d\d-\d\d$/.test(v) && Number.isFinite(Date.parse(v+'T00:00:00Z')) && new Date(v+'T00:00:00Z').toISOString().slice(0,10) === v;
    const count = v => Number.isSafeInteger(v) && v >= 0;
    const states=['missing','pending','ready','published','inactive'];
    const issues=v=>Array.isArray(v)&&v.every(x=>typeof x==='string'&&x.length<=2000);
    const ready = v => plain(v) && states.includes(v.state) && v.ready === (v.state==='ready') && issues(v.issues);
    if (!plain(data) || data.companyCode !== 'palitra-love' || data.from !== from || data.to !== to || !day(data.today) ||
        typeof data.timezone !== 'string' || !data.timezone || data.truncated !== false || typeof data.undatedTruncated !== 'boolean' ||
        !Array.isArray(data.posts) || !Array.isArray(data.undated) || !count(data.undatedTotal) || data.undatedTotal<data.undated.length ||
        !plain(data.coverage) || !['none','current_plan'].includes(data.coverage.basis) || !plain(data.summary)) bad();
    try {new Intl.DateTimeFormat('ru-RU',{timeZone:data.timezone});} catch(_){bad();}
    const ids=new Set();
    for (const [rows,dated] of [[data.posts,true],[data.undated,false]]) for (const row of rows) {
      if (!plain(row) || !Number.isSafeInteger(row.id) || row.id<1 || ids.has(row.id) || row.companyCode!=='palitra-love' ||
          !Number.isSafeInteger(row.revision) || row.revision<1 || typeof row.title!=='string' || row.title.length>200 ||
          !(dated ? day(row.effectiveDate)&&row.effectiveDate>=from&&row.effectiveDate<=to : row.effectiveDate===null) ||
          !ready(row.calendarReadiness) || !Array.isArray(row.calendarReadiness.platforms)) bad();
      const platforms=new Set();
      for (const item of row.calendarReadiness.platforms) {
        // A published receipt is truthful even though ready:false (not future stock).
        if (!plain(item) || typeof item.platform!=='string' || !/^[a-z0-9_-]{1,64}$/.test(item.platform) || platforms.has(item.platform) ||
            !states.includes(item.state) || typeof item.ready!=='boolean' || item.ready && item.state!=='ready' || !issues(item.issues)) bad();
        platforms.add(item.platform);
      }
      ids.add(row.id);
    }
    return data;
  }
  // PALITRA_CONTENT_TASKS_VALIDATOR_END

  // Push HTTP возвращает {ok:false,code}; не переносим произвольный ответ/секреты в интерфейс.
  const PUSH_ERRORS = Object.freeze({
    PUSH_ORIGIN: 'Сервер не подтвердил адрес приложения. Подписка не подтверждена.',
    PUSH_JSON_REQUIRED: 'Сервер не принял формат запроса подписки.',
    PUSH_BODY_LIMIT: 'Сервер не принял размер запроса подписки.',
    PUSH_JSON: 'Сервер не смог прочитать данные подписки.',
    PUSH_FIELDS: 'Сервер не принял поля подписки этого браузера.',
    PUSH_SUBSCRIPTION: 'Сервер не принял данные подписки этого браузера.',
    PUSH_ENDPOINT: 'Сервер не принял адрес службы уведомлений этого браузера.',
    PUSH_PROVIDER: 'Служба уведомлений этого браузера пока не поддерживается.',
    PUSH_KEY: 'Сервер не принял ключи подписки этого браузера.',
    PUSH_EXPIRATION: 'Срок подписки истёк или не распознан сервером.',
    PUSH_ACTOR: 'Сервер не подтвердил текущую учётную запись.',
    PUSH_ACTOR_CHANGED: 'Учётная запись изменилась. Откройте приложение заново.',
    PUSH_ACTOR_REVOKED: 'Доступ учётной записи изменился. Войдите в приложение заново.',
    PUSH_FORBIDDEN: 'Для этой учётной записи нет доступа к уведомлениям.',
    PUSH_ENDPOINT_OTHER_ACTOR: 'Эта подписка связана с другой учётной записью.',
    PUSH_DEVICE_LIMIT: 'Достигнут лимит подключённых устройств для этой учётной записи.',
    PUSH_SUBSCRIPTION_NOT_FOUND: 'Подписка этой учётной записи не найдена на сервере.',
    PUSH_NOT_READY: 'Служба уведомлений ещё не готова. Попробуйте позже.',
    PUSH_NOT_CONFIGURED: 'Уведомления пока не настроены на сервере.',
    PUSH_KEYS_UNAVAILABLE: 'Служба уведомлений временно недоступна на сервере.',
    PUSH_STORE: 'Сервер не смог прочитать сохранённую подписку.',
    PUSH_STORE_LIMIT: 'Сервер не смог обработать список подписок.',
    PUSH_UNAVAILABLE: 'Служба уведомлений временно недоступна.',
    PUSH_BAD_RESPONSE: 'Сервер вернул нераспознанный ответ. Подключение не подтверждено.',
    METHOD: 'Сервер не поддерживает это действие с подпиской.',
    NOT_FOUND: 'Сервис подписки не найден на сервере.',
  });
  function pushHttpError(operation, method, status, data) {
    const safeOperation = ['capability', 'subscription', 'subscription/status'].includes(operation) ? operation : 'unknown';
    const code = data && typeof data.code === 'string' && Object.prototype.hasOwnProperty.call(PUSH_ERRORS, data.code) ? data.code : 'PUSH_REQUEST_FAILED';
    const safeStatus = Number.isInteger(status) && status >= 100 && status < 600 ? status : 0;
    const action = safeOperation === 'capability' ? 'Проверка готовности уведомлений' : safeOperation === 'subscription/status' || method === 'GET' ? 'Проверка подписки' : method === 'DELETE' ? 'Отключение уведомлений' : 'Сохранение подписки';
    const fallback = safeStatus === 401 ? 'Сессия завершилась. Войдите в приложение заново.'
      : safeStatus === 403 ? 'Сервер не подтвердил доступ к уведомлениям для текущего входа.'
        : safeStatus === 409 ? 'Состояние подписки изменилось. Подключение не подтверждено.' : 'Не удалось подтвердить подписку на сервере. Можно продолжить без уведомлений.';
    const message = safeStatus === 401 ? fallback : code === 'PUSH_UNAVAILABLE' && safeStatus === 403 ? fallback : PUSH_ERRORS[code] || fallback;
    return Object.assign(new Error(`${action}: ${message}`), { name: 'PalitraPushError', code, status: safeStatus, operation: safeOperation });
  }
  let host;
  if (!allowed) {
    // Чужой адрес (в том числе localhost/127.0.0.1) или страница другого входа: транспорта нет — «Подключение не настроено».
    host = { mode: 'blocked', reason: entry ? 'origin' : 'entry' };
  } else {
    // Штатный crm-session.js — только на входе магазина и только в режиме сайта (cookie аккаунта + CSRF, не Telegram).
    const session = entry === 'shop' && window.PalitraSession && window.PalitraSession.auth === 'site' && typeof window.PalitraSession.request === 'function' ? window.PalitraSession : null;
    const transport = B.createNativeTransport({
      // fetch внедряется только здесь, на разрешённом адресе; мост сам глобальный fetch не трогает.
      fetch: (url, init) => window.fetch(url, init),
      host: {
        origin, portalOrigin: SHOP, allowNetwork: FLAGS.network, e1Native: FLAGS.e1Native,
        cabinet: { get csrfToken() { return cabinetCsrf; } },
        account: { get csrf() { return accountCsrf; } },
        chat: { get csrf() { return chatCsrf; } },
        portal: FLAGS.crm && session ? { request: (path, options) => session.request(path, options) } : null,
      },
    });
    host = {
      mode: 'native', verified: true, origin, transport, e1Native: FLAGS.e1Native,
      selectCompany: (code) => {
        if (entry !== 'cabinet' || !window.SynapseCompanies?.profile(code)) throw new Error('Компания недоступна для этого входа');
        activeCompany = code;
        return B.forCompany(code).createNativeTransport({ fetch: (url, init) => window.fetch(url, init),
          host: { origin, portalOrigin: SHOP, allowNetwork: FLAGS.network, e1Native: code === 'palitra-love' && FLAGS.e1Native,
            cabinet: { get csrfToken() { return cabinetCsrf; } } } });
      },
      // Автоперечитывание открытого чата (5 с) — только при включённых сети и чате сайта E/R1.
      chatAutoRefresh: FLAGS.network === true && FLAGS.e1Native === true,
      // Файлы используют только разрешённую entry/origin и актуальный CSRF замыкания; server uploads.enabled проверяется UI и backend.
      attachments: B.createAttachmentTransport({ fetch: (url, init) => window.fetch(url, init),
        host: { origin, entry, allowNetwork: FLAGS.network, e1Native: FLAGS.e1Native,
          getCsrf: () => entry === 'cabinet' ? cabinetCsrf : chatCsrf } }),
      // Только наличие сессий своего адреса; роли и identity оболочка берёт из ответов whoami/bootstrap.
      getAuthContext: () => (entry === 'cabinet' ? { cabinetSession: true } : { shopSession: true, guest: true, portalAvailable: FLAGS.crm && Boolean(session) }),
      acceptCabinetCsrf: (value) => { cabinetCsrf = typeof value === 'string' ? value : ''; window.dispatchEvent(new Event('palitra:push-auth-ready')); },
      acceptAccountCsrf: (value) => { accountCsrf = typeof value === 'string' ? value : ''; },
      acceptChatSession: (value) => { chatCsrf = typeof value === 'string' ? value : ''; window.dispatchEvent(new Event('palitra:push-auth-ready')); },
      // Только кабинет, разрешённый origin, network flag и CSRF текущего whoami. Роли проверяет backend.
      managerAttention: Object.freeze({ read: async (options = {}) => {
        if (!options || typeof options !== 'object' || Object.keys(options).some(k => !['filter','limit','cursor','signal'].includes(k))) throw new TypeError('Некорректный запрос списка клиентов');
        const query = { filter: options.filter === undefined ? 'all' : options.filter, limit: options.limit === undefined ? 30 : options.limit };
        if (!['all','attention'].includes(query.filter) || !Number.isSafeInteger(query.limit) || query.limit < 1 || query.limit > 100 ||
            options.cursor !== undefined && (typeof options.cursor !== 'string' || !/^[A-Za-z0-9_-]{1,512}$/.test(options.cursor))) throw new TypeError('Некорректный запрос списка клиентов');
        if (activeCompany !== 'palitra-love' || entry !== 'cabinet' || origin !== CABINET || FLAGS.network !== true || !cabinetCsrf) throw Object.assign(new Error('Список клиентов недоступен для этого входа.'), {status:403});
        const sentCompany = activeCompany, sentCsrf = cabinetCsrf;
        const params = new URLSearchParams({filter:query.filter,limit:String(query.limit)});
        if (options.cursor !== undefined) params.set('cursor',options.cursor);
        const response = await window.fetch('/content/palitra/manager-attention?'+params, {method:'GET',credentials:'same-origin',cache:'no-store',redirect:'error',signal:options.signal,headers:{Accept:'application/json'}});
        if (activeCompany !== sentCompany || cabinetCsrf !== sentCsrf) throw Object.assign(new Error('Вход изменился. Откройте список заново.'), {status:403});
        if (!response.ok) throw Object.assign(new Error(response.status === 401 ? 'Войдите в приложение заново.' : response.status === 403 ? 'Нет доступа к клиентам Палитры.' : 'Не удалось получить список клиентов. Обновите список.'), {status:response.status});
        const data = await response.json();
        if (activeCompany !== sentCompany || cabinetCsrf !== sentCsrf) throw Object.assign(new Error('Вход изменился. Откройте список заново.'), {status:403});
        return validateManagerAttention(data,query);
      } }),
      contentTasks: Object.freeze({ read: async (options = {}) => {
        if (!options || typeof options !== 'object' || Object.keys(options).some(k=>!['signal'].includes(k))) throw new TypeError('Некорректный запрос контент-плана');
        if (activeCompany!=='palitra-love' || entry!=='cabinet' || origin!==CABINET || FLAGS.network!==true || !cabinetCsrf) throw Object.assign(new Error('Контент-план недоступен для этого входа.'),{status:403});
        const sentCompany=activeCompany,sentCsrf=cabinetCsrf;
        const check=()=>{if(activeCompany!==sentCompany || cabinetCsrf!==sentCsrf)throw Object.assign(new Error('Вход изменился. Откройте контент-план заново.'),{status:403});};
        const from=new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Moscow',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
        const end=new Date(from+'T12:00:00Z');end.setUTCDate(end.getUTCDate()+6);const to=end.toISOString().slice(0,10);
        const params=new URLSearchParams({companyCode:'palitra-love',from,to});
        const response=await window.fetch('/content/crm/autoposting/calendar?'+params,{method:'GET',credentials:'same-origin',cache:'no-store',redirect:'error',signal:options.signal,headers:{Accept:'application/json'}});
        check();
        if(!response.ok)throw Object.assign(new Error(response.status===401?'Войдите в приложение заново.':response.status===403?'Нет доступа к контент-плану Палитры.':'Не удалось загрузить контент-план. Попробуйте ещё раз.'),{status:response.status});
        const data=await response.json();check();return validateContentTasks(data,from,to);
      } }),
      responseReport: Object.freeze({ read: async (options = {}) => {
        if (!options || typeof options !== 'object' || Object.keys(options).some(k => !['signal'].includes(k))) throw new TypeError('Некорректный запрос отчёта');
        if (activeCompany !== 'palitra-love' || entry !== 'cabinet' || origin !== CABINET || FLAGS.network !== true || !cabinetCsrf) throw Object.assign(new Error('Отчёт недоступен для этого входа.'), {status:403});
        const sentCompany = activeCompany, sentCsrf = cabinetCsrf;
        const check = () => { if (activeCompany !== sentCompany || cabinetCsrf !== sentCsrf) throw Object.assign(new Error('Вход изменился. Откройте отчёт заново.'), {status:403}); };
        const response = await window.fetch('/content/palitra/response-report', {method:'GET',credentials:'same-origin',cache:'no-store',redirect:'error',signal:options.signal,headers:{Accept:'application/json'}});
        check();
        if (!response.ok) throw Object.assign(new Error(response.status === 401 ? 'Войдите в приложение заново.' : response.status === 403 ? 'Нет доступа к отчёту Палитры.' : 'Не удалось получить отчёт. Попробуйте ещё раз.'), {status:response.status});
        const data = await response.json(); check();
        return validateResponseReport(data);
      } }),
      customerReports: Object.freeze({ request: async (query = {}, options = {}) => {
        if (entry !== 'cabinet' || origin !== CABINET || FLAGS.network !== true || !['alvi', 'avokado'].includes(activeCompany)) throw Object.assign(new Error('Отчёты этой компании ещё не подключены.'), { status: 403 });
        for (const key of Object.keys(query)) if (!['mode', 'month', 'day', 'basis'].includes(key) || typeof query[key] !== 'string') throw new TypeError('Неизвестный фильтр отчёта');
        const path = `/content/${window.SynapseCompanies.profile(activeCompany).site}/customer-reports?${new URLSearchParams(query)}`;
        const response = await window.fetch(path, { method: 'GET', credentials: 'same-origin', cache: 'no-store', redirect: 'error', signal: options.signal, headers: { Accept: 'application/json' } });
        if (!response.ok) throw Object.assign(new Error(response.status === 403 ? 'Нет доступа к отчётам этой компании.' : response.status === 401 ? 'Войдите в приложение заново.' : 'Не удалось получить отчёт.'), { status: response.status });
        return response.json();
      } }),
      workflow: Object.freeze({ request: async (path, options = {}) => {
        const method = options.method || 'GET';
        const base = path === '/content/palitra/workflow' || path === '/content/palitra/workflow/widget-settings' || path === '/content/palitra/workflow/completion-settings';
        const readOnly = path === '/content/palitra/workflow/funnel-report' || path === '/content/palitra/workflow/memo-assets';
        const order = /^\/content\/palitra\/workflow\/orders\/[1-9]\d*(?:\/(confirm|advance|stage))?$/.exec(path);
        const allowedMethod = base ? ['GET', 'PUT'].includes(method) : readOnly ? method === 'GET' : order ? (order[1] ? method === 'POST' : method === 'GET') : false;
        if (activeCompany !== 'palitra-love' || entry !== 'cabinet' || origin !== CABINET || FLAGS.network !== true || !cabinetCsrf || !allowedMethod) throw Object.assign(new Error('Этапы заказа не подключены для этого входа.'), { status: 403 });
        const sentCompany = activeCompany, sentCsrf = cabinetCsrf;
        const response = await window.fetch(path, { method, credentials: 'same-origin', cache: 'no-store', redirect: 'error', signal: options.signal,
          headers: { Accept: 'application/json', ...(method !== 'GET' ? { 'Content-Type': 'application/json', 'X-CSRF-Token': cabinetCsrf } : {}) },
          ...(method !== 'GET' ? { body: JSON.stringify(options.body) } : {}) });
        if (activeCompany !== sentCompany || cabinetCsrf !== sentCsrf) throw Object.assign(new Error('Вход изменился. Откройте заказ заново.'), {status:403});
        const data = await response.json();
        if (activeCompany !== sentCompany || cabinetCsrf !== sentCsrf) throw Object.assign(new Error('Вход изменился. Откройте заказ заново.'), {status:403});
        if (!response.ok) throw Object.assign(new Error(data && data.error && typeof data.error === 'string' ? data.error : 'Не удалось выполнить действие с заказом.'), { status: response.status });
        return data;
      }, memoUpload: async ({ file, requestId } = {}) => {
        if (activeCompany !== 'palitra-love' || entry !== 'cabinet' || origin !== CABINET || FLAGS.network !== true || !cabinetCsrf) throw Object.assign(new Error('Загрузка памятки недоступна для этого входа.'), {status:403});
        if (!(file instanceof window.File) || file.size < 1 || file.size > 2 * 1024 * 1024 || !['application/pdf','image/jpeg','image/png','image/webp'].includes(file.type)
          || !/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(requestId || '')
          || !file.name || file.name.length > 180 || /[\x00-\x1f\x7f\\/]/.test(file.name)) throw new TypeError('Выберите памятку PDF, JPG, PNG или WebP размером до 2 МБ.');
        const sentCompany = activeCompany, sentCsrf = cabinetCsrf;
        const check = () => { if (activeCompany !== sentCompany || cabinetCsrf !== sentCsrf) throw Object.assign(new Error('Вход изменился. Откройте настройки заново.'), {status:403}); };
        const response = await window.fetch('/content/palitra/workflow/memo-assets', {method:'POST',credentials:'same-origin',cache:'no-store',redirect:'error',
          headers:{Accept:'application/json','Content-Type':file.type,'X-CSRF-Token':sentCsrf,'X-Palitra-Memo-Request-Id':requestId,'X-Palitra-Memo-Name':encodeURIComponent(file.name)},body:file});
        check(); const data = await response.json(); check();
        if (!response.ok) throw Object.assign(new Error(typeof data?.error === 'string' ? data.error : 'Не удалось загрузить памятку.'), {status:response.status});
        const a = data?.asset;
        if (data?.ok !== true || typeof data.duplicate !== 'boolean' || !a || a.reference !== 'memo:' + requestId || a.name !== file.name.trim() || a.size !== file.size || a.contentType !== file.type
          || !['photo','document'].includes(a.kind) || !/^[0-9a-f]{64}$/.test(a.sha256 || '') || !Number.isFinite(Date.parse(a.createdAt))) throw new Error('Сервер не подтвердил именно этот файл памятки. Повторите ту же загрузку.');
        return data;
      } }),
      push: Object.freeze({ request: async (operation, options = {}) => {
        const method = options.method || 'GET';
        const permitted = operation === 'capability' ? method === 'GET' : operation === 'subscription' ? ['GET', 'POST', 'DELETE'].includes(method) : operation === 'subscription/status' && method === 'POST';
        const csrf = entry === 'cabinet' ? cabinetCsrf : chatCsrf;
        if ((entry === 'cabinet' && activeCompany !== 'palitra-love') || !permitted || !FLAGS.network || !csrf || (entry === 'shop' && !FLAGS.e1Native)) throw Object.assign(new Error('Уведомления пока не подключены для этого входа.'), { status: 403 });
        const path = (entry === 'cabinet' ? '/content/palitra/push/' : '/api/customer-chat/push/') + operation;
        const response = await window.fetch(path, { method, credentials: 'same-origin', cache: 'no-store', redirect: 'error',
          headers: { Accept: 'application/json', [entry === 'cabinet' ? 'X-CSRF-Token' : 'X-Palitra-Chat-CSRF']: csrf, ...(method !== 'GET' ? { 'Content-Type': 'application/json' } : {}) },
          ...(method !== 'GET' ? { body: JSON.stringify(options.body) } : {}) });
        let data;
        try { data = await response.json(); }
        catch (_) { throw pushHttpError(operation, method, response.status, { code: 'PUSH_BAD_RESPONSE' }); }
        if (!response.ok) throw pushHttpError(operation, method, response.status, data);
        return data;
      } }),
      onAuthChange: (fn) => { if (typeof fn === 'function') listeners.push(fn); },
    };
    // Штатное событие завершения portal-сессии (crm-session.js) — смена identity: прежние данные и CSRF очищаются.
    window.addEventListener('palitra:session-ended', () => { cabinetCsrf = ''; accountCsrf = ''; chatCsrf = ''; for (const fn of listeners) fn(); });
  }
  Object.defineProperty(window, 'PalitraShellHost', { value: Object.freeze(host), writable: false, configurable: false });
})();
