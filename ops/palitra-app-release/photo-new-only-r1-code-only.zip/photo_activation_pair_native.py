"""Root-only: existing worker image switch, then uploads flag; never edit queues or roll back old code."""
import argparse, hashlib, json, os, re, sqlite3, stat, sys, time, types
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/opt/synapse/releases/palitra-app-20261015')
PHOTO_HELPER_SHA = 'e9be603986710c935f8e2c133e9921f99a4d81b7e8edcf92dd7f656ae07f6a76'
PHOTO_RECEIPT_SHA = '1819806edb53a647ee0b8cab8d50b12728fdfb2b52c7eb1df44284422b9cc2d7'
CONTENT = 'sha256:bcb7187b4a79ef65bfda218a287e25bd858eedf08fee84983b2f73e51a8346e6'
GRAPH_SHA = '2c57ff64c0074f725c4c1709152076a4a35a67ddc1f1d43a8bcf715d3fa8aa23'
NODE_IMAGE = 'sha256:e67514e5d0f6c46656005e1b693b2ec9d52e80b641307de684d4a015ba7a4eaf'
BRIDGE_SHA = 'ac3a139d9715036ce5a6966794b61d65e900b0deb2eb3cf6edcd108c643cf683'
CUTOFF = '2026-10-15T10:33:38.177Z'
EMPTY_WORKDIR = 'sha256:5f70bf18a086007016e948b04aed3b82103a36bea41755b6cddfaf10ace3c6ef'
PREDECESSOR_UNKNOWN_SHA = 'c589190ac41ba50c3e49573caf8c8994a5010ca2f8a134926943d690f96b3b43'
RESERVE_READER_SHA = '6f3592dd533ba8af8345a0d21ac43f799c705ab6853f3cc142f143710cd37250'
NEW_ONLY_HELPER_SHA = '1df23bb5d81cc2a6eec4ecdbbedaa039fc013e3dbeddf1ebe1752f44fa91ea90'
RESIDUALS = ['NOT_FULL_ROOTFS_EQUIVALENCE', 'NO_NETWORK_DELIVERY_PROOF', 'RESTORE_IMAGE_IS_RECONSTRUCTED_CODE_NOT_ORIGINAL_C5DD', 'EXISTING_PINNED_IPV6_NODE_OPTIONS_PRESERVED']
IPV6_NODE_OPTIONS_SHA = '543b8e67253492993423c87495f783f002206c3aaf5504a09311ce00e29ea650'
HOOKS = ('NODE_OPTIONS','NODE_PATH','NODE_EXTRA_CA_CERTS','NODE_USE_SYSTEM_CA','NODE_ICU_DATA','NODE_V8_COVERAGE','NODE_COMPILE_CACHE','NODE_DISABLE_COMPILE_CACHE','LD_PRELOAD','LD_LIBRARY_PATH','LD_AUDIT','OPENSSL_CONF','OPENSSL_MODULES','SSL_CERT_FILE','SSL_CERT_DIR','TZ','LANG','LANGUAGE','LC_ALL','LC_CTYPE','NODE_REDIRECT_WARNINGS')
CLEAR = ('NODE_OPTIONS','NODE_PATH','NODE_EXTRA_CA_CERTS','NODE_USE_SYSTEM_CA','NODE_ICU_DATA','NODE_V8_COVERAGE','NODE_COMPILE_CACHE','LD_PRELOAD','LD_LIBRARY_PATH','LD_AUDIT','OPENSSL_CONF','OPENSSL_MODULES','SSL_CERT_FILE','SSL_CERT_DIR','NODE_REDIRECT_WARNINGS')
LABELS = '{"image":{{json .Image}},"project":{{json (index .Config.Labels "com.docker.compose.project")}},"service":{{json (index .Config.Labels "com.docker.compose.service")}},"workingDir":{{json (index .Config.Labels "com.docker.compose.project.working_dir")}},"configFiles":{{json (index .Config.Labels "com.docker.compose.project.config_files")}},"configHash":{{json (index .Config.Labels "com.docker.compose.config-hash")}},"running":{{json .State.Running}},"health":{{with index .State "Health"}}{{json .Status}}{{else}}null{{end}}}'
WORKER_INSPECT = '{"Id":{{json .Id}},"Image":{{json .Image}},"Env":{{json .Config.Env}},"Cmd":{{json .Config.Cmd}},"Entrypoint":{{json .Config.Entrypoint}},"WorkingDir":{{json .Config.WorkingDir}},"User":{{json .Config.User}},"Labels":{{json .Config.Labels}},"Mounts":{{json .Mounts}},"HostConfig":{{json .HostConfig}},"StartedAt":{{json .State.StartedAt}},"Running":{{json .State.Running}},"RestartCount":{{json .RestartCount}}}'
IMAGE_INSPECT = '{"Id":{{json .Id}},"Os":{{json .Os}},"Architecture":{{json .Architecture}},"RootFS":{{json .RootFS}},"OnBuild":{{json (index .Config "OnBuild")}},"Volumes":{{json (index .Config "Volumes")}},"Healthcheck":{{json (index .Config "Healthcheck")}}}'
FLAGS_JS = "console.log(JSON.stringify({enabled:process.env.PALITRA_CONTACT_FOLLOWUP_ENABLED??null,cutoff:process.env.PALITRA_CONTACT_FOLLOWUP_ENABLED_AFTER_UTC??null}));"
STAGES = ('worker', 'uploads', 'stop')
OPERATIONS = {'approve-worker':'worker','activate-worker':'worker','inspect-worker':'worker','approve-uploads':'uploads','enable-uploads':'uploads','inspect-uploads':'uploads','approve-stop':'stop','stop-uploads':'stop','inspect-stop':'stop'}

def sha(raw): return hashlib.sha256(raw).hexdigest()
def encoded(value): return (json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True) + '\n').encode()
def need(value, code):
    if not value: raise ValueError(code)
def digest(value): return type(value) is str and re.fullmatch('[0-9a-f]{64}', value) is not None
def image(value): return type(value) is str and re.fullmatch('sha256:[0-9a-f]{64}', value) is not None
def epoch(value):
    need(type(value) is str and len(value) <= 48, 'UTC_TIME_REQUIRED')
    date = datetime.fromisoformat(value.replace('Z', '+00:00'))
    need(date.tzinfo is not None and date.utcoffset().total_seconds() == 0, 'UTC_TIME_REQUIRED')
    return date.timestamp()
def stamp(seconds): return datetime.fromtimestamp(seconds, timezone.utc).isoformat(timespec='milliseconds')
def fresh(value, now): need(0 <= now - epoch(value) <= 600, 'ROOT_DECISION_STALE_OR_FUTURE')
def exact_path(value, missing=False):
    path = Path(value)
    need(path.is_absolute() and '..' not in path.parts, 'ABSOLUTE_PATH_REQUIRED')
    for part in [*reversed(path.parents), path]:
        try: info = part.lstat()
        except FileNotFoundError:
            need(missing and part == path, 'REQUIRED_PATH_MISSING'); continue
        need(not stat.S_ISLNK(info.st_mode) and not (getattr(info, 'st_file_attributes', 0) & 0x400), 'SYMLINK_OR_REPARSE_REFUSED')
        if part != path: need(stat.S_ISDIR(info.st_mode), 'DIRECTORY_PARENT_REQUIRED')
    return path
def read(path, limit=2*1024*1024):
    path = exact_path(path); before = path.stat()
    need(stat.S_ISREG(before.st_mode) and 0 < before.st_size <= limit, 'BOUNDED_REGULAR_INPUT_REQUIRED')
    fd = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_BINARY', 0))
    try:
        with os.fdopen(fd, 'rb', closefd=False) as handle: raw = handle.read(limit+1)
        end = os.fstat(fd); after = path.stat()
        fields = lambda row: (row.st_dev, row.st_ino, row.st_size, row.st_mtime_ns)
        # Python/NTFS stat and fstat expose different ctime semantics. Native POSIX keeps the full ctime guard.
        need(fields(before) == fields(end) == fields(after) and before.st_ctime_ns == after.st_ctime_ns and (os.name != 'posix' or before.st_ctime_ns == end.st_ctime_ns) and len(raw) == before.st_size, 'PRIVATE_INPUT_CHANGED_DURING_READ')
        return raw
    finally: os.close(fd)
def decode(raw):
    def pairs(values):
        result = {}
        for key, value in values:
            need(key not in result, 'DUPLICATE_JSON_KEY'); result[key] = value
        return result
    return json.loads(raw.decode('utf8'), object_pairs_hook=pairs)
def pinned(path, pin, private=False):
    need(digest(pin), 'EXACT_SHA_REQUIRED'); raw = read(path)
    need(sha(raw) == pin, 'PINNED_INPUT_CHANGED')
    if private:
        info = Path(path).stat()
        need(os.name != 'posix' or (stat.S_IMODE(info.st_mode) == 0o600 and info.st_uid == 0), 'ROOT_PRIVATE_INPUT_REQUIRED')
    return decode(raw)
def write_new(path, value):
    path = exact_path(path, True); raw = encoded(value)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_BINARY', 0), 0o600)
    with os.fdopen(fd, 'wb') as handle: handle.write(raw); handle.flush(); os.fsync(handle.fileno())
    if os.name == 'posix':
        fd = os.open(path.parent, os.O_RDONLY | getattr(os, 'O_DIRECTORY', 0))
        try: os.fsync(fd)
        finally: os.close(fd)
def replace(path, value):
    pending = Path(str(path)+'.pending'); write_new(pending, value); os.replace(pending, path)
def load_module(path, pin, name):
    raw = read(path); need(sha(raw) == pin, 'FROZEN_HELPER_SHA_REQUIRED')
    result = types.ModuleType(name); result.__file__ = str(path); exec(compile(raw, str(path), 'exec'), result.__dict__); return result

def validate_runtime_hooks(runtime):
    old = runtime.get('oldHooks'); node = runtime.get('nodeImage', {}).get('hooks')
    need(type(old) is dict and type(node) is dict and set(old) == set(node) == set(HOOKS), 'EXACT_TWENTY_ONE_RUNTIME_HOOKS_REQUIRED')
    for collection in (old, node):
        for value in collection.values():
            need(type(value) is dict and set(value) == {'present','effective'} and type(value['present']) is bool and type(value['effective']) is bool and (not value['effective'] or value['present']), 'EXACT_RUNTIME_HOOK_RECORD_REQUIRED')
    need(old['NODE_OPTIONS'] == {'present':True,'effective':True} and all(not value['effective'] for name,value in old.items() if name != 'NODE_OPTIONS') and all(not value['effective'] for value in node.values()), 'ONLY_EXISTING_IPV6_NODE_OPTIONS_HOOK_ALLOWED')
    expected = {name:old[name]['present'] or node[name]['present'] for name in HOOKS}
    aggregate = runtime.get('startupHooksPresent')
    need(type(aggregate) is dict and set(aggregate) == set(HOOKS) and all(type(v) is bool for v in aggregate.values()) and aggregate == expected and runtime.get('effectiveHooksRequireRootDecision') is True, 'ACCURATE_EXISTING_IPV6_HOOK_AGGREGATE_REQUIRED')

def verified_pair_lineage(pair, runtime, root):
    parent = root/'.worker-images-photo-r1'; c = pair.get('continuation')
    need(type(c) is dict and set(c) == {'oldUnknownJournalSha256','reserveProofPath','reserveProofSha256','reserveReaderSha256','revalidationPath','revalidationSha256','newBuildJournalPath','newBuildJournalSha256','helperSha256','emptyLayerDiffId'} and c['oldUnknownJournalSha256'] == PREDECESSOR_UNKNOWN_SHA and c['reserveReaderSha256'] == RESERVE_READER_SHA and c['helperSha256'] == NEW_ONLY_HELPER_SHA and c['emptyLayerDiffId'] == EMPTY_WORKDIR, 'EXACT_NEW_ONLY_PAIR_PROVENANCE_REQUIRED')
    reserve_path = Path(c['reserveProofPath']); rv_path = Path(c['revalidationPath']); build_path = Path(c['newBuildJournalPath'])
    need(reserve_path == root/'reserve-layer-r1-result.json' and rv_path.parent == root and re.fullmatch(r'runtime-revalidation-r[1-9][0-9]{0,3}\.json',rv_path.name) and build_path == parent/'new-build-attempt-r1.json', 'EXACT_PREDECESSOR_PROOF_PATHS_REQUIRED')
    pins = {str(parent/'journal.json'):PREDECESSOR_UNKNOWN_SHA,str(reserve_path):c['reserveProofSha256'],str(rv_path):c['revalidationSha256'],str(build_path):c['newBuildJournalSha256']}
    old = pinned(parent/'journal.json',PREDECESSOR_UNKNOWN_SHA,True); reserve = pinned(reserve_path,c['reserveProofSha256'],True); rv = pinned(rv_path,c['revalidationSha256'],True); built = pinned(build_path,c['newBuildJournalSha256'],True)
    need(old.get('phase') == 'UNKNOWN_DO_NOT_RETRY' and old.get('previousPhase') == 'OLD_BUILT_NOT_VERIFIED' and old.get('failure') == {'code':'EXACT_NODE_PLUS_ONE_COPY_LAYER_REQUIRED'} and old.get('runtimeProofSha256') == pair['runtimeProofSha256'] and old.get('workerBefore') == pair['workerBefore'], 'ORIGINAL_UNKNOWN_LINEAGE_MUST_STAY_EXACT')
    need(reserve.get('status') == 'EXISTING_RESERVE_LAYERS_OBSERVED_NOT_BUILD_OR_ACTIVATION_APPROVAL' and reserve.get('journalSha256') == PREDECESSOR_UNKNOWN_SHA and reserve.get('oldJournalUnmodified') is True and reserve.get('oldJournalStillUnknown') is True and reserve.get('baseImage') == NODE_IMAGE and reserve.get('reserveImage') == pair['results']['old']['image'] and reserve.get('workerBefore') == reserve.get('workerAfter') == pair['workerBefore'], 'EXACT_READONLY_RESERVE_LINEAGE_REQUIRED')
    proof = reserve['proof']; tail = proof['addedLayers'][1]
    need(proof.get('baseLayers') == 4 and proof.get('reserveLayers') == 6 and proof.get('fullBasePrefix') is True and proof.get('allTenExact') is True and proof.get('sourceFiles') == 10 and proof.get('layerDiffIdsVerified') == 6 and proof.get('contentAddressedBlobsVerified') == 12 and proof['addedLayers'][0].get('kind') == 'COPY_EXACT_TEN' and tail.get('members') == [] and tail.get('decodedBytes') == 1024 and tail.get('zeroOnly') is True and tail.get('diffId') == EMPTY_WORKDIR and tail.get('tarSha256') == EMPTY_WORKDIR[7:], 'EXACT_COPY_THEN_PINNED_EMPTY_PROOF_REQUIRED')
    need(rv.get('status') == 'CURRENT_REVALIDATION_FROM_KNOWN_SUCCESS' and rv.get('historicalRuntimeProofSha256') == pair['runtimeProofSha256'] and rv.get('historicalObservedAtUtc') == runtime['observedAtUtc'] and rv.get('projection') == runtime['match']['old'] and rv.get('workerBefore') == rv.get('workerAfter') == pair['workerBefore'] and rv.get('nodeImage') == runtime['nodeImage'] and rv.get('oldHooks') == runtime['oldHooks'] and rv.get('candidateRerun') is False, 'HONEST_CURRENT_REVALIDATION_PROVENANCE_REQUIRED')
    binding = {'oldUnknownJournalSha256':PREDECESSOR_UNKNOWN_SHA,'reserveProofSha256':c['reserveProofSha256'],'reserveReaderSha256':RESERVE_READER_SHA,'revalidationSha256':c['revalidationSha256'],'historicalRuntimeProofSha256':pair['runtimeProofSha256'],'existingNodeOptionsSha256':IPV6_NODE_OPTIONS_SHA,'helperSha256':NEW_ONLY_HELPER_SHA}
    need(built.get('phase') == 'NEW_CODE_IMAGE_VERIFIED_NOT_ACTIVATED' and built.get('binding') == binding and built.get('results') == pair['results'] and built.get('automaticRetry') is False and built.get('oldJournalUnmodified') is True and built.get('applicationStarted') is False and built.get('activation') is False and built.get('decisionSha256') == pair['rootDecisionSha256'], 'COMPLETED_NEW_ONLY_BUILD_REQUIRED')
    decision_path = parent/'new-build-root-decision-r1.json'; decision = pinned(decision_path,pair['rootDecisionSha256'],True)
    need(decision == {**binding,'schema':1,'scope':'BUILD_NEW_ONLY_FROM_VERIFIED_EXISTING_RESERVE','rootApproved':True,'acceptObservedRuntimeSubset':True,'acceptExistingIpv6NodeOptions':True,'approvedAtUtc':decision.get('approvedAtUtc')} and epoch(decision['approvedAtUtc']) >= epoch(rv['observedAtUtc']), 'EXACT_NEW_ONLY_ROOT_DECISION_REQUIRED')
    pins[str(decision_path)] = pair['rootDecisionSha256']; return pins

class NativeBackend:
    """Reuse accepted source/static lineage; verify worker and both service chains independently."""
    def __init__(self, photo, graph, build_path, build_pin, runtime_path, runtime_pin, root=ROOT):
        self.photo, self.g, self.root = photo, graph, exact_path(root)
        self.c, self.a, self.run = photo.c, photo.a, photo.run
        self.photo_path = photo.paths('photo-ui-r1')['journal']
        self.receipt = pinned(self.photo_path, PHOTO_RECEIPT_SHA, True)
        need(self.receipt.get('phase') == 'PHOTO_UI_CONTENT_AND_STATIC_APPLIED_NOT_UPLOAD_OR_DELIVERY_PROOF' and self.receipt.get('childImage') == CONTENT and self.receipt.get('uploadsEnabled') is False and self.receipt.get('cutoff') == CUTOFF, 'EXACT_COMPLETED_PHOTO_BASE_REQUIRED')
        self.base = self.receipt['after']
        need(len(self.base['containers']['content']['files']) == 16 and self.base['afterImages'] == {'content': CONTENT, 'chat': graph.IMAGE}, 'EXACT_PHOTO_CHAIN16_REQUIRED')
        self.build_path, self.build_pin = exact_path(build_path), build_pin
        self.runtime_path, self.runtime_pin = exact_path(runtime_path), runtime_pin
        need(self.build_path.name == 'verified-pair-r1.json' and self.build_path.parent == self.root/'.worker-images-photo-r1', 'EXACT_VERIFIED_PAIR_SIDECAR_PATH_REQUIRED')
        need(self.runtime_path.parent == self.root, 'ROOT_RUNTIME_PROOF_PATH_REQUIRED')
        self.build = pinned(self.build_path, build_pin, True); runtime = pinned(self.runtime_path, runtime_pin, True)
        need(self.build.get('schema') == 1 and self.build.get('phase') == 'TWO_CODE_IMAGES_VERIFIED_NOT_ACTIVATED' and self.build.get('runtimeProofSha256') == runtime_pin and self.build.get('nodeImage') == NODE_IMAGE and self.build.get('applicationStarted') is False and self.build.get('activation') is False and self.build.get('composeActions') == self.build.get('dbWrites') == self.build.get('workerRestarts') == 0, 'COMPLETED_OFFLINE_TWO_IMAGE_PROOF_REQUIRED')
        need(self.build.get('workerBefore') == self.build.get('workerAfter') and self.build['workerBefore']['cid'] == graph.CID and self.build['workerBefore']['image'] == graph.IMAGE, 'OFFLINE_OLD_WORKER_PROOF_REQUIRED')
        need(runtime.get('status') == 'RUNTIME_FILES_OBSERVED_NOT_BUILD_OR_ROLLBACK_APPROVAL' and runtime.get('workerStable') is True and runtime.get('workerBefore') == runtime.get('workerAfter') == self.build['workerBefore'] and runtime.get('nodeImageId') == NODE_IMAGE, 'ACCEPTED_RUNTIME_SUBSET_REQUIRED')
        validate_runtime_hooks(runtime)
        need(self.build.get('acceptedExistingNodeOptionsSha256') == IPV6_NODE_OPTIONS_SHA, 'EXACT_ACCEPTED_EXISTING_IPV6_NODE_OPTIONS_REQUIRED')
        match = runtime.get('match', {})
        need(match.get('status') == 'MATCH_OBSERVED_RUNTIME_FILES_NOT_BASE_APPROVAL' and match.get('directBinaryHashEqual') is True and match.get('projectionsEqual') is True and match.get('incomplete') is False and match.get('incompleteReasons') == [], 'MATCHED_RUNTIME_SUBSET_REQUIRED')
        self.pair_lineage_pins = verified_pair_lineage(self.build, runtime, self.root)
        self.images = {}
        need(set(self.build.get('results', {})) == {'old', 'new'}, 'TWO_OFFLINE_IMAGES_REQUIRED')
        for kind, row in self.build['results'].items():
            need(set(row) == {'image','layersSha256','sourceSha256','reconstructedCodeOnly','originalImageEquivalent'} and image(row['image']) and row['image'] not in (NODE_IMAGE, graph.IMAGE) and digest(row['layersSha256']) and digest(row['sourceSha256']) and row['reconstructedCodeOnly'] is True and row['originalImageEquivalent'] is False, 'EXACT_CODE_IMAGE_RESULT_REQUIRED')
            self.images[kind] = row['image']
        need(self.images['old'] != self.images['new'], 'DISTINCT_OLD_AND_NEW_CODE_IMAGES_REQUIRED')
        self.db_path = exact_path(photo.ui.ps['before']['binding']['hostPath'])
        self.self_path = exact_path(__file__); self.self_pin = sha(read(self.self_path))
        self.graph_path = exact_path(graph.__file__)
        self.input_pins = {str(self.photo_path): PHOTO_RECEIPT_SHA, str(self.build_path): build_pin, str(self.runtime_path): runtime_pin, str(self.self_path): self.self_pin, str(self.graph_path): GRAPH_SHA, **self.pair_lineage_pins}
    def stable(self):
        self.photo.stable()
        for name, pin in self.input_pins.items(): need(sha(read(Path(name))) == pin, 'ACTIVATION_INPUT_CHANGED')
    def lease(self): self.a.lease()
    def command(self, snapshot, service, overlay, operation):
        need(service in ('chat', 'content'), 'EXACT_SERVICE_REQUIRED')
        meta = snapshot['containers'][service]
        args = ['docker','compose','--project-name',meta['project'],'--project-directory',meta['workingDir']]
        for name in meta['files']+[str(overlay)]: args += ['--file',name]
        return args+operation
    def plan(self, snapshot, service, overlay):
        text = self.run(self.command(snapshot, service, overlay, ['config','--hash',service])).decode('ascii').strip()
        found = re.fullmatch(re.escape(service)+r'\s+([0-9a-f]{64})', text)
        need(found is not None, 'EXACT_PLANNED_CONFIG_HASH_REQUIRED'); return found.group(1)
    def up(self, snapshot, service, overlay):
        return self.run(self.command(snapshot, service, overlay, ['up','--detach','--no-build','--pull','never','--no-deps',service]))
    def metadata(self, service):
        row = decode(self.run(['docker','inspect','--format',LABELS,'synapse-'+service+'-1']))
        need(set(row) == {'image','project','service','workingDir','configFiles','configHash','running','health'} and image(row['image']) and row['service'] == service and row['running'] is True and row['health'] in (None, 'healthy', 'starting') and digest(row['configHash']), 'RUNNING_EXACT_SERVICE_REQUIRED')
        need(type(row['project']) is str and re.fullmatch('[a-z0-9][a-z0-9_-]{0,63}', row['project']) and exact_path(row['workingDir']).is_dir() and type(row['configFiles']) is str and len(row['configFiles']) <= 65536, 'ACTUAL_COMPOSE_IDENTITY_REQUIRED')
        files = row['configFiles'].split(','); need(1 <= len(files) <= 20 and len(files) == len(set(files)), 'UNIQUE_BOUNDED_ACTUAL_CHAIN_REQUIRED')
        pins = {}
        for name in files:
            path = exact_path(name); need(path.suffix.lower() in ('.json','.yaml','.yml'), 'EXACT_COMPOSE_FILE_REQUIRED'); pins[name] = sha(read(path))
        row.update(files=files, filePins=pins); return row
    def worker_facts(self):
        value = decode(self.run(['docker','inspect','--format',WORKER_INSPECT,'synapse-chat-1']))
        need(set(value) == {'Id','Image','Env','Cmd','Entrypoint','WorkingDir','User','Labels','Mounts','HostConfig','StartedAt','Running','RestartCount'} and digest(value['Id']) and image(value['Image']) and value['Running'] is True and type(value['RestartCount']) is int and value['RestartCount'] == 0, 'EXACT_UNRESTARTED_WORKER_REQUIRED')
        need(value['Cmd'] == ['node','server.js'] and value['Entrypoint'] in (['docker-entrypoint.sh'],['/usr/local/bin/docker-entrypoint.sh']) and value['WorkingDir'] == '/app' and value['User'] in ('','root','0'), 'EXACT_CURRENT_WORKER_STARTUP_REQUIRED')
        env = value['Env']; need(type(env) is list and len(env) <= 256 and all(type(e) is str and '=' in e for e in env), 'OPAQUE_ENV_REQUIRED')
        names = [e.split('=',1)[0] for e in env]; need(len(set(names)) == len(names), 'UNIQUE_ENV_NAMES_REQUIRED')
        env_map = dict(e.split('=',1) for e in env); options = env_map.get('NODE_OPTIONS')
        need(type(options) is str and len(options) == 62 and sha(options.encode('utf8')) == IPV6_NODE_OPTIONS_SHA and all(not env_map.get(name) for name in HOOKS if name != 'NODE_OPTIONS'), 'CURRENT_EXISTING_IPV6_NODE_OPTIONS_CHANGED')
        mounts = value['Mounts']; need(type(mounts) is list and len(mounts) <= 64 and all(type(m) is dict and type(m.get('Destination')) is str for m in mounts), 'CANONICAL_MOUNTS_REQUIRED')
        dest = [m['Destination'] for m in mounts]; need(len(set(dest)) == len(dest), 'UNIQUE_MOUNT_DESTINATION_REQUIRED')
        for target in dest:
            need(target.startswith('/') and target != '/' and '..' not in target.split('/') and not any(target == p or target.startswith(p+'/') or p.startswith(target.rstrip('/')+'/') for p in ('/app','/usr/local/bin','/usr/bin')), 'NO_APP_RUNTIME_MOUNT_OVERLAP_REQUIRED')
        need(type(value['HostConfig']) is dict and type(value['Labels']) is dict, 'HOSTCONFIG_REQUIRED'); epoch(value['StartedAt'])
        build_config = {key:value[key] for key in ('Cmd','Entrypoint','WorkingDir','User','Env','Labels')}
        build_host = {key:value['HostConfig'][key] for key in ('RestartPolicy','NetworkMode','PortBindings')}
        build_full = {'Id':value['Id'],'Image':value['Image'],'Config':build_config,'Mounts':sorted(mounts,key=lambda m:m['Destination']),'HostConfig':build_host}
        return {'cid':value['Id'],'image':value['Image'],'startedAt':value['StartedAt'],'envSha256':sha(encoded(sorted(env))),'mountsSha256':sha(encoded(sorted(mounts,key=lambda m:m['Destination']))),'hostSha256':sha(encoded(value['HostConfig'])),'startupSha256':sha(encoded([value[k] for k in ('Cmd','Entrypoint','WorkingDir','User')])),'buildOpaqueSha256':sha(encoded(build_full).rstrip(b'\n'))}
    def graph(self, ident=None, new=False):
        clear = sum((['--env', k+'='] for k in CLEAR), [])+['--env','NODE_DISABLE_COMPILE_CACHE=1']
        if ident is None: args = ['docker','exec']+clear+['synapse-chat-1','/usr/local/bin/node','-e',self.g.GRAPH_PROBE]
        else:
            need(image(ident) and ident in self.images.values(), 'EXACT_CHILD_IMAGE_REQUIRED')
            args = ['docker','run','--rm','--pull','never','--network','none','--read-only','--no-healthcheck','--cap-drop','ALL','--security-opt','no-new-privileges','--pids-limit','32','--memory','128m','--cpus','1','--user','0:0','--workdir','/app']+clear+['--entrypoint','/usr/local/bin/node',ident,'-e',self.g.GRAPH_PROBE]
        value = decode(self.run(args)); need(set(value) == {'schema','files'} and value['schema'] == 1 and set(value['files']) == set(self.g.EXPECTED), 'EXACT_TEN_FILE_GRAPH_REQUIRED')
        for name, (size, pin) in self.g.EXPECTED.items():
            if new and name == 'client-bot-bridge.js': size, pin = 34975, BRIDGE_SHA
            row = value['files'][name]
            need(set(row) == {'available','size','mode','sha256'} and row['available'] is True and row['size'] == size and row['sha256'] == pin and type(row['mode']) is int and 0 <= row['mode'] <= 0o7777, 'EXACT_WORKER_SOURCE_REQUIRED')
        return sha(encoded(value).rstrip(b'\n'))
    def image_proofs(self):
        self.stable(); parent = decode(self.run(['docker','image','inspect','--format',IMAGE_INSPECT,NODE_IMAGE]))
        need(parent['Id'] == NODE_IMAGE and parent['Os'] == 'linux' and parent['Architecture'] == 'amd64' and type(parent['RootFS']['Layers']) is list, 'IMMUTABLE_NODE_IMAGE_REQUIRED')
        for kind, ident in self.images.items():
            row = decode(self.run(['docker','image','inspect','--format',IMAGE_INSPECT,ident]))
            need(row['Id'] == ident and row['Os'] == parent['Os'] and row['Architecture'] == parent['Architecture'] and row['OnBuild'] in (None,[]) and row['Volumes'] in (None,{}) and row['Healthcheck'] is None and row['RootFS']['Type'] == 'layers' and len(parent['RootFS']['Layers']) == 4 and len(row['RootFS']['Layers']) == 6 and row['RootFS']['Layers'][:4] == parent['RootFS']['Layers'] and row['RootFS']['Layers'][-1] == EMPTY_WORKDIR, 'EXACT_BASE4_COPY_KNOWN_EMPTY_WORKDIR_REQUIRED')
            record = self.build['results'][kind]
            need(sha(encoded(row['RootFS']).rstrip(b'\n')) == record['layersSha256'] and self.graph(ident, kind == 'new') == record['sourceSha256'], 'OFFLINE_CHILD_PROOF_CHANGED')
        self.stable()
    def push_guard(self):
        ui = self.photo.ui; keys = ui.k; directory = Path(keys['directory'])
        need(directory == ui.p.key_directory and ui.p.private_meta(directory) == keys['keyMetadata'], 'PRIVATE_PUSH_METADATA_CHANGED')
        expected = sorted(ui.ps['before']['mounts']+[{'Type':'bind','Source':str(directory),'Destination':ui.pm.TARGET,'RW':False}], key=lambda row:row['Destination'])
        mounts = ui.p.mounts(); need(mounts == expected and ui.p.binding(mounts) == ui.ps['before']['binding'] and ui.p.flag(), 'PUSH_RO_MOUNT_DB_OR_FLAG_CHANGED')
        probe = decode(self.run(['docker','exec','synapse-content-1','node','-e',ui.pm.KEY_JS]))
        need(probe == {'keyValid':True,'publicKeySha256':keys['publicKeySha256'],'webPushVersion':'3.6.7','transportReady':True}, 'ACTIVE_PUSH_LIBRARY_CHANGED')
        health = decode(self.run(['docker','exec','synapse-content-1','node','-e',ui.pm.HEALTH_JS]))
        need(health == {'status':200,'ok':True,'service':'content'}, 'CONTENT_HEALTH_FAILED')
    def snapshot(self, new_worker=False, uploads=False):
        self.stable(); self.lease(); first = {s:self.metadata(s) for s in ('content','chat')}; worker = self.worker_facts()
        expected = {s:dict(self.base['selected'][s]) for s in ('content','chat')}; expected['content']['PALITRA_WEB_UPLOADS_ENABLED'] = 'true' if uploads else 'false'
        selected = {s:self.a.selected(s) for s in ('content','chat')}; need(selected == expected, 'ONLY_UPLOADS_SELECTED_CHANGE_ALLOWED')
        flags = decode(self.run(['docker','exec','synapse-content-1','node','-e',FLAGS_JS]))
        need(flags == {'enabled':'true','cutoff':CUTOFF}, 'L12_FLAG_CUTOFF_MUST_STAY_EXACT')
        for service, row in first.items():
            text = self.run(self._resolve_command(row, service)).decode('ascii').strip()
            found = re.fullmatch(re.escape(service)+r'\s+([0-9a-f]{64})', text)
            need(found is not None and found.group(1) == row['configHash'], 'RESOLVED_OPAQUE_CONFIG_MISMATCH')
        need(first['content']['image'] == CONTENT and worker['image'] == (self.images['new'] if new_worker else self.g.IMAGE) and first['chat']['image'] == worker['image'], 'EXACT_EXPECTED_CURRENT_IMAGES_REQUIRED')
        if not new_worker:
            need(worker['cid'] == self.g.CID and worker['buildOpaqueSha256'] == self.build['workerBefore']['configOpaqueSha256'], 'ORIGINAL_WORKER_BUILD_SNAPSHOT_REQUIRED')
        self.graph(new=new_worker); self.push_guard()
        need(self.photo.hashes(self.photo.expected_hashes(True)) == self.photo.expected_hashes(True), 'EXACT_CONTENT_SOURCE202_REQUIRED'); self.photo.static_inventory(True)
        content_cid = self.photo.cid(); last = {s:self.metadata(s) for s in ('content','chat')}
        need(first == last and worker == self.worker_facts() and selected == {s:self.a.selected(s) for s in ('content','chat')}, 'CONCURRENT_NATIVE_CHANGE')
        self.lease(); self.stable(); need(content_cid == self.photo.cid(), 'CONTENT_CID_CHANGED_DURING_CAPTURE')
        return {'containers':last,'selected':selected,'worker':worker,'contentCid':content_cid,'l12':flags}
    def _resolve_command(self, row, service):
        args = ['docker','compose','--project-name',row['project'],'--project-directory',row['workingDir']]
        for name in row['files']: args += ['--file',name]
        return args+['config','--hash',service]
    def db_read(self, callback):
        exact_path(self.db_path); connection = sqlite3.connect(self.db_path.as_uri()+'?mode=ro', uri=True, timeout=5, isolation_level=None)
        try:
            connection.execute('PRAGMA query_only=ON'); connection.execute('BEGIN'); result = callback(connection); connection.execute('COMMIT'); return result
        finally: connection.close()
    def heartbeat(self, after, now):
        row = self.db_read(lambda db:db.execute('SELECT ok,checked_at FROM client_bot_bridge_state WHERE bot_key=?', ('palitra',)).fetchone())
        need(row is not None and row[0] in (0,1), 'EXISTING_BRIDGE_HEARTBEAT_REQUIRED')
        at = epoch(row[1]); return {'ok':row[0] == 1,'checkedAt':row[1],'freshAfterWorkerStart':row[0] == 1 and epoch(after) <= at <= now and now-at <= 300}
    def wait_heartbeat(self, worker, clock=time.time, sleep=time.sleep):
        deadline = clock()+40
        while True:
            need(self.worker_facts() == worker, 'WORKER_CHANGED_WAITING_HEARTBEAT'); self.lease()
            result = self.heartbeat(worker['startedAt'], clock())
            if result['freshAfterWorkerStart']: return result
            need(clock() < deadline, 'NEW_WORKER_FRESH_HEARTBEAT_NOT_OBSERVED'); sleep(2)
    def queues(self):
        def project(db):
            states = dict(db.execute("SELECT state,COUNT(*) FROM chat_web_uploads WHERE site='palitra' AND company_code='palitra-love' GROUP BY state"))
            need(set(states) <= {'prepared','receiving','ready','committed','rejected','expired'}, 'KNOWN_UPLOAD_STATES_REQUIRED')
            deliveries = dict(db.execute("SELECT d.status,COUNT(*) FROM chat_message_deliveries d JOIN chat_web_uploads u ON u.thread_message_id=d.message_id WHERE u.site='palitra' AND u.company_code='palitra-love' GROUP BY d.status"))
            need(set(deliveries) <= {'queued','not_queued','sent','failed','uncertain'}, 'KNOWN_FILE_DELIVERY_STATES_REQUIRED')
            rows = db.execute("SELECT status,parts FROM client_bot_outbox WHERE bot_key='palitra' AND company_code='palitra-love' AND status IN ('pending','sending','uncertain') LIMIT 10001").fetchall()
            need(len(rows) <= 10000, 'BOUNDED_QUEUE_PROJECTION_REQUIRED'); jobs = {}
            for status, body in rows:
                need(type(body) is str and len(body) <= 1024*1024, 'BOUNDED_QUEUE_BODY_REQUIRED'); parts = decode(body.encode())
                need(type(parts) is list and len(parts) <= 1000 and all(type(p) is dict for p in parts), 'KNOWN_OUTBOX_PARTS_REQUIRED')
                if any(p.get('method') in ('sendPhoto','sendDocument') for p in parts): jobs[status] = jobs.get(status,0)+1
            return {'uploads':states,'fileDeliveries':deliveries,'activeFileJobs':jobs,'oldWorkerRollbackAllowed':False,'queueEdits':0}
        return self.db_read(project)

class Activation:
    def __init__(self, backend, name, clock=time.time):
        need(type(name) is str and re.fullmatch('photo-live-r[1-9][0-9]{0,3}', name), 'UNIQUE_PHOTO_LIVE_RN_REQUIRED')
        self.b, self.name, self.root, self.clock = backend, name, backend.root, clock
    def path(self, stage, kind):
        need(stage in STAGES and kind in ('decision','journal','overlay'), 'EXACT_STAGE_ARTIFACT_REQUIRED')
        return self.root/(self.name+'-'+stage+'-'+kind+'.json')
    def absent(self, stage, decision=False):
        attempts = list(self.root.glob('photo-live-r*-*-journal.json')); need(len(attempts) <= 32, 'BOUNDED_PRIOR_ATTEMPTS_REQUIRED')
        completed = {'WORKER_APPLIED_UPLOADS_FALSE_NOT_DELIVERY_PROOF','UPLOADS_ENABLED_NOT_FILE_DELIVERY_PROOF','UPLOADS_DISABLED_NEW_WORKER_PRESERVED'}
        for prior in attempts:
            need(re.fullmatch(r'photo-live-r[1-9][0-9]{0,3}-(?:worker|uploads|stop)-journal\.json',prior.name) is not None, 'UNKNOWN_PRIOR_ATTEMPT_NAME')
            need(decode(read(prior)).get('phase') in completed, 'INCOMPLETE_PRIOR_ATTEMPT_INSPECT_NO_NEW_NAMESPACE')
        for kind in ('decision','journal','overlay'):
            if kind == 'decision' and not decision: continue
            path = self.path(stage,kind); exact_path(path,True)
            need(not os.path.lexists(path) and not os.path.lexists(str(path)+'.pending'), 'ATTEMPT_EXISTS_INSPECT_DO_NOT_RETRY')
    def bound(self): return {'photoReceiptSha256':PHOTO_RECEIPT_SHA,'buildReceiptSha256':self.b.build_pin,'runtimeProofSha256':self.b.runtime_pin,'helperSha256':self.b.self_pin,'newWorkerImage':self.b.images['new'],'reserveImage':self.b.images['old']}
    def decision(self, stage, pin):
        value = pinned(self.path(stage,'decision'), pin, True)
        need(set(value) == {'schema','name','stage','rootApproved','observedAtUtc','inputs','before','acceptedResiduals','priorReceiptSha256'} and value['schema'] == 1 and value['name'] == self.name and value['stage'] == stage and value['rootApproved'] is True and value['inputs'] == self.bound() and value['acceptedResiduals'] == RESIDUALS, 'EXACT_STAGE_ROOT_DECISION_REQUIRED')
        fresh(value['observedAtUtc'],self.clock()); return value
    def completed(self, stage, pin):
        value = pinned(self.path(stage,'journal'),pin,True)
        phases = {'worker':'WORKER_APPLIED_UPLOADS_FALSE_NOT_DELIVERY_PROOF','uploads':'UPLOADS_ENABLED_NOT_FILE_DELIVERY_PROOF','stop':'UPLOADS_DISABLED_NEW_WORKER_PRESERVED'}
        need(value.get('schema') == 1 and value.get('name') == self.name and value.get('stage') == stage and value.get('phase') == phases[stage] and value.get('inputs') == self.bound() and value.get('automaticRetry') is False and value.get('automaticOldWorkerRollback') is False, 'EXACT_COMPLETED_STAGE_RECEIPT_REQUIRED')
        overlay = self.path(stage,'overlay'); need(value.get('overlay') == str(overlay) and sha(read(overlay)) == value['overlaySha256'], 'APPLIED_OVERLAY_CHANGED')
        return value
    def same(self, current, expected): need(current == expected, 'APPROVED_CURRENT_STATE_CHANGED')
    def approve(self, stage, prior_pin=None, accept=False, apply=False):
        need(apply is True and accept is True, 'EXPLICIT_ROOT_RUNTIME_SUBSET_DECISION_REQUIRED'); self.absent(stage,True); at = self.clock()
        if stage == 'worker':
            self.b.photo.inspect_completed('photo-ui-r1',PHOTO_RECEIPT_SHA); self.b.image_proofs(); before = self.b.snapshot()
            need(before['containers'] == self.b.base['containers'] and before['contentCid'] == self.b.base['contentContainerId'], 'EXACT_COMPLETED_PHOTO_CURRENT_STATE_REQUIRED')
        else:
            prior = self.completed('worker' if stage == 'uploads' else 'uploads', prior_pin)
            before = self.b.snapshot(True,stage == 'stop'); self.same(before,prior['after'])
            if stage == 'uploads':
                self.b.image_proofs()
                heartbeat = self.b.heartbeat(before['worker']['startedAt'],self.clock()); need(heartbeat['freshAfterWorkerStart'], 'CURRENT_NEW_WORKER_HEARTBEAT_REQUIRED')
        self.b.queues(); self.b.stable(); self.b.lease(); fresh(stamp(at),self.clock())
        self.same(self.b.snapshot(stage != 'worker',stage == 'stop'),before)
        value = {'schema':1,'name':self.name,'stage':stage,'rootApproved':True,'observedAtUtc':stamp(at),'inputs':self.bound(),'before':before,'acceptedResiduals':RESIDUALS,'priorReceiptSha256':prior_pin}
        write_new(self.path(stage,'decision'),value)
        return {'status':'ROOT_'+stage.upper()+'_DECISION_READY_NOT_APPLIED','decisionSha256':sha(read(self.path(stage,'decision'))),'runtimeWrites':0,'directDbWrites':0}
    def transition(self, before, after, stage, overlay, planned):
        service = 'chat' if stage == 'worker' else 'content'; other = 'content' if service == 'chat' else 'chat'
        need(after['containers'][other] == before['containers'][other], 'UNTOUCHED_SERVICE_CHANGED')
        old, new = before['containers'][service], after['containers'][service]
        expected = dict(old, files=old['files']+[str(overlay)], configFiles=','.join(old['files']+[str(overlay)]), filePins={**old['filePins'],str(overlay):sha(read(overlay))}, configHash=planned)
        if stage == 'worker': expected['image'] = self.b.images['new']
        need(new == expected, 'ONLY_EXACT_SERVICE_OVERLAY_TRANSITION_ALLOWED')
        if stage == 'worker':
            need(after['contentCid'] == before['contentCid'] and after['selected'] == before['selected'] and after['worker']['cid'] != before['worker']['cid'], 'WORKER_ONLY_RECREATION_REQUIRED')
            unchanged = ('envSha256','mountsSha256','hostSha256','startupSha256')
            need(all(after['worker'][key] == before['worker'][key] for key in unchanged), 'WORKER_STARTUP_ENV_MOUNTS_HOST_CHANGED')
        else:
            need(after['worker'] == before['worker'] and after['contentCid'] != before['contentCid'], 'CONTENT_ONLY_RECREATION_REQUIRED')
            selected = {s:dict(v) for s,v in before['selected'].items()}; selected['content']['PALITRA_WEB_UPLOADS_ENABLED'] = 'true' if stage == 'uploads' else 'false'
            need(after['selected'] == selected, 'ONLY_UPLOAD_FLAG_TRANSITION_ALLOWED')
        need(after['l12'] == before['l12'], 'L12_CUTOFF_CHANGED')
    def apply(self, stage, decision_pin, apply=False):
        need(apply is True, 'EXPLICIT_ROOT_APPLY_REQUIRED'); self.absent(stage); decision = self.decision(stage,decision_pin)
        prior = decision['priorReceiptSha256']
        if stage != 'worker': self.completed('worker' if stage == 'uploads' else 'uploads',prior)
        current = self.b.snapshot(stage != 'worker',stage == 'stop'); self.same(current,decision['before'])
        if stage != 'stop': self.b.image_proofs()
        overlay = self.path(stage,'overlay'); value = {'services':{'chat':{'image':self.b.images['new']}}} if stage == 'worker' else {'services':{'content':{'environment':{'PALITRA_WEB_UPLOADS_ENABLED':'true' if stage == 'uploads' else 'false'}}}}
        write_new(overlay,value); planned = self.b.plan(current,'chat' if stage == 'worker' else 'content',overlay)
        journal = {'schema':1,'name':self.name,'stage':stage,'phase':stage.upper()+'_UP_STARTED_UNKNOWN','inputs':self.bound(),'decisionSha256':decision_pin,'priorReceiptSha256':prior,'before':current,'overlay':str(overlay),'overlaySha256':sha(read(overlay)),'plannedConfigHash':planned,'automaticRetry':False,'automaticOldWorkerRollback':False,'directDbWrites':0,'queueEdits':0,'deviceDeliveryProven':False}
        write_new(self.path(stage,'journal'),journal)
        self.b.stable(); self.same(self.b.snapshot(stage != 'worker',stage == 'stop'),current); self.b.lease(); self.decision(stage,decision_pin)
        need(decode(read(overlay)) == value and sha(read(overlay)) == journal['overlaySha256'], 'LAST_OVERLAY_CHANGED')
        if stage == 'uploads': need(self.b.heartbeat(current['worker']['startedAt'],self.clock())['freshAfterWorkerStart'], 'LAST_NEW_WORKER_HEARTBEAT_REQUIRED')
        fresh(decision['observedAtUtc'],self.clock()); self.b.up(current,'chat' if stage == 'worker' else 'content',overlay)
        after = self.b.snapshot(True,stage == 'uploads'); self.transition(current,after,stage,overlay,planned)
        if stage == 'worker':
            need(epoch(after['worker']['startedAt']) >= epoch(decision['observedAtUtc']), 'NEW_WORKER_START_TIME_REQUIRED')
            heartbeat = self.b.wait_heartbeat(after['worker'],self.clock)
        else:
            heartbeat = self.b.heartbeat(after['worker']['startedAt'],self.clock())
            if stage == 'uploads': need(heartbeat['freshAfterWorkerStart'], 'AFTER_NEW_WORKER_HEARTBEAT_REQUIRED')
        self.same(self.b.snapshot(True,stage == 'uploads'),after); self.b.stable(); self.b.lease()
        phases = {'worker':'WORKER_APPLIED_UPLOADS_FALSE_NOT_DELIVERY_PROOF','uploads':'UPLOADS_ENABLED_NOT_FILE_DELIVERY_PROOF','stop':'UPLOADS_DISABLED_NEW_WORKER_PRESERVED'}
        journal.update(phase=phases[stage],after=after,heartbeat=heartbeat,queues=self.b.queues(),finishedAtUtc=stamp(self.clock()))
        replace(self.path(stage,'journal'),journal)
        return {'status':journal['phase'],'journalSha256':sha(read(self.path(stage,'journal'))),'newWorkerImage':self.b.images['new'],'uploadsEnabled':stage == 'uploads','deviceDeliveryProven':False,'directDbWrites':0,'automaticRetry':False,'automaticOldWorkerRollback':False}
    def inspect(self, stage, pin):
        receipt = self.completed(stage,pin); current = self.b.snapshot(True,stage == 'uploads'); self.same(current,receipt['after'])
        return {'status':'COMPLETED_'+stage.upper()+'_READONLY_NOT_DEVICE_PROOF','heartbeat':self.b.heartbeat(current['worker']['startedAt'],self.clock()),'queues':self.b.queues(),'mutations':0,'oldWorkerRollbackAllowed':False}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation',choices=tuple(OPERATIONS))
    for name in ('bundle','photo-code','ui-code','l12-code','graph','build-journal','runtime-proof'): parser.add_argument('--'+name,type=Path,required=True)
    for name in ('build-sha','runtime-sha','name'): parser.add_argument('--'+name,required=True)
    parser.add_argument('--decision-sha'); parser.add_argument('--prior-receipt-sha'); parser.add_argument('--receipt-sha'); parser.add_argument('--accept-runtime-subset',action='store_true'); parser.add_argument('--apply',action='store_true'); args = parser.parse_args()
    try:
        need(os.name == 'posix' and os.geteuid() == 0, 'NATIVE_ROOT_REQUIRED')
        for path in (args.photo_code,args.ui_code,args.l12_code,args.bundle): need(exact_path(path).is_dir() and path.is_relative_to(ROOT), 'EXACT_ROOT_CODE_DIRECTORY_REQUIRED')
        need(args.graph.parent == ROOT, 'EXACT_ROOT_GRAPH_PATH_REQUIRED')
        module = load_module(args.photo_code/'photo_ui_release_native.py',PHOTO_HELPER_SHA,'accepted_photo_release')
        graph = load_module(args.graph,GRAPH_SHA,'accepted_worker_graph')
        x, l = module.loaded(args.bundle,args.ui_code,args.l12_code); photo = module.PhotoRelease(x,l,args.photo_code)
        backend = NativeBackend(photo,graph,args.build_journal,args.build_sha,args.runtime_proof,args.runtime_sha)
        release = Activation(backend,args.name); stage = OPERATIONS[args.operation]
        if args.operation.startswith('approve-'): output = release.approve(stage,args.prior_receipt_sha,args.accept_runtime_subset,args.apply)
        elif args.operation.startswith('inspect-'): output = release.inspect(stage,args.receipt_sha)
        else: output = release.apply(stage,args.decision_sha,args.apply)
        print(json.dumps(output,separators=(',',':'))); return 0
    except BaseException as error:
        message = str(error); code = message if type(error) is ValueError and re.fullmatch('[A-Z][A-Z0-9_]{0,100}',message) else 'ACTIVATION_GUARD_REFUSED'
        print(json.dumps({'status':'REFUSED_OR_UNKNOWN_INSPECT_PRIVATE_JOURNAL','operation':args.operation,'code':code,'errorClass':type(error).__name__,'messageSha256':sha(message.encode()),'automaticRetry':False,'automaticOldWorkerRollback':False,'directDbWrites':0},separators=(',',':'))); return 2
if __name__ == '__main__': sys.exit(main())
