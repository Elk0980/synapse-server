"""Existing reserve proof -> fresh historical-runtime revalidation -> ONE new image build. Never activate."""
import argparse,hashlib,json,os,re,sys,time
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path('/opt/synapse/releases/palitra-app-20261015');ATTEMPT='worker-images-photo-r1'
BUILDER_SHA='10039482649848eb58f3ea18ccd7643cb44bbb5b95be752f3ba32f5c62505360'
UNKNOWN_SHA='c589190ac41ba50c3e49573caf8c8994a5010ca2f8a134926943d690f96b3b43'
EMPTY='sha256:5f70bf18a086007016e948b04aed3b82103a36bea41755b6cddfaf10ace3c6ef'
READER_SHA='6f3592dd533ba8af8345a0d21ac43f799c705ab6853f3cc142f143710cd37250'
sha=lambda b:hashlib.sha256(b).hexdigest()
def need(ok,code):
 if not ok:raise ValueError(code)
def nowstamp():return datetime.now(timezone.utc).isoformat()

class Continue:
 def __init__(self,m,b,reserve_path,reserve_pin,revalidation_path,clock=time.time):
  self.m,self.b,self.root,self.now=m,b,b.root,clock;self.reserve_path=Path(reserve_path);self.reserve_pin=reserve_pin;self.rv=Path(revalidation_path)
  need(b.name==ATTEMPT and b.dir==self.root/('.'+ATTEMPT),'EXACT_EXISTING_ATTEMPT_REQUIRED')
  need(self.reserve_path.parent==self.rv.parent==self.root and re.fullmatch(r'runtime-revalidation-r[1-9][0-9]{0,3}\.json',self.rv.name),'EXACT_ROOT_PROOF_PATHS_REQUIRED')
  self.decision=b.dir/'new-build-root-decision-r1.json';self.journal=b.dir/'new-build-attempt-r1.json';self.pair=b.dir/'verified-pair-r1.json'
  self.revalidation_pin=None;self.decision_pin=None;self.base=None
  self.run=b.run;b.inputs=self.inputs
  def bounded(args,*a,**kw):
   need(args[:3]!=['docker','image','tag'] and(args[:2]!=['docker','build']or args==b.build_cmd('new')),'ONLY_ORIGINAL_NEW_BUILD_COMMAND_ALLOWED')
   return self.run(args,*a,**kw)
  b.run=bounded
 def read(self,p,pin):return json.loads(self.m.pinpath(p,pin,private=True))
 def records(self):
  old=self.read(self.b.dir/'journal.json',UNKNOWN_SHA);r=self.read(self.reserve_path,self.reserve_pin);h=self.read(self.b.runtime_path,self.b.runtime_pin)
  need(old.get('phase')=='UNKNOWN_DO_NOT_RETRY'and old.get('previousPhase')=='OLD_BUILT_NOT_VERIFIED'and old.get('failure')=={'code':'EXACT_NODE_PLUS_ONE_COPY_LAYER_REQUIRED'}and old.get('results')=={}and old.get('name')==ATTEMPT,'EXACT_UNCHANGED_PREDECESSOR_UNKNOWN_REQUIRED')
  need(old.get('runtimeProofSha256')==self.b.runtime_pin and old.get('acceptedExistingNodeOptionsSha256')==self.m.NODE_OPTIONS_SHA,'HISTORIC_RUNTIME_AND_IPV6_BINDING_REQUIRED')
  need(r.get('schema')==1 and r.get('status')=='EXISTING_RESERVE_LAYERS_OBSERVED_NOT_BUILD_OR_ACTIVATION_APPROVAL'and r.get('journalSha256')==UNKNOWN_SHA and r.get('oldJournalStillUnknown')is True and r.get('oldJournalUnmodified')is True and r.get('baseImage')==self.m.NODE_IMAGE and r.get('workerBefore')==r.get('workerAfter')==old['workerBefore'],'ACCEPTED_EXISTING_RESERVE_PROOF_REQUIRED')
  p=r['proof'];need(p.get('baseLayers')==4 and p.get('reserveLayers')==6 and p.get('fullBasePrefix')is True and p.get('layerDiffIdsVerified')==6 and p.get('allTenExact')is True and p.get('sourceFiles')==10 and p.get('contentAddressedBlobsVerified')==12,'EXACT_RESERVE_COPY_PROOF_REQUIRED')
  added=p['addedLayers'];need(len(added)==2 and added[0].get('kind')=='COPY_EXACT_TEN'and added[1].get('members')==[]and added[1].get('zeroOnly')is True and added[1].get('decodedBytes')==1024 and added[1].get('diffId')==EMPTY and added[1].get('tarSha256')==EMPTY[7:]and p.get('addedLayerDiffIds')[-1]==EMPTY,'EXACT_KNOWN_EMPTY_WORKDIR_LAYER_REQUIRED')
  need(set(added[0]['files'])==set(self.b.g.EXPECTED),'EXACT_TEN_RESERVE_FILES_REQUIRED')
  for n,(size,pin)in self.b.g.EXPECTED.items():need(added[0]['files'][n]=={'size':size,'sha256':pin,'mode':0o600},'EXACT_RESERVE_SOURCE_REQUIRED')
  match=h.get('match',{});need(h.get('status')=='RUNTIME_FILES_OBSERVED_NOT_BUILD_OR_ROLLBACK_APPROVAL'and h.get('workerStable')is True and h.get('workerBefore')==h.get('workerAfter')==old['workerBefore']and match==self.b.rt.compare(match.get('old'),match.get('candidate'))and match.get('status')=='MATCH_OBSERVED_RUNTIME_FILES_NOT_BASE_APPROVAL'and match.get('incomplete')is False,'PINNED_SUCCESSFUL_HISTORICAL_RUNTIME_REQUIRED')
  self.b.validate_hooks(h.get('oldHooks'),True);self.b.validate_hooks(h['nodeImage']['hooks'],False)
  return old,r,h
 def revalidate(self,probe,execute=None):
  need(not os.path.lexists(self.rv),'NEW_REVALIDATION_RECEIPT_ONLY_NO_OVERWRITE');old,r,h=self.records();started=nowstamp()
  q=self.b.rt.Runner(self.b.a,probe,execute=execute,root=self.root);q.reader.lease();before,hooks=q.snapshot();node=q.image()
  need(before==h['workerAfter']and hooks==h['oldHooks']and node==h['nodeImage'],'CURRENT_WORKER_OR_NODE_BASE_DRIFT')
  projection=self.b.rt.projection(json.loads(q.run(q.oldcmd,probe).stdout))
  need(projection==h['match']['old'],'CURRENT_RUNTIME_PROJECTION_DRIFT')
  after,afterhooks=q.snapshot();nodeafter=q.image();q.reader.lease();self.records()
  need(before==after and hooks==afterhooks and node==nodeafter,'REVALIDATION_CURRENT_STATE_CHANGED')
  result=dict(schema=1,status='CURRENT_REVALIDATION_FROM_KNOWN_SUCCESS',observedAtUtc=started,historicalRuntimeProofSha256=self.b.runtime_pin,historicalObservedAtUtc=h['observedAtUtc'],projection=projection,workerBefore=before,workerAfter=after,nodeImage=node,oldHooks=hooks,candidateRerun=False,applicationStarted=False,builds=0)
  self.m.write_new(self.rv,self.m.canon(result)+b'\n');return dict(status=result['status'],revalidationSha256=sha(self.rv.read_bytes()),builds=0,candidateRerun=False)
 def inputs(self,decision=True):
  old,r,h=self.records();need(self.revalidation_pin is not None,'PINNED_FRESH_REVALIDATION_REQUIRED');v=self.read(self.rv,self.revalidation_pin)
  need(v.get('schema')==1 and v.get('status')=='CURRENT_REVALIDATION_FROM_KNOWN_SUCCESS'and v.get('historicalRuntimeProofSha256')==self.b.runtime_pin and v.get('historicalObservedAtUtc')==h['observedAtUtc']and v.get('projection')==h['match']['old']and v.get('workerBefore')==v.get('workerAfter')==h['workerAfter']and v.get('nodeImage')==h['nodeImage']and v.get('oldHooks')==h['oldHooks']and v.get('candidateRerun')is False,'EXACT_CURRENT_REVALIDATION_REQUIRED')
  self.m.fresh(v['observedAtUtc'],self.now());self.b.context('old');self.b.context('new')
  if decision:
   d=self.read(self.decision,self.decision_pin);need(d=={**self.binding(),'schema':1,'scope':'BUILD_NEW_ONLY_FROM_VERIFIED_EXISTING_RESERVE','rootApproved':True,'acceptObservedRuntimeSubset':True,'acceptExistingIpv6NodeOptions':True,'approvedAtUtc':d.get('approvedAtUtc')},'EXACT_NEW_ONLY_ROOT_DECISION_REQUIRED');self.m.fresh(d['approvedAtUtc'],self.now());need(self.m.epoch(d['approvedAtUtc'])>=self.m.epoch(v['observedAtUtc']),'ROOT_DECISION_BEFORE_REVALIDATION')
  else:d=None
  return v,h,d
 def binding(self):return dict(oldUnknownJournalSha256=UNKNOWN_SHA,reserveProofSha256=self.reserve_pin,reserveReaderSha256=READER_SHA,revalidationSha256=self.revalidation_pin,historicalRuntimeProofSha256=self.b.runtime_pin,existingNodeOptionsSha256=self.m.NODE_OPTIONS_SHA,helperSha256=sha(Path(__file__).read_bytes()))
 def current(self):
  old,r,h=self.records();before=self.b.snapshot();need(before==old['workerBefore'],'CURRENT_WORKER_DRIFT');self.b.lease();graph=self.b.graph_now();need(graph['worker']==before,'CURRENT_GRAPH_WORKER_DRIFT')
  base=self.b.image(self.m.NODE_IMAGE);reserve=self.b.image(self.b.tags['old']);need(base['Id']==r['baseImage']and reserve['Id']==r['reserveImage']and sha(self.m.canon(base['RootFS']))==r['baseLayersSha256']and sha(self.m.canon(reserve['RootFS']))==r['reserveLayersSha256']and reserve['RootFS']['Layers'][:4]==base['RootFS']['Layers']and len(base['RootFS']['Layers'])==4 and len(reserve['RootFS']['Layers'])==6 and reserve['RootFS']['Layers'][-1]==EMPTY,'CURRENT_EXACT_BASE_RESERVE_DRIFT')
  self.b.child_images={'old':reserve};self.b.pinned_images(base);return before,base,reserve
 def absent(self):
  need(not any(os.path.lexists(p)or os.path.lexists(str(p)+'.pending')for p in(self.journal,self.pair)),'NEW_BUILD_ATTEMPT_EXISTS_NO_REPLAY')
 def approve(self,pin,accept=False):
  need(accept is True,'EXPLICIT_ROOT_NEW_ONLY_DECISION_REQUIRED');self.revalidation_pin=pin;self.absent();need(not os.path.lexists(self.decision),'ROOT_DECISION_EXISTS_NO_RETIME');at=nowstamp();self.inputs(False);self.current();need(self.b.image(self.b.tags['new'],True)is None,'ORIGINAL_NEW_TAG_MUST_BE_ABSENT');self.inputs(False)
  d={**self.binding(),'schema':1,'scope':'BUILD_NEW_ONLY_FROM_VERIFIED_EXISTING_RESERVE','rootApproved':True,'acceptObservedRuntimeSubset':True,'acceptExistingIpv6NodeOptions':True,'approvedAtUtc':at};self.m.write_new(self.decision,self.m.canon(d)+b'\n');return dict(status='NEW_ONLY_ROOT_DECISION_READY_NOT_BUILT',decisionSha256=sha(self.decision.read_bytes()))
 def build(self,revalidation_pin,decision_pin):
  self.revalidation_pin,self.decision_pin=revalidation_pin,decision_pin;self.absent();self.inputs();before,base,reserve=self.current();need(self.b.image(self.b.tags['new'],True)is None,'ORIGINAL_NEW_TAG_MUST_BE_ABSENT');self.b.guard(before,base,'new');self.inputs()
  state=dict(schema=1,phase='NEW_BUILD_STARTED_UNKNOWN',binding=self.binding(),decisionSha256=decision_pin,startedAtUtc=nowstamp(),automaticRetry=False,oldJournalUnmodified=True,applicationStarted=False,activation=False)
  self.m.write_new(self.journal,self.m.canon(state)+b'\n');self.b.guard(before,base,'new');need(self.b.image(self.b.tags['new'],True)is None,'LAST_NEW_TAG_MUST_BE_ABSENT');self.inputs();self.b.run(self.b.build_cmd('new'),timeout=120)
  child=self.b.image(self.b.tags['new']);need(child['Id']not in(base['Id'],reserve['Id'])and child['RootFS']['Layers'][:4]==base['RootFS']['Layers']and len(child['RootFS']['Layers'])==6 and child['RootFS']['Layers'][-1]==EMPTY,'EXACT_NEW_BASE_COPY_KNOWN_EMPTY_LAYER_REQUIRED')
  self.b.built_ids=[child['Id']];observed=json.loads(self.b.run(self.b.probe_cmd(child['Id'])));need(set(observed)=={'schema','files'}and observed['schema']==1 and set(observed['files'])==set(self.b.g.EXPECTED),'NEW_EXACT_TEN_SOURCE_PROBE_REQUIRED')
  for n,(size,pin)in self.b.g.EXPECTED.items():
   if n=='client-bot-bridge.js':size,pin=self.m.NEW_BYTES,self.m.NEW_BRIDGE
   need(observed['files'][n]=={'available':True,'size':size,'sha256':pin,'mode':0o600},'NEW_EXACT_SOURCE_BYTES_REQUIRED')
  self.b.child_images['new']=child;self.b.guard(before,base,'new');after=self.b.snapshot();need(after==before,'FINAL_CURRENT_WORKER_DRIFT');self.inputs();old,r,h=self.records()
  files={n:{'available':True,**rec}for n,rec in r['proof']['addedLayers'][0]['files'].items()};oldsource=sha(self.m.canon({'schema':1,'files':files}))
  results={'old':dict(image=reserve['Id'],layersSha256=sha(self.m.canon(reserve['RootFS'])),sourceSha256=oldsource,reconstructedCodeOnly=True,originalImageEquivalent=False),'new':dict(image=child['Id'],layersSha256=sha(self.m.canon(child['RootFS'])),sourceSha256=sha(self.m.canon(observed)),reconstructedCodeOnly=True,originalImageEquivalent=False)}
  state.update(phase='NEW_CODE_IMAGE_VERIFIED_NOT_ACTIVATED',results=results,finishedAtUtc=nowstamp());pending=Path(str(self.journal)+'.pending');self.m.write_new(pending,self.m.canon(state)+b'\n');os.replace(pending,self.journal);self.m.sync_dir(self.b.dir)
  continuation=dict(oldUnknownJournalSha256=UNKNOWN_SHA,reserveProofPath=str(self.reserve_path),reserveProofSha256=self.reserve_pin,reserveReaderSha256=READER_SHA,revalidationPath=str(self.rv),revalidationSha256=revalidation_pin,newBuildJournalPath=str(self.journal),newBuildJournalSha256=sha(self.journal.read_bytes()),helperSha256=self.binding()['helperSha256'],emptyLayerDiffId=EMPTY)
  pair=dict(schema=1,name=ATTEMPT,phase='TWO_CODE_IMAGES_VERIFIED_NOT_ACTIVATED',runtimeProofSha256=self.b.runtime_pin,rootDecisionSha256=decision_pin,workerBefore=before,workerAfter=after,nodeImage=self.m.NODE_IMAGE,applicationStarted=False,activation=False,composeActions=0,dbWrites=0,workerRestarts=0,acceptedExistingNodeOptionsSha256=self.m.NODE_OPTIONS_SHA,results=results,continuation=continuation)
  self.m.write_new(self.pair,self.m.canon(pair)+b'\n');return dict(status=pair['phase'],pairSha256=sha(self.pair.read_bytes()),results=results,activation=False,oldJournalUnmodified=True)

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('operation',choices=('revalidate','approve-new-build','build-new'))
 for n in('builder','graph','reader','runtime-reader','probe','runtime-proof','reserve-proof','revalidation'):p.add_argument('--'+n,type=Path,required=True)
 for n in('runtime-sha','reserve-sha'):p.add_argument('--'+n,required=True)
 p.add_argument('--revalidation-sha');p.add_argument('--decision-sha');p.add_argument('--accept-runtime-subset',action='store_true');p.add_argument('--apply',action='store_true');a=p.parse_args()
 try:
  need(a.apply and os.name=='posix'and os.geteuid()==0,'EXPLICIT_NATIVE_ROOT_ONLY_ACTION_REQUIRED')
  import types
  raw=a.builder.read_bytes();need(sha(raw)==BUILDER_SHA and len(raw)==23718,'FROZEN_BUILDER100394_REQUIRED');m=types.ModuleType('accepted_builder100394');m.__file__=str(a.builder);exec(compile(raw,str(a.builder),'exec'),m.__dict__)
  g=m.module(a.graph,m.GRAPH_SHA,m.GRAPH_BYTES,'accepted_graph');reader=g.load_reader(a.reader);rt=m.module(a.runtime_reader,m.RUNTIME_RUNNER_SHA,m.RUNTIME_RUNNER_BYTES,'accepted_runtime615');probe=m.pinpath(a.probe,m.RUNTIME_PROBE_SHA,4648)
  b=m.Builder(g,reader,rt,ROOT,ATTEMPT,a.reserve_proof,a.reserve_sha,a.reader,a.runtime_proof,a.runtime_sha,ROOT/('.'+ATTEMPT)/'new-build-root-decision-r1.json','0'*64,ROOT/('.'+ATTEMPT)/'new/client-bot-bridge.js');c=Continue(m,b,a.reserve_proof,a.reserve_sha,a.revalidation)
  out=c.revalidate(probe)if a.operation=='revalidate'else c.approve(a.revalidation_sha,a.accept_runtime_subset)if a.operation=='approve-new-build'else c.build(a.revalidation_sha,a.decision_sha)
 except Exception as e:out=dict(status='NEW_ONLY_REFUSED_OR_UNKNOWN_INSPECT_SIDECAR',code=str(e)if type(e)is ValueError and re.fullmatch('[A-Z0-9_]{1,100}',str(e))else'NEW_ONLY_ACTION_REFUSED',automaticRetry=False,oldJournalUnmodified=True,activation=False)
 print(json.dumps(out,sort_keys=True,separators=(',',':')))
if __name__=='__main__':main()
