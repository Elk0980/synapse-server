"""Root only: snapshot-backed cleanup of fixed eight Palitra orders and related history.
No sends, worker writes, sequence reset, media deletion, schema or application changes.
"""
import argparse,hashlib,json,os,re,sqlite3,stat,subprocess,sys,types
from datetime import datetime,timezone
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('/opt/synapse/releases/palitra-app-20261015')
DB=Path('/var/lib/docker/volumes/synapse_content_data/_data/content.sqlite')
PRIVATE=ROOT/'history-clear8-r1'
PHASE1_SHA='39d2ccf48eea0cf421cca124f1928d3a29fab82ce18ba01d879d2c2d8d7c328f'
SCRIPT_SHA='d703f87eac0e39e493a24a8c46a461486ef7ffd0673a540fda5ee0793ec4982e'
SNAPSHOT_SHA='a0e30076faf359149aacf3e61e8f1732b275c56fa241bf7f7172b5a51527ab39'
IDS=[1,2,3,4,5,6,9,10]
KEEP_IDS=[11,12,13]
ZERO_TABLES=('client_dialogs','client_dialog_messages','client_dialog_versions','client_dialog_attachments','client_dialog_owner_requests','chat_thread_attachments','chat_thread_media_events','chat_web_uploads')
DELETE_ORDER=('chat_message_deliveries','chat_thread_requests','chat_manager_map','chat_native_jobs','chat_thread_links','chat_web_grants','chat_thread_channels','chat_thread_messages','chat_threads','client_bot_receipts','client_bot_map','client_order_links','client_bot_outbox','documents','site_order_work_events','site_order_checklist_events','site_order_checklist','site_order_work','site_order_outbox','site_orders')
INDEPENDENT={'actor_workspace_ai_jobs':'actor_workspace_messages','project_chat_ai_jobs':'project_chat_messages','project_chat_attachments':'project_chat_messages','project_chat_outbox':'project_chat_messages'}
CRM=('palitra_crm_inquiries','palitra_crm_orders')
CONFIRM='USER_CONFIRMED_DELETE_ONLY_FIXED_EIGHT_ORDERS_AND_RELATED_HISTORY'
WORKER_PROJECT_JS="""const fs=require('node:fs');const {DatabaseSync}=require('node:sqlite');const p=process.env.DATABASE_PATH||'/data/chat.sqlite';if(!/^24\\./.test(process.versions.node)||p!=='/data/chat.sqlite'||fs.realpathSync(p)!==p)throw Error('WORKER_READ_PATH_REFUSED');const refs=JSON.parse(process.argv[1]);if(!Array.isArray(refs)||refs.length>10000||refs.some(v=>!/^(?:cb|order):[1-9]\\d*$/.test(v)))throw Error('REFS_REFUSED');const d=new DatabaseSync(p,{readOnly:true});try{d.exec('PRAGMA query_only=ON');if(d.prepare('PRAGMA query_only').get().query_only!==1)throw Error('QUERY_ONLY_REQUIRED');d.exec('BEGIN');const marks=refs.map(()=>'?').join(',');const delivery=refs.length?d.prepare('SELECT * FROM project_telegram_delivery WHERE job_id IN ('+marks+') ORDER BY job_id,part').all(...refs):[];const ack=refs.length?d.prepare('SELECT job_id FROM project_telegram_ack WHERE job_id IN ('+marks+') ORDER BY job_id').all(...refs):[];if(delivery.length>10000||ack.length>10000)throw Error('ROWS_BOUNDED');d.exec('COMMIT');const s=fs.statSync(p);const sequence=d.prepare("SELECT name FROM sqlite_master WHERE name='sqlite_sequence'").get()?d.prepare('SELECT name,seq FROM sqlite_sequence ORDER BY name').all():[];process.stdout.write(JSON.stringify({delivery,ack,sequence,device:s.dev,inode:s.ino,readOnly:true}));}finally{d.close();}"""
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def data(value):return (json.dumps(value,sort_keys=True,ensure_ascii=True,separators=(',',':'))+'\n').encode()
def need(ok,code):
 if not ok:raise ValueError(code)
def qi(name):
 need(type(name)is str and re.fullmatch('[A-Za-z_][A-Za-z0-9_]*',name)is not None,'UNREVIEWED_IDENTIFIER');return '"'+name+'"'
def safe(path):
 path=Path(path);need(path.is_absolute()and'..'not in path.parts,'EXACT_ABSOLUTE_PATH_REQUIRED')
 for part in [*reversed(path.parents),path]:
  if os.path.lexists(part):need(not part.is_symlink(),'LINK_REFUSED')
 return path
def read_private(path):
 p=safe(path);s=p.stat();need(stat.S_ISREG(s.st_mode)and stat.S_IMODE(s.st_mode)==0o600 and s.st_uid==0 and 0<s.st_size<=32*1024*1024,'PRIVATE_ROOT_0600_FILE_REQUIRED');raw=p.read_bytes();n=p.stat();need((s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)==(n.st_dev,n.st_ino,n.st_size,n.st_mtime_ns),'PRIVATE_FILE_CHANGED');return raw
def sync_directory(path):
 fd=os.open(path,os.O_RDONLY|getattr(os,'O_DIRECTORY',0))
 try:os.fsync(fd)
 finally:os.close(fd)
def private_directory(path):
 st=safe(path).stat();need(stat.S_ISDIR(st.st_mode)and stat.S_IMODE(st.st_mode)==0o700 and st.st_uid==0,'PRIVATE_ROOT_0700_DIRECTORY_REQUIRED')
def create(path,value):
 p=safe(path);raw=data(value);fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|getattr(os,'O_NOFOLLOW',0),0o600)
 with os.fdopen(fd,'wb')as f:f.write(raw);f.flush();os.fsync(f.fileno())
 sync_directory(p.parent);need(read_private(p)==raw,'PRIVATE_READBACK_CHANGED');return sha(raw)
def replace_journal(path,value):
 pending=Path(str(path)+'.pending');create(pending,value);os.replace(pending,path);sync_directory(path.parent)
def load(path,pin,name):
 raw=safe(path).read_bytes();need(sha(raw)==pin,'FROZEN_HELPER_CHANGED');m=types.ModuleType(name);m.__file__=str(path);exec(compile(raw,str(path),'exec'),m.__dict__);return m
def allrows(conn,table):
 rows=[dict(r)for r in conn.execute('SELECT * FROM '+qi(table)+' LIMIT 50001')];need(len(rows)<=50000,'TABLE_ROW_BOUND_EXCEEDED');return sorted(rows,key=data)
def pk_fields(conn,table):
 fields=[r['name']for r in sorted(conn.execute('PRAGMA table_info('+qi(table)+')'),key=lambda r:r['pk'])if r['pk']];need(fields,'EXPLICIT_PRIMARY_KEY_REQUIRED');return fields
def row_key(row,fields):return tuple(row[f]for f in fields)
def where_rows(conn,table,expected):
 fields=pk_fields(conn,table);found=[]
 for row in expected:
  values=conn.execute('SELECT * FROM '+qi(table)+' WHERE '+' AND '.join(qi(f)+' IS ?'for f in fields),row_key(row,fields)).fetchall();need(len(values)==1,'TARGET_PRIMARY_KEY_CHANGED');found.append(dict(values[0]))
 need(sorted(found,key=data)==sorted(expected,key=data),'EXACT_TARGET_ROW_CHANGED');return fields
def audit_rows(conn):
 rows=[dict(r)for r in conn.execute("SELECT * FROM client_bot_audit WHERE bot_key='palitra' AND kind IN ('order_linked','order_unlinked','order_link_refused','order_status') ORDER BY id")];need(len(rows)<=1000,'AUDIT_ROWS_BOUNDED');target=[]
 for r in rows:
  need(r['kind']=='order_status','AUDIT_GRAMMAR_REQUIRES_REVIEW');match=re.fullmatch('заявка №([1-9][0-9]*): (Новая|В работе|Выполнена|Отменена)',r['detail']);need(match is not None,'AUDIT_DETAIL_REQUIRES_REVIEW')
  if int(match[1])in IDS:target.append(r)
 return rows,target
def reviewed(conn,content,worker,historical,project,worker_started_at):
 old=historical['content'];need(content['fixedOrderIds']==IDS and content['rows']==old['rows']and content['schemaInventory']['sha256']==old['schemaInventory']['sha256']and content['sequence']==old['sequence'],'PHASE1_TARGET_SCHEMA_OR_SEQUENCE_DRIFT')
 need(sorted(r['id']for r in content['projection']['otherNativeOrders'])==KEEP_IDS,'EXACT_OUTSIDE_ORDERS_REQUIRED');need(all(not content['rows'][t]for t in ZERO_TABLES),'LEGACY_OR_MEDIA_NOT_ZERO');need(len(content['rows']['chat_threads'])==2 and len(content['rows']['chat_thread_messages'])==4,'EXACT_NATIVE_HISTORY_BRANCH_REQUIRED')
 for t in ('site_order_outbox','client_bot_outbox'):
  need(all(r['status']in('sent','error','failed','uncertain')and r.get('claimed_at')is None for r in content['rows'][t]),'TARGET_OUTBOX_NOT_TERMINAL')
  start=datetime.fromisoformat(worker_started_at.replace('Z','+00:00'));need(start.tzinfo is not None,'WORKER_START_TIME_REQUIRED')
  for r in content['rows'][t]:
   queued=datetime.fromisoformat(r['next_attempt_at'].replace('Z','+00:00'));need(queued.tzinfo is not None and queued<=start,'TARGET_QUEUE_NOT_PROVEN_BEFORE_CURRENT_WORKER')
 need(all(r['status']in('sent','uncertain')for r in content['rows']['chat_message_deliveries']),'TARGET_DELIVERY_NOT_TERMINAL')
 need(worker['rows']['client_bot_ack']==[]and all(r['state']=='done'for r in worker['inboxAggregate'])and all(r['state']in('sent','uncertain')and r['part']==0 for r in worker['rows']['client_bot_delivery']),'WORKER_TARGET_NOT_SETTLED')
 need(worker['rows']==historical['worker']['rows'],'WORKER_TARGET_LEDGER_DRIFT');need(content['projection']['push']['activeEncrypted']==0 and content['projection']['push']['decrypted']is False,'ACTIVE_PUSH_JOB_REFUSED')
 refs=content['projection']['unreviewedReferences'];need(len(refs)==4 and {(r['table'],r['column'])for r in refs}=={(t,'message_id')for t in INDEPENDENT},'UNREVIEWED_REFERENCE_CHANGED')
 for table,parent in INDEPENDENT.items():
  fks=[r for r in content['schemaInventory']['foreignKeys']if r['sourceTable']==table and r['from']=='message_id'];need(len(fks)==1 and fks[0]['table']==parent and fks[0]['to']=='id','INDEPENDENT_MESSAGE_NAMESPACE_UNPROVEN')
 allowed={'ACTIVE_CLIENT_BOT_OUTBOX','AUDIT_HISTORY_SCOPE_UNRESOLVED','CRM_REFERENCE_OUTSIDE_DELETE_SCOPE','OTHER_NATIVE_ORDERS_EXIST','QUEUED_OR_UNCERTAIN_NATIVE_CHAT_DELIVERIES'}|{'UNREVIEWED_TYPED_REFERENCE:'+sha(t.encode())[:16]for t in INDEPENDENT}
 need(set(content['blockers'])<=allowed,'UNRESOLVED_CONTENT_BLOCKER')
 # These terminal ledger records are intentionally retained; no worker writes are possible here.
 allowed_worker={'WORKER_DELIVERY_INFLIGHT_OR_UNCERTAIN'}|{'WORKER_JOB_SCOPE_UNRESOLVED:'+sha(t.encode())[:16]for t in('project_telegram_delivery','project_telegram_ack')};need(set(worker['blockers'])<=allowed_worker,'UNRESOLVED_WORKER_BLOCKER');need(project['readOnly']is True and project['ack']==[]and all(r['state']in('sent','failed','uncertain')for r in project['delivery']),'PROJECT_WORKER_LEDGER_NOT_SETTLED')
 need(worker['schemaInventory']['sha256']==historical['worker']['schemaInventory']['sha256'],'WORKER_SCHEMA_CHANGED')
 audit_all,audit_target=audit_rows(conn);need([{'kind':r['kind'],'count':sum(x['kind']==r['kind']for x in audit_all)}for r in audit_all[:1]]==old['projection']['auditHistory']['kinds']and len(audit_all)==1 and [(r['id'],r['kind'])for r in audit_target]==[(4,'order_status')]and re.match('заявка №6: ',audit_target[0]['detail'])is not None,'AUDIT_HISTORY_DRIFT')
 crm={}
 for t in CRM:
  actual=[dict(r)for r in conn.execute('SELECT * FROM '+qi(t)+' WHERE site_order_id IN ('+','.join('?'for _ in IDS)+') ORDER BY id',IDS)];need([(r['id'],r['company_code'],r['site_order_id'])for r in actual]==[(1,'palitra-love',9),(2,'palitra-love',10)],'EXACT_FOUR_CRM_BACKLINKS_REQUIRED');crm[t]=actual
  info={r['name']:dict(r)for r in conn.execute('PRAGMA table_info('+qi(t)+')')};need(info['site_order_id']['notnull']==0 and not any(r['from']=='site_order_id'for r in conn.execute('PRAGMA foreign_key_list('+qi(t)+')')),'NULLABLE_NON_FK_BACKLINK_REQUIRED')
 rows={t:content['rows'][t]for t in DELETE_ORDER};rows['client_bot_audit']=audit_target;targets=set(rows)|set(CRM)
 need(not any(s['type']=='trigger'and s['tbl_name']in targets for s in content['schemaInventory']['schema']),'TARGET_TRIGGER_REFUSED')
 for fk in content['schemaInventory']['foreignKeys']:
  if fk['table']in rows:need(fk['on_delete']=='NO ACTION','UNREVIEWED_DELETE_CASCADE_REFUSED')
 keys={t:where_rows(conn,t,r)for t,r in rows.items()}
 preserved={}
 for t in set(rows)|set(INDEPENDENT)|set(CRM):
  current=allrows(conn,t)
  if t in rows:
   drop={row_key(r,keys[t])for r in rows[t]};current=[r for r in current if row_key(r,keys[t])not in drop]
  preserved[t]={'count':len(current),'sha256':sha(data(current))}
 keep=[dict(r)for r in conn.execute('SELECT * FROM site_orders WHERE id IN (11,12,13) ORDER BY id')];need([r['id']for r in keep]==KEEP_IDS,'PRESERVED_NATIVE_ORDERS_CHANGED')
 return {'rows':rows,'keys':keys,'crm':crm,'preserved':preserved,'keepOrdersSha256':sha(data(keep)),'sequence':content['sequence'],'schemaSha256':content['schemaInventory']['sha256'],'workerRows':worker['rows'],'workerSchemaSha256':worker['schemaInventory']['sha256'],'projectWorker':project,'workerRefs':content['projection']['jobs']['siteOrder']+content['projection']['jobs']['clientBot']}
def delete_locked(conn,state,*,fault=None):
 need(conn.in_transaction,'LOCKED_TRANSACTION_REQUIRED');before=conn.total_changes;counts={}
 for t,rows in state['crm'].items():
  for r in rows:
   cur=conn.execute('UPDATE '+qi(t)+' SET site_order_id=NULL WHERE id=? AND company_code=? AND site_order_id=?',(r['id'],'palitra-love',r['site_order_id']));need(cur.rowcount==1,'CRM_BACKLINK_CAS_FAILED')
 for t in ('client_bot_audit',)+DELETE_ORDER:
  fields=state['keys'][t];n=0
  for r in state['rows'][t]:n+=conn.execute('DELETE FROM '+qi(t)+' WHERE '+' AND '.join(qi(f)+' IS ?'for f in fields),row_key(r,fields)).rowcount
  need(n==len(state['rows'][t]),'EXACT_DELETE_COUNT_CHANGED');counts[t]=n
  if fault:fault(t,conn)
 need(conn.total_changes-before==sum(counts.values())+4,'UNINTENDED_MUTATION_COUNT')
 for t,expected in state['preserved'].items():
  actual=allrows(conn,t)
  if t in CRM:
   adjusted=[]
   for r in actual:
    matches=[x for x in state['crm'][t]if x['id']==r['id']]
    if matches:need(r['site_order_id']is None,'CRM_BACKLINK_REMAINS');r={**r,'site_order_id':matches[0]['site_order_id']}
    adjusted.append(r)
   actual=sorted(adjusted,key=data)
  need({'count':len(actual),'sha256':sha(data(actual))}==expected,'OUTSIDE_OR_CRM_FIELD_CHANGED')
 need([dict(r)for r in conn.execute('SELECT name,seq FROM sqlite_sequence ORDER BY name')]==state['sequence'],'SEQUENCE_CHANGED')
 need(sha(data([dict(r)for r in conn.execute('SELECT * FROM site_orders WHERE id IN (11,12,13) ORDER BY id')]))==state['keepOrdersSha256'],'OUTSIDE_ORDERS_CHANGED')
 need(conn.execute('SELECT COUNT(*) FROM site_orders WHERE id IN (1,2,3,4,5,6,9,10)').fetchone()[0]==0,'FIXED_TARGETS_REMAIN');return counts
def connect():
 p=safe(DB);need(p.is_file(),'EXISTING_DATABASE_REQUIRED');s=p.stat();c=sqlite3.connect(p.as_uri()+'?mode=rw',uri=True,isolation_level=None,timeout=10);c.row_factory=sqlite3.Row;c.execute('PRAGMA foreign_keys=ON');need(c.execute('PRAGMA foreign_keys').fetchone()[0]==1,'FOREIGN_KEYS_REQUIRED');need((s.st_dev,s.st_ino)==(p.stat().st_dev,p.stat().st_ino),'DB_INODE_CHANGED');return c
class Purge:
 def __init__(self,args):
  self.args=args;self.h=load(args.phase1_helper,PHASE1_SHA,'purge_readonly_phase1');self.a,self.reports,self.receipt=self.h.dependencies(args);self.root=PRIVATE;self.paths={k:self.root/(k+'.json')for k in('decision','target-backup','apply-journal')};self.h.lease(args.lease_pid);self.code=self.a.read(args.collector_js);need(sha(self.code)==SCRIPT_SHA,'READONLY_COLLECTOR_CHANGED');original_raw=read_private(ROOT/'history-reset-r1-snapshot.json');self.original=json.loads(original_raw);need(sha(original_raw)==SNAPSHOT_SHA and self.original['status']=='HISTORY_PHASE1_READONLY_SNAPSHOT_NOT_PURGE_APPROVAL'and self.original['fixedOrderIds']==IDS,'EXACT_PHASE1_SNAPSHOT_REQUIRED')
 def runtime(self):
  need(sha(safe(self.args.phase1_helper).read_bytes())==PHASE1_SHA and sha(self.a.read(self.args.collector_js))==SCRIPT_SHA and sha(read_private(ROOT/'history-reset-r1-snapshot.json'))==SNAPSHOT_SHA,'IMMUTABLE_PHASE1_INPUT_CHANGED');value=self.h.runtime(self.a,self.reports,self.receipt,self.args.lease_pid);mounts=self.a.decode(self.reports.b.run(['docker','inspect','--format','{{json .Mounts}}','synapse-content-1']));data_mount=[m for m in mounts if m.get('Destination')=='/data'];need(len(data_mount)==1 and data_mount[0].get('Source')==str(DB.parent)and data_mount[0].get('Type')=='volume'and data_mount[0].get('RW')is True,'EXACT_CONTENT_DB_BINDING_REQUIRED');need(all(not self.root.is_relative_to(Path(m['Source']))and not Path(m['Source']).is_relative_to(self.root)for m in mounts),'PRIVATE_BACKUP_MOUNT_OVERLAP');return value
 def worker_read(self,refs):
  worker=self.a.decode(self.h.run(['docker','exec','--env','PALITRA_HISTORY_READONLY_NATIVE=1','synapse-chat-1','/usr/local/bin/node','-e',self.code.decode(),'worker',json.dumps(refs,separators=(',',':'))],timeout=30));need(worker['status']=='READONLY_WORKER_TARGET_JOB_PROJECTION','WORKER_COLLECTION_REFUSED');project=self.a.decode(self.h.run(['docker','exec','synapse-chat-1','/usr/local/bin/node','-e',WORKER_PROJECT_JS,json.dumps(refs,separators=(',',':'))],timeout=30));need((project['device'],project['inode'])==(worker['database']['device'],worker['database']['inode']),'WORKER_DATABASE_IDENTITY_MISMATCH');return worker,project
 def settled_worker_unchanged(self,state):
  worker,project=self.worker_read(state['workerRefs']);need(worker['rows']==state['workerRows']and worker['schemaInventory']['sha256']==state['workerSchemaSha256']and project==state['projectWorker']and all(r['state']=='done'for r in worker['inboxAggregate']),'WORKER_LEDGER_DRIFT_NO_REPLAY')
 def observe_locked(self,conn):
  need(conn.in_transaction,'LOCKED_READ_REQUIRED');prefix=['docker','exec','--env','PALITRA_HISTORY_READONLY_NATIVE=1'];content=self.a.decode(self.h.run(prefix+['synapse-content-1','node','-e',self.code.decode(),'content'],timeout=60));need(content['status']=='READONLY_CONTENT_HISTORY_SNAPSHOT_NOT_DELETE_APPROVAL','CONTENT_COLLECTION_REFUSED');s=DB.stat();need((s.st_dev,s.st_ino)==(content['database']['device'],content['database']['inode']),'HOST_CONTAINER_DATABASE_IDENTITY_MISMATCH');refs=content['projection']['jobs']['siteOrder']+content['projection']['jobs']['clientBot'];worker,project=self.worker_read(refs);return reviewed(conn,content,worker,self.original,project,self.receipt['after']['worker']['startedAt'])
 def approve(self):
  need(not os.path.lexists(self.root),'PRIOR_ATTEMPT_NO_NEW_APPROVAL');at=datetime.now(timezone.utc);runtime=self.runtime();conn=connect()
  try:
   conn.execute('BEGIN IMMEDIATE');state=self.observe_locked(conn);need(self.runtime()==runtime,'RUNTIME_DRIFT_DURING_APPROVAL');conn.execute('ROLLBACK')
  finally:conn.close()
  need((datetime.now(timezone.utc)-at).total_seconds()<300,'APPROVAL_OBSERVATION_STALE');self.h.lease(self.args.lease_pid);safe(self.root).mkdir(mode=0o700);private_directory(self.root);sync_directory(self.root.parent);backup={'schema':1,'fixedOrderIds':IDS,'phase1SnapshotSha256':SNAPSHOT_SHA,'state':state,'runtime':runtime,'workerDbReadOnly':True};bp=create(self.paths['target-backup'],backup);decision={'schema':1,'status':'ROOT_FIXED8_BACKUP_READY_NOT_DELETED','observedAtUtc':at.isoformat(),'fixedOrderIds':IDS,'userConfirmation':CONFIRM,'phase1SnapshotSha256':SNAPSHOT_SHA,'backupSha256':bp,'runtime':runtime,'stateSha256':sha(data(state)),'helperSha256':sha(Path(__file__).read_bytes()),'phase1HelperSha256':PHASE1_SHA,'scriptSha256':SCRIPT_SHA};pin=create(self.paths['decision'],decision);safe_ledger=lambda rows:[{k:r[k]for k in('job_id','part','state')}for r in rows];return {'status':decision['status'],'decisionSha256':pin,'backupSha256':bp,'counts':{t:len(r)for t,r in state['rows'].items()},'crmBacklinksToDetach':4,'clientWorkerTargetLedger':safe_ledger(state['workerRows']['client_bot_delivery']),'projectWorkerTargetLedger':safe_ledger(state['projectWorker']['delivery']),'targetWorkerAckCount':0,'workerSequenceSha256':sha(data(state['projectWorker']['sequence'])),'dbWrites':0,'outboundMessages':0}
 def apply(self,pin):
  need(self.args.apply and self.args.confirmed_delete_fixed_eight_and_history,'EXPLICIT_ROOT_APPLY_REQUIRED');private_directory(self.root);need(not os.path.lexists(self.paths['apply-journal'])and not os.path.lexists(str(self.paths['apply-journal'])+'.pending'),'PRIOR_OR_UNKNOWN_APPLY_NO_RETRY');d_raw=read_private(self.paths['decision']);d=json.loads(d_raw);need(sha(d_raw)==pin and d['status']=='ROOT_FIXED8_BACKUP_READY_NOT_DELETED'and d['fixedOrderIds']==IDS and d['userConfirmation']==CONFIRM and d['phase1SnapshotSha256']==SNAPSHOT_SHA and d['helperSha256']==sha(Path(__file__).read_bytes()),'EXACT_PRIVATE_DECISION_REQUIRED');backup_raw=read_private(self.paths['target-backup']);need(sha(backup_raw)==d['backupSha256'],'EXACT_PRIVATE_BACKUP_REQUIRED');backup=json.loads(backup_raw);need(sha(data(backup['state']))==d['stateSha256']and backup['runtime']==d['runtime'],'BACKUP_STATE_BINDING_CHANGED')
  def fresh():
   elapsed=(datetime.now(timezone.utc)-datetime.fromisoformat(d['observedAtUtc'])).total_seconds();need(0<=elapsed<300,'DECISION_STALE_OR_FUTURE')
  fresh();need(self.runtime()==d['runtime'],'RUNTIME_DRIFT_BEFORE_APPLY');journal={'schema':1,'status':'FIXED8_DELETE_STARTED_UNKNOWN_NO_REPLAY','decisionSha256':pin,'backupSha256':d['backupSha256'],'fixedOrderIds':IDS,'startedAtUtc':datetime.now(timezone.utc).isoformat(),'automaticRetry':False};create(self.paths['apply-journal'],journal);conn=None;committed=False;commit_attempted=False
  try:
   conn=connect();conn.execute('BEGIN IMMEDIATE');state=self.observe_locked(conn);need(sha(data(state))==d['stateSha256'],'EXACT_TARGET_CHANGED_AFTER_APPROVAL');need(self.runtime()==d['runtime'],'LAST_RUNTIME_GUARD_CHANGED');fresh();need(read_private(self.paths['decision'])==d_raw and read_private(self.paths['target-backup'])==backup_raw,'LAST_PRIVATE_INPUT_DRIFT');counts=delete_locked(conn,state);self.settled_worker_unchanged(state);self.h.lease(self.args.lease_pid);fresh();journal.update(status='FIXED8_COMMIT_STARTED_UNKNOWN_NO_REPLAY');replace_journal(self.paths['apply-journal'],journal);commit_attempted=True;conn.execute('COMMIT');committed=True;self.settled_worker_unchanged(state);need(conn.execute('SELECT COUNT(*) FROM site_orders WHERE id IN (1,2,3,4,5,6,9,10)').fetchone()[0]==0,'POST_COMMIT_TARGETS_REMAIN');journal.update(status='ONLY_FIXED_EIGHT_ORDERS_AND_RELATED_HISTORY_DELETED',finishedAtUtc=datetime.now(timezone.utc).isoformat(),deletedOrders=8,deletedCounts=counts,crmBacklinksDetached=4,workerDbWrites=0,targetWorkerLedgerPreserved=True,contentSequencePreserved=True,otherOrdersPreserved=KEEP_IDS,outboundMessages=0);replace_journal(self.paths['apply-journal'],journal);return {k:v for k,v in journal.items()if k!='startedAtUtc'}
  except Exception:
   rolled_back=False
   if conn is not None and conn.in_transaction:conn.execute('ROLLBACK');rolled_back=True
   if not commit_attempted and not committed and rolled_back:journal.update(status='REFUSED_TRANSACTION_ROLLED_BACK_NO_DELETE',finishedAtUtc=datetime.now(timezone.utc).isoformat());replace_journal(self.paths['apply-journal'],journal)
   raise
  finally:
   if conn is not None:conn.close()
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('operation',choices=('approve','apply'))
 for n in('phase1-helper','reports-helper','activation-helper','bundle','photo-code','ui-code','l12-code','graph','build-journal','runtime-proof','payload','collector-js'):p.add_argument('--'+n,type=Path,required=True)
 for n in('build-sha','runtime-sha','manifest-sha'):p.add_argument('--'+n,required=True)
 p.add_argument('--lease-pid',type=int,required=True);p.add_argument('--decision-sha');p.add_argument('--confirmed-delete-fixed-eight-and-history',action='store_true');p.add_argument('--apply',action='store_true');args=p.parse_args()
 try:
  need(os.name=='posix'and os.geteuid()==0 and args.confirmed_delete_fixed_eight_and_history,'ROOT_CONFIRMED_FIXED_EIGHT_SCOPE_REQUIRED');need(args.operation!='approve'or not args.apply,'APPROVE_CANNOT_DELETE');purge=Purge(args);result=purge.approve()if args.operation=='approve'else purge.apply(args.decision_sha);print(json.dumps(result,separators=(',',':')));return 0
 except Exception as e:
  message=str(e);code=message if type(e)is ValueError and re.fullmatch('[A-Z][A-Z0-9_]{0,100}',message)else'OPERATION_REFUSED_INSPECT_PRIVATE_JOURNAL';print(json.dumps({'status':'REFUSED_OR_UNKNOWN_NO_REPLAY','code':code,'messageSha256':sha(message.encode()),'automaticRetry':False},separators=(',',':')));return 2
if __name__=='__main__':sys.exit(main())
