"""Root-only two-file reports UI release after the completed uploads=true activation.
No worker, flag, auth, rights, DB, queue or automatic rollback/retry operations.
"""
import argparse,base64,hashlib,json,os,re,stat,sys,time
from pathlib import Path

ROOT=Path('/opt/synapse/releases/palitra-app-20261015')
ACTIVATION_SHA='5069df0759312e2410bcfb05e94db00583af1cb6d87ab3c8dde62c161e22b8ec'
UPLOADS_SHA='0a49cfbaf9b814ddb59580f5dda29b3c5501236f6d3ed8e13fc82cb63ac99bb9'
CONTENT='sha256:bcb7187b4a79ef65bfda218a287e25bd858eedf08fee84983b2f73e51a8346e6'
WORKER='sha256:d4d4d453ce2e3dc47d5e0962d62b95938f42c56ec73789fe76a324e0d2ff0508'
BEFORE={'shell.js':('2400831bffc5b61535f60fcdebe5ad83444fe7e1d8b9df209c2aa5d507a8960c',115142),'synapse-bridge.js':('4b560d0e8ee13a1704d9e16d572ab96a61907ab393b26f7596b7b7cc714268e5',62203)}
NAME='reports-ui-r1';PHASE='REPORTS_UI_CONTENT_AND_STATIC_APPLIED_NOT_ROLE_ACCEPTANCE'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def need(ok,code):
 if not ok:raise ValueError(code)
for _pin in (ACTIVATION_SHA,UPLOADS_SHA,*[v[0]for v in BEFORE.values()]):need(re.fullmatch('[0-9a-f]{64}',_pin)is not None,'BAD_REPORTS_PRODUCTION_SHA_LITERAL')
for _image in (CONTENT,WORKER):need(re.fullmatch('sha256:[0-9a-f]{64}',_image)is not None,'BAD_REPORTS_PRODUCTION_IMAGE_LITERAL')

class ReportsRelease:
 def __init__(self,a,b,payload,manifest_pin,clock=time.time):
  self.a,self.b,self.photo,self.root,self.clock=a,b,b.photo,b.root,clock;self.c=b.photo.c;self.run=b.run
  self.payload=a.exact_path(payload);need(self.payload.is_dir()and self.payload.is_relative_to(self.root),'ROOT_REPORTS_PAYLOAD_REQUIRED')
  self.manifest_pin=manifest_pin;raw=a.read(self.payload/'MANIFEST.json');need(sha(raw)==manifest_pin,'PINNED_REPORTS_MANIFEST_REQUIRED');m=a.decode(raw)
  need(set(m)=={'schema','status','records'}and m['schema']==1 and m['status']=='EXACT_REPORTS_UI_TWO_FILES_NO_BACKEND_CHANGE'and type(m['records'])is list and len(m['records'])==2,'TWO_FILE_REPORTS_MANIFEST_REQUIRED')
  self.pins={str(self.payload/'MANIFEST.json'):manifest_pin};self.records={};self.m={'records':[]}
  self.helper=a.exact_path(__file__);self.helper_pin=sha(a.read(self.helper));self.pins[str(self.helper)]=self.helper_pin
  for r in m['records']:
   need(type(r)is dict and set(r)=={'name','payload','beforeSha256','beforeBytes','sha256','bytes','hunks'}and r['name']in BEFORE and r['payload']==r['name']and r['name']not in self.records,'EXACT_TWO_REPORTS_RECORDS_REQUIRED')
   n=r['name'];need((r['beforeSha256'],r['beforeBytes'])==BEFORE[n]and a.digest(r['sha256'])and type(r['bytes'])is int and 0<r['bytes']<=2097152 and r['sha256']!=r['beforeSha256']and type(r['hunks'])is list and 1<=len(r['hunks'])<=32,'EXACT_REPORTS_BASE_AND_BOUNDED_HUNKS_REQUIRED')
   new=a.read(self.payload/n);need(len(new)==r['bytes']and sha(new)==r['sha256'],'REPORTS_PAYLOAD_CHANGED');old=new
   for h in reversed(r['hunks']):
    need(type(h)is dict and set(h)=={'before','after'}and type(h['before'])is str and type(h['after'])is str and h['before']and h['after']and h['before']!=h['after'],'EXACT_NONEMPTY_REPORTS_HUNK_REQUIRED')
    x,y=h['after'].encode(),h['before'].encode();need(old.count(x)==1,'REPORTS_REVERSE_UNIQUE_HUNK_REQUIRED');old=old.replace(x,y,1)
   need(sha(old)==r['beforeSha256']and len(old)==r['beforeBytes']and self.patch(old,r)==new,'EXACT_RAW_REPORTS_BASE_RECONSTRUCTION_REQUIRED')
   self.records[n]=r;self.pins[str(self.payload/n)]=r['sha256'];self.m['records'].append({'group':'content','target':'palitra-orders-public/'+n,'sha256':r['sha256']})
  need(set(self.records)==set(BEFORE),'EXACT_TWO_REPORTS_NAMES_REQUIRED')
  activation=a.Activation(b,'photo-live-r1');self.receipt=activation.completed('uploads',UPLOADS_SHA);self.base=self.receipt['after']
  self.pins[str(activation.path('uploads','journal'))]=UPLOADS_SHA;self.pins[self.receipt['overlay']]=self.receipt['overlaySha256']
  need(self.base['containers']['content']['image']==CONTENT and len(self.base['containers']['content']['files'])==17 and self.base['worker']['image']==b.images['new']==WORKER and self.base['selected']['content']['PALITRA_WEB_UPLOADS_ENABLED']=='true','EXACT_LIVE_UPLOADS_BASE_REQUIRED')
  self.source=dict(self.photo.expected_hashes(True));self.static=dict(self.photo.inventory)
  for r,p in self.photo.statics:self.static[str(p)]=r['sha256']
  need(len(self.source)==202 and len(self.static)==12,'EXACT_SOURCE202_STATIC12_REQUIRED')
  self.cabinet=self.photo.ui.cabinet;need(self.cabinet==Path('/opt/synapse/sites/synapse/cabinet/palitra-orders')or self.root!=ROOT,'EXACT_EXISTING_CABINET_REQUIRED')
  for n,(pin,size)in BEFORE.items():need(self.source['palitra-orders-public/'+n]==self.static[str(self.cabinet/n)]==pin,'EXACT_LIVE_REPORTS_BEFORE_PINS_REQUIRED')
  self.final_source=dict(self.source);self.final_static=dict(self.static)
  for n,r in self.records.items():self.final_source['palitra-orders-public/'+n]=r['sha256'];self.final_static[str(self.cabinet/n)]=r['sha256']
 def patch(self,raw,r):
  need(len(raw)==r['beforeBytes']and sha(raw)==r['beforeSha256'],'REPORTS_ACTUAL_RAW_BASE_CHANGED')
  for h in r['hunks']:
   old,new=h['before'].encode(),h['after'].encode();need(raw.count(old)==1,'REPORTS_FORWARD_UNIQUE_HUNK_REQUIRED');raw=raw.replace(old,new,1)
  need(len(raw)==r['bytes']and sha(raw)==r['sha256'],'REPORTS_FINAL_BYTES_CHANGED');return raw
 def paths(self):return {k:self.root/(NAME+'-'+k+('.json'if k in ('decision','journal','overlay')else''))for k in ('decision','journal','overlay','context','backup')}
 def stable(self):
  self.b.stable()
  for path,pin in self.pins.items():need(sha(self.a.read(Path(path)))==pin,'REPORTS_PINNED_INPUT_CHANGED')
 def static_guard(self,changed):
  for path,pin in (self.final_static if changed else self.static).items():need(sha(self.a.read(Path(path)))==pin,'REPORTS_FULL_STATIC12_CHANGED')
 def snapshot(self,content=CONTENT,source=False,static=False):
  # Same checks as accepted NativeBackend.snapshot; only exact two-file maps and content image vary.
  self.stable();self.b.lease();first={s:self.b.metadata(s)for s in ('content','chat')};worker=self.b.worker_facts()
  selected={s:self.b.a.selected(s)for s in ('content','chat')};need(selected==self.base['selected'],'REPORTS_SELECTED_FLAGS_CHANGED')
  flags=self.a.decode(self.run(['docker','exec','synapse-content-1','node','-e',self.a.FLAGS_JS]));need(flags==self.base['l12'],'REPORTS_L12_CUTOFF_CHANGED')
  for service,row in first.items():
   text=self.run(self.b._resolve_command(row,service)).decode('ascii').strip();found=re.fullmatch(re.escape(service)+r'\s+([0-9a-f]{64})',text);need(found is not None and found.group(1)==row['configHash'],'REPORTS_RESOLVED_CONFIG_MISMATCH')
  need(first['content']['image']==content and worker==self.base['worker']and first['chat']==self.base['containers']['chat'],'REPORTS_CURRENT_WORKER_OR_IMAGE_CHANGED')
  self.b.graph(new=True);self.b.push_guard();expected=self.final_source if source else self.source;need(self.photo.hashes(expected)==expected,'REPORTS_FULL_SOURCE202_CHANGED');self.static_guard(static)
  cid=self.photo.cid();last={s:self.b.metadata(s)for s in ('content','chat')};need(first==last and worker==self.b.worker_facts()and selected=={s:self.b.a.selected(s)for s in ('content','chat')},'REPORTS_CONCURRENT_CHANGE')
  self.b.lease();self.stable();need(cid==self.photo.cid(),'REPORTS_CONTENT_CID_CHANGED_DURING_READ');return {'containers':last,'selected':selected,'worker':worker,'contentCid':cid,'l12':flags}
 def baseline(self,static=False):
  current=self.snapshot(static=static);need(current==self.base,'REPORTS_UPLOADS_RECEIPT_BASE_CHANGED');heartbeat=self.b.heartbeat(current['worker']['startedAt'],self.clock());need(heartbeat['freshAfterWorkerStart'],'REPORTS_FRESH_WORKER_HEARTBEAT_REQUIRED');return current
 def absent(self,decision=False):
  old=list(self.root.glob('reports-ui-r*-journal.json'));need(len(old)<=32,'BOUNDED_REPORTS_HISTORY_REQUIRED')
  for p in old:need(re.fullmatch('reports-ui-r[1-9][0-9]{0,3}-journal.json',p.name)is not None and self.a.decode(self.a.read(p)).get('phase')==PHASE,'REPORTS_UNKNOWN_HISTORY_NO_NEW_NAMESPACE')
  for kind,p in self.paths().items():
   if kind=='decision'and not decision:continue
   self.a.exact_path(p,True);need(not os.path.lexists(p)and not os.path.lexists(str(p)+'.pending'),'REPORTS_ATTEMPT_EXISTS_NO_REPLAY')
 def binding(self):return {'uploadsReceiptSha256':UPLOADS_SHA,'activationHelperSha256':ACTIVATION_SHA,'manifestSha256':self.manifest_pin,'helperSha256':self.helper_pin,'workerImage':WORKER,'contentImage':CONTENT}
 def decision(self,pin):
  d=self.a.pinned(self.paths()['decision'],pin,True);need(set(d)=={'schema','scope','name','rootApproved','observedAtUtc','inputs','before'}and d['schema']==1 and d['scope']=='TWO_REPORTS_UI_FILES_KEEP_LIVE_UPLOADS_WORKER_FLAGS'and d['name']==NAME and d['rootApproved']is True and d['inputs']==self.binding()and d['before']==self.base,'EXACT_REPORTS_ROOT_DECISION_REQUIRED');self.a.fresh(d['observedAtUtc'],self.clock());return d
 def approve(self,apply=False):
  need(apply is True,'EXPLICIT_ROOT_REPORTS_APPROVAL_REQUIRED');self.absent(True);at=self.clock();before=self.baseline();self.stable();self.b.lease();self.a.fresh(self.a.stamp(at),self.clock())
  d={'schema':1,'scope':'TWO_REPORTS_UI_FILES_KEEP_LIVE_UPLOADS_WORKER_FLAGS','name':NAME,'rootApproved':True,'observedAtUtc':self.a.stamp(at),'inputs':self.binding(),'before':before};self.a.write_new(self.paths()['decision'],d);return {'status':'REPORTS_UI_ROOT_DECISION_READY_NOT_APPLIED','decisionSha256':sha(self.a.read(self.paths()['decision'])),'runtimeWrites':0,'directDbWrites':0}
 def context(self,p,state,alias,built=False):return self.photo.ui.inc.Release.context_proof(self,p,state,alias,built)
 def update(self,j,s,phase,**values):s.update(phase=phase,**values);self.a.replace(j,s)
 def apply(self,pin,apply=False):
  need(apply is True,'EXPLICIT_ROOT_REPORTS_APPLY_REQUIRED');self.absent();d=self.decision(pin);before=self.baseline();p=self.paths();alias='palitra-reports-ui-base:'+NAME;tag='palitra-reports-ui:'+NAME
  self.photo.unused(alias);self.photo.unused(tag);need(self.run(['docker','image','inspect','--format','{{.Id}}',CONTENT]).decode().strip()==CONTENT,'EXACT_REPORTS_PARENT_IMAGE_REQUIRED');layers=self.a.decode(self.run(['docker','image','inspect','--format','{{json .RootFS.Layers}}',CONTENT]));need(type(layers)is list and layers,'REPORTS_PARENT_LAYERS_REQUIRED')
  self.decision(pin);self.b.lease();self.stable();self.baseline();self.decision(pin)
  s={'schema':1,'name':NAME,'phase':'REPORTS_CONTEXT_STARTED_UNKNOWN','inputs':self.binding(),'decisionSha256':pin,'before':before,'static':[],'automaticRetry':False,'automaticCodeRollback':False,'workerRecreated':False,'uploadsEnabled':True,'directDbWrites':0,'queueEdits':0}
  self.a.write_new(p['journal'],s);p['context'].mkdir(mode=0o700);p['backup'].mkdir(mode=0o700)
  for n,r in sorted(self.records.items()):
   encoded=self.run(['docker','exec','synapse-content-1','node','-e',self.photo.ui.inc.SOURCE_JS,'palitra-orders-public/'+n]);need(len(encoded)<=3*1024*1024,'BOUNDED_REPORTS_SOURCE_REQUIRED');raw=self.patch(base64.b64decode(encoded,validate=True),r);need(raw==self.a.read(self.payload/n),'REPORTS_SOURCE_NOT_REVIEWED_PAYLOAD');target=p['context']/'app/palitra-orders-public'/n;target.parent.mkdir(parents=True,exist_ok=True,mode=0o755);self.photo.u.write(target,raw,0o644)
  for i,(n,r)in enumerate(sorted(self.records.items())):
   target=self.cabinet/n;old=self.a.read(target);raw=self.patch(old,r);mode=stat.S_IMODE(target.stat().st_mode);backup=p['backup']/str(i);prepared=p['context']/'static'/str(i);prepared.parent.mkdir(exist_ok=True,mode=0o700);self.photo.u.write(backup,old);self.photo.u.write(prepared,raw);s['static'].append({'target':str(target),'baseSha256':r['beforeSha256'],'sha256':r['sha256'],'mode':mode,'backup':str(backup),'prepared':str(prepared),'written':False})
  self.photo.u.write(p['context']/'Dockerfile',('FROM '+alias+'\nCOPY app/ /app/\n').encode());s['contextSha256']=self.context(p['context'],s,alias);self.a.replace(p['journal'],s)
  self.baseline();self.decision(pin);self.photo.unused(alias);self.b.lease();self.run(['docker','image','tag',CONTENT,alias]);need(self.run(['docker','image','inspect','--format','{{.Id}}',alias]).decode().strip()==CONTENT,'REPORTS_PARENT_ALIAS_CHANGED');self.photo.unused(tag);self.update(p['journal'],s,'REPORTS_BUILD_STARTED_UNKNOWN')
  self.decision(pin);self.b.lease();self.stable();need(self.context(p['context'],s,alias)==s['contextSha256']and self.run(['docker','image','inspect','--format','{{.Id}}',alias]).decode().strip()==CONTENT,'REPORTS_LAST_BUILD_INPUT_CHANGED');self.baseline();self.decision(pin)
  iid=p['context']/'image.id';self.run(['docker','build','--network=none','--pull=false','--tag',tag,'--iidfile',str(iid),str(p['context'])]);child=self.a.read(iid).decode().strip();need(self.a.image(child)and child!=CONTENT,'REPORTS_EXACT_CHILD_REQUIRED');need(self.run(['docker','image','inspect','--format','{{.Id}}',tag]).decode().strip()==child and self.context(p['context'],s,alias,True)==s['contextSha256'],'REPORTS_BUILT_CHILD_OR_CONTEXT_CHANGED')
  childlayers=self.a.decode(self.run(['docker','image','inspect','--format','{{json .RootFS.Layers}}',child]));need(childlayers[:len(layers)]==layers and len(childlayers)==len(layers)+1,'REPORTS_EXACT_PARENT_SINGLE_COPY_REQUIRED');need(self.photo.hashes(self.final_source,child)==self.final_source,'REPORTS_CHILD_SOURCE202_CHANGED')
  self.baseline();self.decision(pin);self.stable();self.update(p['journal'],s,'REPORTS_STATIC_STARTED_UNKNOWN',childImage=child)
  for rec in s['static']:need(sha(self.a.read(Path(rec['backup'])))==rec['baseSha256']and sha(self.a.read(Path(rec['prepared'])))==rec['sha256'],'REPORTS_BACKUP_OR_PREPARED_CHANGED')
  self.decision(pin);self.b.lease()
  for rec in s['static']:
   self.decision(pin);raw=self.a.read(Path(rec['prepared']));need(sha(raw)==rec['sha256'],'REPORTS_LAST_PREPARED_STATIC_CHANGED');target=Path(rec['target']);need(sha(self.a.read(target))==rec['baseSha256']and stat.S_IMODE(target.stat().st_mode)==rec['mode'],'REPORTS_STATIC_CAS_CONFLICT');self.photo.atomic(target,raw,rec['mode']);rec['written']=True;self.a.replace(p['journal'],s)
  self.decision(pin);value={'services':{'content':{'image':child}}};self.a.write_new(p['overlay'],value);overlaypin=sha(self.a.read(p['overlay']));planned=self.b.plan(before,'content',p['overlay']);self.update(p['journal'],s,'REPORTS_CONTENT_UP_STARTED_UNKNOWN',overlay=str(p['overlay']),overlaySha256=overlaypin,plannedConfigHash=planned)
  self.baseline(True);self.decision(pin);self.stable();self.b.lease();need(self.context(p['context'],s,alias,True)==s['contextSha256']and self.a.decode(self.a.read(p['overlay']))==value and sha(self.a.read(p['overlay']))==overlaypin,'REPORTS_LAST_UP_INPUT_CHANGED')
  for rec in s['static']:need(sha(self.a.read(Path(rec['backup'])))==rec['baseSha256'],'REPORTS_LAST_BACKUP_CHANGED')
  self.decision(pin);self.b.up(before,'content',p['overlay']);after=self.snapshot(child,True,True);self.transition(before,after,p['overlay'],planned,child);heartbeat=self.b.heartbeat(after['worker']['startedAt'],self.clock());need(heartbeat['freshAfterWorkerStart'],'REPORTS_AFTER_FRESH_HEARTBEAT_REQUIRED');need(self.snapshot(child,True,True)==after,'REPORTS_LATE_CURRENT_STATE_CHANGED');self.stable();self.b.lease();self.update(p['journal'],s,PHASE,after=after,heartbeat=heartbeat,finishedAtUtc=self.a.stamp(self.clock()))
  return {'status':PHASE,'journalSha256':sha(self.a.read(p['journal'])),'contentImage':child,'sourceFiles':202,'staticFiles':12,'contentChainFiles':18,'workerRecreated':False,'uploadsEnabled':True,'directDbWrites':0,'queueEdits':0,'automaticRetry':False,'roleAcceptanceProven':False}
 def transition(self,before,after,overlay,planned,child):
  old=before['containers']['content'];expected=dict(old,image=child,files=old['files']+[str(overlay)],configFiles=','.join(old['files']+[str(overlay)]),filePins={**old['filePins'],str(overlay):sha(self.a.read(overlay))},configHash=planned)
  need(after['containers']['content']==expected and len(expected['files'])==18 and after['containers']['chat']==before['containers']['chat']and after['worker']==before['worker']and after['contentCid']!=before['contentCid']and after['selected']==before['selected']and after['l12']==before['l12'],'REPORTS_ONLY_TWO_UI_FILES_CONTENT_OVERLAY_ALLOWED')
 def inspect(self,pin):
  p=self.paths();s=self.a.pinned(p['journal'],pin,True);need(s.get('schema')==1 and s.get('name')==NAME and s.get('phase')==PHASE and s.get('inputs')==self.binding()and s.get('before')==self.base and s.get('workerRecreated')is False and s.get('uploadsEnabled')is True and s.get('automaticRetry')is False and s.get('directDbWrites')==s.get('queueEdits')==0,'EXACT_COMPLETED_REPORTS_RECEIPT_REQUIRED')
  need(s['overlay']==str(p['overlay'])and sha(self.a.read(p['overlay']))==s['overlaySha256']and self.a.decode(self.a.read(p['overlay']))=={'services':{'content':{'image':s['childImage']}}},'REPORTS_COMPLETED_OVERLAY_CHANGED');after=self.snapshot(s['childImage'],True,True);self.transition(self.base,after,p['overlay'],s['plannedConfigHash'],s['childImage']);need(after==s['after'],'REPORTS_COMPLETED_CURRENT_STATE_CHANGED')
  return {'status':'COMPLETED_REPORTS_READONLY_NOT_ROLE_ACCEPTANCE','heartbeat':self.b.heartbeat(after['worker']['startedAt'],self.clock()),'mutations':0,'workerRecreated':False,'uploadsEnabled':True,'roleAcceptanceProven':False}

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('operation',choices=('approve-current','apply','inspect'))
 for n in ('activation-helper','bundle','photo-code','ui-code','l12-code','graph','build-journal','runtime-proof','payload'):p.add_argument('--'+n,type=Path,required=True)
 for n in ('build-sha','runtime-sha','manifest-sha'):p.add_argument('--'+n,required=True)
 p.add_argument('--decision-sha');p.add_argument('--receipt-sha');p.add_argument('--apply',action='store_true');args=p.parse_args()
 try:
  need(os.name=='posix'and os.geteuid()==0,'NATIVE_ROOT_REPORTS_REQUIRED')
  import types
  path=args.activation_helper;raw=path.read_bytes();need(path.is_absolute()and path.is_relative_to(ROOT)and sha(raw)==ACTIVATION_SHA,'FROZEN_ACTIVATION5069_REQUIRED');a=types.ModuleType('reports_accepted5069');a.__file__=str(path);exec(compile(raw,str(path),'exec'),a.__dict__);a.exact_path(path)
  for path in (args.bundle,args.photo_code,args.ui_code,args.l12_code,args.payload):need(a.exact_path(path).is_dir()and path.is_relative_to(ROOT),'ROOT_REPORTS_INPUT_DIRECTORY_REQUIRED')
  need(args.graph.parent==ROOT,'ROOT_REPORTS_GRAPH_PATH_REQUIRED');photo_module=a.load_module(args.photo_code/'photo_ui_release_native.py',a.PHOTO_HELPER_SHA,'reports_photo');graph=a.load_module(args.graph,a.GRAPH_SHA,'reports_graph');x,l=photo_module.loaded(args.bundle,args.ui_code,args.l12_code);photo=photo_module.PhotoRelease(x,l,args.photo_code);b=a.NativeBackend(photo,graph,args.build_journal,args.build_sha,args.runtime_proof,args.runtime_sha);release=ReportsRelease(a,b,args.payload,args.manifest_sha)
  out=release.approve(args.apply)if args.operation=='approve-current'else release.apply(args.decision_sha,args.apply)if args.operation=='apply'else release.inspect(args.receipt_sha);print(json.dumps(out,separators=(',',':')));return 0
 except Exception as e:
  message=str(e);code=message if type(e)is ValueError and re.fullmatch('[A-Z][A-Z0-9_]{0,100}',message)else'REPORTS_ACTION_REFUSED';print(json.dumps({'status':'REPORTS_REFUSED_OR_UNKNOWN_INSPECT_PRIVATE_JOURNAL','code':code,'messageSha256':sha(message.encode()),'automaticRetry':False,'automaticCodeRollback':False,'workerRecreated':False,'directDbWrites':0,'queueEdits':0},separators=(',',':')));return 2
if __name__=='__main__':sys.exit(main())
