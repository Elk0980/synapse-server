"""Phase 1 only: fresh-lease read-only inventory of eight approved Palitra orders.
Private target snapshot only; no deletion, factories, DDL, DB backup, worker stop or queue edits.
"""
import argparse,hashlib,json,os,re,stat,subprocess,sys,types
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path('/opt/synapse/releases/palitra-app-20261015')
REPORTS_HELPER_SHA='08c49246784a37b260de11c94c2736399975c3478d7c49a5c2bedf380f06226d'
REPORTS_RECEIPT_SHA='1af498408cba20f63f9be1c49421511e508ee25f874dee810e974a97e2b69113'
ACTIVATION_SHA='5069df0759312e2410bcfb05e94db00583af1cb6d87ab3c8dde62c161e22b8ec'
SCRIPT_SHA='d703f87eac0e39e493a24a8c46a461486ef7ffd0673a540fda5ee0793ec4982e'
IDS=[1,2,3,4,5,6,9,10]
LOCK='/opt/synapse/.palitra-app-release.lock'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def need(ok,code):
 if not ok:raise ValueError(code)
def run(args,timeout=30,limit=32*1024*1024):
 result=subprocess.run(args,capture_output=True,stdin=subprocess.DEVNULL,shell=False,timeout=timeout)
 if result.returncode!=0 and len(result.stdout)<=4096:
  try:failure=json.loads(result.stdout)
  except (ValueError,UnicodeError):failure={}
  if failure.get('status')=='READONLY_COLLECTION_REFUSED'and re.fullmatch('[A-Z][A-Z0-9_]{0,100}',str(failure.get('code',''))):raise ValueError(failure['code'])
 need(result.returncode==0 and len(result.stdout)<=limit and len(result.stderr)<=1048576,'READONLY_NATIVE_COMMAND_REFUSED');return result.stdout
def lease(pid):
 need(type(pid)is int and pid>1,'FRESH_ROOT_LEASE_PID_REQUIRED');rows=run(['lslocks','--noheadings','--output','PID,PATH'],limit=1048576).decode().splitlines();matches=[line.strip().split(maxsplit=1)for line in rows if len(line.strip().split(maxsplit=1))==2 and line.strip().split(maxsplit=1)[1]==LOCK];need(matches==[[str(pid),LOCK]],'FRESH_EXCLUSIVE_ROOT_LEASE_REQUIRED')
def load(path,pin,name):
 raw=path.read_bytes();need(sha(raw)==pin,'EXACT_FROZEN_HELPER_REQUIRED');m=types.ModuleType(name);m.__file__=str(path);exec(compile(raw,str(path),'exec'),m.__dict__);return m
def dependencies(args):
 report=load(args.reports_helper,REPORTS_HELPER_SHA,'history_reports');a=load(args.activation_helper,ACTIVATION_SHA,'history_activation')
 for p in (args.reports_helper,args.activation_helper,args.collector_js):a.exact_path(p);need(p.is_relative_to(ROOT),'ROOT_CODE_FILE_REQUIRED')
 for p in (args.bundle,args.photo_code,args.ui_code,args.l12_code,args.payload):need(a.exact_path(p).is_dir()and p.is_relative_to(ROOT),'ROOT_CODE_DIRECTORY_REQUIRED')
 need(args.graph.parent==ROOT,'ROOT_GRAPH_FILE_REQUIRED');photo_module=a.load_module(args.photo_code/'photo_ui_release_native.py',a.PHOTO_HELPER_SHA,'history_photo');graph=a.load_module(args.graph,a.GRAPH_SHA,'history_graph');x,l=photo_module.loaded(args.bundle,args.ui_code,args.l12_code);photo=photo_module.PhotoRelease(x,l,args.photo_code);b=a.NativeBackend(photo,graph,args.build_journal,args.build_sha,args.runtime_proof,args.runtime_sha);reports=report.ReportsRelease(a,b,args.payload,args.manifest_sha)
 receipt=a.pinned(ROOT/'reports-ui-r1-journal.json',REPORTS_RECEIPT_SHA,True);need(receipt.get('phase')==report.PHASE and receipt.get('inputs')==reports.binding()and receipt.get('workerRecreated')is False and receipt.get('uploadsEnabled')is True,'EXACT_COMPLETED_REPORTS_RECEIPT_REQUIRED');overlay=Path(receipt['overlay']);need(overlay==ROOT/'reports-ui-r1-overlay.json'and sha(a.read(overlay))==receipt['overlaySha256']and a.decode(a.read(overlay))=={'services':{'content':{'image':receipt['childImage']}}},'EXACT_COMPLETED_REPORTS_OVERLAY_REQUIRED')
 return a,reports,receipt
def runtime(a,reports,receipt,pid):
 b=reports.b;reports.stable();lease(pid);before={s:b.metadata(s)for s in ('content','chat')};worker=b.worker_facts();selected={s:b.a.selected(s)for s in ('content','chat')};flags=a.decode(b.run(['docker','exec','synapse-content-1','node','-e',a.FLAGS_JS]));cid=reports.photo.cid();current={'containers':before,'selected':selected,'worker':worker,'contentCid':cid,'l12':flags}
 need(current==receipt['after']and len(before['content']['files'])==18,'EXACT_CURRENT_REPORTS_CHAIN18_REQUIRED')
 for s,row in before.items():
  text=b.run(b._resolve_command(row,s)).decode('ascii').strip();need(text==s+' '+row['configHash'],'CURRENT_RESOLVED_CONFIG_HASH_CHANGED')
 b.graph(new=True);b.push_guard();need(len(reports.final_source)==202 and len(reports.final_static)==16,'EXACT_SOURCE202_STATIC16_REQUIRED');need(reports.photo.hashes(reports.final_source)==reports.final_source,'CURRENT_SOURCE202_CHANGED');reports.static_guard(True)
 need(before=={s:b.metadata(s)for s in ('content','chat')}and worker==b.worker_facts()and selected=={s:b.a.selected(s)for s in ('content','chat')}and cid==reports.photo.cid(),'CURRENT_RUNTIME_CHANGED_DURING_OBSERVATION');lease(pid);reports.stable()
 return {'current':current,'sourceInventorySha256':sha(a.encoded(reports.final_source)),'staticInventorySha256':sha(a.encoded(reports.final_static)),'serverSha256':reports.final_source['server.js'],'sourceFiles':202,'staticFiles':16,'reportsReceiptSha256':REPORTS_RECEIPT_SHA,'freshLeasePid':pid}
def private_output(path,raw):
 need(path.parent==ROOT and re.fullmatch('history-reset-r[1-9][0-9]{0,3}-snapshot.json',path.name),'EXACT_PRIVATE_SNAPSHOT_PATH_REQUIRED')
 need(not os.path.lexists(path)and not os.path.lexists(str(path)+'.pending'),'SNAPSHOT_EXISTS_NO_REPLACEMENT');fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|getattr(os,'O_NOFOLLOW',0),0o600)
 with os.fdopen(fd,'wb')as f:f.write(raw);f.flush();os.fsync(f.fileno())
 st=path.stat();need(stat.S_ISREG(st.st_mode)and stat.S_IMODE(st.st_mode)==0o600 and st.st_uid==0 and path.read_bytes()==raw,'ROOT_PRIVATE_SNAPSHOT_READBACK_REQUIRED')
def main():
 p=argparse.ArgumentParser(description=__doc__)
 for n in ('reports-helper','activation-helper','bundle','photo-code','ui-code','l12-code','graph','build-journal','runtime-proof','payload','collector-js','output'):p.add_argument('--'+n,type=Path,required=True)
 for n in ('build-sha','runtime-sha','manifest-sha'):p.add_argument('--'+n,required=True)
 p.add_argument('--lease-pid',type=int,required=True);p.add_argument('--collect-readonly',action='store_true');args=p.parse_args()
 try:
  need(args.collect_readonly and os.name=='posix'and os.geteuid()==0,'EXPLICIT_NATIVE_ROOT_READONLY_COLLECTION_REQUIRED');need(args.output.parent==ROOT and not os.path.lexists(args.output),'NEW_PRIVATE_OUTPUT_REQUIRED');lease(args.lease_pid);a,reports,receipt=dependencies(args);a.exact_path(args.output,True);code=a.read(args.collector_js);need(sha(code)==SCRIPT_SHA,'EXACT_READONLY_JS_REQUIRED');before=runtime(a,reports,receipt,args.lease_pid)
  prefix=['docker','exec','--env','PALITRA_HISTORY_READONLY_NATIVE=1'];content=a.decode(run(prefix+['synapse-content-1','node','-e',code.decode(),'content'],timeout=60));need(content.get('status')=='READONLY_CONTENT_HISTORY_SNAPSHOT_NOT_DELETE_APPROVAL'and content.get('fixedOrderIds')==IDS,'READONLY_CONTENT_COLLECTION_REFUSED');lease(args.lease_pid)
  refs=content['projection']['jobs']['siteOrder']+content['projection']['jobs']['clientBot'];worker=a.decode(run(prefix+['synapse-chat-1','/usr/local/bin/node','-e',code.decode(),'worker',json.dumps(refs,separators=(',',':'))],timeout=30));need(worker.get('status')=='READONLY_WORKER_TARGET_JOB_PROJECTION','READONLY_WORKER_COLLECTION_REFUSED');after=runtime(a,reports,receipt,args.lease_pid);need(after==before,'RUNTIME_CHANGED_AROUND_READONLY_COLLECTION')
  value={'schema':1,'status':'HISTORY_PHASE1_READONLY_SNAPSHOT_NOT_PURGE_APPROVAL','observedAtUtc':datetime.now(timezone.utc).isoformat(),'fixedOrderIds':IDS,'runtimeBefore':before,'runtimeAfter':after,'content':content,'worker':worker,'crossDatabaseAtomic':False,'requiresFreshPreDeleteRecheck':True,'purgeApprovedBySnapshot':False,'collectorSha256':sha(Path(__file__).read_bytes()),'scriptSha256':SCRIPT_SHA,'mutations':0,'dbBackup':False,'fileDeletion':False,'workerStopped':False};raw=a.encoded(value);need(len(raw)<=32*1024*1024,'BOUNDED_PRIVATE_SNAPSHOT_REQUIRED');lease(args.lease_pid);private_output(args.output,raw)
  print(json.dumps({'status':value['status'],'snapshotSha256':sha(raw),'snapshotFile':args.output.name,'orderIds':IDS,'counts':content['counts'],'blockers':sorted(set(content['blockers']+worker['blockers'])),'sourceFiles':202,'staticFiles':16,'mutations':0,'purgeApprovedBySnapshot':False,'crossDatabaseAtomic':False},separators=(',',':')));return 0
 except Exception as e:
  message=str(e);code=message if type(e)is ValueError and re.fullmatch('[A-Z][A-Z0-9_]{0,100}',message)else'READONLY_COLLECTION_REFUSED';print(json.dumps({'status':'READONLY_COLLECTION_REFUSED_NO_DELETE','code':code,'messageSha256':sha(message.encode()),'mutations':0,'automaticRetry':False},separators=(',',':')));return 2
if __name__=='__main__':sys.exit(main())
