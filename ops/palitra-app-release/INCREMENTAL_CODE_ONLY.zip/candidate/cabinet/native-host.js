/* Palitra Love Заказы — хост рабочего подключения к существующему Synapse.

   Открывается только на разрешённых адресах: кабинет https://synapse.synapsebusiness.ru (whoami cookie + CSRF)
   и магазин https://palitra-love.ru (сессия аккаунта /api/draft-account/session, portal через штатный crm-session.js,
   чат сайта /api/customer-chat/*). Новой авторизации нет: только существующие относительные маршруты моста.

   Сеть, CRM и чат включены после проверки Root. Изменение флагов требует отдельного проверенного выпуска
   (свободное окно общего сервера, origin/CSP, PALITRA_APP_ORIGIN). Адрес, роль, localStorage и данные макета флаги
   не меняют. Проверки разрешённого адреса, сессии и CSRF выполняются перед каждым запросом.
   CSRF/токены живут только в замыкании этого файла и в штатном crm-session.js; в state оболочки, URL и манифест не идут. */
'use strict';
(() => {
  const B = window.SynapseBridge;
  const FLAGS = Object.freeze({ network: true, crm: true, e1Native: true });
  const CABINET = B.ORIGINS.synapse, SHOP = B.ORIGINS.shop;
  const origin = window.location.origin;
  /* Точка входа задаётся страницей: shop.html (data-entry="shop", data-auth="site", штатный crm-session.js до этого файла)
     или cabinet.html (data-entry="cabinet", без инициализации магазина). Страница работает только на «своём» адресе. */
  const root = document.documentElement;
  const entry = root.dataset.entry === 'shop' || root.dataset.entry === 'cabinet' ? root.dataset.entry : '';
  const allowed = (entry === 'cabinet' && origin === CABINET) || (entry === 'shop' && origin === SHOP && root.dataset.auth === 'site');
  let cabinetCsrf = '', accountCsrf = '', chatCsrf = '';
  const listeners = [];
  let host;
  if (!allowed) {
    // Чужой адрес (в том числе localhost/127.0.0.1) или страница другого входа: транспорта нет — «Подключение не настроено».
    host = { mode: 'blocked', reason: entry ? 'origin' : 'entry' };
  } else {
    // Штатный crm-session.js — только на входе магазина и только в режиме сайта (cookie аккаунта + CSRF, не Telegram).
    const session = entry === 'shop' && window.PalitraSession && window.PalitraSession.auth === 'site' && typeof window.PalitraSession.request === 'function' ? window.PalitraSession : null;
    const transport = B.createNativeTransport({
      // fetch внедряется только здесь, на разрешённом адресе; мост сам глобальный fetch не трогает.
      fetch: (url, init) => window.fetch(url, init),
      host: {
        origin, portalOrigin: SHOP, allowNetwork: FLAGS.network, e1Native: FLAGS.e1Native,
        cabinet: { get csrfToken() { return cabinetCsrf; } },
        account: { get csrf() { return accountCsrf; } },
        chat: { get csrf() { return chatCsrf; } },
        portal: FLAGS.crm && session ? { request: (path, options) => session.request(path, options) } : null,
      },
    });
    host = {
      mode: 'native', verified: true, origin, transport, e1Native: FLAGS.e1Native,
      // Автоперечитывание открытого чата (5 с) — только при включённых сети и чате сайта E/R1.
      chatAutoRefresh: FLAGS.network === true && FLAGS.e1Native === true,
      // Только наличие сессий своего адреса; роли и identity оболочка берёт из ответов whoami/bootstrap.
      getAuthContext: () => (entry === 'cabinet' ? { cabinetSession: true } : { shopSession: true, guest: true, portalAvailable: FLAGS.crm && Boolean(session) }),
      acceptCabinetCsrf: (value) => { cabinetCsrf = typeof value === 'string' ? value : ''; window.dispatchEvent(new Event('palitra:push-auth-ready')); },
      acceptAccountCsrf: (value) => { accountCsrf = typeof value === 'string' ? value : ''; },
      acceptChatSession: (value) => { chatCsrf = typeof value === 'string' ? value : ''; window.dispatchEvent(new Event('palitra:push-auth-ready')); },
      // Только кабинет, разрешённый origin, network flag и CSRF текущего whoami. Роли проверяет backend.
      workflow: Object.freeze({ request: async (path, options = {}) => {
        const method = options.method || 'GET';
        const base = path === '/content/palitra/workflow';
        const order = /^\/content\/palitra\/workflow\/orders\/[1-9]\d*(?:\/(confirm|advance))?$/.exec(path);
        const allowedMethod = base ? ['GET', 'PUT'].includes(method) : order ? (order[1] ? method === 'POST' : method === 'GET') : false;
        if (entry !== 'cabinet' || origin !== CABINET || FLAGS.network !== true || !cabinetCsrf || !allowedMethod) throw Object.assign(new Error('Этапы заказа не подключены для этого входа.'), { status: 403 });
        const response = await window.fetch(path, { method, credentials: 'same-origin', cache: 'no-store', redirect: 'error',
          headers: { Accept: 'application/json', ...(method !== 'GET' ? { 'Content-Type': 'application/json', 'X-CSRF-Token': cabinetCsrf } : {}) },
          ...(method !== 'GET' ? { body: JSON.stringify(options.body) } : {}) });
        const data = await response.json();
        if (!response.ok) throw Object.assign(new Error(data && data.error && typeof data.error === 'string' ? data.error : 'Не удалось выполнить действие с заказом.'), { status: response.status });
        return data;
      } }),
      push: Object.freeze({ request: async (operation, options = {}) => {
        const method = options.method || 'GET';
        const permitted = operation === 'capability' ? method === 'GET' : operation === 'subscription' ? ['GET', 'POST', 'DELETE'].includes(method) : operation === 'subscription/status' && method === 'POST';
        const csrf = entry === 'cabinet' ? cabinetCsrf : chatCsrf;
        if (!permitted || !FLAGS.network || !csrf || (entry === 'shop' && !FLAGS.e1Native)) throw Object.assign(new Error('Уведомления пока не подключены для этого входа.'), { status: 403 });
        const path = (entry === 'cabinet' ? '/content/palitra/push/' : '/api/customer-chat/push/') + operation;
        const response = await window.fetch(path, { method, credentials: 'same-origin', cache: 'no-store', redirect: 'error',
          headers: { Accept: 'application/json', ...(method !== 'GET' ? { 'Content-Type': 'application/json', [entry === 'cabinet' ? 'X-CSRF-Token' : 'X-Palitra-Chat-CSRF']: csrf } : {}) },
          ...(method !== 'GET' ? { body: JSON.stringify(options.body) } : {}) });
        const data = await response.json();
        if (!response.ok) throw Object.assign(new Error(typeof data.error === 'string' ? data.error : 'Не удалось изменить подписку на уведомления.'), { status: response.status });
        return data;
      } }),
      onAuthChange: (fn) => { if (typeof fn === 'function') listeners.push(fn); },
    };
    // Штатное событие завершения portal-сессии (crm-session.js) — смена identity: прежние данные и CSRF очищаются.
    window.addEventListener('palitra:session-ended', () => { cabinetCsrf = ''; accountCsrf = ''; chatCsrf = ''; for (const fn of listeners) fn(); });
  }
  Object.defineProperty(window, 'PalitraShellHost', { value: Object.freeze(host), writable: false, configurable: false });
})();
