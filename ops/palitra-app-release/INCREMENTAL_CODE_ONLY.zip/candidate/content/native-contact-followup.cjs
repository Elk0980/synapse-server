'use strict';
const DEADLINE_MS = 300000;
const ALERT = 'Клиент не написал в чат. Свяжитесь удобным для него способом';
const idOf = (value) => {
  if (typeof value === 'string' && !/^[1-9]\d*$/.test(value)) return null;
  const id = typeof value === 'number' || typeof value === 'string' ? Number(value) : NaN;
  return Number.isSafeInteger(id) && id > 0 ? id : null;
};
function createFollowupReader({ db, siteOrders, ownerStillValid, enabled = false, now = Date.now }) {
  // Только вызывается из уже защищённого owner GET. Повторная проверка здесь; отсутствие функции закрывает доступ.
  return function read(site, orderId, owner) {
    if (site !== 'palitra' || enabled !== true || typeof ownerStillValid !== 'function' ||
        !owner || !idOf(owner.id) || !Number.isSafeInteger(owner.sessionVersion) ||
        ownerStillValid(owner.id, owner.sessionVersion) !== true) return null;
    const id = idOf(orderId);
    if (!id) return null;
    const order = siteOrders.orderSummary(site, id);
    if (!order || order.id !== id || ['done', 'cancelled'].includes(order.work?.status)) return null;
    // createdAt именно заявки, не последнего ответа/обновления чата. Не принимать дату без зоны.
    if (typeof order.createdAt !== 'string' || !/(Z|[+-]\d{2}:\d{2})$/.test(order.createdAt)) return null;
    const created = Date.parse(order.createdAt), current = now();
    if (!Number.isFinite(created) || !Number.isSafeInteger(current)) return null;
    const rows = db.prepare('SELECT id FROM chat_threads WHERE site=? AND company_code=? AND order_id=? LIMIT 2')
      .all('palitra', 'palitra-love', id);
    if (rows.length !== 1 || !idOf(rows[0].id)) return null; // старые заявки без чата или неоднозначность — без выдуманного предупреждения
    const threadId = rows[0].id;
    const first = db.prepare("SELECT id FROM chat_thread_messages WHERE thread_id=? AND direction='in' AND author_kind='customer' LIMIT 1").get(threadId);
    const dueAt = created + DEADLINE_MS;
    if (ownerStillValid(owner.id, owner.sessionVersion) !== true) return null;
    return { orderRef: `native-order:${id}`, threadRef: `thread:${threadId}`, dueAt: new Date(dueAt).toISOString(),
      state: first ? 'answered' : current >= dueAt ? 'due' : 'waiting', alert: !first && current >= dueAt ? ALERT : '' };
  };
}
module.exports = { createFollowupReader, DEADLINE_MS, ALERT };
