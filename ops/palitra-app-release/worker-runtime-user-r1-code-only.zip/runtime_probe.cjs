/* Read-only runtime projection. No app imports, environment, DB, child process or network. */
'use strict';
const fs=require('node:fs'),p=require('node:path').posix,c=require('node:crypto'),tls=require('node:tls');
const NODE='/usr/local/bin/node',ENTRY='/usr/local/bin/docker-entrypoint.sh';
const CA=new Set(['/etc/ssl/certs/ca-certificates.crt','/etc/ssl/cert.pem']);
const ROOTS=new Set(['/lib','/usr/lib','/usr/local/lib','/lib/x86_64-linux-gnu','/usr/lib/x86_64-linux-gnu']);
const LIB=/^(?:ld-musl-x86_64\.so\.1|ld-linux-x86-64\.so\.2|libc\.musl-x86_64\.so\.1|lib(?:c|m|dl|pthread|rt|gcc_s|stdc\+\+|atomic|z|crypto|ssl)\.so\.[0-9]+(?:\.[0-9]+)*)$/;
let total=0;
function need(ok,code){if(!ok)throw Error(code);}
function kind(path){if(path===NODE)return'node';if(path===ENTRY)return'entrypoint';if(CA.has(path))return'ca';if(ROOTS.has(p.dirname(path))&&LIB.test(p.basename(path)))return'library';return null;}
function resolveKnown(path){
 const k=kind(path);need(k&&p.normalize(path)===path,'UNKNOWN_RUNTIME_PATH');let current=path,links=0;
 for(;;){let changed=false;const parts=current.split('/').filter(Boolean);let q='';
  for(let i=0;i<parts.length;i++){q+='/'+parts[i];const s=fs.lstatSync(q);if(!s.isSymbolicLink())continue;
   need(++links<=8,'SYMLINK_LIMIT');const t=p.resolve(p.dirname(q),fs.readlinkSync(q));need(ROOTS.has(t)||kind(t)===k,'SYMLINK_TARGET_REFUSED');current=p.resolve(t,...parts.slice(i+1));need(kind(current)===k,'REALPATH_SCOPE_REFUSED');changed=true;break;
  }
  if(!changed)break;
 }
 need(fs.realpathSync(path)===current,'REALPATH_RACE');return current;
}
function file(path,limit){
 let fd=null;try{
  const real=resolveKnown(path),s=fs.lstatSync(real);need(s.isFile()&&!s.isSymbolicLink()&&s.size<=limit&&total+s.size<=512*1024*1024,'RUNTIME_FILE_BOUND');
  fd=fs.openSync(real,fs.constants.O_RDONLY|fs.constants.O_NOFOLLOW);const first=fs.fstatSync(fd);need(first.dev===s.dev&&first.ino===s.ino&&first.size===s.size,'RUNTIME_RACE');
  const b=Buffer.alloc(65536),h=c.createHash('sha256');let n,size=0;
  while((n=fs.readSync(fd,b,0,Math.min(b.length,limit+1-size),null))>0){size+=n;need(size<=limit,'RUNTIME_FILE_LIMIT');h.update(b.subarray(0,n));}
  const end=fs.fstatSync(fd),last=fs.lstatSync(real);need(size===s.size&&end.dev===s.dev&&end.ino===s.ino&&end.size===s.size&&end.mtimeMs===s.mtimeMs&&end.ctimeMs===s.ctimeMs&&last.dev===s.dev&&last.ino===s.ino&&last.size===s.size&&last.mtimeMs===s.mtimeMs&&last.ctimeMs===s.ctimeMs&&!last.isSymbolicLink()&&resolveKnown(path)===real,'RUNTIME_RACE');total+=size;
  return{available:true,realPath:real,size,mode:s.mode&4095,sha256:h.digest('hex')};
 }catch(e){return{available:false,code:/^[A-Z_]{1,50}$/.test(e.message)?e.message:'READ_REFUSED'};}finally{if(fd!==null)fs.closeSync(fd);}
}
function mapped(){
 const fd=fs.openSync('/proc/self/maps',fs.constants.O_RDONLY|fs.constants.O_NOFOLLOW);let raw;try{const b=Buffer.alloc(131073);let size=0,n;while((n=fs.readSync(fd,b,size,b.length-size,null))>0){size+=n;need(size<=131072,'MAPS_LIMIT');}raw=b.subarray(0,size).toString('utf8');}finally{fs.closeSync(fd);}
 const libs=new Set();let unknown=0;for(const line of raw.split('\n')){
  const m=/^[0-9a-f]+-[0-9a-f]+\s+\S+\s+[0-9a-f]+\s+\S+\s+\d+\s+(.+)$/.exec(line);if(!m||!m[1].startsWith('/'))continue;
  const name=m[1];if(name===NODE)continue;if(kind(name)==='library')libs.add(name);else unknown++;
 }
 need(libs.size>0&&libs.size<=24,'MAPPED_LIBRARY_BOUND');return{libraries:[...libs].sort(),unrecognizedFileMappings:unknown};
}
function main(){
 need(process.platform==='linux'&&process.arch==='x64'&&process.execPath===NODE,'EXACT_LINUX_X64_NODE_REQUIRED');
 const maps=mapped(),files={};files[NODE]=file(NODE,256*1024*1024);files[ENTRY]=file(ENTRY,65536);
 for(const n of maps.libraries)files[n]=file(n,128*1024*1024);for(const n of [...CA].sort())files[n]=file(n,4*1024*1024);
 const roots=tls.rootCertificates;need(Array.isArray(roots)&&roots.length<=1024,'BUILTIN_CA_BOUND');const bundledCaSha256=c.createHash('sha256').update(JSON.stringify(roots)).digest('hex');
 console.log(JSON.stringify({schema:1,node:process.version,platform:process.platform,arch:process.arch,execPath:NODE,versions:{node:process.versions.node,openssl:process.versions.openssl,modules:process.versions.modules,uv:process.versions.uv},api:{fetch:typeof fetch==='function',FormData:typeof FormData==='function',Blob:typeof Blob==='function',abortTimeout:typeof AbortSignal.timeout==='function'},unrecognizedFileMappings:maps.unrecognizedFileMappings,files,bundledCaCount:roots.length,bundledCaSha256,totalHashedBytes:total,completeRuntimeEquivalence:false}));
}
main();
