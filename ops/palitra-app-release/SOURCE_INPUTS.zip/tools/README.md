# Проверяемый перенос исходников: E + Forms + Palitra Love Заказы

Этот набор готовит исходники и операции установки. Здесь не выполнялись Docker, сеть, запись в DB, сервер или действующие модели. Активация нового приложения — отдельный шаг Root после проверки конфигурации. Флаги `network`, `crm`, `e1Native` остаются `false`.

## Что сохраняется

- Текущие Main HTTP и feature не копируются поверх сервера. Host меняется только принятым E-кандидатом при точном совпадении старой базы с актуальным Main.
- Уже установленные 17 CRM-модулей сохраняются. Единственное допустимое изменение — точечная проекция `siteOrderId` в существующем workspace. Частичная установка CRM запрещает сборку; полностью отсутствующие 17 модулей требуют дополнительного независимо подтверждённого источника.
- `site-orders`, `draft-account-service`, DB, заказы, сообщения, каталог, роли и настройки не изменяются этими инструментами.
- Приватные `project.json`, история редактора и рабочие журналы не входят в публичную статику. Перенос свежей приватной модели выполняет Root отдельно.

## Нужные входы

1. Полный свежий каталог `native_capture.py`: точные 40 записей, два чтения, настоящий `managed_root`, без `managed_pending`.
2. Отдельный JSON, подписанный решением Root: `rootApproved: true`, SHA снимка, SHA трёх frozen manifest, точные образы, подтверждённые origins, actual managed root, действующий lease PID/path и новый releaseId. `APPROVAL_TEMPLATE.json` намеренно имеет `false` и не разрешает сборку.
3. Worker повторно прочитан Root и подтверждён: `sha256:c5dd4502daf630afaac7415da5b19dc456c81a5f81626574f5480dec04307cca`. Ранее отсутствовал один `0` в ручной записи; образ не менялся, защитная проверка не ослаблялась.

## Постоянная ссылка и перенос исходников на сервер

Публичные 26 файлов `/love-app/*` входят в child content image под `/app/palitra-orders-public`. Принятый additive host candidate имеет SHA `21a580435921e399d1c27465b3856a05838ec70478f0f557c2068bc56dd7c493`; предыдущий accepted E host проверяется по `cdbf01c92288e265182422681aa6187adc15fd38392a7d4c6a75992576223d6b`. После обычной смены версии сайта эта статика остаётся в образе. Запись `love-app` под managedRoot запрещена. В managedRoot обновляется только прежний guarded `assets/order.js`; DB manifest не меняется.

`package_inputs.py pack` создаёт переносимый SOURCE_INPUTS.zip по аргументам `--e-root`, `--e-base-root`, `--forms-root`, `--app-root`, `--persistent-root`, `--output`. ZIP содержит только принятые исходники, известные manifest и инструменты; actual capture, Root approval, модель, историю, QA scripts, mock и preview в него не входят. Native capture остаётся на сервере.

Root передаёт проверенный ZIP и два его SHA. Безопасная распаковка:

```text
python3 package_inputs.py extract --archive <SOURCE_INPUTS.zip> --output <new-private-input-directory> --expected-archive-sha <verified-sha> --expected-manifest-sha <verified-source-manifest-sha>
```

Из распакованной папки сборщик работает с относительными `inputs/*`, а actual native capture и новый approval передаются отдельными абсолютными путями:

```text
python3 tools/build_release.py --e-root inputs/e --e-base-root inputs/e-base --forms-root inputs/forms --app-root inputs/app/web --persistent-root inputs/persistent --capture-root <fresh-native-full-capture> --approval-path <new-private-Root-approval> --output <new-private-bundle> --check
```

После успешной проверки та же команда без `--check` создаёт настоящий bundle на сервере. Source template имеет `rootApproved:false`; он не заменяет actual approval. Root дополнительно проверяет, что текущий Main `/love-app/*` достигает существующего content handler через Caddy. Никакого нового proxy/service этот набор не создаёт.

## Локальная сборка (без сервера)

`build_release.py --help` перечисляет обязательные аргументы. Передайте существующие каталоги принятых E, E BASE, frozen Forms, latest app web, свежего capture и независимый approval. `--output` должен указывать новый каталог с существующим родителем.

```text
python -B build_release.py --e-root <accepted-E> --e-base-root <E-WORK-BASE> --forms-root <frozen-Forms-WORK> --app-root <latest-web> --persistent-root <accepted-persistent-candidate> --capture-root <actual-full-capture> --approval-path <Root-approved-json> --output <new-bundle> --check
```

Повторите ту же команду без `--check` только после успешной проверки. Результат: новый каталог, новый ZIP, точные `manifestSha256` и `archiveSha256`. Старые каталоги/ZIP не перезаписываются. Если CRM17 действительно отсутствуют, нужен `--crm-root` и дополнительный `sourcePins.crm`; никакие старые P Main/server/host не копируются.

## Подготовленные команды на сервере (выполняет только Root)

Сначала Root передаёт проверенный ZIP и SHA штатным разрешённым способом. Смена managed root, образа, lease, живого файла или отсутствие обещанного файла приводят к отказу.

```text
python3 native_release.py extract --archive <new-zip> --output <new-private-directory> --expected-archive-sha <verified-archive-sha> --expected-manifest-sha <verified-manifest-sha>
python3 <bundle>/native_release.py preflight --bundle <bundle> --expected-manifest-sha <verified-manifest-sha>
python3 <bundle>/native_release.py build --bundle <bundle> --expected-manifest-sha <verified-manifest-sha> --journal <new-private-build-journal> --apply
python3 <bundle>/native_release.py static-apply --bundle <bundle> --expected-manifest-sha <verified-manifest-sha> --journal <new-private-static-journal> --backup <new-private-backup-directory> --apply
```

`build` собирает child content на точном immutable base, worker — отдельно; сеть сборки и pull отключены. Образы не активируются и контейнеры не перезапускаются. Установка статики требует, чтобы действующие контейнеры всё ещё находились на исходных pinned images; поэтому её выполняют до отдельной активации Root. Каталоги/журналы должны быть уникальными. Существующий журнал означает неизвестный или уже выполненный запуск; повтор запрещён.

## Откат кода

```text
python3 <bundle>/native_release.py static-rollback --bundle <bundle> --expected-manifest-sha <verified-manifest-sha> --journal <same-static-journal> --apply
```

Сначала проверяются весь журнал, все текущие файлы и все резервные копии. Изменённый после установки живой код не затирается. Откат касается только перечисленных статических файлов; DB никогда не восстанавливается. Возврат предыдущих образов и конфигурации после отдельной активации координирует Root, эти инструменты контейнеры не меняют.

## Проверка набора

`python -B ../QA/test_release.py` использует собственные временные каталоги и подставной исполнитель. Docker/сервер/DB/сеть не запускаются. Каждый тест удаляет свои файлы. Старый LOCAL_BOARD и пользовательские изменения остаются нетронутыми.
