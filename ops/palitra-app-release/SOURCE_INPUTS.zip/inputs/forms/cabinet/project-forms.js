'use strict';
(() => {
  const api = window.SbCabinet;
  if (!api?.registerView) return;
  let root = null, frame = null, observer = null;
  const resize = () => {
    if (!frame) return;
    const top = frame.getBoundingClientRect().top;
    frame.style.height = Math.max(480, window.innerHeight - top - 16) + 'px';
  };
  function leave() {
    observer?.disconnect(); observer = null;
    window.removeEventListener('resize', resize);
    frame?.remove(); frame = null;
  }
  function render(container, context) {
    leave(); root = container; container.replaceChildren();
    const title = document.createElement('h1'); title.textContent = 'Формы проектов'; container.append(title);
    if (context.identity?.role !== 'owner') {
      const note = document.createElement('p'); note.textContent = 'Раздел доступен владельцу проекта.'; container.append(note); return;
    }
    if (context.selectedProjectId !== 'palitra-love') {
      const note = document.createElement('p'); note.textContent = 'Для этого проекта формы пока не перенесены. Выберите Palitra Love.'; container.append(note); return;
    }
    const note = document.createElement('p'); note.textContent = 'Palitra Love → Palitra Love Заказы'; container.append(note);
    frame = document.createElement('iframe');
    frame.title = 'Редактор форм Palitra Love Заказы';
    frame.src = '/cabinet/project-forms/index.html?company=palitra-love&board=palitra-orders';
    frame.referrerPolicy = 'same-origin';
    frame.style.cssText = 'display:block;width:100%;min-height:480px;border:1px solid #ded8cc;border-radius:16px;background:#fff';
    container.append(frame); resize();
    window.addEventListener('resize', resize);
    if (window.ResizeObserver) { observer = new ResizeObserver(resize); observer.observe(container); }
  }
  api.registerView('project-forms', { render, onLeave: leave, onProjectChange(context) { if (root) render(root, context); } });
})();
