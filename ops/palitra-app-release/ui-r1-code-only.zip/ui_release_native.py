"""Root-only exact Palitra UI release: three image files, four static files.
No worker/key/DB/auth writes. Old A10 unknown journal is immutable lineage only.
Frozen general Compose cap12 remains unchanged; only pinned chain13+this overlay.
"""
import argparse,base64,hashlib,json,os,re,stat,sys,types
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path('/opt/synapse/releases/palitra-app-20261015')
CORE_SHA='60a129b3467068932e0d1ca5529f808a76f36f52027990d71bd19d588149db4b'
INC_SHA='f7170af089f3ca6e951426320f74b139294e85eda18a56296726c360c1f807d7'
PUSH_SHA='7b761a06694ab713b01b974b1ec3090b75b1c3f05bcd5268533bb8b6181b9be8'
MANIFEST_SHA='3a881e2e7ca5f094209e87cfc0027054d4cac45d7dd6aa5c7acb9f3bfa1ce374'
FEATURES_SHA='dcc2c3c91029021117321066698cb555896b8cb13cc132e947142dece9e36bae'
PUSH_JOURNAL_SHA='00abb8d802d59b86013e8ca893c08ae41799ef887c4c330b501538c4f5176870'
A10_JOURNAL_SHA='16bfbde077bc5074fcf49c26ad86992ac9d49d4bb9f51b431ab9bb41859e6839'
A10_DECISION_SHA='2152d13fffad5cc9370b42f44f1a7f63c748aa8aac5c73ab7cdf869f1c174fac'
CONTENT='sha256:5cceeb7019e78fa1269e7e5ed1c5f93951ab26afae6aa73457cfb1622aaefa0e'
WORKER='sha256:c5dd4502daf630afaac7415da5b19dc456c81a5f81626574f5480dec04307cca'
WORKER_CID='7d7ec369e7ce44e492874137813caf3399b21b0242438b3b6df1281e4f379415'
WORKER_SOURCE='36b0bdc733ad4f4514635d0416867d5964fef4c82aeabe125f542a20969de0ee'
A10_SHELL='102daf2d7a9439918258955e7673149ec49c81aee46a6c58a16ef162da22b13d'
EXACT_CHAIN=(
 '/opt/synapse/docker-compose.yml','/opt/synapse/ops/site-workspaces.release.yml',
 '/opt/palitra-editor-backups-36-38/image.override.yml','/opt/palitra-order-guard-20261013/image.override.yml',
 '/opt/palitra-production-20261013/image.override.yml','/opt/palitra-main-usability.override.yml',
 '/opt/palitra-category.override.yml','/opt/palitra-app.override.yml',
 '/opt/synapse/releases/palitra-app-20261015/activation-r3-content-overlay.json',
 '/opt/synapse/releases/palitra-app-20261015/frontend-runtime-overlay.json',
 '/opt/synapse/releases/palitra-app-20261015/features1-overlay.json',
 '/opt/synapse/releases/palitra-app-20261015/push-r1-overlay.json',
 '/opt/synapse/releases/palitra-app-20261015/a10-r1-overlay.json')
UI_NAMES={'shell.js','shell.css','workflow-ui.js'}
OUTPUTS={'shell.js':'ee5976aba77f7acff8192b812c20511ac26024b62516752c579c6cb332f6d4bb','shell.css':'d721b4cceb497cc8501644a95af9269b60a218c4967c82917910da3df5ca8082','workflow-ui.js':'57c96e68edf12a2891c274a605f19e4ad28a4f90810e59d6ce841efbe2e8b2a7','cabinet.html':'21a7807236973549c9c9ced75a5a0e255db8abd6cb1068fcf7784097130fd869'}

def need(v,code):
 if not v:raise ValueError(code)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def validate_literals():
 for n in ('CORE_SHA','INC_SHA','PUSH_SHA','MANIFEST_SHA','FEATURES_SHA','PUSH_JOURNAL_SHA','A10_JOURNAL_SHA','A10_DECISION_SHA','WORKER_CID','WORKER_SOURCE','A10_SHELL'):need(re.fullmatch('[0-9a-f]{64}',globals()[n])is not None,'BAD_PIN_LITERAL_'+n)
 for n in ('CONTENT','WORKER'):need(re.fullmatch('sha256:[0-9a-f]{64}',globals()[n])is not None,'BAD_IMAGE_LITERAL_'+n)
 need(len(EXACT_CHAIN)==len(set(EXACT_CHAIN))==13,'EXACT_CHAIN13_LITERAL_REQUIRED')
 for v in OUTPUTS.values():need(re.fullmatch('[0-9a-f]{64}',v)is not None,'BAD_OUTPUT_LITERAL')
validate_literals()
def loaded(root=ROOT):
 p=root/'push_enable.py';raw=p.read_bytes();need(not p.is_symlink()and sha(raw)==PUSH_SHA,'EXACT_PUSH_HELPER_REQUIRED');m=types.ModuleType('ui_release_push');m.__file__=str(p);exec(compile(raw,str(p),'exec'),m.__dict__);inc,c=m.loaded_incremental(root);need(sha(c.read(root/'incremental_native.py'))==INC_SHA and sha(c.read(root/'activate_root.py'))==CORE_SHA,'EXACT_ACCEPTED_DEPENDENCIES_REQUIRED');return m,inc,c

def write(p,raw,mode=0o600):
 fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|getattr(os,'O_NOFOLLOW',0),mode)
 with os.fdopen(fd,'wb')as f:f.write(raw);f.flush();os.fsync(f.fileno())

class UIRelease:
 def __init__(self,pm,inc,r,payload=None,*,lineage_pins=None,expected_chain=EXACT_CHAIN,key_directory=None,public_roots=None,main_cabinet=Path('/opt/synapse/sites/synapse/cabinet.html'),helper_pins=None):
  self.pm,self.inc,self.r=pm,inc,r;self.c,self.a,self.run,self.root,self.now=r.c,r.a,r.run,r.root,r.now;self.bundle=self.c.path(payload or Path(__file__).parent);self.cabinet=r.cabinet;self.main_cabinet=Path(main_cabinet);self.msha=MANIFEST_SHA;self.chain=list(expected_chain)
  need(len(self.chain)==len(set(self.chain))==13,'EXACT_CHAIN13_REQUIRED');opts={}
  if key_directory is not None:opts['key_directory']=key_directory
  if public_roots is not None:opts['public_roots']=public_roots
  pins=lineage_pins or {};self.p=pm.PushEnable(r,'features1',pins.get('features',FEATURES_SHA),**opts);self.pp=self.p.paths('push-r1');self.ps=self.r.pin(self.pp['journal'],pins.get('push',PUSH_JOURNAL_SHA));self.k=self.r.pin(self.pp['keys'],self.ps['keyReceiptSha256']);self.pre=self.r.pin(self.pp['preflight'],self.ps['preflightSha256'])
  self.jpath=self.root/'a10-r1-journal.json';self.dpath=self.root/'a10-r1-decision.json';self.j=self.r.pin(self.jpath,pins.get('a10journal',A10_JOURNAL_SHA));self.d=self.r.pin(self.dpath,pins.get('a10decision',A10_DECISION_SHA));self.old=self.j['before'];self.a10overlay=self.root/'a10-r1-overlay.json'
  need(self.j.get('phase')=='A10_CONTENT_UP_STARTED_UNKNOWN'and self.j.get('name')=='a10-r1'and self.j['childImage']==CONTENT and self.j['decisionSha256']==pins.get('a10decision',A10_DECISION_SHA)and self.j['decisionFile']==self.dpath.name and self.d['facts']['snapshot']==self.old and self.d.get('rootApproved')is True,'EXACT_UNKNOWN_A10_LINEAGE_REQUIRED')
  need(self.ps.get('phase')=='PUSH_SERVER_CONFIG_APPLIED_NOT_DEVICE_PROOF'and self.ps.get('name')=='push-r1'and self.ps.get('workerRecreated')is False and self.ps.get('dbWrites')==0 and self.ps['after']==self.old and self.ps['publicKeySha256']==self.k['publicKeySha256']and self.ps['before']==self.pre['facts'],'EXACT_COMPLETED_PUSH_LINEAGE_REQUIRED')
  need(self.p.incremental['workerProof']['containerId']==WORKER_CID and self.j['workerProof']['containerId']==WORKER_CID and self.d['workerContainerId']==WORKER_CID and self.old['afterImages']['chat']==WORKER,'EXACT_OLD_WORKER_REQUIRED')
  need(self.chain==self.old['containers']['content']['files']+[str(self.a10overlay)]and len(self.old['containers']['content']['files'])==12 and self.j['overlay']==str(self.a10overlay),'EXACT_PINNED12_PLUS_A10_REQUIRED')
  need(self.c.obj(self.c.read(self.a10overlay))=={'services':{'content':{'image':CONTENT}}},'EXACT_A10_IMAGE_ONLY_OVERLAY_REQUIRED');self.basepins={**self.old['containers']['content']['filePins'],str(self.a10overlay):self.j['overlaySha256']};need(set(self.basepins)==set(self.chain),'EXACT_BASE_CHAIN_PINS_REQUIRED')
  raw=self.c.read(self.bundle/'MERGED_MANIFEST.json');need(sha(raw)==MANIFEST_SHA,'EXACT_ROOT_UI_MANIFEST_REQUIRED');self.manifest=self.c.obj(raw);m=self.manifest;need(set(m)=={'schema','status','records'}and m['schema']==1 and m['status']=='ROOT_MERGED_CANDIDATE_NOT_INSTALLED'and len(m['records'])==4,'EXACT_ROOT_UI_SCOPE_REQUIRED')
  self.records={};self.m={'records':[]};self.statics=[]
  for rec in m['records']:
   n=rec['path'];need(set(rec)=={'path','baseSha256','sha256','bytes','hunks'}and n in OUTPUTS and n not in self.records and rec['sha256']==OUTPUTS[n]and re.fullmatch('[0-9a-f]{64}',rec['baseSha256'])is not None and 0<rec['bytes']<=2097152,'EXACT_UI_RECORD_REQUIRED');raw=self.c.read(self.bundle/n);need(sha(raw)==rec['sha256']and len(raw)==rec['bytes'],'EXACT_UI_PAYLOAD_REQUIRED');self.records[n]=rec
   rr={'payload':n,'baseSha256':rec['baseSha256'],'sha256':rec['sha256'],'bytes':rec['bytes'],'edits':rec['hunks']}
   if n in UI_NAMES:self.m['records'].append(dict(rr,group='content',target='palitra-orders-public/'+n));self.statics.append((rr,self.cabinet/n))
   else:self.statics.append((rr,self.main_cabinet))
  need(set(self.records)==set(OUTPUTS)and self.records['shell.js']['baseSha256']==A10_SHELL,'EXACT_FOUR_FILES_REQUIRED');self.sourcebase=r.expected_hashes(True);self.sourcebase['palitra-orders-public/shell.js']=A10_SHELL
  for n in UI_NAMES:need(self.sourcebase.get('palitra-orders-public/'+n)==self.records[n]['baseSha256'],'UI_NOT_EXACT_EXISTING_SOURCE')
  self.pinfiles={str(self.bundle/'MERGED_MANIFEST.json'):MANIFEST_SHA,str(self.jpath):pins.get('a10journal',A10_JOURNAL_SHA),str(self.dpath):pins.get('a10decision',A10_DECISION_SHA),str(self.pp['journal']):pins.get('push',PUSH_JOURNAL_SHA),str(self.p.incremental_path):pins.get('features',FEATURES_SHA),str(self.pp['keys']):self.ps['keyReceiptSha256'],str(self.pp['preflight']):self.ps['preflightSha256'],str(self.pp['overlay']):self.ps['overlaySha256'],str(self.a10overlay):self.j['overlaySha256']}
  for n,rec in self.records.items():self.pinfiles[str(self.bundle/n)]=rec['sha256']
  for n,pin in (helper_pins if helper_pins is not None else {'activate_root.py':CORE_SHA,'incremental_native.py':INC_SHA,'push_enable.py':PUSH_SHA}).items():self.pinfiles[str(self.root/n)]=pin
  self.inventory={row['target']:row['sha256']for row in self.p.incremental['static']};self.inventory[str(self.cabinet/'shell.js')]=A10_SHELL
  for rec,p in self.statics:self.inventory[str(p)]=rec['baseSha256']
 def __getattr__(self,name):return getattr(self.r,name)
 def stable(self):
  self.r.stable();self.r.frozen()
  for n,pin in self.pinfiles.items():need(sha(self.c.read(Path(n)))==pin,'REVIEWED_UI_OR_PRIVATE_LINEAGE_CHANGED')
 def paths(self,name):
  need(type(name)is str and re.fullmatch('ui-r[1-9][0-9]{0,3}',name)is not None,'UNIQUE_UI_RN_REQUIRED');return {k:self.root/(name+'-'+k+('.json'if k in ('decision','journal','overlay','rollback-overlay')else''))for k in ('decision','journal','overlay','context','backup','rollback-overlay')}
 def available(self,name,decision=False):
  paths=self.paths(name)
  for k,p in paths.items():
   self.c.path(p,True)
   if k!='decision'or decision:need(not p.exists()and not Path(str(p)+'.pending').exists(),'UI_ATTEMPT_EXISTS_INSPECT_DO_NOT_RETRY')
  return paths
 def cid(self,service='content'):
  value=self.run(['docker','inspect','--format','{{.Id}}','synapse-'+service+'-1']).decode().strip();need(re.fullmatch('[0-9a-f]{64}',value)is not None,'EXACT_CONTAINER_ID_REQUIRED');return value
 def metadata(self,image,chain,pins,config):
  c=self.c;b=self.old['containers']['content'];v=c.obj(self.run(['docker','inspect','--format',c.LABELS,'synapse-content-1']));need(set(v)=={'image','project','service','workingDir','configFiles','configHash','running','health'}and v['image']==image and v['service']=='content'and v['project']==b['project']and v['workingDir']==b['workingDir']and v['running']is True and v['health']in (None,'healthy','starting','unhealthy')and v['configHash']==config,'EXACT_CONTENT_METADATA_REQUIRED');need(c.path(v['workingDir']).is_dir()and type(v['configFiles'])is str and len(v['configFiles'])<=65536,'EXACT_CONTENT_LABEL_REQUIRED');files=v['configFiles'].split(',');need(files==chain and len(files)==len(set(files))and len(files)in (13,14,15),'ONLY_EXACT_RELEASE_CHAIN_ALLOWED');actual={}
  for n in files:p=c.path(n);need(p.suffix.lower()in ('.json','.yml','.yaml'),'COMPOSE_FILE_TYPE_REQUIRED');actual[n]=sha(c.read(p))
  need(actual==pins,'COMPOSE_FILE_PIN_CHANGED');v.update(files=files,filePins=actual);return v
 def snapshot(self,image=CONTENT,overlay=None,config=None,*,previous=None):
  self.stable();self.a.lease();cid=self.cid();worker=self.cid('chat');need(worker==WORKER_CID,'WORKER_CONTAINER_CHANGED');chain=list(self.chain);pins=dict(self.basepins);config=config or self.j['plannedConfigHash']
  if previous:
   chain=previous['containers']['content']['files'][:];pins=dict(previous['containers']['content']['filePins'])
  if overlay:chain.append(str(overlay));pins[str(overlay)]=sha(self.c.read(overlay));need(self.c.obj(self.c.read(overlay))=={'services':{'content':{'image':image}}},'IMAGE_ONLY_UI_OVERLAY_REQUIRED')
  first={'content':self.metadata(image,chain,pins,config),'chat':self.a.metadata('chat')};selected={s:self.a.selected(s)for s in ('content','chat')};proof=self.a.hashproof(first);last={'content':self.metadata(image,chain,pins,config),'chat':self.a.metadata('chat')};need(first==last and selected=={s:self.a.selected(s)for s in ('content','chat')},'CONCURRENT_METADATA_OR_SELECTED_CHANGE');need(selected==self.old['selected']and last['chat']==self.old['containers']['chat'],'SHARED_SELECTED_OR_WORKER_CHANGED');self.a.lease();need(self.cid()==cid and self.cid('chat')==worker,'CID_CHANGED_DURING_SNAPSHOT');return {'schema':1,'containers':last,'selected':selected,'afterImages':{s:last[s]['image']for s in last},'sharedConfigHashProof':proof,'contentContainerId':cid}
 def push_guard(self):
  self.stable();keys=self.k;directory=Path(keys['directory']);need(directory==self.p.key_directory and self.p.private_meta(directory)==keys['keyMetadata'],'PRIVATE_KEY_METADATA_CHANGED');expected=sorted(self.ps['before']['mounts']+[{'Type':'bind','Source':str(directory),'Destination':self.pm.TARGET,'RW':False}],key=lambda row:row['Destination']);mounts=self.p.mounts();need(mounts==expected and self.p.binding(mounts)==self.ps['before']['binding'],'PUSH_MOUNT_OR_DB_BINDING_CHANGED');need(self.p.flag(),'PUSH_MUST_REMAIN_ENABLED');probe=self.c.obj(self.run(['docker','exec','synapse-content-1','node','-e',self.pm.KEY_JS]));need(probe=={'keyValid':True,'publicKeySha256':keys['publicKeySha256'],'webPushVersion':'3.6.7','transportReady':True},'ACTIVE_PUSH_KEY_LIBRARY_CHANGED');health=self.c.obj(self.run(['docker','exec','synapse-content-1','node','-e',self.pm.HEALTH_JS]));need(health=={'status':200,'ok':True,'service':'content'},'CONTENT_HEALTH_FAILED');self.r.worker({'workerContainerId':WORKER_CID})
 def expected_hashes(self,new=False):
  values=dict(self.sourcebase)
  if new:
   for n in UI_NAMES:values['palitra-orders-public/'+n]=self.records[n]['sha256']
  return values
 def static_inventory(self,new=False):
  values=dict(self.inventory)
  if new:
   for rec,p in self.statics:values[str(p)]=rec['sha256']
  for n,pin in values.items():need(self.fingerprint(Path(n))==pin,'STATIC_INVENTORY_CHANGED')
 def capture(self):
  snap=self.snapshot();self.inc.Release.compare(self,snap,self.old,{'content':CONTENT,'chat':WORKER},self.a10overlay,self.j['plannedConfigHash']);self.push_guard();need(snap['selected']['content']['PALITRA_WEB_UPLOADS_ENABLED']!='true','MEDIA_UPLOADS_MUST_STAY_OFF');expected=self.expected_hashes();need(self.hashes(expected)==expected,'SOURCE_INVENTORY_CHANGED');self.static_inventory();need(self.cid()==snap['contentContainerId'],'CONTENT_CID_CHANGED_DURING_CAPTURE');return {'snapshot':snap,'contentContainerId':snap['contentContainerId']}
 def approve_current(self,name,*,apply=False):
  need(apply is True,'EXPLICIT_ROOT_APPROVAL_REQUIRED');p=self.available(name,True);started=self.now();facts=self.capture();self.stable();self.a.lease();need(self.cid()==facts['contentContainerId'],'CONTENT_CID_CHANGED_BEFORE_APPROVAL');need(0<=(self.now()-started).total_seconds()<=600,'UI_NATIVE_CHECK_STALE');d={'schema':1,'scope':'EXACT_UI_ONLY_PUSH_WORKER_PRESERVED','name':name,'rootApproved':True,'manifestSha256':self.msha,'contentImage':CONTENT,'workerImage':WORKER,'workerContainerId':WORKER_CID,'observedAtUtc':started.isoformat(),'facts':facts};self.c.create(p['decision'],d);return {'status':'UI_ROOT_DECISION_READY_RUNTIME_UNCHANGED','decisionFile':p['decision'].name,'decisionSha256':sha(self.c.read(p['decision'])),'sourceFiles':len(self.sourcebase),'staticFiles':len(self.inventory),'runtimeWrites':0,'dbWrites':0}
 def decision(self,name,pin):
  need(type(name)is str and re.fullmatch('ui-r[1-9][0-9]{0,3}-decision.json',name)is not None,'EXACT_UI_DECISION_NAME_REQUIRED');d=self.r.pin(self.root/name,pin);need(set(d)=={'schema','scope','name','rootApproved','manifestSha256','contentImage','workerImage','workerContainerId','observedAtUtc','facts'}and d['schema']==1 and d['scope']=='EXACT_UI_ONLY_PUSH_WORKER_PRESERVED'and d['rootApproved']is True and d['manifestSha256']==self.msha and d['contentImage']==CONTENT and d['workerImage']==WORKER and d['workerContainerId']==WORKER_CID and self.paths(d['name'])['decision'].name==name,'EXACT_UI_ROOT_DECISION_REQUIRED');at=datetime.fromisoformat(d['observedAtUtc'].replace('Z','+00:00'));need(at.tzinfo is not None and 0<=(self.now()-at).total_seconds()<=600,'UI_DECISION_STALE_OR_FUTURE');return d
 def before(self,d):
  facts=self.capture();need(facts==d['facts'],'UI_APPROVED_BASE_CHANGED');return facts['snapshot'],self.statics
 def patch(self,raw,record):return self.inc.Release.patch(self,raw,record)
 def tree(self,root):return self.inc.Release.tree(self,root)
 def context_proof(self,*args):return self.inc.Release.context_proof(self,*args)
 def apply(self,name,decision_sha,*,apply=False):
  need(apply is True,'EXPLICIT_ROOT_APPLY_REQUIRED');paths=self.available(name);dn=paths['decision'].name;d=self.decision(dn,decision_sha);before,static=self.before(d);context,journal,overlay,backup=(paths[k]for k in ('context','journal','overlay','backup'));alias='palitra-ui-base:'+name;tag='palitra-ui:'+name
  self.unused(alias);self.unused(tag);need(self.run(['docker','image','inspect','--format','{{.Id}}',CONTENT]).decode().strip()==CONTENT,'EXACT_LOCAL_PARENT_REQUIRED');layers=self.c.obj(self.run(['docker','image','inspect','--format','{{json .RootFS.Layers}}',CONTENT]));need(type(layers)is list and layers,'PARENT_LAYERS_REQUIRED');context.mkdir(mode=0o700);backup.mkdir(mode=0o700);s={'schema':1,'name':name,'phase':'UI_CONTEXT_STARTED_UNKNOWN','manifestSha256':self.msha,'decisionFile':dn,'decisionSha256':decision_sha,'before':before,'oldA10JournalUnmodified':True,'workerRecreated':False,'pushEnabled':True,'dbWrites':0,'static':[]};self.c.create(journal,s)
  for rec in self.m['records']:
   encoded=self.run(['docker','exec','synapse-content-1','node','-e',self.inc.SOURCE_JS,rec['target']]);need(len(encoded)<=3*1024*1024,'BOUNDED_SOURCE_REQUIRED');raw=self.patch(base64.b64decode(encoded,validate=True),rec);p=context/'app'/rec['target'];p.parent.mkdir(mode=0o755,parents=True,exist_ok=True);write(p,raw,0o644)
  for i,(rec,p)in enumerate(static):
   old=self.c.read(p);new=self.patch(old,rec);mode=stat.S_IMODE(p.stat().st_mode);prepared=context/'static'/str(i);prepared.parent.mkdir(mode=0o700,exist_ok=True);write(prepared,new);b=backup/str(i);write(b,old);s['static'].append({'target':str(p),'baseSha256':rec['baseSha256'],'sha256':rec['sha256'],'mode':mode,'prepared':str(prepared),'backup':str(b),'written':False})
  write(context/'Dockerfile',('FROM '+alias+'\nCOPY app/ /app/\n').encode());s['contextSha256']=self.context_proof(context,s,alias);self.c.replace(journal,s)
  self.before(d);self.unused(alias);self.a.lease();self.decision(dn,decision_sha);self.run(['docker','image','tag',CONTENT,alias]);need(self.run(['docker','image','inspect','--format','{{.Id}}',alias]).decode().strip()==CONTENT,'PARENT_ALIAS_CHANGED');s['phase']='UI_BUILD_STARTED_UNKNOWN';self.c.replace(journal,s);iid=context/'image.id';need(self.context_proof(context,s,alias)==s['contextSha256'],'BUILD_CONTEXT_CHANGED');self.unused(tag);self.a.lease();need(self.run(['docker','image','inspect','--format','{{.Id}}',alias]).decode().strip()==CONTENT and self.cid()==d['facts']['contentContainerId'],'LAST_BUILD_BASE_CHANGED');need(self.context_proof(context,s,alias)==s['contextSha256'],'LAST_BUILD_CONTEXT_CHANGED');self.stable();self.decision(dn,decision_sha);self.run(['docker','build','--network=none','--pull=false','--tag',tag,'--iidfile',str(iid),str(context)]);child=self.c.read(iid).decode().strip();need(self.c.image(child)and child!=CONTENT,'EXACT_CHILD_REQUIRED');need(self.context_proof(context,s,alias,True)==s['contextSha256'],'BUILD_CONTEXT_CHANGED_DURING_BUILD');need(self.run(['docker','image','inspect','--format','{{.Id}}',tag]).decode().strip()==child,'CHILD_TAG_CHANGED');cl=self.c.obj(self.run(['docker','image','inspect','--format','{{json .RootFS.Layers}}',child]));need(cl[:len(layers)]==layers and len(cl)==len(layers)+1,'ONE_COPY_EXACT_PARENT_REQUIRED');expected=self.expected_hashes(True);need(self.hashes(expected,child)==expected,'CHILD_FULL_SOURCE_MISMATCH');self.before(d);self.decision(dn,decision_sha);s.update(phase='UI_STATIC_STARTED_UNKNOWN',childImage=child,contextTreeSha256=self.tree(context/'app'));self.c.replace(journal,s)
  for rec in s['static']:
   p=Path(rec['target']);need(self.fingerprint(p)==rec['baseSha256'],'STATIC_CAS_CONFLICT');raw=self.c.read(Path(rec['prepared']));need(sha(raw)==rec['sha256'],'PREPARED_STATIC_CHANGED');self.atomic(p,raw,rec['mode']);rec['written']=True;self.c.replace(journal,s)
  self.c.create(overlay,{'services':{'content':{'image':child}}});op=sha(self.c.read(overlay));planned=self.plan_hash(before,overlay);s.update(phase='UI_CONTENT_UP_STARTED_UNKNOWN',overlay=str(overlay),overlaySha256=op,plannedConfigHash=planned);self.c.replace(journal,s)
  self.stable();self.inc.Release.compare(self,self.snapshot(),before,before['afterImages']);need(self.hashes(self.expected_hashes())==self.expected_hashes(),'PRE_UP_SOURCE_CHANGED');self.static_inventory(True);self.push_guard();self.r.worker({'workerContainerId':WORKER_CID});self.a.lease();need(sha(self.c.read(overlay))==op and self.context_proof(context,s,alias,True)==s['contextSha256'],'LAST_INPUT_CHANGED');need(self.cid()==d['facts']['contentContainerId'],'CONTENT_CID_CHANGED_BEFORE_UP');self.decision(dn,decision_sha);self.run(self.command(before,overlay,['up','--detach','--no-build','--pull','never','--no-deps','content']))
  after_cid=self.cid();need(after_cid!=d['facts']['contentContainerId'],'CONTENT_RECREATION_EXPECTED');self.push_guard();after=self.snapshot(child,overlay,planned);self.inc.Release.compare(self,after,before,{'content':child,'chat':WORKER},overlay,planned);need(self.hashes(expected)==expected,'ACTIVE_CHILD_SOURCE_CHANGED');self.static_inventory(True);need(self.cid()==after_cid,'CONTENT_CID_CHANGED_DURING_READBACK');self.stable();s.update(phase='UI_CONTENT_AND_STATIC_APPLIED_NOT_PUBLIC_PROOF',after=after,contentContainerId=after_cid);self.c.replace(journal,s);return {'status':s['phase'],'journalFile':journal.name,'journalSha256':sha(self.c.read(journal)),'contentImage':child,'workerRecreated':False,'pushEnabled':True,'dbWrites':0,'publicReady':False,'oldA10JournalCompleted':False}
 def rollback(self,name,journal_sha,*,apply=False):
  need(apply is True,'EXPLICIT_ROOT_ROLLBACK_REQUIRED');paths=self.paths(name);journal=paths['journal'];s=self.r.pin(journal,journal_sha);need(s.get('phase')=='UI_CONTENT_AND_STATIC_APPLIED_NOT_PUBLIC_PROOF'and s.get('name')==name and s.get('manifestSha256')==self.msha and s.get('workerRecreated')is False and s.get('pushEnabled')is True,'COMPLETED_EXACT_UI_RECEIPT_REQUIRED');before=s['before'];overlay=paths['overlay'];need(s['overlay']==str(overlay)and sha(self.c.read(overlay))==s['overlaySha256'],'APPLIED_OVERLAY_CHANGED');current=self.snapshot(s['childImage'],overlay,s['plannedConfigHash']);need(current==s['after']and self.cid()==s['contentContainerId'],'COMPLETED_UI_BASE_CHANGED');self.push_guard();self.static_inventory(True);need(self.hashes(self.expected_hashes(True))==self.expected_hashes(True),'ROLLBACK_SOURCE_CHANGED')
  for rec in s['static']:need(sha(self.c.read(Path(rec['backup'])))==rec['baseSha256'],'BACKUP_CHANGED')
  need(self.run(['docker','image','inspect','--format','{{.Id}}',CONTENT]).decode().strip()==CONTENT,'PREVIOUS_LOCAL_CONTENT_MISSING');ro=paths['rollback-overlay'];self.c.create(ro,{'services':{'content':{'image':CONTENT}}});rp=sha(self.c.read(ro));planned=self.plan_hash(current,ro);s['phase']='UI_ROLLBACK_STARTED_UNKNOWN';self.c.replace(journal,s);self.snapshot(s['childImage'],overlay,s['plannedConfigHash']);self.static_inventory(True);self.push_guard();self.a.lease();need(sha(self.c.read(ro))==rp and self.cid()==s['contentContainerId'],'ROLLBACK_LAST_INPUT_CHANGED')
  for rec in s['static']:need(sha(self.c.read(Path(rec['backup'])))==rec['baseSha256'],'BACKUP_CHANGED_BEFORE_UP')
  need(sha(self.c.read(journal))==sha(self.c.data(s)),'ROLLBACK_JOURNAL_CHANGED');self.run(self.command(current,ro,['up','--detach','--no-build','--pull','never','--no-deps','content']));self.push_guard();restored=self.snapshot(CONTENT,ro,planned,previous=current);self.inc.Release.compare(self,restored,current,{'content':CONTENT,'chat':WORKER},ro,planned);need(self.hashes(self.expected_hashes())==self.expected_hashes(),'RESTORED_SOURCE_CHANGED')
  for rec in s['static']:need(sha(self.c.read(Path(rec['backup'])))==rec['baseSha256'],'BACKUP_CHANGED_AFTER_UP')
  for rec in reversed(s['static']):
   p=Path(rec['target']);need(self.fingerprint(p)==rec['sha256'],'ROLLBACK_STATIC_CAS_CONFLICT');raw=self.c.read(Path(rec['backup']));need(sha(raw)==rec['baseSha256'],'BACKUP_CHANGED_BEFORE_RESTORE');self.atomic(p,raw,rec['mode'])
  self.static_inventory();self.r.worker({'workerContainerId':WORKER_CID});self.stable();s.update(phase='UI_CODE_ROLLED_BACK_NO_DB_RESTORE',afterRollback=restored);self.c.replace(journal,s);return {'status':s['phase'],'contentImage':CONTENT,'workerRecreated':False,'pushEnabled':True,'dbRestore':False,'oldA10JournalCompleted':False}

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('operation',choices=['approve-current','apply','rollback']);p.add_argument('--bundle',type=Path,required=True);p.add_argument('--payload',type=Path,default=Path(__file__).parent);p.add_argument('--name',required=True);p.add_argument('--decision-sha');p.add_argument('--receipt-sha');p.add_argument('--apply',action='store_true');a=p.parse_args()
 try:
  need(a.apply is True and os.name=='posix'and os.geteuid()==0,'EXPLICIT_NATIVE_ROOT_APPLY_REQUIRED');pm,inc,c=loaded();r=inc.Release(c,a.bundle,pm.MANIFEST_SHA,ROOT);ui=UIRelease(pm,inc,r,a.payload);result=ui.approve_current(a.name,apply=True)if a.operation=='approve-current'else ui.apply(a.name,a.decision_sha,apply=True)if a.operation=='apply'else ui.rollback(a.name,a.receipt_sha,apply=True);print(json.dumps(result,separators=(',',':')));return 0
 except BaseException as e:
  msg=str(e);code=msg if re.fullmatch('[A-Z][A-Z0-9_]{0,100}',msg)else'ACCEPTED_GUARD_REFUSED';print(json.dumps({'status':'REFUSED_UNKNOWN_INSPECT_DO_NOT_RETRY','operation':a.operation,'errorClass':type(e).__name__,'code':code,'messageSha256':sha(msg.encode()),'automaticRetry':False,'dbRestore':False},separators=(',',':')));return 2
if __name__=='__main__':sys.exit(main())
