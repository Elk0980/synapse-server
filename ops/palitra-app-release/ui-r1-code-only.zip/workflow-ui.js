/* Palitra Love: этапы, автоответ и установка. Данные только через внедрённый same-origin host.
   Этот модуль не даёт прав по роли экрана и не создаёт клиентов, чаты, уведомления или свою БД. */
'use strict';
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else Object.defineProperty(root, 'PalitraWorkflowUI', { value: api, writable: false });
})(typeof globalThis !== 'undefined' ? globalThis : this, () => {
  const REQUIREMENTS = Object.freeze({ contact_confirmed: 'Связались с клиентом', details_confirmed: 'Детали заказа согласованы', payment_confirmed: 'Оплата подтверждена', photo_sent: 'Фото отправлено клиенту', handover_confirmed: 'Заказ передан клиенту', feedback_requested: 'Отзыв запрошен' });
  const CHANNELS = Object.freeze({ app: 'Чат приложения', phone: 'Телефон', telegram: 'Telegram', whatsapp: 'WhatsApp' });
  const copy = (value) => JSON.parse(JSON.stringify(value));
  const idOk = (id) => Number.isSafeInteger(id) && id > 0;
  function create({ document: doc, window: win, request, onUnauthorized = () => {}, onChanged = () => {}, now = () => Date.now() }) {
    const h = (tag, props, ...children) => {
      const el = doc.createElement(tag);
      for (const [key, value] of Object.entries(props || {})) {
        if (value == null || value === false) continue;
        if (key === 'text') el.textContent = String(value);
        else if (['value', 'checked', 'disabled', 'selected'].includes(key)) el[key] = value;
        else if (key === 'class') el.className = value;
        else if (key.startsWith('on')) el.addEventListener(key.slice(2), value);
        else el.setAttribute(key, value === true ? '' : String(value));
      }
      for (const child of children.flat(Infinity)) if (child != null && child !== false) el.append(typeof child === 'object' ? child : String(child));
      return el;
    };
    const button = (text, onclick, props = {}) => h('button', { type: 'button', class: 'app-btn app-btn--ghost', text, onclick, ...props });
    const field = (label, input) => h('label', { class: 'field' }, h('span', { class: 'field__label', text: label }), input);
    const input = (value, oninput, props = {}) => h('input', { type: 'text', class: 'app-input', value, oninput: (e) => oninput(e.target.value), ...props });
    const textarea = (value, oninput, props = {}) => h('textarea', { rows: '3', class: 'app-input', value, oninput: (e) => oninput(e.target.value), ...props });
    const msg = (text, error = false) => h('p', { class: error ? 'app-error' : 'muted', role: error ? 'alert' : 'status', text });
    let identity = { key: '', role: '', member: false, permissions: [] }, epoch = 0;
    let settings = null;
    const orders = new Map();
    const questionnaires = new Map();
    let installEvent = null, installed = false, onboardingExpanded = false, pushStatus = '', installBusy = false;
    const onboardingRoots = new Set();
    const memoryPrefs = new Map();
    const nativeInstalled = () => installed || Boolean(win.navigator && win.navigator.standalone) || Boolean(win.matchMedia && win.matchMedia('(display-mode: standalone)').matches);
    function allowed(permission) { return identity.member === true && (identity.role === 'owner' || identity.permissions.includes(permission)); }
    const canRead = () => allowed('crm.view');
    const canWrite = () => allowed('crm.edit');
    const isOwner = () => identity.member === true && identity.role === 'owner';
    function setIdentity(next) {
      const sanitized = { key: typeof next.key === 'string' ? next.key : '', role: next.role || '', member: next.member === true, permissions: Array.isArray(next.permissions) ? next.permissions.filter((p) => typeof p === 'string') : [] };
      if (JSON.stringify(identity) !== JSON.stringify(sanitized)) { epoch++; settings = null; orders.clear(); questionnaires.clear(); onboardingRoots.clear(); onboardingExpanded = false; pushStatus = ''; }
      identity = sanitized;
    }
    async function call(path, method = 'GET', body) {
      if (!request) throw new Error('Этапы заказа ещё не подключены. Обновите страницу позже.');
      try { return await request(path, { method, ...(body === undefined ? {} : { body }) }); }
      catch (error) { if (error.status === 401) onUnauthorized(error); throw error; }
    }
    const requestId = () => win.crypto && typeof win.crypto.randomUUID === 'function' ? win.crypto.randomUUID() : 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => { const r = Math.floor(Math.random() * 16); return (c === 'x' ? r : (r & 3) | 8).toString(16); });
    function resultConfig(data) { const value = data && data.config || data; if (!value || !Number.isSafeInteger(value.revision) || !value.autoReply || !Array.isArray(value.stages)) throw new Error('Сервер не подтвердил настройки.'); return value; }
    function resultOrder(data, orderId) { const value = data && data.order || data; if (!value || value.orderRef !== `native-order:${orderId}` || !Number.isSafeInteger(value.revision) || !Array.isArray(value.stages) || !Array.isArray(value.missing)) throw new Error('Сервер не подтвердил этап именно этого заказа.'); return value; }
    function settingsPanel() {
      if (!isOwner()) return h('section', { class: 'card workflow', 'data-workflow': 'forbidden' }, msg('Настройки автоответа и этапов доступны собственнику.'));
      if (!settings) settings = { data: null, draft: null, loading: false, saving: false, error: '', message: '', pending: null, roots: new Set() };
      for (const old of settings.roots) if (!old.isConnected) settings.roots.delete(old);
      const root = h('section', { class: 'card workflow', 'data-workflow': 'settings' });
      settings.roots.add(root);
      paintSettings(root);
      if (!settings.data && !settings.loading && !settings.error) loadSettings();
      return root;
    }
    function paintAllSettings() { if (settings) for (const root of settings.roots) if (root.isConnected) paintSettings(root); }
    async function loadSettings({ replaceDraft = false } = {}) {
      const s = settings, token = epoch; if (!s || s.loading) return;
      s.loading = true; s.error = ''; paintAllSettings();
      try { const value = resultConfig(await call('/content/palitra/workflow')); if (token !== epoch || s !== settings) return; s.data = copy(value); if (!s.draft || replaceDraft) s.draft = copy(value); }
      catch (error) { if (token === epoch && s === settings) s.error = error.message; }
      finally { if (token === epoch && s === settings) { s.loading = false; paintAllSettings(); } }
    }
    function paintSettings(root) {
      const s = settings; if (!s) return;
      const header = h('h2', { class: 'text__title', text: 'Автоответ и этапы заказа' });
      if (s.pending && !s.saving) { root.replaceChildren(header, msg(s.error || 'Исход сохранения ещё не подтверждён.', true), msg('Ваш текст сохранён в этой вкладке. Повтор отправляет тот же запрос, чтобы не создать дубликат.'),
        button('Повторить то же сохранение', saveSettings), button('Перечитать с сервера', () => loadSettings()),
        button('Сверил результат — вернуться к правкам', () => { s.pending = null; s.error = ''; paintAllSettings(); })); return; }
      if (!s.draft) { root.replaceChildren(...[header, msg(s.loading ? 'Загружаем настройки…' : s.error || 'Нет настроек.', Boolean(s.error)), !s.loading ? button('Повторить чтение', () => loadSettings()) : null].filter(Boolean)); return; }
      const draft = s.draft, busy = s.saving;
      const auto = draft.autoReply;
      const questions = Array.isArray(auto.questions) ? auto.questions : (auto.questions = []);
      const area = h('div', { class: 'workflow__settings' }, header,
        h('h3', { text: 'Первое сообщение в чате' }),
        h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: auto.enabled, disabled: busy, 'data-auto-enabled': '', onchange: (e) => { auto.enabled = e.target.checked; } }), 'Отправлять автоответ после первого сообщения клиента'),
        field('Текст автоответа', textarea(auto.text || '', (v) => { auto.text = v; }, { maxlength: '3000', disabled: busy, 'data-auto-text': '' })),
        msg('Автоответ отправляется один раз в этот же чат. Заявка без сообщения клиента его не запускает.'),
        h('h3', { text: 'Необязательные вопросы' }),
        ...questions.map((q, i) => h('div', { class: 'workflow__row' }, field(`Вопрос ${i + 1}`, input(q.label, (v) => { q.label = v; }, { disabled: busy, maxlength: '180' })),
          field('Варианты ответа — по одному в строке', textarea((q.options || []).join('\n'), (v) => { q.options = v.split('\n').map((t) => t.trim()).filter(Boolean); }, { disabled: busy, maxlength: '1500' })),
          button('Удалить вопрос', () => { questions.splice(i, 1); paintAllSettings(); }, { disabled: busy }))),
        button('Добавить вопрос', () => { questions.push({ id: `question_${requestId().replace(/-/g, '').slice(0, 16)}`, label: '', options: [] }); paintAllSettings(); }, { disabled: busy || questions.length >= 6 }),
        h('h3', { text: 'Этапы продаж' }), msg('Условия относятся к текущему этапу. Переход откроется после подтверждений. Изменения настроек не переписывают цепочку уже начатого заказа.'),
        ...draft.stages.map((stage, i) => h('fieldset', { class: 'workflow__stage', disabled: busy },
          h('legend', { text: `Этап ${i + 1}` }), field('Название', input(stage.label, (v) => { stage.label = v; }, { disabled: busy, maxlength: '100' })),
          field('Подсказка менеджеру', textarea(stage.hint || '', (v) => { stage.hint = v; }, { disabled: busy, maxlength: '500' })),
          h('strong', { text: 'Для следующего этапа требуется' }), ...Object.entries(REQUIREMENTS).map(([key, label]) => h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: (stage.requirements || []).includes(key), disabled: busy,
            onchange: (e) => { stage.requirements = e.target.checked ? [...new Set([...(stage.requirements || []), key])] : (stage.requirements || []).filter((x) => x !== key); } }), label)),
          h('div', { class: 'workflow__buttons' }, button('↑ Выше', () => { [draft.stages[i - 1], draft.stages[i]] = [stage, draft.stages[i - 1]]; paintAllSettings(); }, { disabled: busy || i === 0, 'aria-label': `Этап ${i + 1} выше` }),
            button('↓ Ниже', () => { [draft.stages[i + 1], draft.stages[i]] = [stage, draft.stages[i + 1]]; paintAllSettings(); }, { disabled: busy || i === draft.stages.length - 1, 'aria-label': `Этап ${i + 1} ниже` }),
            button('Удалить этап', () => { draft.stages.splice(i, 1); paintAllSettings(); }, { disabled: busy || draft.stages.length <= 2 })))),
        button('Добавить этап', () => { draft.stages.push({ id: `stage_${requestId().replace(/-/g, '').slice(0, 16)}`, label: 'Новый этап', hint: '', requirements: [] }); paintAllSettings(); }, { disabled: busy || draft.stages.length >= 20 }),
        s.error ? msg(s.error, true) : null, s.message ? msg(s.message) : null,
        h('div', { class: 'workflow__buttons' }, button(busy ? 'Сохраняем…' : s.pending ? 'Повторить то же сохранение' : 'Сохранить настройки', saveSettings, { class: 'app-btn', disabled: busy, 'data-save-settings': '' }),
          button('Перечитать с сервера', () => loadSettings(), { disabled: busy }), button('Сбросить мои изменения', () => { s.draft = copy(s.data); s.error = ''; s.pending = null; paintAllSettings(); }, { disabled: busy })));
      root.replaceChildren(area);
    }
    async function saveSettings() {
      const s = settings, token = epoch; if (!s || s.saving || !isOwner()) return;
      if (s.draft.stages.some((x) => !x.label.trim()) || (s.draft.autoReply.enabled && !s.draft.autoReply.text.trim())) { s.error = 'Заполните названия этапов и текст включённого автоответа.'; paintAllSettings(); return; }
      if (s.draft.stages.at(-1).requirements.length) { s.error = 'Последний этап завершает цепочку. Уберите у него условия перехода или переместите его выше.'; paintAllSettings(); return; }
      if (s.draft.autoReply.questions.some((q) => !q.label.trim() || q.options.length > 8 || q.options.some((v) => v.length > 100))) { s.error = 'Укажите текст каждого вопроса. Можно до восьми вариантов, каждый до 100 символов.'; paintAllSettings(); return; }
      const body = s.pending || { expectedRevision: s.data.revision, requestId: requestId(), config: { autoReply: copy(s.draft.autoReply), stages: copy(s.draft.stages) } };
      s.pending = body; s.saving = true; s.error = ''; s.message = ''; paintAllSettings();
      try { const value = resultConfig(await call('/content/palitra/workflow', 'PUT', body)); if (token !== epoch || s !== settings) return; s.data = copy(value); s.draft = copy(value); s.pending = null; s.message = 'Настройки сохранены на сервере.'; }
      catch (error) { if (token !== epoch || s !== settings) return; s.error = error.status === 409 ? 'Настройки уже изменились. Ваш ввод сохранён. Перечитайте сервер, затем сверьте и сохраните изменения.' : `${error.message} Исход сохранения уточните чтением; повтор использует тот же запрос.`; if (error.status) s.pending = null; }
      finally { if (token === epoch && s === settings) { s.saving = false; paintAllSettings(); } }
    }
    function orderPanel(orderId) {
      if (!idOk(orderId) || !canRead()) return null;
      if (!orders.has(orderId)) orders.set(orderId, { data: null, loading: false, busy: false, readAt: 0, error: '', drafts: new Map(), pending: null, roots: new Set() });
      const s = orders.get(orderId), root = h('section', { class: 'card workflow', 'data-workflow-order': String(orderId) });
      for (const old of s.roots) if (!old.isConnected) s.roots.delete(old);
      s.roots.add(root); paintOrder(root, orderId);
      if (!s.loading && !s.busy && (!s.data || now() - s.readAt > 5000) && !s.error) loadOrder(orderId);
      return root;
    }
    function paintAllOrders(orderId) { const s = orders.get(orderId); if (s) for (const root of s.roots) if (root.isConnected) paintOrder(root, orderId); }
    async function loadOrder(orderId) {
      const s = orders.get(orderId), token = epoch; if (!s || s.loading) return;
      s.loading = true; s.error = ''; paintAllOrders(orderId);
      try { const data = resultOrder(await call(`/content/palitra/workflow/orders/${orderId}`), orderId); if (token !== epoch || orders.get(orderId) !== s) return; s.data = copy(data); s.readAt = now(); }
      catch (error) { if (token === epoch && orders.get(orderId) === s) s.error = error.message; }
      finally { if (token === epoch && orders.get(orderId) === s) { s.loading = false; paintAllOrders(orderId); } }
    }
    function paintOrder(root, orderId) {
      const s = orders.get(orderId); if (!s) return;
      const header = h('h3', { text: 'Этапы заказа' });
      if (!s.data) { root.replaceChildren(...[header, msg(s.loading ? 'Загружаем этапы…' : s.error || 'Нет данных этапов.', Boolean(s.error)), s.loading ? null : button('Повторить чтение', () => loadOrder(orderId))].filter(Boolean)); return; }
      const d = s.data, stage = d.stages.find((x) => x.id === d.currentStageId);
      const rows = (d.missing || []).filter((r) => Object.hasOwn(REQUIREMENTS, r));
      const children = [header, h('strong', { class: 'workflow__current', text: stage ? stage.label : 'Этап не определён' }), stage && stage.hint ? msg(stage.hint) : null,
        h('ol', { class: 'workflow__timeline' }, ...d.stages.map((st) => h('li', { class: st.id === d.currentStageId ? 'is-current' : '', 'aria-current': st.id === d.currentStageId ? 'step' : null, text: st.label }))),
        msg('Можно общаться в удобном клиенту канале. Подтвердите результат здесь — Дарья увидит его в истории заказа.')];
      for (const requirement of rows) {
        if (!s.drafts.has(requirement)) s.drafts.set(requirement, { channel: 'app', note: '', attachmentRef: '' });
        const draft = s.drafts.get(requirement), writable = canWrite() && d.canEdit !== false && !d.terminal && !s.busy;
        const select = h('select', { class: 'app-input', value: draft.channel, disabled: !writable, 'aria-label': `Канал: ${REQUIREMENTS[requirement]}`, onchange: (e) => { draft.channel = e.target.value; paintAllOrders(orderId); } },
          ...Object.entries(CHANNELS).map(([value, label]) => h('option', { value, text: label, ...(value === draft.channel ? { selected: true } : {}) })));
        const photos = Array.isArray(d.availablePhotos) ? d.availablePhotos : [];
        const photoChoice = requirement === 'photo_sent' && draft.channel === 'app' ? field('Уже отправленное фото в этом чате', h('select', { class: 'app-input', disabled: !writable, value: draft.attachmentRef,
          onchange: (e) => { draft.attachmentRef = e.target.value; } }, h('option', { value: '', text: 'Выберите отправленное фото' }),
          ...photos.map((photo) => h('option', { value: photo.attachmentRef, text: photo.label || `Фото ${photo.id}`, ...(photo.attachmentRef === draft.attachmentRef ? { selected: true } : {}) })))) : null;
        children.push(h('fieldset', { class: 'workflow__confirmation' }, h('legend', { text: REQUIREMENTS[requirement] }), field('Где подтвердили', select), photoChoice,
          requirement === 'photo_sent' && draft.channel === 'app' && !photos.length ? msg('Сначала отправьте фото клиенту. Затем обновите этапы. Выбор файла сам по себе отправку не подтверждает.') : null,
          field(draft.channel === 'app' ? 'Комментарий' : 'Что подтвердили с клиентом в этом канале', textarea(draft.note, (v) => { draft.note = v; }, { disabled: !writable, maxlength: '1000', 'aria-label': `Подтверждение: ${REQUIREMENTS[requirement]}` })),
          button(`Подтвердить: ${REQUIREMENTS[requirement].toLowerCase()}`, () => confirmOrder(orderId, requirement), { disabled: !writable, 'data-confirm': requirement })));
      }
      if (!canWrite()) children.push(msg('Вы можете просматривать заказ. Изменять этапы может сотрудник с правом редактирования CRM.'));
      children.push(s.error ? msg(s.error, true) : null,
        button(d.cancelled ? 'Заказ отменён' : d.terminal ? 'Заказ завершён' : d.nextStage ? `Следующий этап: ${d.nextStage.label}` : 'Завершить этап', () => mutateOrder(orderId, 'advance'),
          { class: 'app-btn', disabled: !canWrite() || s.busy || d.allowed !== true || d.terminal === true, 'data-advance': '' }),
        button(s.loading ? 'Обновляем…' : 'Обновить этапы', () => loadOrder(orderId), { disabled: s.loading || s.busy }),
        s.pending ? button('Повторить прежний запрос', () => mutateOrder(orderId, s.pending.action), { disabled: s.busy || !canWrite() }) : null,
        h('details', { class: 'workflow__history' }, h('summary', { text: 'История подтверждений' }), ...(d.confirmations || []).map((c) => h('p', { text: `${REQUIREMENTS[c.requirement] || c.requirement} · ${CHANNELS[c.channel] || c.channel} · ${c.actor && c.actor.label || 'Менеджер'} · ${c.at || ''}${c.note ? ` — ${c.note}` : ''}` }))));
      root.replaceChildren(...children.filter(Boolean));
    }
    function confirmOrder(orderId, requirement) {
      const s = orders.get(orderId), draft = s && s.drafts.get(requirement); if (!s || !draft || !canWrite()) return;
      if (s.pending) { s.error = 'Сначала уточните результат предыдущего действия или повторите прежний запрос.'; paintAllOrders(orderId); return; }
      if (draft.channel !== 'app' && !draft.note.trim()) { s.error = 'Опишите подтверждение клиента в выбранном канале.'; paintAllOrders(orderId); return; }
      if (requirement === 'photo_sent' && draft.channel === 'app' && !draft.attachmentRef) { s.error = 'Выберите фото, которое уже отправлено в этот чат.'; paintAllOrders(orderId); return; }
      mutateOrder(orderId, 'confirm', { requirement, channel: draft.channel, note: draft.note.trim(), ...(draft.channel === 'app' && draft.attachmentRef && requirement === 'photo_sent' ? { attachmentRef: draft.attachmentRef } : {}) });
    }
    async function mutateOrder(orderId, action, patch = {}) {
      const s = orders.get(orderId), token = epoch; if (!s || s.busy || !s.data || !canWrite()) return;
      if (s.pending && s.pending.action !== action) { s.error = 'Сначала уточните результат предыдущего действия чтением или повторите прежний запрос.'; paintAllOrders(orderId); return; }
      const body = s.pending ? s.pending.body : { expectedRevision: s.data.revision, requestId: requestId(), ...patch };
      s.pending = { action, body }; s.busy = true; s.error = ''; paintAllOrders(orderId);
      try { const result = resultOrder(await call(`/content/palitra/workflow/orders/${orderId}/${action}`, 'POST', body), orderId); if (token !== epoch || orders.get(orderId) !== s) return; s.data = copy(result); s.readAt = now(); s.pending = null; onChanged(orderId); }
      catch (error) { if (token !== epoch || orders.get(orderId) !== s) return; s.error = error.status === 409 ? 'Заказ изменился. Обновите этапы и проверьте текущие подтверждения.' : `${error.message} Проверьте результат обновлением; неизвестный запрос можно повторить без изменений.`; if (error.status) s.pending = null; }
      finally { if (token === epoch && orders.get(orderId) === s) { s.busy = false; paintAllOrders(orderId); } }
    }
    function questionnairePanel(key, items, send) {
      const questions = Array.isArray(items) ? items.filter((q) => q && typeof q.id === 'string' && typeof q.label === 'string').slice(0, 8) : [];
      if (!questions.length || typeof key !== 'string' || typeof send !== 'function') return null;
      if (!questionnaires.has(key)) questionnaires.set(key, { answers: {}, busy: false, sent: false, error: '', mounts: new Set() });
      const s = questionnaires.get(key), root = h('details', { class: 'card workflow questionnaire', 'data-questionnaire': key });
      for (const old of s.mounts) if (!old.root.isConnected) s.mounts.delete(old);
      const repaint = () => { for (const mount of s.mounts) if (mount.root.isConnected) mount.paint(); };
      const paint = () => {
        const content = [h('summary', { text: s.sent ? 'Ответы отправлены менеджеру' : 'Расскажите о празднике — по желанию' }), msg('Можно ответить на вопросы или сразу написать менеджеру в чате.')];
        if (!s.sent) {
          for (const question of questions) {
            if (!Object.hasOwn(s.answers, question.id)) s.answers[question.id] = '';
            const control = input(s.answers[question.id], (value) => { s.answers[question.id] = value; }, { disabled: s.busy, maxlength: '300', 'aria-label': question.label });
            const choices = Array.isArray(question.options) ? question.options.filter((x) => typeof x === 'string').slice(0, 12) : [];
            content.push(field(question.label, control));
            if (choices.length) content.push(h('div', { class: 'workflow__buttons' }, ...choices.map((value) => button(value, () => { s.answers[question.id] = value; control.value = value; }, { disabled: s.busy }))));
          }
          content.push(button(s.busy ? 'Отправляем ответы…' : 'Отправить ответы в этот чат', async () => {
            if (s.busy) return;
            const text = questions.map((q) => s.answers[q.id].trim() ? `${q.label}: ${s.answers[q.id].trim()}` : '').filter(Boolean).join('\n');
            if (!text) { s.error = 'Ответьте хотя бы на один вопрос или продолжите обычную переписку.'; paint(); return; }
            const token = epoch; s.busy = true; s.error = ''; paint();
            try { await send(text); if (token === epoch && questionnaires.get(key) === s) s.sent = true; }
            catch (error) { if (token === epoch && questionnaires.get(key) === s) s.error = error.message; }
            finally { if (token === epoch && questionnaires.get(key) === s) { s.busy = false; repaint(); } }
          }, { class: 'app-btn', disabled: s.busy, 'data-send-questionnaire': '' }));
        }
        if (s.error) content.push(msg(s.error, true));
        root.replaceChildren(...content);
      };
      s.mounts.add({ root, paint }); paint(); return root;
    }
    // Здесь сохраняется только выбор показа подсказки на устройстве. Это не авторизация и не подписка.
    function prefKey() { return `palitra:onboarding:v1:${identity.key || 'anonymous'}`; }
    function readPref() { try { return JSON.parse(win.localStorage.getItem(prefKey()) || '{}'); } catch (_) { return memoryPrefs.get(prefKey()) || {}; } }
    function savePref(value) { memoryPrefs.set(prefKey(), value); try { win.localStorage.setItem(prefKey(), JSON.stringify(value)); } catch (_) { /* приватный режим: память вкладки */ } }
    function onboardingPanel(role, moment, { force = false } = {}) {
      const staff = role === 'staff' || role === 'admin';
      if (!identity.key || (staff ? moment !== 'login' : role !== 'client' || moment !== 'chat')) return null;
      const pref = readPref();
      if (!force && (pref.off === true || Number(pref.nextAt) > now())) return null;
      const provider = win.PalitraPushService;
      const needsPush = Boolean(provider && provider.deliveryReady === true && !(provider.state && provider.state.subscribed === true && provider.state.serverSaved === true));
      if (!force && !staff && nativeInstalled() && !needsPush) return null;
      for (const old of onboardingRoots) if (!old.isConnected) onboardingRoots.delete(old);
      const root = h('section', { class: 'card app-onboarding', 'data-onboarding': role, ...(force ? { 'data-notification-settings': 'true' } : {}) });
      onboardingRoots.add(root); paintOnboarding(root, staff); return root;
    }
    function repaintOnboarding() { for (const root of onboardingRoots) if (root.isConnected) paintOnboarding(root, root.getAttribute('data-onboarding') !== 'client'); }
    function paintOnboarding(root, staff) {
      const isInstalled = nativeInstalled();
      const ios = /iPad|iPhone|iPod/.test(win.navigator && win.navigator.userAgent || '') || /Macintosh/.test(win.navigator && win.navigator.userAgent || '') && Number(win.navigator && win.navigator.maxTouchPoints) > 1;
      const instructions = ios ? ['Откройте эту страницу в Safari.', 'Нажмите «Поделиться» (квадрат со стрелкой), затем «На экран Домой».', 'Нажмите «Добавить» и открывайте Palitra Love с нового значка.']
        : ['Откройте меню браузера ⋮ или ….', 'Выберите «Установить приложение» или «Добавить на главный экран».', 'Подтвердите и открывайте Palitra Love с нового значка.'];
      const children = [h('h3', { text: isInstalled ? 'Уведомления Palitra Love' : 'Заказ всегда под рукой' }),
        msg(isInstalled ? 'Приложение уже открыто с главного экрана. Выберите, хотите ли получать уведомления на этом устройстве.' : staff ? 'Закрепите приложение, чтобы быстро открывать заказы и переписку.' : 'Добавьте Palitra Love на главный экран, чтобы возвращаться в чат и отслеживать заказ. Это необязательно.'),
        !isInstalled ? button(installBusy ? 'Подтвердите в браузере…' : installEvent ? 'Установить приложение' : 'Как добавить на главный экран', async () => {
          if (!installEvent) { onboardingExpanded = !onboardingExpanded; repaintOnboarding(); return; }
          const event = installEvent; installEvent = null; installBusy = true; repaintOnboarding();
          try { await event.prompt(); await event.userChoice; } catch (_) { onboardingExpanded = true; }
          finally { installBusy = false; repaintOnboarding(); }
        }, { class: 'app-btn', disabled: installBusy, 'data-install': '' }) : null,
        !isInstalled && onboardingExpanded ? h('ol', { class: 'app-onboarding__steps' }, ...instructions.map((text) => h('li', { text }))) : null];
      // Самого разрешения Notification недостаточно: без sender+subscription нельзя обещать push на закрытом сайте.
      const push = win.PalitraPushService;
      const configured = Boolean(push && push.deliveryReady === true && typeof push.getStatus === 'function' && typeof push.subscribe === 'function');
      const permission = win.Notification && win.Notification.permission;
      if (staff || configured || root.getAttribute('data-notification-settings') === 'true') {
        children.push(h('h4', { text: 'Уведомления на этом устройстве' }));
        if (!configured) children.push(msg('Push-уведомления пока не подключены. Заказы и сообщения проверяйте в приложении. Установка сама по себе push не включает.'));
        else if (ios && !isInstalled) children.push(msg('Для push на iPhone/iPad сначала добавьте приложение на экран Домой и откройте его оттуда (iOS/iPadOS 16.4 или новее).'));
        else if (permission === 'denied') children.push(msg('Уведомления запрещены в браузере. Откройте настройки этого сайта → «Уведомления» и разрешите их, если хотите получать push.'));
        else if (push.state && push.state.subscribed === true && push.state.serverSaved === true) children.push(msg('Уведомления подключены на этом устройстве.'),
          button('Отключить уведомления', async () => { const token = epoch; try { await push.unsubscribe(); if (token === epoch) { pushStatus = 'Уведомления отключены на этом устройстве.'; repaintOnboarding(); } } catch (error) { if (token === epoch) { pushStatus = error.message; repaintOnboarding(); } } }, { 'data-disable-push': '' }));
        else children.push(button('Включить уведомления', async () => {
          // subscribe запускается только этим явным нажатием. Провайдер обязан запросить разрешение,
          // создать browser subscription и подтвердить её сохранение на сервере для ТЕКУЩЕГО аккаунта.
          const token = epoch; pushStatus = 'Подтвердите разрешение браузера.'; repaintOnboarding();
          try { const receipt = await push.subscribe(); if (token !== epoch) return; const status = await push.getStatus(); if (token !== epoch) return;
            pushStatus = receipt && receipt.serverSaved === true && status && status.subscribed === true && status.serverSaved === true ? 'Уведомления подключены на этом устройстве.' : 'Подписка не подтверждена сервером. Push пока не включён.';
          } catch (error) { if (token === epoch) pushStatus = error.message || 'Не удалось подключить уведомления. Можно продолжить без них.'; }
          if (token === epoch) repaintOnboarding();
        }, { 'data-enable-push': '' }));
      }
      if (pushStatus) children.push(msg(pushStatus));
      children.push(h('div', { class: 'workflow__buttons' }, button('Позже', () => { savePref({ nextAt: now() + 86400000 }); root.remove(); }),
        button('Больше не предлагать', () => { savePref({ off: true }); root.remove(); })));
      root.replaceChildren(...children.filter(Boolean));
    }
    if (typeof win.addEventListener === 'function') {
      win.addEventListener('beforeinstallprompt', (event) => { event.preventDefault(); installEvent = event; repaintOnboarding(); });
      win.addEventListener('appinstalled', () => { installed = true; installEvent = null; repaintOnboarding(); });
      win.addEventListener('palitra:push-ready', repaintOnboarding);
    }
    return Object.freeze({ setIdentity, canRead, canWrite, isOwner, settingsPanel, orderPanel, questionnairePanel, onboardingPanel, reloadOrder: loadOrder });
  }
  return Object.freeze({ create, REQUIREMENTS, CHANNELS });
});
