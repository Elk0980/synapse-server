"""Root-only once bounded runtime observation. No app/DB/build/worker restart or BASE approval."""
import argparse,hashlib,json,os,posixpath,re,subprocess,sys,time,types
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path('/opt/synapse/releases/palitra-app-20261015')
READER_SHA='26010f48a7e88a9d3dda6fef05fb61caa6a1358cb3e6a780f2e892aa5abc2a4f';READER_SIZE=13683
PROBE_SHA='76fd37e1aadd34097c47e4731400848f3e0d37f7732d5b337d063dc88d44af47';PROBE_SIZE=4648
CID='7d7ec369e7ce44e492874137813caf3399b21b0242438b3b6df1281e4f379415';OLD='sha256:c5dd4502daf630afaac7415da5b19dc456c81a5f81626574f5480dec04307cca'
IMAGE='sha256:e67514e5d0f6c46656005e1b693b2ec9d52e80b641307de684d4a015ba7a4eaf';NAME='palitra-runtime-probe-r1'
HOOKS=('NODE_OPTIONS','NODE_PATH','NODE_EXTRA_CA_CERTS','NODE_USE_SYSTEM_CA','NODE_ICU_DATA','NODE_V8_COVERAGE','NODE_COMPILE_CACHE','NODE_DISABLE_COMPILE_CACHE','LD_PRELOAD','LD_LIBRARY_PATH','LD_AUDIT','OPENSSL_CONF','OPENSSL_MODULES','SSL_CERT_FILE','SSL_CERT_DIR','TZ','LANG','LANGUAGE','LC_ALL','LC_CTYPE','NODE_REDIRECT_WARNINGS')
CLEAR=HOOKS[:7]+HOOKS[8:15]+('NODE_REDIRECT_WARNINGS',)
INSPECT='{"Id":{{json .Id}},"Os":{{json .Os}},"Architecture":{{json .Architecture}},"RootFS":{{json .RootFS}},"Config":{"Cmd":{{json .Config.Cmd}},"Entrypoint":{{json .Config.Entrypoint}},"WorkingDir":{{json .Config.WorkingDir}},"User":{{json .Config.User}},"Env":{{json .Config.Env}}}}'
FIXED={'/usr/local/bin/node','/usr/local/bin/docker-entrypoint.sh','/etc/ssl/cert.pem','/etc/ssl/certs/ca-certificates.crt'}
LIBROOT={'/lib','/usr/lib','/usr/local/lib','/lib/x86_64-linux-gnu','/usr/lib/x86_64-linux-gnu'}
LIB=re.compile(r'(?:ld-musl-x86_64\.so\.1|ld-linux-x86-64\.so\.2|libc\.musl-x86_64\.so\.1|lib(?:c|m|dl|pthread|rt|gcc_s|stdc\+\+|atomic|z|crypto|ssl)\.so\.[0-9]+(?:\.[0-9]+)*)')
def sha(b):return hashlib.sha256(b).hexdigest()
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode()
def need(v,code):
 if not v:raise ValueError(code)
def readpin(path,pin,size,root=ROOT):
 path=Path(path);need(path.is_absolute()and path.is_file()and not path.is_symlink()and path.resolve()==path and path.is_relative_to(root),'CODE_PATH_REQUIRED');raw=path.read_bytes();need(len(raw)==size and sha(raw)==pin,'EXACT_CODE_PIN_REQUIRED');return raw
def load_reader(path,root=ROOT):
 raw=readpin(path,READER_SHA,READER_SIZE,root);m=types.ModuleType('runtime_accepted_reader');m.__file__=str(path);exec(compile(raw,str(path),'exec'),m.__dict__);need(m.CID==CID and m.IMAGE==OLD and m.PID==2744197 and m.LOCK=='/opt/synapse/.palitra-app-release.lock','ACCEPTED_READER_BINDING_REQUIRED');return m
def hooks(env):
 need(type(env)is list and len(env)<=256 and all(type(e)is str and len(e)<=65536 and'='in e for e in env),'ENV_BOUND');d={}
 for e in env:
  k,v=e.split('=',1);need(k not in d,'ENV_DUPLICATE');d[k]=v
 return {k:{'present':k in d,'effective':bool(d.get(k))}for k in HOOKS}
def known(n):return type(n)is str and(n in FIXED or posixpath.dirname(n)in LIBROOT and LIB.fullmatch(posixpath.basename(n))is not None)
def projection(v):
 need(type(v)is dict and set(v)=={'schema','node','platform','arch','execPath','versions','api','unrecognizedFileMappings','files','bundledCaCount','bundledCaSha256','totalHashedBytes','completeRuntimeEquivalence'},'PROJECTION_SCHEMA_REQUIRED')
 need(type(v['schema'])is int and v['schema']==1 and v['platform']=='linux'and v['arch']=='x64'and v['execPath']=='/usr/local/bin/node'and type(v['node'])is str and re.fullmatch(r'v24\.\d+\.\d+',v['node'])and v['completeRuntimeEquivalence']is False,'PROJECTION_RUNTIME_REQUIRED')
 need(type(v['versions'])is dict and set(v['versions'])=={'node','openssl','modules','uv'}and all(type(x)is str and re.fullmatch(r'[0-9A-Za-z.+_-]{1,64}',x)for x in v['versions'].values()),'PROJECTION_VERSIONS_REQUIRED')
 need(type(v['api'])is dict and set(v['api'])=={'fetch','FormData','Blob','abortTimeout'}and all(type(x)is bool for x in v['api'].values()),'PROJECTION_API_REQUIRED')
 need(type(v['files'])is dict and 1<=len(v['files'])<=28 and v['execPath']in v['files'],'PROJECTION_FILES_REQUIRED')
 for name,r in v['files'].items():
  need(known(name)and type(r)is dict and type(r.get('available'))is bool,'PROJECTION_FILE_SCOPE_REQUIRED')
  if r['available']:need(set(r)=={'available','realPath','size','mode','sha256'}and known(r['realPath'])and type(r['size'])is int and 0<=r['size']<=256*1024*1024 and type(r['mode'])is int and 0<=r['mode']<=4095 and type(r['sha256'])is str and re.fullmatch('[0-9a-f]{64}',r['sha256']),'PROJECTION_FILE_HASH_REQUIRED')
  else:need(set(r)=={'available','code'}and type(r['code'])is str and re.fullmatch('[A-Z_]{1,50}',r['code']),'PROJECTION_FILE_FAILURE_REQUIRED')
 need(all(type(v[k])is int and 0<=v[k]<=limit for k,limit in [('unrecognizedFileMappings',10000),('bundledCaCount',1024),('totalHashedBytes',512*1024*1024)])and type(v['bundledCaSha256'])is str and re.fullmatch('[0-9a-f]{64}',v['bundledCaSha256']),'PROJECTION_BOUNDS_REQUIRED');return v
def compare(a,b):
 projection(a);projection(b);reasons=[]
 for label,v in [('old',a),('candidate',b)]:
  if v['unrecognizedFileMappings']:reasons.append(label+':unknown_file_mappings')
  if not FIXED.issubset(v['files']):reasons.append(label+':required_paths_missing')
  if not any(posixpath.dirname(n)in LIBROOT for n in v['files']):reasons.append(label+':no_mapped_libraries')
  if any(not r['available']for r in v['files'].values()):reasons.append(label+':unavailable_files')
  if not all(v['api'].values()):reasons.append(label+':missing_builtin_api')
 if a!=b:reasons.append('runtime_projection_difference')
 node='/usr/local/bin/node';binary=a['files'][node].get('sha256')==b['files'][node].get('sha256')and a['files'][node]['available']and b['files'][node]['available']
 return {'status':('RUNTIME_PROJECTION_MISMATCH'if a!=b else'MATCH_OBSERVED_SUBSET_INCOMPLETE'if reasons else'MATCH_OBSERVED_RUNTIME_FILES_NOT_BASE_APPROVAL'),'projectionsEqual':a==b,'directBinaryHashEqual':binary,'incomplete':bool(reasons),'incompleteReasons':reasons,'old':a,'candidate':b,'completeRuntimeEquivalence':False,'buildApproved':False,'rollbackApproved':False}

class Runner:
 def __init__(self,accepted,probe,*,execute=None,root=ROOT):
  need(len(probe)==PROBE_SIZE and sha(probe)==PROBE_SHA,'EXACT_PROBE_REQUIRED');self.m=accepted;self.probe=probe;self.execute=execute or subprocess.run;self.root=Path(root);self.events=[];self.started=time.monotonic()
  env=[]
  for k in CLEAR:env+=['--env',k+'=']
  env+=['--env','NODE_DISABLE_COMPILE_CACHE=1'];self.oldcmd=['docker','exec','-i']+env+[CID,'/usr/local/bin/node','-'];self.newcmd=['docker','run','--rm','--pull=never','--name',NAME,'-i','--network','none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges']+env+['--entrypoint','/usr/local/bin/node',IMAGE,'-']
  self.allowed=[['lslocks','--json','--output','PID,MODE,PATH'],['docker','inspect','--format',accepted.INSPECT,'synapse-chat-1'],['docker','image','inspect','--format',INSPECT,IMAGE],['docker','container','ls','--all','--filter','name=^/'+NAME+'$','--format','{{.ID}}'],self.oldcmd,self.newcmd];self.reader=accepted.Reader(execute=self.reader_execute)
 def run(self,args,input=None):
  need(args in self.allowed,'COMMAND_NOT_ALLOWED');index=self.allowed.index(args);need((input==self.probe)if index in (4,5)else input is None,'EXACT_STDIN_REQUIRED')
  left=180-(time.monotonic()-self.started);need(left>=1,'OBSERVATION_BUDGET_EXCEEDED_NO_RETRY')
  try:r=self.execute(args,input=input,capture_output=True,shell=False,timeout=min(30,left))
  except subprocess.TimeoutExpired:self.events.append({'command':index,'timeout':True});raise ValueError('COMMAND_TIMEOUT_UNKNOWN_NO_RETRY')from None
  out,err=r.stdout or b'',r.stderr or b'';self.events.append({'command':index,'rc':r.returncode,'stdoutBytes':len(out),'stderrSha256':sha(err)});need(len(out)<=262144 and len(err)<=262144,'OUTPUT_BOUND');need(r.returncode==0,'COMMAND_FAILED_UNKNOWN_NO_RETRY');return r
 def reader_execute(self,args,**kwargs):
  need(kwargs==dict(capture_output=True,stdin=subprocess.DEVNULL,shell=False,timeout=30),'EXACT_READER_EXEC_REQUIRED');return self.run(args)
 def snapshot(self):
  raw=self.reader.snapshot();safe=self.m.safe_snapshot(raw);need(safe['startupAllowed']and not safe['appOrRuntimeMountOverlap'],'STARTUP_OR_RUNTIME_MOUNT_REFUSED');return safe,hooks(raw['Config']['Env'])
 def image(self):
  v=json.loads(self.run(self.allowed[2]).stdout);need(type(v)is dict and set(v)=={'Id','Os','Architecture','RootFS','Config'}and v['Id']==IMAGE and v['Os']=='linux'and v['Architecture']=='amd64','EXACT_NODE_IMAGE_REQUIRED');rootfs=v['RootFS'];need(type(rootfs)is dict and rootfs.get('Type')=='layers'and type(rootfs.get('Layers'))is list and 1<=len(rootfs['Layers'])<=128 and all(type(x)is str and re.fullmatch('sha256:[0-9a-f]{64}',x)for x in rootfs['Layers']),'IMAGE_LAYERS_REQUIRED');conf=v['Config'];need(type(conf)is dict and set(conf)=={'Cmd','Entrypoint','WorkingDir','User','Env'},'IMAGE_CONFIG_REQUIRED');h=hooks(conf['Env']);startup={k:conf[k]for k in ('Cmd','Entrypoint','WorkingDir','User')};allowed=conf['Cmd']==['node']and conf['Entrypoint']in (None,[],['docker-entrypoint.sh'],['/usr/local/bin/docker-entrypoint.sh'])and conf['WorkingDir']in ('','/')and conf['User']in ('','root','node','0','1000')
  return {'id':IMAGE,'os':'linux','architecture':'amd64','layersCount':len(rootfs['Layers']),'layersSha256':sha(canon(rootfs)),'configOpaqueSha256':sha(canon(conf)),'startupAllowed':allowed,'startup':startup if allowed else None,'startupSha256':sha(canon(startup)),'hooks':h}
 def reserve(self):
  need(self.root.is_absolute()and self.root.is_dir()and self.root.resolve()==self.root and not self.root.is_symlink(),'ATTEMPT_ROOT_REQUIRED');p=self.root/(NAME+'-attempt.json');need(not os.path.lexists(p),'ATTEMPT_EXISTS_NO_RETRY');fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|getattr(os,'O_NOFOLLOW',0),0o600)
  with os.fdopen(fd,'wb')as out:out.write(canon({'schema':1,'phase':'STARTED_UNKNOWN_NO_RETRY','name':NAME,'probeSha256':PROBE_SHA})+b'\n');out.flush();os.fsync(out.fileno())
  return p
 def observe(self):
  out={'schema':1,'status':'RUNTIME_OBSERVATION_INCOMPLETE_NO_RETRY','name':NAME,'commands':self.events,'readerSha256':READER_SHA,'probeSha256':PROBE_SHA,'nodeImageId':IMAGE,'mutationsToApplicationOrDB':0,'workerRestarts':0,'completeRuntimeEquivalence':False,'buildApproved':False,'rollbackApproved':False,'automaticRetry':False,'observedAtUtc':datetime.now(timezone.utc).isoformat()}
  try:
   need(not os.path.lexists(self.root/(NAME+'-attempt.json')),'ATTEMPT_EXISTS_NO_RETRY');self.reader.lease();p=self.reserve();before,oldhooks=self.snapshot();image=self.image();need(image['startupAllowed'],'NODE_IMAGE_STARTUP_NEEDS_REVIEW');need(not self.run(self.allowed[3]).stdout.strip(),'NAMED_CONTAINER_EXISTS_NO_RETRY');self.reader.lease();old=projection(json.loads(self.run(self.oldcmd,self.probe).stdout));self.reader.lease();candidate=projection(json.loads(self.run(self.newcmd,self.probe).stdout));after,newhooks=self.snapshot();imageafter=self.image();self.reader.lease();need(before==after and oldhooks==newhooks and image==imageafter,'FINAL_IDENTITY_CONFIG_MOUNTS_OR_IMAGE_DRIFT');out.update(workerBefore=before,workerAfter=after,workerStable=True,nodeImage=image,oldHooks=oldhooks,match=compare(old,candidate),startupHooksPresent={k:oldhooks[k]['present']or image['hooks'][k]['present']for k in HOOKS});effective=any(x['effective']for h in (oldhooks,image['hooks'])for x in h.values());out['effectiveHooksRequireRootDecision']=effective;out['status']='RUNTIME_FILES_OBSERVED_NOT_BUILD_OR_ROLLBACK_APPROVAL';out['attemptMarkerRemains']=p.name
  except Exception as e:out['failure']={'class':type(e).__name__,'code':str(e)if type(e)is ValueError and re.fullmatch('[A-Z0-9_]{1,80}',str(e))else'OBSERVATION_REFUSED_UNKNOWN_NO_RETRY'}
  return out
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--reader',type=Path,required=True);p.add_argument('--probe',type=Path,default=Path(__file__).with_name('runtime_probe.cjs'));p.add_argument('--execute-once',action='store_true');args=p.parse_args()
 try:
  need(args.execute_once and os.name=='posix'and os.geteuid()==0,'EXPLICIT_NATIVE_ROOT_ONCE_REQUIRED');m=load_reader(args.reader);probe=readpin(args.probe,PROBE_SHA,PROBE_SIZE);r=Runner(m,probe);out=r.observe();need(sha(readpin(args.reader,READER_SHA,READER_SIZE))==READER_SHA and sha(readpin(args.probe,PROBE_SHA,PROBE_SIZE))==PROBE_SHA,'CODE_INPUT_CHANGED')
 except Exception as e:out={'status':'RUNTIME_OBSERVATION_INCOMPLETE_NO_RETRY','failure':{'code':str(e)if type(e)is ValueError and re.fullmatch('[A-Z0-9_]{1,80}',str(e))else'INPUT_OR_OBSERVATION_REFUSED'},'automaticRetry':False,'completeRuntimeEquivalence':False,'buildApproved':False,'rollbackApproved':False}
 print(json.dumps(out,sort_keys=True,separators=(',',':')))
if __name__=='__main__':main()
