"""Prepare two code-only worker images; never activate, start the application or claim original-image recovery."""
import argparse,base64,hashlib,json,os,re,stat,subprocess,time,types
from datetime import datetime,timezone
from pathlib import Path

ROOT=Path('/opt/synapse/releases/palitra-app-20261015')
GRAPH_SHA='2c57ff64c0074f725c4c1709152076a4a35a67ddc1f1d43a8bcf715d3fa8aa23';GRAPH_BYTES=8533
READER_SHA='26010f48a7e88a9d3dda6fef05fb61caa6a1358cb3e6a780f2e892aa5abc2a4f'
RUNTIME_RUNNER_SHA='14de6aa84d25a3138b6920dafbdcef205a4441b89e9aa45fcd3ded4e7e7a9c33';RUNTIME_RUNNER_BYTES=12947
RUNTIME_PROBE_SHA='76fd37e1aadd34097c47e4731400848f3e0d37f7732d5b337d063dc88d44af47'
NODE_IMAGE='sha256:e67514e5d0f6c46656005e1b693b2ec9d52e80b641307de684d4a015ba7a4eaf'
NEW_BRIDGE='ac3a139d9715036ce5a6966794b61d65e900b0deb2eb3cf6edcd108c643cf683';NEW_BYTES=34975
RESIDUALS=['NOT_FULL_ROOTFS_EQUIVALENCE','NO_NETWORK_DELIVERY_PROOF','RESTORE_IMAGE_IS_RECONSTRUCTED_CODE_NOT_ORIGINAL_C5DD']
IMAGE_INSPECT='{"Id":{{json .Id}},"Os":{{json .Os}},"Architecture":{{json .Architecture}},"RootFS":{{json .RootFS}},"OnBuild":{{json (index .Config "OnBuild")}},"Volumes":{{json (index .Config "Volumes")}},"Healthcheck":{{json (index .Config "Healthcheck")}}}'
sha=lambda x:hashlib.sha256(x).hexdigest()
canon=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode()
def need(value,code):
 if not value:raise ValueError(code)
def stamp():return datetime.now(timezone.utc).isoformat()
def epoch(s):
 need(type(s)is str and len(s)<=40,'UTC_TIMESTAMP_REQUIRED')
 d=datetime.fromisoformat(s.replace('Z','+00:00'));need(d.utcoffset() is not None and d.utcoffset().total_seconds()==0,'UTC_TIMESTAMP_REQUIRED');return d.timestamp()
def fresh(s,now):need(0<=now-epoch(s)<=600,'FRESH_ROOT_PROOF_REQUIRED')
def imageid(s):return type(s)is str and re.fullmatch(r'sha256:[0-9a-f]{64}',s)is not None
def private_mode(path,mode):
 st=Path(path).stat();need(stat.S_IMODE(st.st_mode)==mode and st.st_uid==0,'ROOT_PRIVATE_MODE_REQUIRED')
def sync_dir(path):
 fd=os.open(path,os.O_RDONLY|getattr(os,'O_DIRECTORY',0))
 try:os.fsync(fd)
 finally:os.close(fd)
def pinpath(path,digest,limit=2*1024*1024,private=False):
 path=Path(path);need(path.is_absolute()and not path.is_symlink()and path.resolve(strict=True)==path,'EXACT_LOCAL_PATH_REQUIRED')
 st=path.stat();need(stat.S_ISREG(st.st_mode)and st.st_size<=limit and re.fullmatch(r'[0-9a-f]{64}',digest or''),'PINNED_FILE_REQUIRED')
 if private:private_mode(path,0o600)
 fd=os.open(path,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0)|getattr(os,'O_BINARY',0))
 try:
  first=os.fstat(fd);need((st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns)==(first.st_dev,first.st_ino,first.st_size,first.st_mtime_ns),'INPUT_FILE_RACE')
  body=b''
  while len(body)<=limit:
   part=os.read(fd,min(65536,limit+1-len(body)))
   if not part:break
   body+=part
  last=os.fstat(fd);after=path.stat();need(len(body)==st.st_size and (last.st_dev,last.st_ino,last.st_size,last.st_mtime_ns,last.st_ctime_ns)==(first.st_dev,first.st_ino,first.st_size,first.st_mtime_ns,first.st_ctime_ns)and(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns)==(st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns),'INPUT_FILE_RACE')
 finally:os.close(fd)
 need(len(body)<=limit and sha(body)==digest,'EXACT_INPUT_SHA_REQUIRED');return body
def write_new(path,body,mode=0o600):
 fd=os.open(path,os.O_CREAT|os.O_EXCL|os.O_WRONLY|getattr(os,'O_BINARY',0),mode)
 try:
  os.fchmod(fd,mode);view=memoryview(body)
  while view:
   n=os.write(fd,view);need(n>0,'PRIVATE_WRITE_REQUIRED');view=view[n:]
  os.fsync(fd)
 finally:os.close(fd)
def module(path,digest,size,name):
 raw=pinpath(path,digest,size);need(len(raw)==size,'EXACT_DEPENDENCY_SIZE_REQUIRED')
 m=types.ModuleType(name);m.__file__=str(path);exec(compile(raw,name,'exec'),m.__dict__);return m
def safe_code(error):return str(error)if type(error)is ValueError and re.fullmatch(r'[A-Z0-9_]{1,80}',str(error))else'BUILD_PREPARATION_REFUSED'

class Builder:
 def __init__(self,graph,accepted,runtime_module,root,name,graph_path,graph_pin,reader_path,runtime_path,runtime_pin,decision_path,decision_pin,bridge_path,execute=None,clock=None):
  need(re.fullmatch(r'worker-images-[a-z0-9-]{1,32}',name or'')is not None,'UNIQUE_ATTEMPT_NAME_REQUIRED')
  self.g=graph;self.a=accepted;self.rt=runtime_module;self.root=Path(root);self.name=name;self.graph_path=Path(graph_path);self.graph_pin=graph_pin;self.reader_path=Path(reader_path)
  self.runtime_path=Path(runtime_path);self.runtime_pin=runtime_pin;self.decision_path=Path(decision_path);self.decision_pin=decision_pin;self.bridge_path=Path(bridge_path)
  self.execute=execute or subprocess.run;self.now=clock or time.time;self.events=[];self.j=None;self.side_effect=False;self.child_images={}
  self.clear_env=[]
  for key in runtime_module.CLEAR:self.clear_env+=['--env',key+'=']
  self.clear_env+=['--env','NODE_DISABLE_COMPILE_CACHE=1']
  self.dir=self.root/('.'+name);self.alias='palitra-worker-nodebase:'+name;self.tags={'old':'palitra-worker-reserve:'+name,'new':'palitra-photo-worker:'+name}
  self.capture_js=graph.GRAPH_PROBE.replace('let size=0,n;const buffer','const chunks=[];let size=0,n;const buffer').replace('h.update(buffer.subarray(0,n));','const part=Buffer.from(buffer.subarray(0,n));chunks.push(part);h.update(part);').replace("sha256:h.digest('hex')","sha256:h.digest('hex'),base64:Buffer.concat(chunks).toString('base64')")
  self.readonly=[['lslocks','--json','--output','PID,MODE,PATH'],['docker','inspect','--format',accepted.INSPECT,'synapse-chat-1'],['docker','exec',graph.CID,'node','-e',graph.GRAPH_PROBE],['docker','exec',graph.CID,'node','-e',self.capture_js]]
 def run(self,args,optional_missing=False,timeout=30):
  allowed=args in self.readonly
  if args[:5]==['docker','image','inspect','--format',IMAGE_INSPECT]:allowed=len(args)==6 and(args[5]in[NODE_IMAGE,self.alias,*self.tags.values()]or imageid(args[5]))
  if args[:3]==['docker','image','tag']:allowed=args==['docker','image','tag',NODE_IMAGE,self.alias]
  if args[:2]==['docker','build']:
   allowed=any(args==self.build_cmd(k)for k in ('old','new'))
  if args[:2]==['docker','run']:allowed=any(args==self.probe_cmd(v)for v in getattr(self,'built_ids',[]))
  need(allowed,'FIXED_BUILD_OR_READONLY_COMMAND_REQUIRED')
  if args[:3]==['docker','image','tag']or args[:2]==['docker','build']:self.inputs()
  actual=args
  if args in self.readonly[2:]:actual=['docker','exec']+self.clear_env+[self.g.CID,'/usr/local/bin/node','-e',args[-1]]
  try:r=self.execute(actual,capture_output=True,stdin=subprocess.DEVNULL,shell=False,timeout=timeout)
  except subprocess.TimeoutExpired:self.events.append(dict(command=len(self.events),timeout=True));raise ValueError('COMMAND_OUTCOME_UNKNOWN')from None
  out,err=r.stdout or b'',r.stderr or b'';self.events.append(dict(command=len(self.events),rc=r.returncode,stdoutBytes=len(out),stderrSha256=sha(err)))
  need(len(out)<=2*1024*1024 and len(err)<=2*1024*1024,'COMMAND_OUTPUT_BOUND')
  if r.returncode:
   if optional_missing and re.search(rb'(?i)no such image|no such object',err):return None
   raise ValueError('COMMAND_FAILED_OR_UNKNOWN')
  return out
 def reader_exec(self,args,**kwargs):
  need(kwargs==dict(capture_output=True,stdin=subprocess.DEVNULL,shell=False,timeout=30),'EXACT_READER_EXEC_REQUIRED')
  return subprocess.CompletedProcess(args,0,self.run(args),b'')
 def snapshot(self):return self.a.safe_snapshot(self.a.Reader(execute=self.reader_exec).snapshot())
 def lease(self):self.a.Reader(execute=self.reader_exec).lease()
 def graph_now(self):
  out=self.g.Observer(self.a,execute=self.reader_exec).observe();need(out['status']=='EXACT_TEN_WORKER_CODE_PINS_STABLE_NOT_RUNTIME_BASE_APPROVAL','CURRENT_EXACT_TEN_GRAPH_REQUIRED');return out
 def image(self,ref,optional=False):
  body=self.run(['docker','image','inspect','--format',IMAGE_INSPECT,ref],optional_missing=optional)
  if body is None:return None
  row=json.loads(body);need(set(row)=={'Id','Os','Architecture','RootFS','OnBuild','Volumes','Healthcheck'}and imageid(row['Id'])and row['Os']=='linux'and row['Architecture']in('amd64','arm64'),'EXACT_IMAGE_FACTS_REQUIRED')
  need(row['OnBuild']in(None,[])and row['Volumes']in(None,{})and row['Healthcheck']is None,'IMAGE_MUST_NOT_HAVE_STARTUP_BUILD_OR_VOLUME_HOOKS')
  rf=row['RootFS'];need(type(rf)is dict and set(rf)=={'Type','Layers'}and rf['Type']=='layers'and type(rf['Layers'])is list and 1<=len(rf['Layers'])<=128 and all(imageid(x)for x in rf['Layers']),'EXACT_IMAGE_LAYERS_REQUIRED');return row
 def inputs(self):
  proof=json.loads(pinpath(self.graph_path,self.graph_pin,private=True));runtime=json.loads(pinpath(self.runtime_path,self.runtime_pin,private=True));decision=json.loads(pinpath(self.decision_path,self.decision_pin,65536,private=True))
  pinpath(self.reader_path,READER_SHA,13683);pinpath(self.bridge_path,NEW_BRIDGE,NEW_BYTES)
  need(proof.get('schema')==1 and proof.get('status')=='EXACT_TEN_WORKER_CODE_PINS_STABLE_NOT_RUNTIME_BASE_APPROVAL'and proof.get('allTenExact')is True and proof.get('stableStartupConfigMountsLease')is True,'PINNED_EXACT_GRAPH_PROOF_REQUIRED')
  fresh(proof.get('observedAtUtc'),self.now());need(type(proof.get('files'))is dict and set(proof['files'])==set(self.g.EXPECTED),'EXACT_TEN_GRAPH_REQUIRED')
  for n,(size,digest)in self.g.EXPECTED.items():need(proof['files'][n].get('available')is True and proof['files'][n].get('size')==size and proof['files'][n].get('sha256')==digest,'EXACT_TEN_GRAPH_REQUIRED')
  w=proof.get('worker');need(type(w)is dict and w.get('cid')==self.g.CID and w.get('image')==self.g.IMAGE and w.get('startupAllowed')is True and w.get('appOrRuntimeMountOverlap')is False,'EXACT_GRAPH_WORKER_REQUIRED')
  self.validate_runtime(runtime,w)
  need(set(decision)=={'schema','scope','runtimeProofSha256','nodeImageId','workerCid','workerImage','workerConfigOpaqueSha256','approvedAtUtc','approvedForBuildOnly','acceptObservedRuntimeSubset','residuals'},'EXPLICIT_ROOT_DECISION_SCHEMA_REQUIRED')
  need(decision['schema']==1 and decision['scope']=='BUILD_TWO_WORKER_IMAGES_ONLY_NOT_ACTIVATION'and decision['runtimeProofSha256']==self.runtime_pin and decision['nodeImageId']==NODE_IMAGE and decision['workerCid']==self.g.CID and decision['workerImage']==self.g.IMAGE and decision['workerConfigOpaqueSha256']==w['configOpaqueSha256']and decision['approvedForBuildOnly']is True and decision['acceptObservedRuntimeSubset']is True and decision['residuals']==RESIDUALS,'EXPLICIT_ROOT_BUILD_ONLY_DECISION_REQUIRED')
  fresh(decision['approvedAtUtc'],self.now());need(epoch(decision['approvedAtUtc'])>=epoch(runtime['observedAtUtc']),'ROOT_DECISION_BEFORE_FACTS')
  return proof,runtime,decision
 def validate_runtime(self,r,w):
  need(r.get('schema')==1 and r.get('status')=='RUNTIME_FILES_OBSERVED_NOT_BUILD_OR_ROLLBACK_APPROVAL'and r.get('readerSha256')==READER_SHA and r.get('probeSha256')==RUNTIME_PROBE_SHA and r.get('nodeImageId')==NODE_IMAGE and r.get('workerStable')is True,'REVIEWED_RUNTIME_PROOF_REQUIRED')
  fresh(r.get('observedAtUtc'),self.now());need(r.get('workerBefore')==r.get('workerAfter')and r.get('workerAfter')==w,'RUNTIME_GRAPH_WORKER_MISMATCH')
  match=r.get('match',{});need(match==self.rt.compare(match.get('old'),match.get('candidate'))and match.get('status')=='MATCH_OBSERVED_RUNTIME_FILES_NOT_BASE_APPROVAL'and match.get('directBinaryHashEqual')is True and match.get('projectionsEqual')is True and match.get('incomplete')is False and match.get('incompleteReasons')==[],'RUNTIME_COMPARISON_REQUIRED')
  need(r.get('completeRuntimeEquivalence')is False and r.get('buildApproved')is False and r.get('rollbackApproved')is False,'RUNTIME_PROOF_CANNOT_APPROVE_BUILD')
  node=r.get('nodeImage',{});need(node.get('id')==NODE_IMAGE and node.get('os')=='linux'and node.get('architecture')=='amd64'and node.get('startupAllowed')is True and re.fullmatch(r'[0-9a-f]{64}',node.get('layersSha256',''))and type(node.get('layersCount'))is int,'EXACT_RUNTIME_NODE_IMAGE_REQUIRED')
  hooks=[r.get('oldHooks'),node.get('hooks')];need(all(type(h)is dict and set(h)==set(self.rt.HOOKS)for h in hooks),'EXACT_STARTUP_HOOK_SET_REQUIRED')
  for h in hooks:
   for v in h.values():need(type(v)is dict and set(v)=={'present','effective'}and type(v['present'])is bool and v['effective']is False,'STARTUP_HOOK_REQUIRES_SEPARATE_DECISION')
  need(r.get('effectiveHooksRequireRootDecision')is False and type(r.get('startupHooksPresent'))is dict and r['startupHooksPresent']=={k:hooks[0][k]['present']or hooks[1][k]['present']for k in self.rt.HOOKS},'STARTUP_HOOK_REQUIRES_SEPARATE_DECISION')
 def stable(self,current,expected):
  need(current==expected,'ORIGINAL_WORKER_CHANGED')
 def guard(self,expected,base,check_context=None):
  proof,runtime,decision=self.inputs();self.stable(self.snapshot(),expected);self.lease();current=self.graph_now();self.stable(current['worker'],expected)
  need(self.image(NODE_IMAGE)==base,'IMMUTABLE_NODE_BASE_CHANGED')
  if self.child_images:self.pinned_images(base)
  if check_context:self.context(check_context)
  self.inputs();self.lease();self.inputs()
 def pinned_images(self,base,complete=False):
  need(self.image(self.alias)==base,'LOCAL_NODE_ALIAS_CHANGED')
  if complete:need(set(self.child_images)=={'old','new'},'BOTH_VERIFIED_CHILDREN_REQUIRED')
  for k,facts in self.child_images.items():
   need(self.image(self.tags[k])==facts and self.image(facts['Id'])==facts,'VERIFIED_CHILD_TAG_OR_IMAGE_CHANGED')
 def journal(self,phase,**extra):
  self.j.update(phase=phase,updatedAtUtc=stamp(),**extra)
  pending=self.dir/'journal.pending.json';write_new(pending,canon(self.j)+b'\n');os.replace(pending,self.dir/'journal.json')
  sync_dir(self.dir)
 def build_cmd(self,k):return ['docker','build','--pull=false','--network=none','--no-cache','--tag',self.tags[k],'--file',str(self.dir/k/'Dockerfile'),str(self.dir/k)]
 def probe_cmd(self,ident):return ['docker','run','--rm','--pull','never','--network','none','--read-only','--no-healthcheck','--cap-drop','ALL','--security-opt','no-new-privileges','--pids-limit','32','--memory','128m','--cpus','1','--user','0:0','--workdir','/app']+self.clear_env+['--entrypoint','/usr/local/bin/node',ident,'-e',self.g.GRAPH_PROBE]
 def dockerfile(self):
  files=json.dumps(sorted(self.g.EXPECTED)+['/app/'],separators=(',',':'))
  return ('FROM '+self.alias+'\nCOPY '+files+'\nWORKDIR /app\nCMD ["node","server.js"]\n').encode()
 def capture(self):
  value=json.loads(self.run(self.readonly[3]));need(type(value)is dict and set(value)=={'schema','files'}and value['schema']==1 and set(value['files'])==set(self.g.EXPECTED),'EXACT_CAPTURE_SCHEMA_REQUIRED');result={}
  for n,(size,digest)in self.g.EXPECTED.items():
   row=value['files'][n];need(type(row)is dict and set(row)=={'available','size','mode','sha256','base64'}and row['available']is True and row['size']==size and row['sha256']==digest and type(row['base64'])is str and len(row['base64'])<=4*((size+2)//3),'EXACT_CAPTURE_FILE_REQUIRED')
   body=base64.b64decode(row['base64'],validate=True);need(len(body)==size and sha(body)==digest,'EXACT_CAPTURE_HASH_REQUIRED');result[n]=body
  return result
 def context(self,k):
  p=self.dir/k;need(p.is_dir()and not p.is_symlink()and p.resolve(strict=True)==p,'PRIVATE_CONTEXT_REQUIRED');private_mode(p,0o700)
  names={f.name for f in p.iterdir()};need(names==set(self.g.EXPECTED)|{'Dockerfile'},'CLOSED_TEN_SOURCE_CONTEXT_REQUIRED')
  for n,(size,digest)in self.g.EXPECTED.items():
   if k=='new'and n=='client-bot-bridge.js':size,digest=NEW_BYTES,NEW_BRIDGE
   body=pinpath(p/n,digest,size,private=True);need(len(body)==size,'CONTEXT_EXACT_SIZE_REQUIRED')
  body=pinpath(p/'Dockerfile',sha(self.dockerfile()),4096,private=True);need(body==self.dockerfile(),'EXACT_DOCKERFILE_REQUIRED')
 def verify_child(self,k,base):
  self.inputs()
  child=self.image(self.tags[k]);need(child['Id']!=base['Id']and child['Os']==base['Os']and child['Architecture']==base['Architecture']and child['RootFS']['Layers'][:-1]==base['RootFS']['Layers']and len(child['RootFS']['Layers'])==len(base['RootFS']['Layers'])+1,'EXACT_NODE_PLUS_ONE_COPY_LAYER_REQUIRED')
  self.built_ids.append(child['Id']);observed=json.loads(self.run(self.probe_cmd(child['Id'])))
  need(type(observed)is dict and set(observed)=={'schema','files'}and observed['schema']==1 and set(observed['files'])==set(self.g.EXPECTED),'CHILD_TEN_FILE_READBACK_REQUIRED')
  for n,(size,digest)in self.g.EXPECTED.items():
   if k=='new'and n=='client-bot-bridge.js':size,digest=NEW_BYTES,NEW_BRIDGE
   row=observed['files'][n];need(type(row)is dict and set(row)=={'available','size','mode','sha256'}and row.get('available')is True and row.get('size')==size and row.get('sha256')==digest,'CHILD_EXACT_SOURCE_REQUIRED')
  self.inputs();need(self.image(self.tags[k])==child and self.image(child['Id'])==child,'VERIFIED_CHILD_TAG_OR_IMAGE_CHANGED');self.inputs();self.child_images[k]=child
  return dict(image=child['Id'],layersSha256=sha(canon(child['RootFS'])),sourceSha256=sha(canon(observed)),reconstructedCodeOnly=True,originalImageEquivalent=False)
 def prepare(self,apply=False):
  need(apply is True,'EXPLICIT_ROOT_APPLY_REQUIRED')
  need(self.root.is_dir()and not self.root.is_symlink()and self.root.resolve(strict=True)==self.root,'EXACT_RELEASE_ROOT_REQUIRED')
  need(not self.dir.exists(),'NEW_ATTEMPT_REQUIRED_NO_RETRY')
  proof,runtime,decision=self.inputs();self.lease();self.stable(self.snapshot(),proof['worker']);current=self.graph_now();self.stable(current['worker'],proof['worker']);before=current['worker']
  base=self.image(NODE_IMAGE);need(base['Id']==NODE_IMAGE and len(base['RootFS']['Layers'])==runtime['nodeImage']['layersCount']and sha(canon(base['RootFS']))==runtime['nodeImage']['layersSha256'],'EXACT_NODE_IMAGE_REQUIRED')
  for ref in [self.alias,*self.tags.values()]:need(self.image(ref,True)is None,'UNUSED_LOCAL_IMAGE_TAG_REQUIRED')
  self.lease();old=self.capture();after=self.graph_now();self.stable(after['worker'],before);self.inputs()
  self.dir.mkdir(mode=0o700);os.chmod(self.dir,0o700);self.j=dict(schema=1,name=self.name,startedAtUtc=stamp(),phase='PRIVATE_CODE_CONTEXT_PREPARATION',runtimeProofSha256=self.runtime_pin,rootDecisionSha256=self.decision_pin,graphProofSha256=self.graph_pin,workerBefore=before,nodeImage=NODE_IMAGE,applicationStarted=False,activation=False,composeActions=0,dbWrites=0,workerRestarts=0,automaticRetry=False,results={})
  write_new(self.dir/'journal.json',canon(self.j)+b'\n');self.built_ids=[]
  try:
   bridge=pinpath(self.bridge_path,NEW_BRIDGE,NEW_BYTES)
   for k in ('old','new'):
    p=self.dir/k;p.mkdir(mode=0o700);os.chmod(p,0o700)
    for n,body in old.items():write_new(p/n,bridge if k=='new'and n=='client-bot-bridge.js'else body)
    write_new(p/'Dockerfile',self.dockerfile());self.context(k)
   self.guard(before,base);need(self.image(self.alias,True)is None,'UNUSED_LOCAL_ALIAS_REQUIRED');self.lease();self.inputs()
   self.side_effect=True;self.journal('NODE_ALIAS_TAG_STARTED_UNKNOWN');self.lease();need(self.image(self.alias,True)is None,'UNUSED_LOCAL_ALIAS_REQUIRED');self.inputs();self.run(['docker','image','tag',NODE_IMAGE,self.alias]);need(self.image(self.alias)['Id']==NODE_IMAGE,'EXACT_LOCAL_ALIAS_REQUIRED');self.journal('NODE_ALIAS_PINNED')
   for k in ('old','new'):
    self.guard(before,base,k);need(self.image(self.tags[k],True)is None,'UNUSED_CHILD_TAG_REQUIRED');need(self.image(self.alias)['Id']==NODE_IMAGE,'EXACT_LOCAL_ALIAS_REQUIRED');self.context(k);self.lease();self.inputs()
    self.journal(k.upper()+'_BUILD_STARTED_UNKNOWN');self.guard(before,base,k);need(self.image(self.tags[k],True)is None,'UNUSED_CHILD_TAG_REQUIRED');need(self.image(self.alias)['Id']==NODE_IMAGE,'EXACT_LOCAL_ALIAS_REQUIRED');self.context(k);self.inputs();self.run(self.build_cmd(k),timeout=120);self.journal(k.upper()+'_BUILT_NOT_VERIFIED')
    self.j['results'][k]=self.verify_child(k,base);self.journal(k.upper()+'_CODE_IMAGE_VERIFIED_NOT_ACTIVATED')
   final=self.graph_now();self.stable(final['worker'],before);self.guard(before,base);self.pinned_images(base,True);self.inputs();self.lease();self.stable(self.snapshot(),before);self.inputs();self.journal('TWO_CODE_IMAGES_VERIFIED_NOT_ACTIVATED',workerAfter=final['worker'])
   return dict(status=self.j['phase'],name=self.name,journalSha256=sha((self.dir/'journal.json').read_bytes()),results=self.j['results'],applicationStarted=False,activation=False,dbWrites=0,workerRestarts=0,commandCount=len(self.events))
  except Exception as error:
   self.journal('UNKNOWN_DO_NOT_RETRY'if self.side_effect else'REFUSED_NO_IMAGE_BUILD',failure=dict(code=safe_code(error)),previousPhase=self.j['phase'])
   return dict(status=self.j['phase'],name=self.name,failureCode=safe_code(error),journalSha256=sha((self.dir/'journal.json').read_bytes()),automaticRetry=False,applicationStarted=False,activation=False,dbWrites=0,workerRestarts=0)

def main():
 p=argparse.ArgumentParser(description='Build two verified code-only worker images. Never activate or start worker.')
 for name in('graph','reader','runtime-reader','graph-proof','runtime-proof','decision','bridge'):p.add_argument('--'+name,required=True,type=Path)
 for name in('graph-proof','runtime-proof','decision'):p.add_argument('--'+name+'-sha',required=True)
 p.add_argument('--name',required=True);p.add_argument('--apply',action='store_true');a=p.parse_args()
 try:
  need(a.apply,'EXPLICIT_ROOT_APPLY_REQUIRED');need(os.name=='posix'and os.geteuid()==0,'ROOT_OPERATOR_REQUIRED')
  need(a.graph.parent==ROOT and a.runtime_reader.parent==ROOT,'LOCAL_DEPENDENCY_REQUIRED')
  g=module(a.graph,GRAPH_SHA,GRAPH_BYTES,'accepted_graph');reader=g.load_reader(a.reader);runtime_module=module(a.runtime_reader,RUNTIME_RUNNER_SHA,RUNTIME_RUNNER_BYTES,'accepted_runtime_projection')
  b=Builder(g,reader,runtime_module,ROOT,a.name,a.graph_proof,a.graph_proof_sha,a.reader,a.runtime_proof,a.runtime_proof_sha,a.decision,a.decision_sha,a.bridge);out=b.prepare(True)
 except Exception as error:out=dict(status='REFUSED_BEFORE_OR_UNKNOWN_INSPECT_PRIVATE_ATTEMPT',failureCode=safe_code(error),automaticRetry=False,applicationStarted=False,activation=False,dbWrites=0,workerRestarts=0)
 print(json.dumps(out,sort_keys=True,separators=(',',':')))
if __name__=='__main__':main()
