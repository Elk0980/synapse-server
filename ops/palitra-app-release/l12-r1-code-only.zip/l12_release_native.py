"""Root-only Palitra L12: exact UI14 -> L12 image15; same-code stop16.
No old-code rollback, queue edits, DB migration, key/auth/worker/timer changes.
"""
import argparse,base64,hashlib,json,os,re,sqlite3,stat,sys,types
from datetime import datetime,timezone
from pathlib import Path

ROOT=Path('/opt/synapse/releases/palitra-app-20261015')
UI_HELPER_SHA='8d9e31029da9beee4c8a8a38bdbd7b3282c76cd8a8d0c9e8d3b3be23a6979969'
UI_RECEIPT_SHA='a4cf3b925f4f87d0b095663cc39168e9a0b9a1ae85f49e727b513252c0f2232c'
BASE_IMAGE='sha256:acb33eea59a2b526e1a6f5a53e8958bd962def123162bcd8a4d677f7f94bdeab'
MANIFEST_SHA='750a1e0e4d141b236356ae43fe29f857ab28210bd942a0360f2c36d25f9282a0'
TARGETS={'native-contact-followup.cjs','client-dialogs.js','palitra-push.cjs','palitra-push-host.cjs','server.js','customer-chat-native-adapter.cjs','palitra-orders-public/shell.js'}
FLAG='PALITRA_CONTACT_FOLLOWUP_ENABLED';CUTOFF='PALITRA_CONTACT_FOLLOWUP_ENABLED_AFTER_UTC'
MARKERS='palitra-love/order-contact-followup/v1/'
CONFIG='palitra-love/order-contact-followup/config/v1'
PUSH='palitra-push-private/v1/job/followup/'
FLAGS_JS="console.log(JSON.stringify({enabled:process.env.PALITRA_CONTACT_FOLLOWUP_ENABLED??null,cutoff:process.env.PALITRA_CONTACT_FOLLOWUP_ENABLED_AFTER_UTC??null}));"

def sha(raw):return hashlib.sha256(raw).hexdigest()
def need(ok,code):
 if not ok:raise ValueError(code)
def utc(value):return value.astimezone(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00','Z')
def canonical(value):
 try:return type(value)is str and re.fullmatch(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z',value)is not None and utc(datetime.fromisoformat(value.replace('Z','+00:00')))==value
 except ValueError:return False
for pin in (UI_HELPER_SHA,UI_RECEIPT_SHA,MANIFEST_SHA):need(re.fullmatch('[0-9a-f]{64}',pin)is not None,'BAD_PRODUCTION_PIN_LITERAL')
need(re.fullmatch('sha256:[0-9a-f]{64}',BASE_IMAGE)is not None,'BAD_PRODUCTION_IMAGE_LITERAL')

def loaded(bundle,ui_code):
 path=ui_code/'ui_release_native.py';raw=path.read_bytes();need(not path.is_symlink()and sha(raw)==UI_HELPER_SHA,'EXACT_ACCEPTED_UI_HELPER_REQUIRED')
 u=types.ModuleType('l12_accepted_ui');u.__file__=str(path);exec(compile(raw,str(path),'exec'),u.__dict__)
 pm,inc,c=u.loaded(ROOT);r=inc.Release(c,bundle,pm.MANIFEST_SHA,ROOT)
 return u,u.UIRelease(pm,inc,r,ui_code)

def queue_projection(db_path):
 """Read-only aggregate. Encrypted Push bodies stay encrypted; inactive may be unknown."""
 conn=sqlite3.connect(Path(db_path).as_uri()+'?mode=ro',uri=True,timeout=10,isolation_level=None)
 conn.row_factory=sqlite3.Row
 try:
  conn.execute('PRAGMA query_only=ON');conn.execute('BEGIN')
  rows=conn.execute('SELECT d.key,d.body FROM documents d JOIN (SELECT key,MAX(version) AS version FROM documents WHERE key LIKE ? OR key=? OR key LIKE ? GROUP BY key) v ON v.key=d.key AND v.version=d.version ORDER BY d.key LIMIT 10001',(MARKERS+'%',CONFIG,PUSH+'%')).fetchall()
  need(len(rows)<=10000,'L12_QUEUE_INSPECTION_BOUND_EXCEEDED')
  result={'markerCount':0,'configCutoff':None,'markerStates':{},'telegramStatuses':{},'pushActive':0,'pushInactiveOpaque':0}
  seen=set()
  for row in rows:
   body=json.loads(row['body']);need(type(body)is dict,'L12_DOCUMENT_SHAPE_REFUSED')
   if row['key']==CONFIG:
    need(body.get('schema')==1 and canonical(body.get('enabledAfterUtc')),'L12_STORED_CUTOFF_REFUSED');result['configCutoff']=body['enabledAfterUtc'];continue
   if row['key'].startswith(PUSH):
    need(body.get('schema')==1 and body.get('cipher')=='aes-256-gcm'and type(body.get('active'))is bool,'L12_PUSH_ENVELOPE_REFUSED')
    result['pushActive'if body['active']else'pushInactiveOpaque']+=1;continue
   need(row['key'].startswith(MARKERS)and body.get('schema')==1 and body.get('site')=='palitra'and body.get('companyCode')=='palitra-love'and type(body.get('orderId'))is int and body['orderId']>0 and row['key']==MARKERS+str(body['orderId'])and body.get('state')in ('waiting','emitted','answered','stopped'),'L12_MARKER_SCOPE_REFUSED')
   result['markerCount']+=1;s=body['state'];result['markerStates'][s]=result['markerStates'].get(s,0)+1
   job_id=body.get('telegramJobId')
   if job_id is None:continue
   need(type(job_id)is int and job_id>0 and job_id not in seen,'L12_TELEGRAM_JOB_MAPPING_REFUSED');seen.add(job_id)
   job=conn.execute('SELECT bot_key,company_code,kind,dialog_id,message_id,status FROM client_bot_outbox WHERE id=?',(job_id,)).fetchone()
   need(job is not None and job['bot_key']=='palitra'and job['company_code']=='palitra-love'and job['kind']=='notice'and job['dialog_id']is None and job['message_id']is None and job['status']in ('pending','sending','sent','uncertain','failed'),'L12_TELEGRAM_JOB_SCOPE_REFUSED')
   s=job['status'];result['telegramStatuses'][s]=result['telegramStatuses'].get(s,0)+1
  conn.execute('COMMIT');return result
 finally:conn.close()

class L12Release:
 def __init__(self,u,ui,payload,*,receipt_sha=UI_RECEIPT_SHA,base_image=BASE_IMAGE):
  self.u,self.ui,self.r,self.c,self.a=u,ui,ui.r,ui.c,ui.a
  self.run,self.root,self.now=ui.run,ui.root,ui.now;self.bundle=self.c.path(Path(payload));self.base_image=base_image
  self.receipt_path=self.root/'ui-r1-journal.json';self.receipt_sha=receipt_sha;self.receipt=self.r.pin(self.receipt_path,receipt_sha);s=self.receipt
  need(s.get('phase')=='UI_CONTENT_AND_STATIC_APPLIED_NOT_PUBLIC_PROOF'and s.get('name')=='ui-r1'and s.get('manifestSha256')==u.MANIFEST_SHA and s.get('childImage')==base_image and s.get('workerRecreated')is False and s.get('pushEnabled')is True and s.get('dbWrites')==0,'EXACT_COMPLETED_UI_RECEIPT_REQUIRED')
  self.base=s['after'];self.ui_overlay=self.root/'ui-r1-overlay.json'
  need(s['overlay']==str(self.ui_overlay)and sha(self.c.read(self.ui_overlay))==s['overlaySha256']and self.c.obj(self.c.read(self.ui_overlay))=={'services':{'content':{'image':base_image}}},'EXACT_UI_IMAGE_ONLY_OVERLAY_REQUIRED')
  self.chain=ui.chain+[str(self.ui_overlay)]
  need(self.base['containers']['content']['files']==self.chain and len(self.chain)==len(set(self.chain))==14 and self.base['afterImages']=={'content':base_image,'chat':u.WORKER}and self.base['contentContainerId']==s['contentContainerId']and self.base['containers']['chat']==ui.old['containers']['chat']and self.base['selected']==ui.old['selected'],'EXACT_UI_AFTER_BASE_REQUIRED')
  raw=self.c.read(self.bundle/'HUNK_MANIFEST.json');need(sha(raw)==MANIFEST_SHA,'EXACT_L12_MANIFEST_REQUIRED');self.m=self.c.obj(raw)
  need(self.m.get('schema')==1 and self.m.get('companyCode')=='palitra-love'and self.m.get('workerUnchanged')is True and self.m.get('newTables')is False and self.m.get('newAuth')is False and self.m.get('newTimer')is False and self.m.get('enableByDefault')is False and len(self.m['records'])==8,'EXACT_L12_SCOPE_REQUIRED')
  self.sourcebase=ui.expected_hashes(True);self.inventory=dict(ui.inventory)
  for rec,p in ui.statics:self.inventory[str(p)]=rec['sha256']
  self.statics=[];seen=set();self.pins={str(self.receipt_path):receipt_sha,str(self.ui_overlay):s['overlaySha256'],str(self.bundle/'HUNK_MANIFEST.json'):MANIFEST_SHA}
  for rec in self.m['records']:
   need(set(rec)=={'group','target','payload','baseSha256','sha256','bytes','edits'}and rec['group']in ('content','cabinet')and rec['payload']=='candidate/'+rec['target'].split('/')[-1]and (rec['group'],rec['target'])not in seen,'EXACT_L12_RECORD_REQUIRED');seen.add((rec['group'],rec['target']))
   need(rec['target']in TARGETS if rec['group']=='content'else rec['target']=='shell.js','L12_TARGET_NOT_ALLOWED')
   raw=self.c.read(self.bundle/rec['payload']);need(0<len(raw)<=2097152 and len(raw)==rec['bytes']and sha(raw)==rec['sha256'],'EXACT_L12_PAYLOAD_REQUIRED');self.pins[str(self.bundle/rec['payload'])]=rec['sha256']
   old=raw
   for edit in reversed(rec['edits']):
    after,before=edit['after'].encode(),edit['before'].encode();need(after and old.count(after)==1,'L12_REVERSE_UNIQUE_HUNK_REQUIRED');old=old.replace(after,before,1)
   need(sha(old)==rec['baseSha256'],'L12_EXACT_BASE_RECONSTRUCTION_REQUIRED')
   if rec['group']=='content':need(self.sourcebase.get(rec['target'])==rec['baseSha256'],'L12_CURRENT_SOURCE_BASE_CHANGED')
   else:self.statics.append((rec,self.ui.cabinet/'shell.js'));need(self.inventory[str(self.ui.cabinet/'shell.js')]==rec['baseSha256'],'L12_STATIC_BASE_CHANGED')
  need(seen=={('content',n)for n in TARGETS}|{('cabinet','shell.js')}and len(self.statics)==1,'EXACT_SEVEN_SOURCE_ONE_STATIC_REQUIRED')
  self.helper_path=Path(u.__file__);need(sha(self.c.read(self.helper_path))==UI_HELPER_SHA,'EXACT_UI_DEPENDENCY_REQUIRED');self.pins[str(self.helper_path)]=UI_HELPER_SHA
 def __getattr__(self,name):return getattr(self.r,name)
 def stable(self):
  self.ui.stable()
  for path,pin in self.pins.items():need(sha(self.c.read(Path(path)))==pin,'L12_PINNED_INPUT_CHANGED')
 def paths(self,name):
  need(type(name)is str and re.fullmatch('l12-r[1-9][0-9]{0,3}',name)is not None,'UNIQUE_L12_RN_REQUIRED')
  return {key:self.root/(name+'-'+key+('.json'if key not in ('context','backup')else''))for key in ('decision','journal','overlay','context','backup','stop-decision','stop-journal','stop-overlay')}
 def available(self,name,decision=False):
  paths=self.paths(name)
  for key,path in paths.items():
   self.c.path(path,True)
   if key!='decision'or decision:need(not path.exists()and not Path(str(path)+'.pending').exists(),'L12_ATTEMPT_EXISTS_INSPECT_NO_RETRY')
  return paths
 def cid(self,service='content'):return self.ui.cid(service)
 def flags(self):
  value=self.c.obj(self.run(['docker','exec','synapse-content-1','node','-e',FLAGS_JS]));need(set(value)=={'enabled','cutoff'},'EXACT_L12_FLAG_PROJECTION_REQUIRED');return value
 def queues(self):return queue_projection(self.ui.ps['before']['binding']['hostPath'])
 def expected_hashes(self,new=False):
  out=dict(self.sourcebase)
  if new:
   for rec in self.m['records']:
    if rec['group']=='content':out[rec['target']]=rec['sha256']
  return out
 def static_inventory(self,new=False):
  out=dict(self.inventory)
  if new:
   for rec,path in self.statics:out[str(path)]=rec['sha256']
  for path,pin in out.items():need(self.fingerprint(Path(path))==pin,'L12_STATIC_INVENTORY_CHANGED')
 def metadata(self,image,chain,pins,config):
  b=self.base['containers']['content'];v=self.c.obj(self.run(['docker','inspect','--format',self.c.LABELS,'synapse-content-1']))
  need(set(v)=={'image','project','service','workingDir','configFiles','configHash','running','health'}and v['image']==image and v['project']==b['project']and v['service']=='content'and v['workingDir']==b['workingDir']and v['configHash']==config and v['running']is True and v['health']in (None,'healthy','starting','unhealthy'),'EXACT_L12_CONTENT_METADATA_REQUIRED')
  need(self.c.path(v['workingDir']).is_dir()and type(v['configFiles'])is str and len(v['configFiles'])<=65536,'EXACT_L12_COMPOSE_LABEL_REQUIRED');files=v['configFiles'].split(',')
  need(files==chain and len(files)==len(set(files))and len(files)in (14,15,16),'ONLY_EXACT_L12_CHAIN_ALLOWED')
  actual={name:sha(self.c.read(self.c.path(name)))for name in files};need(actual==pins,'L12_COMPOSE_FILE_CHANGED');v.update(files=files,filePins=actual);return v
 def snapshot(self,image=None,overlays=(),config=None):
  self.stable();self.a.lease();cid=self.cid();need(self.cid('chat')==self.u.WORKER_CID,'L12_WORKER_CHANGED')
  image=image or self.base_image;chain=list(self.chain);pins=dict(self.base['containers']['content']['filePins']);config=config or self.base['containers']['content']['configHash']
  for path,expected in overlays:
   need(self.c.obj(self.c.read(path))==expected,'EXACT_L12_OVERLAY_REQUIRED');chain.append(str(path));pins[str(path)]=sha(self.c.read(path))
  first={'content':self.metadata(image,chain,pins,config),'chat':self.a.metadata('chat')};selected={s:self.a.selected(s)for s in ('content','chat')};proof=self.a.hashproof(first)
  last={'content':self.metadata(image,chain,pins,config),'chat':self.a.metadata('chat')}
  need(first==last and selected=={s:self.a.selected(s)for s in ('content','chat')}and selected==self.base['selected']and last['chat']==self.base['containers']['chat'],'L12_SHARED_OR_WORKER_CONFIG_CHANGED')
  self.a.lease();need(self.cid()==cid and self.cid('chat')==self.u.WORKER_CID,'L12_CID_CHANGED_DURING_SNAPSHOT')
  return {'schema':1,'containers':last,'selected':selected,'afterImages':{'content':image,'chat':self.u.WORKER},'sharedConfigHashProof':proof,'contentContainerId':cid}
 def capture(self):
  snap=self.snapshot();need(snap==self.base and self.flags()['enabled']in (None,'false')and self.flags()['cutoff']in (None,''),'EXACT_UI_CURRENT_BASE_REQUIRED');self.ui.push_guard();self.r.worker({'workerContainerId':self.u.WORKER_CID})
  need(self.hashes(self.expected_hashes())==self.expected_hashes(),'L12_BASE_SOURCE_CHANGED');self.static_inventory();q=self.queues();need(q['markerCount']==0 and q['configCutoff']is None and q['pushActive']==0 and q['pushInactiveOpaque']==0,'L12_EXISTING_STATE_REQUIRES_NEW_ROOT_REVIEW');need(self.cid()==snap['contentContainerId'],'L12_BASE_CID_CHANGED');return snap
 def approve_current(self,name,*,apply=False,cutoff_now=False):
  need(apply is True and cutoff_now is True,'EXPLICIT_ROOT_FRESH_CUTOFF_REQUIRED');p=self.available(name,True);started=self.now();cutoff=utc(started);snap=self.capture();self.stable();self.a.lease();need(0<=(self.now()-started).total_seconds()<=600 and self.cid()==snap['contentContainerId'],'L12_APPROVAL_STALE_OR_CHANGED')
  d={'schema':1,'scope':'L12_SEVEN_SOURCE_ONE_STATIC_FRESH_CUTOFF','name':name,'rootApproved':True,'manifestSha256':MANIFEST_SHA,'uiReceiptSha256':self.receipt_sha,'image':self.base_image,'cutoff':cutoff,'observedAtUtc':started.isoformat(),'before':snap};self.c.create(p['decision'],d)
  return {'status':'L12_ROOT_DECISION_READY_NOT_ACTIVATED','decisionSha256':sha(self.c.read(p['decision'])),'cutoff':cutoff,'dbWrites':0,'runtimeWrites':0}
 def decision(self,name,pin):
  path=self.paths(name)['decision'];d=self.r.pin(path,pin)
  need(set(d)=={'schema','scope','name','rootApproved','manifestSha256','uiReceiptSha256','image','cutoff','observedAtUtc','before'}and d['schema']==1 and d['scope']=='L12_SEVEN_SOURCE_ONE_STATIC_FRESH_CUTOFF'and d['name']==name and d['rootApproved']is True and d['manifestSha256']==MANIFEST_SHA and d['uiReceiptSha256']==self.receipt_sha and d['image']==self.base_image and canonical(d['cutoff']),'EXACT_L12_ROOT_DECISION_REQUIRED')
  at=datetime.fromisoformat(d['observedAtUtc']);need(at.tzinfo is not None and utc(at)==d['cutoff']and 0<=(self.now()-at).total_seconds()<=600,'L12_DECISION_STALE_OR_FUTURE');return d
 def before(self,d):need(self.capture()==d['before'],'L12_APPROVED_BASE_CHANGED')
 def patch(self,*args):return self.ui.inc.Release.patch(self,*args)
 def tree(self,*args):return self.ui.inc.Release.tree(self,*args)
 def context_proof(self,*args):return self.ui.inc.Release.context_proof(self,*args)
 def overlay(self,image,cutoff,enabled):return {'services':{'content':{'image':image,'environment':{FLAG:'true'if enabled else'false',CUTOFF:cutoff}}}}
 def apply(self,name,pin,*,apply=False):
  need(apply is True,'EXPLICIT_ROOT_L12_APPLY_REQUIRED');p=self.available(name);d=self.decision(name,pin);self.before(d);before=d['before'];alias='palitra-l12-base:'+name;tag='palitra-l12:'+name
  self.unused(alias);self.unused(tag);need(self.run(['docker','image','inspect','--format','{{.Id}}',self.base_image]).decode().strip()==self.base_image,'EXACT_L12_PARENT_REQUIRED');layers=self.c.obj(self.run(['docker','image','inspect','--format','{{json .RootFS.Layers}}',self.base_image]));need(type(layers)is list and layers,'L12_PARENT_LAYERS_REQUIRED')
  context,backup,journal=p['context'],p['backup'],p['journal'];context.mkdir(mode=0o700);backup.mkdir(mode=0o700)
  s={'schema':1,'name':name,'phase':'L12_CONTEXT_STARTED_UNKNOWN','manifestSha256':MANIFEST_SHA,'uiReceiptSha256':self.receipt_sha,'decisionSha256':pin,'before':before,'cutoff':d['cutoff'],'workerRecreated':False,'pushEnabled':True,'dbWrites':0,'static':[]};self.c.create(journal,s)
  for rec in self.m['records']:
   if rec['group']!='content':continue
   encoded=self.run(['docker','exec','synapse-content-1','node','-e',self.ui.inc.SOURCE_JS,rec['target']]);need(len(encoded)<=3*1024*1024,'L12_BOUNDED_SOURCE_REQUIRED');raw=self.patch(base64.b64decode(encoded,validate=True),rec);path=context/'app'/rec['target'];path.parent.mkdir(parents=True,exist_ok=True,mode=0o755);self.u.write(path,raw,0o644)
  for i,(rec,path)in enumerate(self.statics):
   old=self.c.read(path);raw=self.patch(old,rec);mode=stat.S_IMODE(path.stat().st_mode);prepared=context/'static'/str(i);prepared.parent.mkdir(mode=0o700,exist_ok=True);self.u.write(prepared,raw);self.u.write(backup/str(i),old);s['static'].append({'target':str(path),'baseSha256':rec['baseSha256'],'sha256':rec['sha256'],'mode':mode,'prepared':str(prepared),'backup':str(backup/str(i)),'written':False})
  self.u.write(context/'Dockerfile',('FROM '+alias+'\nCOPY app/ /app/\n').encode());s['contextSha256']=self.context_proof(context,s,alias);self.c.replace(journal,s)
  self.before(d);self.unused(alias);self.a.lease();self.decision(name,pin);self.run(['docker','image','tag',self.base_image,alias]);need(self.run(['docker','image','inspect','--format','{{.Id}}',alias]).decode().strip()==self.base_image,'L12_PARENT_ALIAS_CHANGED')
  s['phase']='L12_BUILD_STARTED_UNKNOWN';self.c.replace(journal,s);self.unused(tag);self.a.lease();need(self.context_proof(context,s,alias)==s['contextSha256']and self.cid()==before['contentContainerId']and self.run(['docker','image','inspect','--format','{{.Id}}',alias]).decode().strip()==self.base_image,'L12_LAST_BUILD_INPUT_CHANGED');self.stable();self.decision(name,pin)
  iid=context/'image.id';self.run(['docker','build','--network=none','--pull=false','--tag',tag,'--iidfile',str(iid),str(context)]);child=self.c.read(iid).decode().strip();need(self.c.image(child)and child!=self.base_image,'L12_EXACT_CHILD_REQUIRED');need(self.context_proof(context,s,alias,True)==s['contextSha256'],'L12_BUILD_CONTEXT_CHANGED');need(self.run(['docker','image','inspect','--format','{{.Id}}',tag]).decode().strip()==child,'L12_CHILD_TAG_CHANGED');cl=self.c.obj(self.run(['docker','image','inspect','--format','{{json .RootFS.Layers}}',child]));need(cl[:len(layers)]==layers and len(cl)==len(layers)+1,'L12_SINGLE_COPY_PARENT_REQUIRED');expected=self.expected_hashes(True);need(self.hashes(expected,child)==expected,'L12_CHILD_FULL_SOURCE_MISMATCH')
  self.before(d);self.decision(name,pin);s.update(phase='L12_STATIC_STARTED_UNKNOWN',childImage=child);self.c.replace(journal,s)
  for rec in s['static']:
   path=Path(rec['target']);need(self.fingerprint(path)==rec['baseSha256'],'L12_STATIC_CAS_CONFLICT');raw=self.c.read(Path(rec['prepared']));need(sha(raw)==rec['sha256'],'L12_PREPARED_STATIC_CHANGED');self.atomic(path,raw,rec['mode']);rec['written']=True;self.c.replace(journal,s)
  content=self.overlay(child,d['cutoff'],True);self.c.create(p['overlay'],content);op=sha(self.c.read(p['overlay']));planned=self.plan_hash(before,p['overlay']);s.update(phase='L12_CONTENT_UP_STARTED_UNKNOWN',overlay=str(p['overlay']),overlaySha256=op,plannedConfigHash=planned);self.c.replace(journal,s)
  self.stable();need(self.snapshot()==before,'L12_PRE_UP_BASE_CHANGED');need(self.hashes(self.expected_hashes())==self.expected_hashes(),'L12_PRE_UP_SOURCE_CHANGED');self.static_inventory(True);self.ui.push_guard();self.r.worker({'workerContainerId':self.u.WORKER_CID});self.a.lease();need(sha(self.c.read(p['overlay']))==op and self.context_proof(context,s,alias,True)==s['contextSha256']and self.cid()==before['contentContainerId'],'L12_LAST_UP_INPUT_CHANGED');self.decision(name,pin)
  self.run(self.command(before,p['overlay'],['up','--detach','--no-build','--pull','never','--no-deps','content']))
  self.ui.push_guard();after=self.snapshot(child,[(p['overlay'],content)],planned);need(after['contentContainerId']!=before['contentContainerId'],'L12_CONTENT_RECREATION_EXPECTED');need(self.flags()=={'enabled':'true','cutoff':d['cutoff']},'L12_ACTIVE_FLAGS_CHANGED');need(self.hashes(expected)==expected,'L12_ACTIVE_SOURCE_CHANGED');self.static_inventory(True);self.stable();q=self.queues();need(q['configCutoff']in (None,d['cutoff']),'L12_ACTIVE_STORED_CUTOFF_CHANGED');need(self.cid()==after['contentContainerId'],'L12_CID_CHANGED_DURING_READBACK');s.update(phase='L12_CONTENT_AND_STATIC_APPLIED_NOT_DELIVERY_PROOF',after=after,queues=q);self.c.replace(journal,s)
  return {'status':s['phase'],'journalSha256':sha(self.c.read(journal)),'contentImage':child,'cutoff':d['cutoff'],'workerRecreated':False,'dbWrites':0,'deviceDeliveryProven':False,'automaticCodeRollback':False}
 def active(self,name,receipt_pin):
  p=self.paths(name);s=self.r.pin(p['journal'],receipt_pin);need(s.get('phase')=='L12_CONTENT_AND_STATIC_APPLIED_NOT_DELIVERY_PROOF'and s.get('name')==name and s.get('manifestSha256')==MANIFEST_SHA and s.get('uiReceiptSha256')==self.receipt_sha and s.get('workerRecreated')is False and s.get('pushEnabled')is True and canonical(s.get('cutoff')),'COMPLETED_EXACT_L12_RECEIPT_REQUIRED');need(s['overlay']==str(p['overlay'])and sha(self.c.read(p['overlay']))==s['overlaySha256'],'L12_APPLIED_OVERLAY_CHANGED')
  overlay=self.overlay(s['childImage'],s['cutoff'],True);snap=self.snapshot(s['childImage'],[(p['overlay'],overlay)],s['plannedConfigHash']);need(snap==s['after']and self.flags()=={'enabled':'true','cutoff':s['cutoff']},'L12_ACTIVE_BASE_CHANGED');self.ui.push_guard();need(self.hashes(self.expected_hashes(True))==self.expected_hashes(True),'L12_STOP_SOURCE_CHANGED');self.static_inventory(True);need(self.cid()==snap['contentContainerId'],'L12_ACTIVE_CID_CHANGED_DURING_READ');return p,s,snap
 def approve_stop(self,name,receipt_pin,*,apply=False):
  need(apply is True,'EXPLICIT_ROOT_SAME_CODE_STOP_REQUIRED');at=self.now();p,s,snap=self.active(name,receipt_pin)
  for key in ('stop-decision','stop-journal','stop-overlay'):need(not p[key].exists()and not Path(str(p[key])+'.pending').exists(),'L12_STOP_ATTEMPT_EXISTS_INSPECT_NO_RETRY')
  q=self.queues();need(q['configCutoff']in (None,s['cutoff']),'L12_STOP_STORED_CUTOFF_CHANGED');self.stable();self.a.lease();need(0<=(self.now()-at).total_seconds()<=600 and self.cid()==snap['contentContainerId'],'L12_STOP_APPROVAL_STALE_OR_CHANGED');d={'schema':1,'scope':'L12_SAME_CODE_FLAG_FALSE_NO_QUEUE_EDITS','rootApproved':True,'name':name,'receiptSha256':receipt_pin,'observedAtUtc':at.isoformat(),'before':snap,'cutoff':s['cutoff'],'queues':q};self.c.create(p['stop-decision'],d)
  return {'status':'L12_SAME_CODE_STOP_APPROVED','decisionSha256':sha(self.c.read(p['stop-decision'])),'queues':q,'oldCodeRollbackAllowed':False}
 def stop_decision(self,name,pin,receipt_pin):
  d=self.r.pin(self.paths(name)['stop-decision'],pin);need(set(d)=={'schema','scope','rootApproved','name','receiptSha256','observedAtUtc','before','cutoff','queues'}and d['schema']==1 and d['scope']=='L12_SAME_CODE_FLAG_FALSE_NO_QUEUE_EDITS'and d['rootApproved']is True and d['name']==name and d['receiptSha256']==receipt_pin and canonical(d['cutoff']),'EXACT_L12_STOP_DECISION_REQUIRED');at=datetime.fromisoformat(d['observedAtUtc']);need(at.tzinfo is not None and 0<=(self.now()-at).total_seconds()<=600,'L12_STOP_DECISION_STALE_OR_FUTURE');return d
 def stop(self,name,receipt_pin,decision_pin,*,apply=False):
  need(apply is True,'EXPLICIT_ROOT_STOP_APPLY_REQUIRED');p,s,before=self.active(name,receipt_pin);d=self.stop_decision(name,decision_pin,receipt_pin);need(before==d['before']and s['cutoff']==d['cutoff'],'L12_STOP_APPROVED_BASE_CHANGED')
  for key in ('stop-journal','stop-overlay'):need(not p[key].exists()and not Path(str(p[key])+'.pending').exists(),'L12_STOP_ATTEMPT_EXISTS_INSPECT_NO_RETRY')
  overlay=self.overlay(s['childImage'],s['cutoff'],False);self.c.create(p['stop-overlay'],overlay);op=sha(self.c.read(p['stop-overlay']));planned=self.plan_hash(before,p['stop-overlay']);j={'schema':1,'phase':'L12_SAME_CODE_STOP_STARTED_UNKNOWN','name':name,'receiptSha256':receipt_pin,'decisionSha256':decision_pin,'before':before,'cutoff':s['cutoff'],'overlaySha256':op,'plannedConfigHash':planned};self.c.create(p['stop-journal'],j)
  self.active(name,receipt_pin);self.a.lease();need(sha(self.c.read(p['stop-overlay']))==op and self.cid()==before['contentContainerId'],'L12_LAST_STOP_INPUT_CHANGED');self.stop_decision(name,decision_pin,receipt_pin);self.run(self.command(before,p['stop-overlay'],['up','--detach','--no-build','--pull','never','--no-deps','content']))
  self.ui.push_guard();after=self.snapshot(s['childImage'],[(p['overlay'],self.overlay(s['childImage'],s['cutoff'],True)),(p['stop-overlay'],overlay)],planned);need(self.flags()=={'enabled':'false','cutoff':s['cutoff']}and after['contentContainerId']!=before['contentContainerId'],'L12_STOP_FLAG_OR_CID_CHANGED');need(self.hashes(self.expected_hashes(True))==self.expected_hashes(True),'L12_STOP_NEW_CODE_CHANGED');self.static_inventory(True);q=self.queues();need(q['configCutoff']in (None,s['cutoff']),'L12_STOP_CUTOFF_DRIFT');self.stable();need(self.cid()==after['contentContainerId'],'L12_STOP_CID_CHANGED_DURING_READBACK');j.update(phase='L12_SAME_CODE_STOPPED_QUEUES_REQUIRE_INSPECTION',after=after,queues=q);self.c.replace(p['stop-journal'],j)
  return {'status':j['phase'],'journalSha256':sha(self.c.read(p['stop-journal'])),'queues':q,'cutoff':s['cutoff'],'newCodePreserved':True,'oldCodeRollbackAllowed':False,'dbWrites':0,'workerRecreated':False}
 def inspect_stopped(self,name,stop_pin):
  p=self.paths(name);j=self.r.pin(p['stop-journal'],stop_pin);need(j.get('phase')=='L12_SAME_CODE_STOPPED_QUEUES_REQUIRE_INSPECTION'and j.get('name')==name,'COMPLETED_L12_STOP_RECEIPT_REQUIRED');s=self.r.pin(p['journal'],j['receiptSha256']);need(sha(self.c.read(p['stop-overlay']))==j['overlaySha256'],'L12_STOP_OVERLAY_CHANGED');after=self.snapshot(s['childImage'],[(p['overlay'],self.overlay(s['childImage'],s['cutoff'],True)),(p['stop-overlay'],self.overlay(s['childImage'],s['cutoff'],False))],j['plannedConfigHash']);need(after==j['after']and self.flags()=={'enabled':'false','cutoff':s['cutoff']},'L12_STOPPED_RUNTIME_CHANGED');self.ui.push_guard();need(self.hashes(self.expected_hashes(True))==self.expected_hashes(True),'L12_STOPPED_SOURCE_CHANGED');self.static_inventory(True);q=self.queues()
  return {'status':'L12_STOPPED_READONLY_QUEUE_PROJECTION','queues':q,'telegramPendingOrInflight':sum(q['telegramStatuses'].get(k,0)for k in ('pending','sending','uncertain')),'pushPendingOrSending':q['pushActive'],'pushInactiveMayIncludeUnknown':q['pushInactiveOpaque'],'oldCodeRollbackAllowed':False,'mutations':0}

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('operation',choices=('approve-current','apply','approve-stop','stop','inspect-stopped'));p.add_argument('--bundle',type=Path,required=True);p.add_argument('--ui-code',type=Path,default=ROOT/'ui-code-r1');p.add_argument('--payload',type=Path,default=Path(__file__).parent);p.add_argument('--name',required=True);p.add_argument('--decision-sha');p.add_argument('--receipt-sha');p.add_argument('--stop-sha');p.add_argument('--enable-cutoff-now',action='store_true');p.add_argument('--apply',action='store_true');args=p.parse_args()
 try:
  need(os.name=='posix'and os.geteuid()==0,'NATIVE_ROOT_REQUIRED');need(args.operation=='inspect-stopped'or args.apply is True,'EXPLICIT_ROOT_ACTION_REQUIRED');u,ui=loaded(args.bundle,args.ui_code);r=L12Release(u,ui,args.payload)
  if args.operation=='approve-current':out=r.approve_current(args.name,apply=args.apply,cutoff_now=args.enable_cutoff_now)
  elif args.operation=='apply':out=r.apply(args.name,args.decision_sha,apply=args.apply)
  elif args.operation=='approve-stop':out=r.approve_stop(args.name,args.receipt_sha,apply=args.apply)
  elif args.operation=='stop':out=r.stop(args.name,args.receipt_sha,args.decision_sha,apply=args.apply)
  else:out=r.inspect_stopped(args.name,args.stop_sha)
  print(json.dumps(out,separators=(',',':')));return 0
 except BaseException as error:
  msg=str(error);code=msg if re.fullmatch('[A-Z][A-Z0-9_]{0,100}',msg)else'ACCEPTED_GUARD_REFUSED';print(json.dumps({'status':'L12_REFUSED_UNKNOWN_INSPECT_DO_NOT_RETRY','operation':args.operation,'code':code,'errorClass':type(error).__name__,'messageSha256':sha(msg.encode()),'automaticRetry':False,'oldCodeRollbackAllowed':False},separators=(',',':')));return 2
if __name__=='__main__':sys.exit(main())
