"""Inspect an existing private Docker reserve archive. Never build, export, run or activate."""
import argparse,gzip,hashlib,io,json,os,re,stat,subprocess,tarfile,time,types
from datetime import datetime,timezone
from pathlib import Path

ROOT=Path('/opt/synapse/releases/palitra-app-20261015')
ATTEMPT='worker-images-photo-r1'
BASE='sha256:e67514e5d0f6c46656005e1b693b2ec9d52e80b641307de684d4a015ba7a4eaf'
TAG='palitra-worker-reserve:'+ATTEMPT
JOURNAL_SHA='c589190ac41ba50c3e49573caf8c8994a5010ca2f8a134926943d690f96b3b43'
GRAPH_SHA='2c57ff64c0074f725c4c1709152076a4a35a67ddc1f1d43a8bcf715d3fa8aa23'
GRAPH_BYTES=8533
READER_SHA='26010f48a7e88a9d3dda6fef05fb61caa6a1358cb3e6a780f2e892aa5abc2a4f'
OPTIONS_SHA='543b8e67253492993423c87495f783f002206c3aaf5504a09311ce00e29ea650'
MAX_ARCHIVE=350*1024*1024
MAX_ADDED=2*1024*1024
IMAGE_FMT='{"Id":{{json .Id}},"Os":{{json .Os}},"Architecture":{{json .Architecture}},"Size":{{json .Size}},"RootFS":{{json .RootFS}},"Config":{{json .Config}}}'
sha=lambda b:hashlib.sha256(b).hexdigest()
canon=lambda v:json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode()
def need(v,code):
 if not v:raise ValueError(code)
def ident(v):return type(v)is str and re.fullmatch(r'sha256:[0-9a-f]{64}',v)is not None
def safe_error(e):return str(e)if type(e)is ValueError and re.fullmatch('[A-Z0-9_]{1,90}',str(e))else'READONLY_OBSERVATION_REFUSED'
def name(v):
 need(type(v)is str and 0<len(v)<=240 and not v.startswith('/')and'\\'not in v and re.fullmatch(r'[A-Za-z0-9_./-]+',v)is not None,'UNSUPPORTED_ARCHIVE_PATH')
 v=v.rstrip('/');need(v and all(x not in ('','.','..')for x in v.split('/')),'UNSUPPORTED_ARCHIVE_PATH');return v
def timestamp_headers(value):
 return type(value)is dict and set(value)<={'mtime','atime','ctime'}and all(type(v)is str and re.fullmatch(r'-?[0-9]{1,20}(?:\.[0-9]{1,9})?',v)is not None for v in value.values())
def fp_hash(fp,limit,check=None):
 h=hashlib.sha256();size=0
 while True:
  if check:check()
  part=fp.read(65536)
  if not part:break
  size+=len(part);need(size<=limit,'FILE_SIZE_BOUND');h.update(part)
 return h.hexdigest(),size
def private_file(path,limit):
 path=Path(path);need(path.is_absolute()and not path.is_symlink()and path.resolve(strict=True)==path,'EXACT_PRIVATE_PATH_REQUIRED')
 s=path.stat();need(stat.S_ISREG(s.st_mode)and s.st_uid==0 and stat.S_IMODE(s.st_mode)==0o600 and 0<=s.st_size<=limit,'ROOT_PRIVATE_FILE_REQUIRED')
 return s
def signature(s):return(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
def read_pin(path,pin,limit,private=True):
 path=Path(path)
 if private:before=private_file(path,limit)
 else:
  need(path.is_absolute()and not path.is_symlink()and path.resolve(strict=True)==path,'EXACT_CODE_PATH_REQUIRED');before=path.stat();need(stat.S_ISREG(before.st_mode)and before.st_size<=limit,'CODE_SIZE_BOUND')
 fd=os.open(path,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0)|getattr(os,'O_BINARY',0))
 with os.fdopen(fd,'rb')as f:
  need(signature(os.fstat(f.fileno()))==signature(before),'INPUT_RACE');raw=f.read(limit+1);after=os.fstat(f.fileno())
 need(len(raw)<=limit and signature(after)==signature(before)==signature(path.stat())and sha(raw)==pin,'PINNED_INPUT_CHANGED');return raw
def load_graph(path):
 raw=read_pin(path,GRAPH_SHA,GRAPH_BYTES,False);need(len(raw)==GRAPH_BYTES,'EXACT_GRAPH_SIZE_REQUIRED');m=types.ModuleType('accepted_graph');m.__file__=str(path);exec(compile(raw,str(path),'exec'),m.__dict__);return m
def image_facts(v):
 need(type(v)is dict and set(v)=={'Id','Os','Architecture','Size','RootFS','Config'}and ident(v['Id'])and v['Os']=='linux'and v['Architecture']=='amd64'and type(v['Size'])is int and 0<v['Size']<MAX_ARCHIVE,'EXACT_BOUNDED_IMAGE_FACTS_REQUIRED')
 r=v['RootFS'];need(type(r)is dict and set(r)=={'Type','Layers'}and r['Type']=='layers'and type(r['Layers'])is list and 1<=len(r['Layers'])<=128 and all(ident(x)for x in r['Layers']),'EXACT_LAYER_FACTS_REQUIRED')
 need(type(v['Config'])is dict,'IMAGE_CONFIG_REQUIRED');return v
def layer_tar(raw,expected):
 need(len(raw)<=MAX_ADDED,'ADDED_LAYER_BOUND');seen=set();files={};dirs=[]
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:')as inner:
  for i,m in enumerate(inner):
   need(i<32 and timestamp_headers(m.pax_headers),'UNSUPPORTED_ADDED_LAYER_HEADERS');n=name(m.name);need(n not in seen,'DUPLICATE_ADDED_MEMBER');seen.add(n)
   need(not m.linkname and m.uid==0 and m.gid==0,'ADDED_MEMBER_OWNER_OR_LINK_REFUSED')
   if m.isdir():need(n=='app'and m.mode==0o755 and m.size==0,'DIRECTORY_METADATA_OUTSIDE_APP');dirs.append(n);continue
   need(m.isreg()and n.startswith('app/')and n[4:]in expected and m.mode==0o600,'UNEXPECTED_ADDED_MEMBER')
   local=n[4:];size,digest=expected[local];need(m.size==size,'EXACT_SOURCE_SIZE_REQUIRED')
   digest_actual,count=fp_hash(inner.extractfile(m),size);need(count==size and digest_actual==digest,'EXACT_SOURCE_BYTES_REQUIRED');files[local]=dict(size=size,sha256=digest,mode=m.mode)
 need(not files or set(files)==set(expected),'COPY_LAYER_EXACT_TEN_REQUIRED')
 return dict(kind='COPY_EXACT_TEN'if files else'APP_DIRECTORY_METADATA_ONLY',files=files,directories=dirs,members=sorted(seen),decodedBytes=len(raw),zeroOnly=not any(raw),tarSha256=sha(raw))
def archive_proof(fileobj,base,child,expected,check=None):
 """Observed 17-member OCI layout with Docker compatibility manifest only."""
 base=image_facts(base);child=image_facts(child);bl=base['RootFS']['Layers'];cl=child['RootFS']['Layers']
 need(base['Id']==BASE and len(bl)==4 and len(cl)==6 and cl[:len(bl)]==bl and child['Id']!=base['Id'],'EXACT_FOUR_PLUS_TWO_LAYER_PREFIX_REQUIRED')
 with tarfile.open(fileobj=fileobj,mode='r:')as outer:
  members={}
  for i,m in enumerate(outer):
   if check:check()
   need(i<17 and timestamp_headers(m.pax_headers),'UNSUPPORTED_OUTER_ARCHIVE_HEADERS');n=name(m.name);need(n not in members and(m.isreg()or m.isdir())and not m.linkname,'UNSUPPORTED_OUTER_MEMBER');members[n]=m
  def small(n,limit):
   need(n in members and members[n].isreg()and 0<=members[n].size<=limit,'REQUIRED_ARCHIVE_MEMBER');return outer.extractfile(members[n]).read(limit+1)
  manifest=json.loads(small('manifest.json',65536));need(type(manifest)is list and len(manifest)==1,'SINGLE_DOCKER_MANIFEST_REQUIRED');entry=manifest[0]
  need(type(entry)is dict and set(entry)=={'Config','RepoTags','Layers'}and entry['RepoTags']is None,'SUPPORTED_DOCKER_MANIFEST_REQUIRED')
  config_name=name(entry['Config']);paths=entry['Layers'];need(type(paths)is list and len(paths)==6 and len(set(paths))==6,'EXACT_SIX_ARCHIVE_LAYERS_REQUIRED');paths=[name(v)for v in paths]
  blob_pattern=r'blobs/sha256/[0-9a-f]{64}'
  need(re.fullmatch(blob_pattern,config_name)and all(re.fullmatch(blob_pattern,v)for v in paths),'SUPPORTED_OBSERVED_OCI_BLOB_LAYOUT_REQUIRED')
  blob_names={n for n in members if re.fullmatch(blob_pattern,n)};metadata={'manifest.json','index.json','oci-layout'};directories={'blobs','blobs/sha256'}
  need(len(members)==17 and len(blob_names)==12 and set(members)==metadata|directories|blob_names and all(members[n].isdir()for n in directories)and all(members[n].isreg()for n in metadata|blob_names),'UNSUPPORTED_OCI_ARCHIVE_MEMBERS')
  need(json.loads(small('oci-layout',1024))=={'imageLayoutVersion':'1.0.0'},'SUPPORTED_OCI_LAYOUT_VERSION_REQUIRED')
  index_type='application/vnd.oci.image.index.v1+json';manifest_type='application/vnd.oci.image.manifest.v1+json'
  def descriptor_path(d):
   need(type(d)is dict and{'mediaType','digest','size'}<=set(d)<={'mediaType','digest','size','platform','annotations'}and type(d['mediaType'])is str and 0<len(d['mediaType'])<=128 and ident(d.get('digest'))and type(d.get('size'))is int and 0<d['size']<=MAX_ARCHIVE,'BOUNDED_OCI_DESCRIPTOR_REQUIRED');p='blobs/sha256/'+d['digest'][7:];need(p in blob_names and members[p].size==d['size'],'OCI_DESCRIPTOR_BLOB_REQUIRED');return p
  index=json.loads(small('index.json',65536));need(type(index)is dict and set(index)=={'schemaVersion','mediaType','manifests'}and index['schemaVersion']==2 and index['mediaType']==index_type and type(index['manifests'])is list and len(index['manifests'])==1,'SUPPORTED_OCI_ROOT_INDEX_REQUIRED')
  root_descriptor=index['manifests'][0];root_path=descriptor_path(root_descriptor);need(set(root_descriptor)=={'mediaType','digest','size'}and root_descriptor['mediaType']==index_type and root_descriptor['digest']==child['Id'],'ACTUAL_IMAGE_ID_OCI_INDEX_BINDING_REQUIRED')
  for p in sorted(blob_names):
   actual,size=fp_hash(outer.extractfile(members[p]),MAX_ARCHIVE,check);need(size==members[p].size and actual==p.rsplit('/',1)[1],'CONTENT_ADDRESSED_BLOB_HASH_MISMATCH')
  nested=json.loads(small(root_path,65536));need(type(nested)is dict and set(nested)=={'schemaVersion','mediaType','manifests'}and nested['schemaVersion']==2 and nested['mediaType']==index_type and type(nested['manifests'])is list and len(nested['manifests'])==2,'OBSERVED_NESTED_OCI_INDEX_REQUIRED')
  selected=[]
  for d in nested['manifests']:
   descriptor_path(d);need(d['mediaType']==manifest_type and type(d.get('platform'))is dict and set(d['platform'])=={'architecture','os'},'OBSERVED_OCI_PLATFORM_DESCRIPTOR_REQUIRED')
   if d['platform']=={'architecture':'amd64','os':'linux'}:need(set(d)=={'mediaType','digest','size','platform'},'EXACT_NATIVE_DESCRIPTOR_FIELDS_REQUIRED');selected.append(d)
   else:need(d['platform']=={'architecture':'unknown','os':'unknown'}and set(d)=={'mediaType','digest','size','platform','annotations'},'UNSUPPORTED_NON_NATIVE_OCI_PLATFORM')
  need(len(selected)==1,'SINGLE_NATIVE_OCI_MANIFEST_REQUIRED');native=selected[0];native_path=descriptor_path(native);image_manifest=json.loads(small(native_path,65536))
  attestation=next(d for d in nested['manifests']if d is not native);need(attestation.get('annotations')=={'vnd.docker.reference.type':'attestation-manifest','vnd.docker.reference.digest':native['digest']},'EXACT_ATTESTATION_DESCRIPTOR_BINDING_REQUIRED')
  need(type(image_manifest)is dict and set(image_manifest)=={'schemaVersion','mediaType','config','layers'}and image_manifest['schemaVersion']==2 and image_manifest['mediaType']==manifest_type and type(image_manifest['layers'])is list and len(image_manifest['layers'])==6,'OBSERVED_NATIVE_OCI_IMAGE_MANIFEST_REQUIRED')
  cfg_descriptor=image_manifest['config'];need(descriptor_path(cfg_descriptor)==config_name and cfg_descriptor['mediaType']=='application/vnd.oci.image.config.v1+json','OCI_DOCKER_CONFIG_BINDING_REQUIRED')
  for d,p in zip(image_manifest['layers'],paths):
   need(descriptor_path(d)==p,'OCI_DOCKER_LAYER_BINDING_REQUIRED')
  config_raw=small(config_name,1024*1024);need(sha(config_raw)==config_name.rsplit('/',1)[1],'EXACT_SAVED_IMAGE_CONFIG_DIGEST_REQUIRED');config=json.loads(config_raw)
  need(type(config)is dict and config.get('rootfs')=={'type':'layers','diff_ids':cl}and config.get('os')=='linux'and config.get('architecture')=='amd64','SAVED_CONFIG_ROOTFS_REQUIRED')
  conf=config.get('config');need(type(conf)is dict and conf==child['Config'],'SAVED_CONFIG_INSPECT_MISMATCH')
  need(conf.get('Cmd')==['node','server.js']and conf.get('WorkingDir')=='/app'and conf.get('User','')==''and conf.get('Entrypoint')==base['Config'].get('Entrypoint')and conf.get('Env')==base['Config'].get('Env')and conf.get('OnBuild')in(None,[])and conf.get('Volumes')in(None,{})and conf.get('Healthcheck')is None,'EXACT_RESERVE_STARTUP_AND_BASE_ENV_REQUIRED')
  added=[];decoded_total=0;compression=[]
  for index,p in enumerate(paths):
   need(p in members and members[p].isreg()and members[p].size<=MAX_ARCHIVE,'REGULAR_BOUNDED_LAYER_REQUIRED');raw_stream=outer.extractfile(members[p]);magic=raw_stream.read(2);raw_stream.seek(0);compressed=magic==b'\x1f\x8b';stream=gzip.GzipFile(fileobj=raw_stream,mode='rb')if compressed else raw_stream;compression.append('gzip'if compressed else'raw-tar')
   if index<4:actual,size=fp_hash(stream,MAX_ARCHIVE-decoded_total,check)
   else:
    body=stream.read(MAX_ADDED+1);need(len(body)<=MAX_ADDED,'ADDED_LAYER_BOUND');actual,size=sha(body),len(body);added.append(layer_tar(body,expected));added[-1].update(diffId=cl[index],blobDigest='sha256:'+p.rsplit('/',1)[1],compression=compression[-1])
   decoded_total+=size;need(decoded_total<=MAX_ARCHIVE and'sha256:'+actual==cl[index],'CRYPTOGRAPHIC_LAYER_DIFFID_MISMATCH');stream.close();raw_stream.close()
  need([x['kind']for x in added]==['COPY_EXACT_TEN','APP_DIRECTORY_METADATA_ONLY'],'EXACT_COPY_THEN_DIRECTORY_LAYER_REQUIRED')
  return dict(baseLayers=4,reserveLayers=6,fullBasePrefix=True,layerDiffIdsVerified=6,contentAddressedBlobsVerified=12,decodedLayerBytes=decoded_total,compression=compression,addedLayerDiffIds=cl[4:],addedLayers=added,imageIdBinding={'ociIndex':child['Id'],'nativeManifest':native['digest'],'configDigest':cfg_descriptor['digest']},imageConfigSha256=sha(config_raw),sourceFiles=10,allTenExact=True,layerProofScope='BASE_LAYERS_STREAM_HASH_ONLY_ADDED_TARS_PARSED_NO_EXTRACTION',completeRootfsEquivalence=False)

class Reader:
 def __init__(self,graph,accepted,root,archive_sha,execute=None,clock=None):
  self.g=graph;self.a=accepted;self.root=Path(root);self.archive_sha=archive_sha;self.execute=execute or subprocess.run;self.now=clock or time.monotonic;self.started=self.now();self.events=[]
  self.private=self.root/('.'+ATTEMPT);self.journal=self.private/'journal.json';self.context=self.private/'old';self.archive=self.private/'reserve-image-r1.tar'
  self.allowed=[['lslocks','--json','--output','PID,MODE,PATH'],['docker','inspect','--format',accepted.INSPECT,'synapse-chat-1']]+[['docker','image','inspect','--format',IMAGE_FMT,v]for v in [BASE,TAG]]
  self.reader=accepted.Reader(execute=self.reader_exec)
 def budget(self):need(self.now()-self.started<=60,'READONLY_TOTAL_BUDGET_EXCEEDED')
 def run(self,args):
  need(args in self.allowed,'READONLY_COMMAND_NOT_ALLOWED');self.budget();left=60-(self.now()-self.started);need(left>=1,'READONLY_TOTAL_BUDGET_EXCEEDED')
  try:r=self.execute(args,capture_output=True,stdin=subprocess.DEVNULL,shell=False,timeout=min(15,left))
  except subprocess.TimeoutExpired:raise ValueError('READONLY_TIMEOUT_NO_RETRY')from None
  out,err=r.stdout or b'',r.stderr or b'';self.events.append(dict(command=self.allowed.index(args),rc=r.returncode,stdoutBytes=len(out),stderrSha256=sha(err)));need(len(out)<=1024*1024 and len(err)<=65536 and r.returncode==0,'READONLY_COMMAND_FAILED');return out
 def reader_exec(self,args,**kwargs):
  need(kwargs==dict(capture_output=True,stdin=subprocess.DEVNULL,shell=False,timeout=30),'EXACT_ACCEPTED_READER_CALL_REQUIRED');return subprocess.CompletedProcess(args,0,self.run(args),b'')
 def snapshot(self):return self.a.safe_snapshot(self.reader.snapshot())
 def inputs(self):
  need(self.root.is_absolute()and self.root.resolve(strict=True)==self.root and not self.root.is_symlink(),'EXACT_RELEASE_ROOT_REQUIRED')
  for p in[self.private,self.context]:
   s=p.stat();need(p.resolve(strict=True)==p and not p.is_symlink()and stat.S_ISDIR(s.st_mode)and s.st_uid==0 and stat.S_IMODE(s.st_mode)==0o700,'EXACT_PRIVATE_CONTEXT_REQUIRED')
  journal=json.loads(read_pin(self.journal,JOURNAL_SHA,1024*1024));need(journal.get('name')==ATTEMPT and journal.get('phase')=='UNKNOWN_DO_NOT_RETRY'and journal.get('previousPhase')=='OLD_BUILT_NOT_VERIFIED'and journal.get('failure')=={'code':'EXACT_NODE_PLUS_ONE_COPY_LAYER_REQUIRED'}and journal.get('results')=={}and journal.get('acceptedExistingNodeOptionsSha256')==OPTIONS_SHA,'EXACT_UNCHANGED_UNKNOWN_JOURNAL_REQUIRED')
  need({p.name for p in self.context.iterdir()}==set(self.g.EXPECTED)|{'Dockerfile'},'EXACT_CLOSED_OLD_CONTEXT_REQUIRED')
  for n,(size,pin)in self.g.EXPECTED.items():need(len(read_pin(self.context/n,pin,size))==size,'CONTEXT_SOURCE_SIZE_REQUIRED')
  df=('FROM palitra-worker-nodebase:'+ATTEMPT+'\nCOPY '+json.dumps(sorted(self.g.EXPECTED)+['/app/'],separators=(',',':'))+'\nWORKDIR /app\nCMD ["node","server.js"]\n').encode();need(read_pin(self.context/'Dockerfile',sha(df),4096)==df,'EXACT_ORIGINAL_DOCKERFILE_REQUIRED');return journal
 def observe(self):
  out=dict(schema=1,status='READONLY_RESERVE_OBSERVATION_INCOMPLETE',observedAtUtc=datetime.now(timezone.utc).isoformat(),commands=self.events,applicationStarted=False,activation=False,builds=0,exports=0,dbWrites=0,workerRestarts=0,oldJournalUnmodified=True,oldJournalStillUnknown=None,buildApproved=False,rollbackApproved=False,automaticRetry=False)
  try:
   need(re.fullmatch('[0-9a-f]{64}',self.archive_sha or''),'ARCHIVE_PIN_REQUIRED');journal=self.inputs();self.reader.lease();before=self.snapshot();need(before==journal['workerBefore'],'CURRENT_WORKER_CHANGED')
   base=image_facts(json.loads(self.run(self.allowed[2])));child=image_facts(json.loads(self.run(self.allowed[3])));st=private_file(self.archive,MAX_ARCHIVE)
   fd=os.open(self.archive,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0)|getattr(os,'O_BINARY',0))
   with os.fdopen(fd,'rb')as fp:
    need(signature(os.fstat(fp.fileno()))==signature(st),'ARCHIVE_RACE');digest,size=fp_hash(fp,MAX_ARCHIVE,self.budget);need(digest==self.archive_sha and size==st.st_size,'EXACT_ARCHIVE_PIN_REQUIRED');self.budget();fp.seek(0);proof=archive_proof(fp,base,child,self.g.EXPECTED,self.budget);self.budget();fp.seek(0);again,sz=fp_hash(fp,MAX_ARCHIVE,self.budget);need(again==digest and sz==size and signature(os.fstat(fp.fileno()))==signature(st)==signature(self.archive.stat()),'ARCHIVE_CHANGED_DURING_OBSERVATION')
   self.inputs();self.reader.lease();after=self.snapshot();need(after==before and image_facts(json.loads(self.run(self.allowed[2])))==base and image_facts(json.loads(self.run(self.allowed[3])))==child,'FINAL_WORKER_IMAGE_OR_TAG_CHANGED');self.reader.lease();self.budget()
   out.update(status='EXISTING_RESERVE_LAYERS_OBSERVED_NOT_BUILD_OR_ACTIVATION_APPROVAL',archiveSha256=digest,archiveBytes=size,journalSha256=JOURNAL_SHA,oldJournalStillUnknown=True,baseImage=base['Id'],reserveImage=child['Id'],baseLayersSha256=sha(canon(base['RootFS'])),reserveLayersSha256=sha(canon(child['RootFS'])),reserveConfigOpaqueSha256=sha(canon(child['Config'])),workerBefore=before,workerAfter=after,proof=proof)
  except Exception as e:out['failure']={'code':safe_error(e)}
  return out
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--graph',required=True,type=Path);p.add_argument('--reader',required=True,type=Path);p.add_argument('--archive-sha',required=True);p.add_argument('--observe',action='store_true');args=p.parse_args()
 try:
  need(args.observe and os.name=='posix'and os.geteuid()==0,'EXPLICIT_NATIVE_ROOT_READONLY_REQUIRED');need(args.graph.parent==ROOT,'ROOT_LOCAL_GRAPH_REQUIRED');g=load_graph(args.graph);accepted=g.load_reader(args.reader);out=Reader(g,accepted,ROOT,args.archive_sha).observe()
 except Exception as e:out=dict(status='READONLY_RESERVE_OBSERVATION_INCOMPLETE',failure={'code':safe_error(e)},applicationStarted=False,activation=False,builds=0,exports=0,dbWrites=0,workerRestarts=0,oldJournalStillUnknown=True,buildApproved=False,automaticRetry=False)
 print(json.dumps(out,sort_keys=True,separators=(',',':')))
if __name__=='__main__':main()
