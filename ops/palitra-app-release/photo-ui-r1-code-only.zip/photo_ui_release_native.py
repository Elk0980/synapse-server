"""Root-only exact completed L12 image15 -> photo/label UI image16.
Uploads stay false; L12 enabled/cutoff, Push, worker and data stay unchanged.
No automatic retry, old-code rollback, queue/key/DB/auth/worker changes.
"""
import argparse,base64,hashlib,json,os,re,stat,sys,types
from datetime import datetime
from pathlib import Path

ROOT=Path('/opt/synapse/releases/palitra-app-20261015')
L12_HELPER_SHA='4801ae0c4cf3e4a1253f803af6ad41a7d1c5a969c9662844655b77c5c6dbf697'
L12_RECEIPT_SHA='52dd742110b26b0e1158c4768717849f433e2b0799d26bb7efa163af1e66e4ed'
BASE_IMAGE='sha256:08b91ce601621360677d436c1475bc242d1842b3a6e400ff6850cd844876ce08'
CUTOFF='2026-10-15T10:33:38.177Z'
MANIFEST_SHA='a7fd983fa493736590cd9d30f84e384fcf505a51aeeabd89a46c9b7158fcda9a'
ASSETS={'attachments-ui.js','attachments-ui.css'}
IMAGE_WEB={'shell.js','synapse-bridge.js','native-host.js','shop.html'}|ASSETS
STATIC_WEB={'shell.js','synapse-bridge.js','native-host.js','cabinet.html'}|ASSETS
SOURCE_TARGETS={'palitra-orders-public/'+n for n in IMAGE_WEB}|{'palitra-host-adapter.cjs'}
PAYLOADS={'payload/web/'+n for n in IMAGE_WEB|STATIC_WEB}|{'payload/content/palitra-host-adapter.cjs'}

def sha(raw):return hashlib.sha256(raw).hexdigest()
def need(ok,code):
 if not ok:raise ValueError(code)
for pin in (L12_HELPER_SHA,L12_RECEIPT_SHA,MANIFEST_SHA):need(re.fullmatch('[0-9a-f]{64}',pin)is not None,'BAD_PRODUCTION_PIN_LITERAL')
need(re.fullmatch('sha256:[0-9a-f]{64}',BASE_IMAGE)is not None,'BAD_PRODUCTION_IMAGE_LITERAL')

def loaded(bundle,ui_code,l12_code):
 path=l12_code/'l12_release_native.py';raw=path.read_bytes();need(not path.is_symlink()and sha(raw)==L12_HELPER_SHA,'EXACT_ACCEPTED_L12_HELPER_REQUIRED')
 x=types.ModuleType('photo_accepted_l12');x.__file__=str(path);exec(compile(raw,str(path),'exec'),x.__dict__)
 u,ui=x.loaded(bundle,ui_code);return x,x.L12Release(u,ui,l12_code)

class PhotoRelease:
 def __init__(self,x,l,payload,*,receipt_sha=L12_RECEIPT_SHA,base_image=BASE_IMAGE,cutoff=CUTOFF):
  self.x,self.l,self.u,self.ui,self.r,self.c,self.a=x,l,l.u,l.ui,l.r,l.c,l.a
  self.run,self.root,self.now=l.run,l.root,l.now;self.bundle=self.c.path(Path(payload));self.base_image=base_image;self.cutoff=cutoff;self.receipt_sha=receipt_sha
  need(x.canonical(cutoff),'EXACT_CANONICAL_CUTOFF_REQUIRED');self.lp=l.paths('l12-r1');s=self.r.pin(self.lp['journal'],receipt_sha);self.receipt=s
  need(s.get('phase')=='L12_CONTENT_AND_STATIC_APPLIED_NOT_DELIVERY_PROOF'and s.get('name')=='l12-r1'and s.get('manifestSha256')==x.MANIFEST_SHA and s.get('uiReceiptSha256')==l.receipt_sha and s.get('childImage')==base_image and s.get('cutoff')==cutoff and s.get('workerRecreated')is False and s.get('pushEnabled')is True and s.get('dbWrites')==0,'EXACT_COMPLETED_L12_BASE_REQUIRED')
  self.l12_overlay=l.overlay(base_image,cutoff,True);need(s['overlay']==str(self.lp['overlay'])and sha(self.c.read(self.lp['overlay']))==s['overlaySha256']and self.c.obj(self.c.read(self.lp['overlay']))==self.l12_overlay,'EXACT_L12_OVERLAY_REQUIRED')
  self.base=s['after'];need(self.base['containers']['content']['files']==l.chain+[str(self.lp['overlay'])]and len(self.base['containers']['content']['files'])==15 and self.base['afterImages']=={'content':base_image,'chat':self.u.WORKER}and self.base['selected']==l.base['selected']and self.base['containers']['chat']==l.base['containers']['chat'],'EXACT_L12_CHAIN15_REQUIRED')
  self.sourcebase=l.expected_hashes(True);need(len(self.sourcebase)==200,'EXACT_L12_SOURCE200_REQUIRED');self.inventory=dict(l.inventory)
  for rec,path in l.statics:self.inventory[str(path)]=rec['sha256']
  raw=self.c.read(self.bundle/'MANIFEST.json');need(sha(raw)==MANIFEST_SHA,'EXACT_PHOTO_LABEL_MANIFEST_REQUIRED');m=self.c.obj(raw);self.manifest=m
  need(m.get('schema')==1 and m.get('status')=='LOCAL_COMPOSITION_OF_ACCEPTED_CODE_NOT_INSTALLED_NO_INSTALLER'and m.get('uploadsFlagChanged')is False and m.get('workerChanged')is False and m.get('sequence')==['exact-L12-base','accepted-photo-wiring','accepted-canonical-client-label']and len(m['records'])==8,'EXACT_PHOTO_LABEL_SCOPE_REQUIRED')
  self.records={};self.m={'records':[]};self.statics=[];seen=set();self.pins={str(self.lp['journal']):receipt_sha,str(self.lp['overlay']):s['overlaySha256'],str(self.bundle/'MANIFEST.json'):MANIFEST_SHA}
  helper=Path(x.__file__);need(sha(self.c.read(helper))==L12_HELPER_SHA,'EXACT_L12_DEPENDENCY_REQUIRED');self.pins[str(helper)]=L12_HELPER_SHA
  self.helper=Path(__file__);self.helper_sha=sha(self.c.read(self.helper));self.pins[str(self.helper)]=self.helper_sha
  for rec in m['records']:
   n=rec['path'];need(n in PAYLOADS and n not in self.records and type(rec['new'])is bool and 0<rec['bytes']<=2097152,'EXACT_PHOTO_RECORD_REQUIRED');self.records[n]=rec;raw=self.c.read(self.bundle/n);need(sha(raw)==rec['sha256']and len(raw)==rec['bytes'],'EXACT_PHOTO_PAYLOAD_REQUIRED');self.pins[str(self.bundle/n)]=rec['sha256'];self.reconstruct(rec,raw)
   for target in rec['targets']:
    kind,name=target['kind'],target['relativePath'];need((kind,name)not in seen,'DUPLICATE_PHOTO_TARGET');seen.add((kind,name));isnew=Path(n).name in ASSETS
    need(target['new']is isnew and rec['new']is isnew and target['expectedPresence']==('absent'if isnew else'file')and target['baseSha256']==rec['baseSha256']and target['baseBytes']==rec['baseBytes']and target['finalSha256']==rec['sha256']and target['finalBytes']==rec['bytes'],'EXACT_PHOTO_TARGET_PINS_REQUIRED')
    if kind=='content-image':
     need(name in SOURCE_TARGETS and target['path']=='/app/'+name and n==('payload/content/palitra-host-adapter.cjs'if name=='palitra-host-adapter.cjs'else'payload/web/'+Path(name).name),'EXACT_PHOTO_IMAGE_TARGET_REQUIRED');need((name not in self.sourcebase)if isnew else self.sourcebase.get(name)==rec['baseSha256'],'PHOTO_SOURCE_BASE_NOT_L12');self.m['records'].append({'group':'content','target':name,'sha256':rec['sha256'],'payload':n})
    else:
     need(kind=='cabinet-static'and name in STATIC_WEB and n=='payload/web/'+name and target['path']=='/opt/synapse/sites/synapse/cabinet/palitra-orders/'+name,'EXACT_PHOTO_STATIC_TARGET_REQUIRED');path=self.ui.cabinet/name
     need((str(path)not in self.inventory)if isnew else self.inventory.get(str(path))==rec['baseSha256'],'PHOTO_STATIC_BASE_NOT_L12');self.statics.append((rec,path))
  need(set(self.records)==PAYLOADS and seen=={('content-image',n)for n in SOURCE_TARGETS}|{('cabinet-static',n)for n in STATIC_WEB}and len(self.m['records'])==7 and len(self.statics)==6,'EXACT_EIGHT_PAYLOAD_THIRTEEN_TARGETS_REQUIRED')
 def __getattr__(self,name):return getattr(self.l,name)
 def reconstruct(self,rec,raw):
  if rec['new']:
   need(rec['baseSha256']is None and rec['baseBytes']is None and not rec['hunks'],'NEW_ASSET_MUST_HAVE_NO_BASE');return None
  old=raw
  for h in reversed(rec['hunks']):
   a,b=h['after'].encode(),h['before'].encode();need(a and old.count(a)==1,'PHOTO_REVERSE_UNIQUE_HUNK_REQUIRED');old=old.replace(a,b,1)
  if 'baseNormalization'in rec:
   need(rec['path']in ('payload/web/synapse-bridge.js','payload/web/native-host.js')and rec['baseNormalization']=='explicit-CRLF-to-LF-after-raw-pin'and sha(old)==rec['baseLfSha256'],'EXACT_PHOTO_NORMALIZATION_REQUIRED')
   if sha(old)!=rec['baseSha256']:old=old.replace(b'\n',b'\r\n')
  need(sha(old)==rec['baseSha256']and len(old)==rec['baseBytes'],'PHOTO_EXACT_BASE_RECONSTRUCTION_REQUIRED');return old
 def patch(self,raw,rec):
  need(not rec['new']and sha(raw)==rec['baseSha256']and len(raw)==rec['baseBytes'],'PHOTO_LIVE_BASE_BYTES_CHANGED')
  if 'baseNormalization'in rec:raw=raw.replace(b'\r\n',b'\n');need(sha(raw)==rec['baseLfSha256'],'PHOTO_RAW_PIN_BEFORE_NORMALIZATION_REQUIRED')
  for h in rec['hunks']:
   a,b=h['before'].encode(),h['after'].encode();need(a and raw.count(a)==1,'PHOTO_UNIQUE_HUNK_REQUIRED');raw=raw.replace(a,b,1)
  need(sha(raw)==rec['sha256']and len(raw)==rec['bytes']and raw==self.c.read(self.bundle/rec['path']),'PHOTO_FINAL_BYTES_MISMATCH');return raw
 def stable(self):
  self.l.stable()
  for path,pin in self.pins.items():need(sha(self.c.read(Path(path)))==pin,'PHOTO_PINNED_INPUT_CHANGED')
 def expected_hashes(self,new=False):
  out=dict(self.sourcebase)
  for rec in self.m['records']:out[rec['target']]=rec['sha256']if new else self.records[rec['payload']]['baseSha256']
  need(len(out)==202,'EXACT_PHOTO_INVENTORY202_REQUIRED');return out
 def static_inventory(self,new=False):
  out=dict(self.inventory)
  for rec,path in self.statics:out[str(path)]=rec['sha256']if new else rec['baseSha256']
  for path,pin in out.items():
   p=self.c.path(Path(path),True);need(not os.path.lexists(p)if pin is None else p.is_file()and sha(self.c.read(p))==pin,'PHOTO_STATIC_INVENTORY_CHANGED')
 def flags_guard(self):
  need(self.l.flags()=={'enabled':'true','cutoff':self.cutoff},'PHOTO_L12_FLAGS_MUST_STAY_EXACT');need(self.a.selected('content')['PALITRA_WEB_UPLOADS_ENABLED']=='false','PHOTO_UPLOADS_MUST_STAY_FALSE');self.ui.push_guard()
 def capture(self):
  self.stable();_,s,snap=self.l.active('l12-r1',self.receipt_sha);need(snap==self.base and s['childImage']==self.base_image,'PHOTO_CURRENT_L12_BASE_CHANGED');self.flags_guard();need(self.hashes(self.expected_hashes())==self.expected_hashes(),'PHOTO_BASE_SOURCE_OR_ABSENCE_CHANGED');self.static_inventory();need(self.cid()==snap['contentContainerId'],'PHOTO_CID_CHANGED_DURING_CAPTURE');return snap
 def paths(self,name):
  need(type(name)is str and re.fullmatch('photo-ui-r[1-9][0-9]{0,3}',name)is not None,'UNIQUE_PHOTO_UI_RN_REQUIRED');return {k:self.root/(name+'-'+k+('.json'if k in ('decision','journal','overlay')else''))for k in ('decision','journal','overlay','context','backup')}
 def available(self,name,decision=False):
  paths=self.paths(name)
  for k,path in paths.items():
   self.c.path(path,True)
   if k!='decision'or decision:need(not os.path.lexists(path)and not os.path.lexists(str(path)+'.pending'),'PHOTO_ATTEMPT_EXISTS_INSPECT_NO_RETRY')
  return paths
 def approve_current(self,name,*,apply=False):
  need(apply is True,'EXPLICIT_ROOT_PHOTO_APPROVAL_REQUIRED');p=self.available(name,True);at=self.now();snap=self.capture();self.stable();self.a.lease();need(self.cid()==snap['contentContainerId']and 0<=(self.now()-at).total_seconds()<=600,'PHOTO_APPROVAL_STALE_OR_CHANGED');d={'schema':1,'scope':'PHOTO_LABEL_IMAGE_ONLY_UPLOADS_FALSE_L12_PRESERVED','name':name,'rootApproved':True,'manifestSha256':MANIFEST_SHA,'helperSha256':self.helper_sha,'l12ReceiptSha256':self.receipt_sha,'image':self.base_image,'cutoff':self.cutoff,'observedAtUtc':at.isoformat(),'before':snap};self.c.create(p['decision'],d)
  return {'status':'PHOTO_UI_ROOT_DECISION_READY_NOT_APPLIED','decisionSha256':sha(self.c.read(p['decision'])),'imageSourceFilesBefore':200,'imageSourceFilesAfter':202,'imageCopyFiles':7,'staticTargets':6,'absenceTargets':4,'uploadsEnabled':False,'dbWrites':0,'runtimeWrites':0}
 def decision(self,name,pin):
  d=self.r.pin(self.paths(name)['decision'],pin);need(set(d)=={'schema','scope','name','rootApproved','manifestSha256','helperSha256','l12ReceiptSha256','image','cutoff','observedAtUtc','before'}and d['schema']==1 and d['scope']=='PHOTO_LABEL_IMAGE_ONLY_UPLOADS_FALSE_L12_PRESERVED'and d['name']==name and d['rootApproved']is True and d['manifestSha256']==MANIFEST_SHA and d['helperSha256']==self.helper_sha and d['l12ReceiptSha256']==self.receipt_sha and d['image']==self.base_image and d['cutoff']==self.cutoff,'EXACT_PHOTO_ROOT_DECISION_REQUIRED');at=datetime.fromisoformat(d['observedAtUtc']);need(at.tzinfo is not None and 0<=(self.now()-at).total_seconds()<=600,'PHOTO_DECISION_STALE_OR_FUTURE');return d
 def before(self,d):need(self.capture()==d['before'],'PHOTO_APPROVED_BASE_CHANGED')
 def tree(self,*args):return self.ui.inc.Release.tree(self,*args)
 def context_proof(self,*args):return self.ui.inc.Release.context_proof(self,*args)
 def publish_new(self,path,raw,mode):
  self.c.path(path,True);need(not os.path.lexists(path),'PHOTO_NEW_STATIC_ABSENCE_CONFLICT');pending=Path(str(path)+'.photo-pending');self.c.path(pending,True);self.u.write(pending,raw,mode)
  # Atomic publication without replacement. A competing target wins and is kept.
  os.link(pending,path,follow_symlinks=False);pending.unlink();need(sha(self.c.read(path))==sha(raw),'PHOTO_NEW_STATIC_READBACK_FAILED')
 def apply(self,name,pin,*,apply=False):
  need(apply is True,'EXPLICIT_ROOT_PHOTO_APPLY_REQUIRED');p=self.available(name);d=self.decision(name,pin);self.before(d);before=d['before'];alias='palitra-photo-ui-base:'+name;tag='palitra-photo-ui:'+name
  self.unused(alias);self.unused(tag);need(self.run(['docker','image','inspect','--format','{{.Id}}',self.base_image]).decode().strip()==self.base_image,'EXACT_LOCAL_L12_PARENT_REQUIRED');layers=self.c.obj(self.run(['docker','image','inspect','--format','{{json .RootFS.Layers}}',self.base_image]));need(type(layers)is list and layers,'PHOTO_PARENT_LAYERS_REQUIRED')
  context,backup,journal=p['context'],p['backup'],p['journal'];context.mkdir(mode=0o700);backup.mkdir(mode=0o700);s={'schema':1,'name':name,'phase':'PHOTO_UI_CONTEXT_STARTED_UNKNOWN','manifestSha256':MANIFEST_SHA,'helperSha256':self.helper_sha,'l12ReceiptSha256':self.receipt_sha,'decisionSha256':pin,'before':before,'cutoff':self.cutoff,'workerRecreated':False,'pushEnabled':True,'uploadsEnabled':False,'dbWrites':0,'automaticCodeRollback':False,'static':[]};self.c.create(journal,s)
  for rr in self.m['records']:
   rec=self.records[rr['payload']]
   if rec['new']:raw=self.c.read(self.bundle/rec['path'])
   else:
    encoded=self.run(['docker','exec','synapse-content-1','node','-e',self.ui.inc.SOURCE_JS,rr['target']]);need(len(encoded)<=3*1024*1024,'PHOTO_BOUNDED_SOURCE_REQUIRED');raw=self.patch(base64.b64decode(encoded,validate=True),rec)
   path=context/'app'/rr['target'];path.parent.mkdir(mode=0o755,parents=True,exist_ok=True);self.u.write(path,raw,0o644)
  for i,(rec,path)in enumerate(self.statics):
   if rec['new']:self.c.path(path,True);need(not os.path.lexists(path),'PHOTO_NEW_STATIC_ABSENCE_CONFLICT');raw=self.c.read(self.bundle/rec['path']);mode=0o644;b=None
   else:
    old=self.c.read(path);raw=self.patch(old,rec);mode=stat.S_IMODE(path.stat().st_mode);b=backup/str(i);self.u.write(b,old)
   prepared=context/'static'/str(i);prepared.parent.mkdir(mode=0o700,exist_ok=True);self.u.write(prepared,raw);s['static'].append({'target':str(path),'baseSha256':rec['baseSha256'],'sha256':rec['sha256'],'mode':mode,'prepared':str(prepared),'backup':str(b)if b else None,'new':rec['new'],'written':False})
  self.u.write(context/'Dockerfile',('FROM '+alias+'\nCOPY app/ /app/\n').encode());s['contextSha256']=self.context_proof(context,s,alias);self.c.replace(journal,s)
  self.before(d);self.unused(alias);self.a.lease();self.decision(name,pin);self.run(['docker','image','tag',self.base_image,alias]);need(self.run(['docker','image','inspect','--format','{{.Id}}',alias]).decode().strip()==self.base_image,'PHOTO_PARENT_ALIAS_CHANGED');s['phase']='PHOTO_UI_BUILD_STARTED_UNKNOWN';self.c.replace(journal,s)
  self.unused(tag);self.a.lease();need(self.context_proof(context,s,alias)==s['contextSha256']and self.cid()==before['contentContainerId']and self.run(['docker','image','inspect','--format','{{.Id}}',alias]).decode().strip()==self.base_image,'PHOTO_LAST_BUILD_INPUT_CHANGED');self.stable();self.decision(name,pin);iid=context/'image.id';self.run(['docker','build','--network=none','--pull=false','--tag',tag,'--iidfile',str(iid),str(context)]);child=self.c.read(iid).decode().strip();need(self.c.image(child)and child!=self.base_image,'PHOTO_EXACT_CHILD_REQUIRED');need(self.context_proof(context,s,alias,True)==s['contextSha256'],'PHOTO_BUILD_CONTEXT_CHANGED');need(self.run(['docker','image','inspect','--format','{{.Id}}',tag]).decode().strip()==child,'PHOTO_CHILD_TAG_CHANGED');cl=self.c.obj(self.run(['docker','image','inspect','--format','{{json .RootFS.Layers}}',child]));need(cl[:len(layers)]==layers and len(cl)==len(layers)+1,'PHOTO_SINGLE_COPY_PARENT_REQUIRED');expected=self.expected_hashes(True);need(self.hashes(expected,child)==expected,'PHOTO_CHILD_FULL_SOURCE_MISMATCH')
  self.before(d);self.decision(name,pin);s.update(phase='PHOTO_UI_STATIC_STARTED_UNKNOWN',childImage=child);self.c.replace(journal,s)
  for rec in s['static']:
   if rec['backup']:need(sha(self.c.read(Path(rec['backup'])))==rec['baseSha256'],'PHOTO_PRIVATE_BACKUP_CHANGED')
  for rec in s['static']:
   path=self.c.path(Path(rec['target']),True);raw=self.c.read(Path(rec['prepared']));need(sha(raw)==rec['sha256'],'PHOTO_PREPARED_STATIC_CHANGED')
   if rec['new']:self.publish_new(path,raw,rec['mode'])
   else:need(self.fingerprint(path)==rec['baseSha256'],'PHOTO_STATIC_CAS_CONFLICT');self.atomic(path,raw,rec['mode'])
   rec['written']=True;self.c.replace(journal,s)
  overlay={'services':{'content':{'image':child}}};self.c.create(p['overlay'],overlay);op=sha(self.c.read(p['overlay']));planned=self.plan_hash(before,p['overlay']);s.update(phase='PHOTO_UI_CONTENT_UP_STARTED_UNKNOWN',overlay=str(p['overlay']),overlaySha256=op,plannedConfigHash=planned);self.c.replace(journal,s)
  self.stable();need(self.l.snapshot(self.base_image,[(self.lp['overlay'],self.l12_overlay)],self.receipt['plannedConfigHash'])==before,'PHOTO_PRE_UP_L12_BASE_CHANGED');need(self.hashes(self.expected_hashes())==self.expected_hashes(),'PHOTO_PRE_UP_SOURCE_OR_ABSENCE_CHANGED');self.static_inventory(True);self.flags_guard();self.a.lease()
  for rec in s['static']:
   if rec['backup']:need(sha(self.c.read(Path(rec['backup'])))==rec['baseSha256'],'PHOTO_LAST_BACKUP_CHANGED')
  need(sha(self.c.read(p['overlay']))==op and self.context_proof(context,s,alias,True)==s['contextSha256']and self.cid()==before['contentContainerId'],'PHOTO_LAST_UP_INPUT_CHANGED');self.decision(name,pin)
  self.run(self.command(before,p['overlay'],['up','--detach','--no-build','--pull','never','--no-deps','content']))
  self.flags_guard();after=self.l.snapshot(child,[(self.lp['overlay'],self.l12_overlay),(p['overlay'],overlay)],planned);need(after['contentContainerId']!=before['contentContainerId'],'PHOTO_CONTENT_RECREATION_EXPECTED');need(self.hashes(expected)==expected,'PHOTO_ACTIVE_FULL_SOURCE_CHANGED');self.static_inventory(True);self.stable();need(self.cid()==after['contentContainerId'],'PHOTO_CID_CHANGED_DURING_READBACK');s.update(phase='PHOTO_UI_CONTENT_AND_STATIC_APPLIED_NOT_UPLOAD_OR_DELIVERY_PROOF',after=after);self.c.replace(journal,s)
  return {'status':s['phase'],'journalSha256':sha(self.c.read(journal)),'contentImage':child,'workerRecreated':False,'pushEnabled':True,'uploadsEnabled':False,'l12Enabled':True,'cutoff':self.cutoff,'dbWrites':0,'deviceDeliveryProven':False,'automaticCodeRollback':False}
 def inspect_completed(self,name,pin):
  p=self.paths(name);s=self.r.pin(p['journal'],pin);need(s.get('phase')=='PHOTO_UI_CONTENT_AND_STATIC_APPLIED_NOT_UPLOAD_OR_DELIVERY_PROOF'and s.get('name')==name and s.get('manifestSha256')==MANIFEST_SHA and s.get('helperSha256')==self.helper_sha and s.get('l12ReceiptSha256')==self.receipt_sha and s.get('cutoff')==self.cutoff and s.get('workerRecreated')is False and s.get('uploadsEnabled')is False and s.get('dbWrites')==0,'COMPLETED_EXACT_PHOTO_RECEIPT_REQUIRED');overlay={'services':{'content':{'image':s['childImage']}}};need(s['overlay']==str(p['overlay'])and sha(self.c.read(p['overlay']))==s['overlaySha256'],'PHOTO_APPLIED_OVERLAY_CHANGED');self.flags_guard();snap=self.l.snapshot(s['childImage'],[(self.lp['overlay'],self.l12_overlay),(p['overlay'],overlay)],s['plannedConfigHash']);need(snap==s['after'],'PHOTO_COMPLETED_RUNTIME_CHANGED');need(self.hashes(self.expected_hashes(True))==self.expected_hashes(True),'PHOTO_COMPLETED_SOURCE_CHANGED');self.static_inventory(True);self.stable();need(self.cid()==snap['contentContainerId'],'PHOTO_INSPECTION_CID_CHANGED');return {'status':'PHOTO_UI_COMPLETED_READONLY_NOT_UPLOAD_OR_DELIVERY_PROOF','sourceFiles':202,'workerRecreated':False,'uploadsEnabled':False,'l12Enabled':True,'cutoff':self.cutoff,'mutations':0,'automaticCodeRollback':False}

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('operation',choices=('approve-current','apply','inspect-completed'));p.add_argument('--bundle',type=Path,required=True);p.add_argument('--ui-code',type=Path,default=ROOT/'ui-code-r1');p.add_argument('--l12-code',type=Path,default=ROOT/'l12-code-r1');p.add_argument('--payload',type=Path,default=Path(__file__).parent);p.add_argument('--name',required=True);p.add_argument('--decision-sha');p.add_argument('--receipt-sha');p.add_argument('--apply',action='store_true');args=p.parse_args()
 try:
  need(os.name=='posix'and os.geteuid()==0,'NATIVE_ROOT_REQUIRED');need(args.operation=='inspect-completed'or args.apply is True,'EXPLICIT_ROOT_ACTION_REQUIRED');x,l=loaded(args.bundle,args.ui_code,args.l12_code);r=PhotoRelease(x,l,args.payload)
  if args.operation=='approve-current':out=r.approve_current(args.name,apply=args.apply)
  elif args.operation=='apply':out=r.apply(args.name,args.decision_sha,apply=args.apply)
  else:out=r.inspect_completed(args.name,args.receipt_sha)
  print(json.dumps(out,separators=(',',':')));return 0
 except BaseException as error:
  msg=str(error);code=msg if re.fullmatch('[A-Z][A-Z0-9_]{0,100}',msg)else'ACCEPTED_GUARD_REFUSED';print(json.dumps({'status':'PHOTO_UI_REFUSED_UNKNOWN_INSPECT_DO_NOT_RETRY','operation':args.operation,'code':code,'errorClass':type(error).__name__,'messageSha256':sha(msg.encode()),'automaticRetry':False,'automaticCodeRollback':False},separators=(',',':')));return 2
if __name__=='__main__':sys.exit(main())
