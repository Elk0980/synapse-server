"""Root entrypoint draft. Root freezes HELPER_SHA after acceptance; no retries."""
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import types

ROOT = Path('/opt/synapse/releases/palitra-app-20261015')
CODE = ROOT / 'palitra-editor-chat-guide-code-r1'
HELPER_SHA = '0ae393d971f63ab97721e240d52fcfd6b3eca34deb94e11ab313773f8d580a1c'  # UNFROZEN: deliberately refuse native use.
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def main():
    try:
        if HELPER_SHA == '0' * 64:
            raise ValueError('DRAFT_NOT_FROZEN_NO_NATIVE_ACTION')
        if os.name != 'posix' or os.geteuid() != 0 or Path(__file__).resolve().parent != CODE:
            raise ValueError('NATIVE_ROOT_EXACT_CODE_DIRECTORY_REQUIRED')
        path = CODE / 'editor_chat_guide_release_native.py'
        # Check every parent before loading executable code.
        for part in [*reversed(path.parents), path]:
            if part.is_symlink():
                raise ValueError('SYMLINK_REFUSED')
        raw = path.read_bytes()
        if sha(raw) != HELPER_SHA:
            raise ValueError('FROZEN_HELPER_REQUIRED')
        module = types.ModuleType('accepted_editor_chat_guide_release')
        module.__file__ = str(path)
        exec(compile(raw, str(path), 'exec'), module.__dict__)
        return module.main()
    except Exception as error:
        message = str(error)
        code = message if type(error) is ValueError and re.fullmatch('[A-Z][A-Z0-9_]{0,100}', message) else 'ENTRY_REFUSED'
        print(json.dumps({'status': 'ENTRY_REFUSED_NO_AUTOMATIC_RETRY', 'code': code, 'messageSha256': sha(message.encode()), 'automaticRetry': False}, separators=(',', ':')))
        return 2


if __name__ == '__main__':
    sys.exit(main())
