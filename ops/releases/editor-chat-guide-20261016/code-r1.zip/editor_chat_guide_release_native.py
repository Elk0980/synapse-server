"""Isolated Root successor draft: exact chain21 -> sealed22, no worker/DB writes.

UNFROZEN manifest pin deliberately prevents native use until Root acceptance.
Frozen predecessors are constructed only to validate immutable historical lineage.
"""
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys
import time

ROOT = Path('/opt/synapse/releases/palitra-app-20261015')
CODE_NAME = 'palitra-editor-chat-guide-code-r1'
NAME = 'palitra-editor-chat-guide-r1'
PHASE = 'EDITOR_CHAT_GUIDE_APPLIED_NOT_DEVICE_OR_CUSTOMER_ACCEPTANCE'
SCOPE = 'EXACT_EDITOR4_PRODUCT4_BACKEND4_GUIDE5_KEEP_WORKER_AUTH_DB_FLAGS'
MANIFEST_STATUS = 'EXACT_EDITOR_CHAT_GUIDE_17_PAYLOADS_26_TARGETS'
LOCK = '/opt/synapse/.palitra-app-release.lock'
UNFROZEN = '0' * 64
PAYLOAD_MANIFEST_SHA = '332bc67b1f6a4902ed859126d7b432a7a2a805dc2eb5b1cfc0d739f7693f9d51'  # Root replaces only after final payload review.
PWA_HELPER_SHA = '5941f28bac4864d2c53635e6b34984f6ea8dc0e16a2f077868401fed48dc5c0a'
PWA_RECEIPT_SHA = 'b18c063004765cf2705fa345c044bc53c4bbe2573fd5cc9a41a3d8a4669c5a3f'
PWA_MANIFEST_SHA = 'b91ab389260ff238c8e1d78ecfcb4d7386c7f9a58824460e017923da104a3bdb'
CONTENT = 'sha256:5bfbd7a9540b44e49ad5775aa1ea2df12a90ce2b30a8b3677b0a52c203f9940a'
WORKER = 'sha256:d4d4d453ce2e3dc47d5e0962d62b95938f42c56ec73789fe76a324e0d2ff0508'
FULLSCREEN_SHA = '59f65e501267d8304aed0795e6d05b270242cfa69d3e2a72391064f8ce0abcfe'
# Candidate raw pins only. Baseline must match these exact native files before
# approval; stale candidates fail closed, never normalize or replace live bytes.
EDITOR_BEFORE = {
    'app.js': ('aef949ead4aef07f7955ec02553af6504fadd8fbbcfd61d75c0404954114a9c2', 185083),
    'form-builder.js': ('f5029bcec9b49416e3fede11a22c3249465f18f95aa459839c6b83a343ff3b56', 17586),
    'index.html': ('137425d2c3404dafc4dbbe3388d6aaf0ce2727fcf9927135a021109dbb2150e9', 7246),
    'style.css': ('f445965d1e024e7296887c7572734e5b812b79670021ceb97ca795f3a9543461', 43741),
}
BACKEND_OLD = {'project-forms.cjs', 'palitra-host-adapter.cjs'}
BACKEND_NEW = {'notification-texts.cjs', 'notification-copy-http.cjs'}
PRODUCT = {'shell.js', 'shell.css', 'workflow-ui.js', 'workflow-ui.css'}
GUIDE = {'ios-share-steps.png', 'ios-add-home.png', 'android-menu.png', 'android-choice.png', 'android-install.png'}
NAMES = ({'content/' + n for n in BACKEND_OLD | BACKEND_NEW}
         | {'product/' + n for n in PRODUCT}
         | {'guide/' + n for n in GUIDE}
         | {'editor/' + n for n in EDITOR_BEFORE})
NEW_NAMES = {'content/' + n for n in BACKEND_NEW} | {'guide/' + n for n in GUIDE}
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def need(ok, code):
    if not ok:
        raise ValueError(code)


def digest(value):
    return type(value) is str and re.fullmatch('[0-9a-f]{64}', value) is not None


class EditorChatGuideRelease:
    def __init__(self, a, b, pwa, payload, manifest_pin, lease_pid, clock=time.time):
        self.a, self.b, self.pwa, self.photo = a, b, pwa, b.photo
        self.c, self.run, self.root, self.clock = b.photo.c, b.run, b.root, clock
        need(type(lease_pid) is int and lease_pid > 1, 'FRESH_ROOT_LEASE_PID_REQUIRED')
        self.lease_pid = lease_pid
        self.b.lease = self.lease
        self.cabinet = self.photo.ui.cabinet
        need(self.cabinet == Path('/opt/synapse/sites/synapse/cabinet/palitra-orders') or self.root != ROOT, 'EXACT_CABINET_REQUIRED')
        self.editor = self.cabinet.parent / 'project-forms'
        self.assets = self.cabinet / 'assets'
        self.guide_dir = self.assets / 'install-guide'
        self.fullscreen = self.cabinet.parent / 'project-forms.js'
        self.parents = self.parent_facts()
        self.guide_created = None
        self.payload = a.exact_path(payload)
        need(self.payload.is_dir() and self.payload.is_relative_to(self.root), 'ROOT_PAYLOAD_REQUIRED')
        need(digest(manifest_pin) and PAYLOAD_MANIFEST_SHA != UNFROZEN and manifest_pin == PAYLOAD_MANIFEST_SHA, 'FROZEN_ROOT_MANIFEST_REQUIRED')
        self.manifest_pin = manifest_pin
        raw = a.read(self.payload / 'MANIFEST.json')
        need(sha(raw) == manifest_pin, 'MANIFEST_CHANGED')
        manifest = a.decode(raw)
        need(type(manifest) is dict and set(manifest) == {'schema', 'status', 'records'} and type(manifest['schema']) is int and manifest['schema'] == 1
             and manifest['status'] == MANIFEST_STATUS and type(manifest['records']) is list and len(manifest['records']) == 17,
             'EXACT_17_PAYLOAD_MANIFEST_REQUIRED')
        payload_files = set()
        for path in self.payload.rglob('*'):
            a.exact_path(path)
            relative = path.relative_to(self.payload).as_posix()
            if path.is_file():
                payload_files.add(relative)
            else:
                need(path.is_dir() and relative in {'content', 'product', 'guide', 'editor'}, 'EXACT_PAYLOAD_DIRECTORIES_REQUIRED')
        need(payload_files == NAMES | {'MANIFEST.json'}, 'CLOSED_17_FILE_PAYLOAD_REQUIRED')
        self.helper = a.exact_path(__file__)
        self.helper_pin = sha(a.read(self.helper))
        self.pins = {str(self.helper): self.helper_pin, str(self.payload / 'MANIFEST.json'): manifest_pin}
        self.wrapper = a.exact_path(self.helper.parent / 'guide.py')
        self.wrapper_pin = sha(a.read(self.wrapper))
        self.pins[str(self.wrapper)] = self.wrapper_pin
        need(sha(a.read(pwa.helper)) == PWA_HELPER_SHA, 'FROZEN_PWA_HELPER_REQUIRED')
        self.pins[str(pwa.helper)] = PWA_HELPER_SHA
        self.receipt_path = self.root / 'pwa-onboarding-overlay-r1-journal.json'
        receipt = a.pinned(self.receipt_path, PWA_RECEIPT_SHA, True)
        historical, expected = receipt.get('inputs'), pwa.binding()
        need(type(historical) is dict and type(historical.get('freshLeasePid')) is int and historical['freshLeasePid'] > 1
             and {k: v for k, v in historical.items() if k != 'freshLeasePid'} == {k: v for k, v in expected.items() if k != 'freshLeasePid'},
             'EXACT_HISTORICAL_PWA_BINDING_REQUIRED')
        need(receipt.get('schema') == 1 and receipt.get('name') == 'pwa-onboarding-overlay-r1'
             and receipt.get('phase') == 'PWA_ONBOARDING_OVERLAY_APPLIED_NOT_DEVICE_OR_CUSTOMER_ACCEPTANCE'
             and receipt.get('before') == pwa.base and receipt.get('childImage') == CONTENT
             and receipt.get('workerRecreated') is False and receipt.get('uploadsEnabled') is True
             and receipt.get('automaticRetry') is False and receipt.get('directDbWrites') == receipt.get('queueEdits') == 0,
             'EXACT_COMPLETED_CHAIN21_RECEIPT_REQUIRED')
        overlay = self.root / 'pwa-onboarding-overlay-r1-overlay.json'
        need(receipt.get('overlay') == str(overlay) and sha(a.read(overlay)) == receipt['overlaySha256']
             and a.decode(a.read(overlay)) == {'services': {'content': {'image': CONTENT}}}, 'COMPLETED_PWA_OVERLAY_CHANGED')
        pwa.transition(pwa.base, receipt['after'], overlay, receipt['plannedConfigHash'], CONTENT)
        self.base = receipt['after']
        self.pins[str(self.receipt_path)] = PWA_RECEIPT_SHA
        self.pins[str(overlay)] = receipt['overlaySha256']
        need(self.base['containers']['content']['image'] == CONTENT and len(self.base['containers']['content']['files']) == 21
             and self.base['worker']['image'] == b.images['new'] == WORKER
             and self.base['selected']['content']['PALITRA_WEB_UPLOADS_ENABLED'] == 'true', 'EXACT_CURRENT_CHAIN21_REQUIRED')
        self.source, self.static = dict(pwa.final_source), dict(pwa.final_static)
        need(len(self.source) == 202 and len(self.static) == 17 and all(digest(x) for x in self.source.values())
             and all(digest(x) for x in self.static.values()), 'FULL_SOURCE202_APPSTATIC17_REQUIRED')
        for name, (pin, size) in EDITOR_BEFORE.items():
            target = str(self.editor / name)
            need(target not in self.static and digest(pin) and type(size) is int and size > 0, 'EXPLICIT_EDITOR4_BEFORE_REQUIRED')
            self.static[target] = pin
        self.records, self.targets, self.m = {}, {}, {'records': []}
        self.before_source, self.final_source = dict(self.source), dict(self.source)
        self.before_static, self.final_static = dict(self.static), dict(self.static)
        for record in manifest['records']:
            self.accept_record(record)
        need(set(self.records) == NAMES and len(self.targets) == 17 and len(self.m['records']) == 13
             and len(self.static_targets()) == 13 and len(self.before_source) == len(self.final_source) == 209
             and sum(x is not None for x in self.before_source.values()) == 202
             and len(self.static) == 21 and len(self.before_static) == len(self.final_static) == 26
             and sum(x is not None for x in self.before_static.values()) == 21, 'EXACT_SOURCE209_STATIC26_FOOTPRINT_REQUIRED')

    def target_map(self, name):
        group, leaf = name.split('/')
        if group == 'content':
            return [('content', leaf)]
        if group == 'product':
            return [('content', 'palitra-orders-public/' + leaf), ('static', str(self.cabinet / leaf))]
        if group == 'guide':
            relative = 'assets/install-guide/' + leaf
            return [('content', 'palitra-orders-public/' + relative), ('static', str(self.cabinet / relative))]
        need(group == 'editor', 'UNKNOWN_TARGET_GROUP')
        return [('static', str(self.editor / leaf))]

    def accept_record(self, record):
        need(type(record) is dict and set(record) == {'name', 'payload', 'new', 'beforeSha256', 'beforeBytes', 'sha256', 'bytes', 'hunks'}, 'EXACT_RECORD_FIELDS_REQUIRED')
        name = record['name']
        need(type(name) is str and name in NAMES and name not in self.records and record['payload'] == name
             and type(record['new']) is bool and record['new'] == (name in NEW_NAMES)
             and digest(record['sha256']) and type(record['bytes']) is int and 0 < record['bytes'] <= 2 * 1024 * 1024
             and type(record['hunks']) is list, 'EXACT_RECORD_NAME_AND_SIZE_REQUIRED')
        raw = self.a.read(self.payload / name)
        need(len(raw) == record['bytes'] and sha(raw) == record['sha256'], 'PAYLOAD_CHANGED')
        self.reconstruct(raw, record)
        targets = self.target_map(name)
        for kind, target in targets:
            before, final = (self.before_source, self.final_source) if kind == 'content' else (self.before_static, self.final_static)
            if record['new']:
                need(target not in before, 'NEW_TARGET_ALREADY_IN_BASE')
                before[target] = None
            else:
                need(before.get(target) == record['beforeSha256'], 'EXACT_INHERITED_TARGET_BASE_REQUIRED')
            final[target] = record['sha256']
            if kind == 'content':
                self.m['records'].append({'group': 'content', 'target': target, 'sha256': record['sha256']})
        if name.startswith('editor/'):
            need((record['beforeSha256'], record['beforeBytes']) == EDITOR_BEFORE[name.split('/')[1]], 'EXACT_EDITOR_RAW_BASE_REQUIRED')
        self.targets[name] = targets
        self.records[name] = record
        self.pins[str(self.payload / name)] = record['sha256']

    def reconstruct(self, raw, record):
        if record['new']:
            need(record['beforeSha256'] is None and record['beforeBytes'] is None and record['hunks'] == [], 'NEW_FILE_WITHOUT_BASE_REQUIRED')
            if record['name'].startswith('guide/'):
                need(raw.startswith(b'\x89PNG\r\n\x1a\n'), 'GUIDE_PNG_SIGNATURE_REQUIRED')
            return
        need(digest(record['beforeSha256']) and record['sha256'] != record['beforeSha256'] and type(record['beforeBytes']) is int
             and 0 < record['beforeBytes'] <= 2 * 1024 * 1024 and 1 <= len(record['hunks']) <= 256, 'EXACT_REPLACEMENT_BASE_REQUIRED')
        old = raw
        for hunk in reversed(record['hunks']):
            need(type(hunk) is dict and set(hunk) == {'before', 'after'} and type(hunk['before']) is str and type(hunk['after']) is str
                 and hunk['before'] and hunk['after'] and hunk['before'] != hunk['after']
                 and max(len(hunk['before'].encode()), len(hunk['after'].encode())) <= 2 * 1024 * 1024, 'BOUNDED_NONEMPTY_HUNK_REQUIRED')
            after, before = hunk['after'].encode(), hunk['before'].encode()
            need(old.count(after) == 1, 'REVERSE_UNIQUE_HUNK_REQUIRED')
            old = old.replace(after, before, 1)
        need(len(old) == record['beforeBytes'] and sha(old) == record['beforeSha256'] and self.patch(old, record) == raw, 'RAW_BASE_RECONSTRUCTION_REQUIRED')

    def patch(self, raw, record):
        need(len(raw) == record['beforeBytes'] and sha(raw) == record['beforeSha256'], 'ACTUAL_RAW_BASE_CHANGED')
        for hunk in record['hunks']:
            old, new = hunk['before'].encode(), hunk['after'].encode()
            need(raw.count(old) == 1, 'FORWARD_UNIQUE_HUNK_REQUIRED')
            raw = raw.replace(old, new, 1)
        need(len(raw) == record['bytes'] and sha(raw) == record['sha256'], 'FINAL_BYTES_CHANGED')
        return raw

    def static_targets(self):
        return [(name, Path(target)) for name, targets in sorted(self.targets.items()) for kind, target in targets if kind == 'static']

    def parent_facts(self):
        result = {}
        for path in (self.cabinet, self.editor, self.assets):
            p = self.a.exact_path(path)
            info = p.stat()
            need(stat.S_ISDIR(info.st_mode), 'EXACT_STATIC_PARENT_REQUIRED')
            result[str(p)] = [info.st_dev, info.st_ino, stat.S_IMODE(info.st_mode), info.st_uid]
        return result

    def parents_guard(self):
        need(self.parent_facts() == self.parents, 'STATIC_PARENT_IDENTITY_CHANGED')

    def guide_facts(self):
        p = self.a.exact_path(self.guide_dir)
        info = p.stat()
        expected_uid = 0 if self.root == ROOT else (os.getuid() if hasattr(os, 'getuid') else info.st_uid)
        need(stat.S_ISDIR(info.st_mode) and (os.name != 'posix' or (stat.S_IMODE(info.st_mode) == 0o755 and info.st_uid == expected_uid)), 'EXACT_CREATED_GUIDE_DIRECTORY_REQUIRED')
        return {'path': str(p), 'device': info.st_dev, 'inode': info.st_ino, 'mode': stat.S_IMODE(info.st_mode), 'uid': info.st_uid}

    def paths(self):
        return {k: self.root / (NAME + '-' + k + ('.json' if k in ('decision', 'journal', 'overlay') else '')) for k in ('decision', 'journal', 'overlay', 'context', 'backup')}

    def lease(self):
        raw = self.run(['lslocks', '--noheadings', '--output', 'PID,PATH'])
        need(len(raw) <= 1048576, 'BOUNDED_LEASE_INVENTORY_REQUIRED')
        rows = [line.strip().split(maxsplit=1) for line in raw.decode('utf8').splitlines() if len(line.strip().split(maxsplit=1)) == 2 and line.strip().split(maxsplit=1)[1] == LOCK]
        need(rows == [[str(self.lease_pid), LOCK]], 'FRESH_EXCLUSIVE_ROOT_LEASE_REQUIRED')

    def stable(self):
        self.pwa.stable()
        for path, pin in self.pins.items():
            need(sha(self.a.read(Path(path))) == pin, 'PINNED_INPUT_CHANGED')
        self.parents_guard()

    def static_guard(self, changed):
        self.parents_guard()
        need(sha(self.a.read(self.fullscreen)) == FULLSCREEN_SHA, 'FULLSCREEN_MODULE_CHANGED')
        if changed:
            need(type(self.guide_created) is dict and self.guide_created == self.guide_facts(), 'CREATED_GUIDE_DIRECTORY_CHANGED')
        else:
            self.a.exact_path(self.guide_dir, True)
            need(not os.path.lexists(self.guide_dir), 'NEW_GUIDE_DIRECTORY_ABSENCE_CONFLICT')
        for name, pin in (self.final_static if changed else self.before_static).items():
            path = Path(name)
            if pin is None:
                # Its only missing parent is the guarded fixed guide directory.
                need(path.parent == self.guide_dir and not os.path.lexists(path), 'NEW_STATIC_ABSENCE_CONFLICT')
            else:
                need(sha(self.a.read(path)) == pin, 'FULL_STATIC_INVENTORY_CHANGED')

    def expected_metadata(self, service, content, proof):
        if service == 'chat':
            return dict(self.base['containers']['chat'])
        old = self.base['containers']['content']
        if content == CONTENT:
            need(proof is None, 'BEFORE_PROOF_MUST_BE_EMPTY')
            return dict(old)
        need(type(proof) is dict and set(proof) == {'childImage', 'overlaySha256', 'plannedConfigHash'}
             and proof['childImage'] == content and self.a.image(content) and content != CONTENT
             and digest(proof['overlaySha256']) and digest(proof['plannedConfigHash']), 'AFTER_SEALED_PROOF_REQUIRED')
        overlay = self.paths()['overlay']
        need(sha(self.a.read(overlay)) == proof['overlaySha256'] and self.a.decode(self.a.read(overlay)) == {'services': {'content': {'image': content}}}, 'SEALED_OVERLAY_CHANGED')
        files = old['files'] + [str(overlay)]
        need(len(old['files']) == 21 and len(files) == len(set(files)) == 22, 'EXACT_ORDERED_CHAIN22_REQUIRED')
        return dict(old, image=content, files=files, configFiles=','.join(files), filePins={**old['filePins'], str(overlay): proof['overlaySha256']}, configHash=proof['plannedConfigHash'])

    def metadata(self, service, expected):
        if service == 'chat':
            row = self.b.metadata(service)
            need(row == expected, 'UNCHANGED_CHAT_METADATA_REQUIRED')
            return row
        need(service == 'content', 'EXACT_SERVICE_REQUIRED')
        row = self.a.decode(self.run(['docker', 'inspect', '--format', self.a.LABELS, 'synapse-content-1']))
        need(set(row) == {'image', 'project', 'service', 'workingDir', 'configFiles', 'configHash', 'running', 'health'}
             and self.a.image(row['image']) and row['service'] == service and row['running'] is True
             and row['health'] in (None, 'healthy', 'starting') and digest(row['configHash']), 'RUNNING_EXACT_SERVICE_REQUIRED')
        need(type(row['project']) is str and re.fullmatch('[a-z0-9][a-z0-9_-]{0,63}', row['project'])
             and self.a.exact_path(row['workingDir']).is_dir() and type(row['configFiles']) is str and len(row['configFiles']) <= 65536, 'ACTUAL_COMPOSE_IDENTITY_REQUIRED')
        files = row['configFiles'].split(',')
        need(files == expected['files'] and len(files) == len(set(files)) and len(files) in (21, 22), 'ONLY_EXACT_CHAIN21_OR_SEALED22_REQUIRED')
        pins = {}
        for name in files:
            path = self.a.exact_path(name)
            need(path.suffix.lower() in ('.json', '.yaml', '.yml'), 'EXACT_COMPOSE_FILE_REQUIRED')
            pins[name] = sha(self.a.read(path))
        row.update(files=files, filePins=pins)
        need(row == expected, 'EXACT_METADATA_AND_FILEPINS_REQUIRED')
        return row

    def snapshot(self, content=CONTENT, source=False, static=False, proof=None):
        self.stable()
        self.lease()
        first = {s: self.metadata(s, self.expected_metadata(s, content, proof)) for s in ('content', 'chat')}
        worker = self.b.worker_facts()
        selected = {s: self.b.a.selected(s) for s in ('content', 'chat')}
        need(selected == self.base['selected'], 'SELECTED_FLAGS_CHANGED')
        flags = self.a.decode(self.run(['docker', 'exec', 'synapse-content-1', 'node', '-e', self.a.FLAGS_JS]))
        need(flags == self.base['l12'], 'L12_CUTOFF_CHANGED')
        for service, row in first.items():
            text = self.run(self.b._resolve_command(row, service)).decode('ascii').strip()
            need(re.fullmatch(re.escape(service) + r'\s+' + re.escape(row['configHash']), text) is not None, 'RESOLVED_CONFIG_MISMATCH')
        need(worker == self.base['worker'] and first['chat'] == self.base['containers']['chat'] and first['content']['image'] == content, 'WORKER_OR_IMAGE_CHANGED')
        self.b.graph(new=True)
        self.b.push_guard()
        expected = self.final_source if source else self.before_source
        need(self.photo.hashes(expected) == expected, 'FULL_SOURCE_INVENTORY_CHANGED')
        self.static_guard(static)
        cid = self.photo.cid()
        last = {s: self.metadata(s, self.expected_metadata(s, content, proof)) for s in ('content', 'chat')}
        need(first == last and worker == self.b.worker_facts() and selected == {s: self.b.a.selected(s) for s in ('content', 'chat')}, 'CONCURRENT_CHANGE')
        self.lease()
        self.stable()
        need(cid == self.photo.cid(), 'CONTENT_CID_CHANGED_DURING_READ')
        return {'containers': last, 'selected': selected, 'worker': worker, 'contentCid': cid, 'l12': flags}

    def baseline(self, static=False):
        current = self.snapshot(static=static)
        need(current == self.base, 'COMPLETED_PWA_BASE_CHANGED')
        heartbeat = self.b.heartbeat(current['worker']['startedAt'], self.clock())
        need(heartbeat['freshAfterWorkerStart'], 'FRESH_WORKER_HEARTBEAT_REQUIRED')
        return current

    def absent(self, decision=False):
        old = list(self.root.glob('palitra-editor-chat-guide-r*-journal.json'))
        need(len(old) <= 32, 'BOUNDED_RELEASE_HISTORY_REQUIRED')
        for path in old:
            need(re.fullmatch('palitra-editor-chat-guide-r[1-9][0-9]{0,3}-journal.json', path.name) is not None
                 and self.a.decode(self.a.read(path)).get('phase') == PHASE, 'UNKNOWN_HISTORY_NO_NEW_NAMESPACE')
        for kind, path in self.paths().items():
            if kind == 'decision' and not decision:
                continue
            self.a.exact_path(path, True)
            need(not os.path.lexists(path) and not os.path.lexists(str(path) + '.pending'), 'ATTEMPT_EXISTS_NO_REPLAY')

    def binding(self):
        return {'pwaReceiptSha256': PWA_RECEIPT_SHA, 'pwaHelperSha256': PWA_HELPER_SHA, 'pwaManifestSha256': PWA_MANIFEST_SHA,
                'manifestSha256': self.manifest_pin, 'helperSha256': self.helper_pin, 'wrapperSha256': self.wrapper_pin, 'workerImage': WORKER,
                'contentImage': CONTENT, 'fullscreenSha256': FULLSCREEN_SHA, 'editorBefore': {k: list(v) for k, v in EDITOR_BEFORE.items()},
                'staticParents': self.parents, 'freshLeasePid': self.lease_pid}

    def decision(self, pin):
        value = self.a.pinned(self.paths()['decision'], pin, True)
        need(set(value) == {'schema', 'scope', 'name', 'rootApproved', 'observedAtUtc', 'inputs', 'before'}
             and value['schema'] == 1 and value['scope'] == SCOPE and value['name'] == NAME and value['rootApproved'] is True
             and value['inputs'] == self.binding() and value['before'] == self.base, 'EXACT_ROOT_DECISION_REQUIRED')
        self.a.fresh(value['observedAtUtc'], self.clock())
        return value

    def inspect_current(self):
        self.baseline()
        return {'status': 'CURRENT_CHAIN21_READONLY_NOT_APPROVED', 'sourceFiles': 202, 'appStaticFiles': 17, 'editorStaticFiles': 4,
                'staticFiles': 21, 'contentChainFiles': 21, 'mutations': 0, 'workerRecreated': False, 'uploadsEnabled': True}

    def approve(self, apply=False):
        need(apply is True, 'EXPLICIT_ROOT_APPROVAL_REQUIRED')
        self.absent(True)
        at = self.clock()
        before = self.baseline()
        self.stable()
        self.lease()
        self.a.fresh(self.a.stamp(at), self.clock())
        value = {'schema': 1, 'scope': SCOPE, 'name': NAME, 'rootApproved': True, 'observedAtUtc': self.a.stamp(at), 'inputs': self.binding(), 'before': before}
        self.a.write_new(self.paths()['decision'], value)
        return {'status': 'ROOT_DECISION_READY_NOT_APPLIED', 'decisionSha256': sha(self.a.read(self.paths()['decision'])), 'runtimeWrites': 0, 'directDbWrites': 0}

    def context(self, path, state, alias, built=False):
        return self.photo.ui.inc.Release.context_proof(self, path, state, alias, built)

    def update(self, journal, state, phase, **values):
        state.update(phase=phase, **values)
        self.a.replace(journal, state)

    def create_guide_directory(self):
        self.parents_guard()
        self.a.exact_path(self.guide_dir, True)
        need(not os.path.lexists(self.guide_dir), 'GUIDE_DIRECTORY_CAS_CONFLICT')
        self.guide_dir.mkdir(mode=0o755)
        self.guide_created = self.guide_facts()

    def publish_new(self, target, raw, mode):
        self.parents_guard()
        need(self.guide_created == self.guide_facts() and target.parent == self.guide_dir, 'FIXED_GUIDE_PARENT_REQUIRED')
        self.a.exact_path(target, True)
        need(not os.path.lexists(target), 'NEW_STATIC_ABSENCE_CONFLICT')
        pending = target.with_name(target.name + '.editor-chat-guide-pending')
        self.a.exact_path(pending, True)
        self.photo.u.write(pending, raw, mode)
        # A concurrent target wins; no replacement is permitted for additions.
        os.link(pending, target, follow_symlinks=False)
        pending.unlink()
        need(sha(self.a.read(target)) == sha(raw), 'NEW_STATIC_READBACK_FAILED')

    def apply(self, pin, apply=False):
        need(apply is True, 'EXPLICIT_ROOT_APPLY_REQUIRED')
        self.absent()
        self.decision(pin)
        before = self.baseline()
        paths = self.paths()
        alias, tag = 'palitra-editor-chat-guide-base:' + NAME, 'palitra-editor-chat-guide:' + NAME
        self.photo.unused(alias)
        self.photo.unused(tag)
        need(self.run(['docker', 'image', 'inspect', '--format', '{{.Id}}', CONTENT]).decode().strip() == CONTENT, 'EXACT_PARENT_IMAGE_REQUIRED')
        layers = self.a.decode(self.run(['docker', 'image', 'inspect', '--format', '{{json .RootFS.Layers}}', CONTENT]))
        need(type(layers) is list and layers, 'PARENT_LAYERS_REQUIRED')
        self.decision(pin)
        self.baseline()
        state = {'schema': 1, 'name': NAME, 'phase': 'CONTEXT_STARTED_UNKNOWN', 'inputs': self.binding(), 'decisionSha256': pin,
                 'before': before, 'static': [], 'guideDirectory': None, 'automaticRetry': False, 'automaticCodeRollback': False,
                 'workerRecreated': False, 'uploadsEnabled': True, 'directDbWrites': 0, 'queueEdits': 0}
        self.a.write_new(paths['journal'], state)
        paths['context'].mkdir(mode=0o700)
        paths['backup'].mkdir(mode=0o700)
        for name, record in sorted(self.records.items()):
            for kind, target in self.targets[name]:
                if kind != 'content':
                    continue
                raw = self.a.read(self.payload / name)
                if not record['new']:
                    encoded = self.run(['docker', 'exec', 'synapse-content-1', 'node', '-e', self.photo.ui.inc.SOURCE_JS, target])
                    need(len(encoded) <= 3 * 1024 * 1024, 'BOUNDED_SOURCE_REQUIRED')
                    need(self.patch(base64.b64decode(encoded, validate=True), record) == raw, 'SOURCE_NOT_REVIEWED_PAYLOAD')
                stage = paths['context'] / 'app' / target
                stage.parent.mkdir(parents=True, exist_ok=True, mode=0o755)
                self.photo.u.write(stage, raw, 0o644)
        for index, (name, target) in enumerate(self.static_targets()):
            record = self.records[name]
            raw = self.a.read(self.payload / name)
            backup = None
            if record['new']:
                need(not os.path.lexists(target), 'NEW_STATIC_ABSENCE_CONFLICT')
                mode = 0o644
            else:
                old = self.a.read(target)
                need(self.patch(old, record) == raw, 'STATIC_NOT_REVIEWED_PAYLOAD')
                mode = stat.S_IMODE(target.stat().st_mode)
                backup = paths['backup'] / str(index)
                self.photo.u.write(backup, old)
            prepared = paths['context'] / 'static' / str(index)
            prepared.parent.mkdir(exist_ok=True, mode=0o700)
            self.photo.u.write(prepared, raw)
            state['static'].append({'target': str(target), 'baseSha256': record['beforeSha256'], 'sha256': record['sha256'], 'mode': mode,
                                    'backup': str(backup) if backup else None, 'prepared': str(prepared), 'new': record['new'], 'written': False})
        self.photo.u.write(paths['context'] / 'Dockerfile', ('FROM ' + alias + '\nCOPY app/ /app/\n').encode())
        state['contextSha256'] = self.context(paths['context'], state, alias)
        self.a.replace(paths['journal'], state)
        self.baseline()
        self.decision(pin)
        self.photo.unused(alias)
        self.lease()
        self.run(['docker', 'image', 'tag', CONTENT, alias])
        need(self.run(['docker', 'image', 'inspect', '--format', '{{.Id}}', alias]).decode().strip() == CONTENT, 'PARENT_ALIAS_CHANGED')
        self.photo.unused(tag)
        self.update(paths['journal'], state, 'BUILD_STARTED_UNKNOWN')
        self.decision(pin)
        self.stable()
        self.lease()
        need(self.context(paths['context'], state, alias) == state['contextSha256'], 'LAST_BUILD_CONTEXT_CHANGED')
        self.baseline()
        self.decision(pin)
        need(self.run(['docker', 'image', 'inspect', '--format', '{{.Id}}', alias]).decode().strip() == CONTENT, 'LAST_PARENT_ALIAS_CHANGED')
        iid = paths['context'] / 'image.id'
        self.run(['docker', 'build', '--network=none', '--pull=false', '--tag', tag, '--iidfile', str(iid), str(paths['context'])])
        child = self.a.read(iid).decode().strip()
        need(self.a.image(child) and child != CONTENT and self.run(['docker', 'image', 'inspect', '--format', '{{.Id}}', tag]).decode().strip() == child
             and self.context(paths['context'], state, alias, True) == state['contextSha256'], 'BUILT_CHILD_OR_CONTEXT_CHANGED')
        child_layers = self.a.decode(self.run(['docker', 'image', 'inspect', '--format', '{{json .RootFS.Layers}}', child]))
        need(child_layers[:len(layers)] == layers and len(child_layers) == len(layers) + 1, 'EXACT_PARENT_SINGLE_COPY_REQUIRED')
        need(self.photo.hashes(self.final_source, child) == self.final_source, 'CHILD_FULL_SOURCE209_CHANGED')
        self.baseline()
        self.decision(pin)
        self.update(paths['journal'], state, 'STATIC_STARTED_UNKNOWN', childImage=child)
        for record in state['static']:
            if record['backup']:
                need(sha(self.a.read(Path(record['backup']))) == record['baseSha256'], 'BACKUP_CHANGED')
            need(sha(self.a.read(Path(record['prepared']))) == record['sha256'], 'PREPARED_STATIC_CHANGED')
        self.decision(pin)
        self.lease()
        self.create_guide_directory()
        state['guideDirectory'] = self.guide_created
        self.a.replace(paths['journal'], state)
        for record in state['static']:
            self.decision(pin)
            self.lease()
            raw = self.a.read(Path(record['prepared']))
            need(sha(raw) == record['sha256'], 'LAST_PREPARED_STATIC_CHANGED')
            target = Path(record['target'])
            if record['new']:
                self.publish_new(target, raw, record['mode'])
            else:
                need(sha(self.a.read(target)) == record['baseSha256'] and stat.S_IMODE(target.stat().st_mode) == record['mode'], 'STATIC_CAS_CONFLICT')
                self.photo.atomic(target, raw, record['mode'])
            record['written'] = True
            self.a.replace(paths['journal'], state)
        self.decision(pin)
        value = {'services': {'content': {'image': child}}}
        self.a.write_new(paths['overlay'], value)
        overlay_pin = sha(self.a.read(paths['overlay']))
        planned = self.b.plan(before, 'content', paths['overlay'])
        self.update(paths['journal'], state, 'CONTENT_UP_STARTED_UNKNOWN', overlay=str(paths['overlay']), overlaySha256=overlay_pin, plannedConfigHash=planned)
        self.baseline(True)
        self.decision(pin)
        self.stable()
        self.lease()
        need(self.context(paths['context'], state, alias, True) == state['contextSha256'], 'LAST_UP_CONTEXT_CHANGED')
        for record in state['static']:
            if record['backup']:
                need(sha(self.a.read(Path(record['backup']))) == record['baseSha256'], 'LAST_BACKUP_CHANGED')
        proof = {'childImage': child, 'overlaySha256': overlay_pin, 'plannedConfigHash': planned}
        need(self.b.plan(before, 'content', paths['overlay']) == planned, 'LAST_PLANNED_HASH_CHANGED')
        self.expected_metadata('content', child, proof)
        self.lease()
        self.b.up(before, 'content', paths['overlay'])
        after = self.snapshot(child, True, True, proof)
        self.transition(before, after, paths['overlay'], planned, child)
        heartbeat = self.b.heartbeat(after['worker']['startedAt'], self.clock())
        need(heartbeat['freshAfterWorkerStart'], 'AFTER_FRESH_HEARTBEAT_REQUIRED')
        need(self.snapshot(child, True, True, proof) == after, 'LATE_CURRENT_STATE_CHANGED')
        self.stable()
        self.lease()
        self.update(paths['journal'], state, PHASE, after=after, heartbeat=heartbeat, finishedAtUtc=self.a.stamp(self.clock()))
        return {'status': PHASE, 'journalSha256': sha(self.a.read(paths['journal'])), 'contentImage': child, 'sourceFiles': 209,
                'appStaticFiles': 22, 'editorStaticFiles': 4, 'staticFiles': 26, 'contentChainFiles': 22, 'workerRecreated': False,
                'uploadsEnabled': True, 'directDbWrites': 0, 'queueEdits': 0, 'automaticRetry': False, 'deviceAcceptanceProven': False}

    def transition(self, before, after, overlay, planned, child):
        old = before['containers']['content']
        files = old['files'] + [str(overlay)]
        expected = dict(old, image=child, files=files, configFiles=','.join(files), filePins={**old['filePins'], str(overlay): sha(self.a.read(overlay))}, configHash=planned)
        need(after['containers']['content'] == expected and len(files) == len(set(files)) == 22
             and after['containers']['chat'] == before['containers']['chat'] and after['worker'] == before['worker']
             and after['contentCid'] != before['contentCid'] and after['selected'] == before['selected'] and after['l12'] == before['l12'], 'ONLY_CONTENT_OVERLAY22_ALLOWED')

    def inspect(self, pin):
        paths = self.paths()
        state = self.a.pinned(paths['journal'], pin, True)
        need(state.get('schema') == 1 and state.get('name') == NAME and state.get('phase') == PHASE
             and state.get('inputs') == self.binding() and state.get('before') == self.base
             and state.get('workerRecreated') is False and state.get('uploadsEnabled') is True
             and state.get('automaticRetry') is False and state.get('automaticCodeRollback') is False
             and state.get('directDbWrites') == state.get('queueEdits') == 0, 'EXACT_COMPLETED_RECEIPT_REQUIRED')
        self.guide_created = state.get('guideDirectory')
        need(state.get('overlay') == str(paths['overlay']), 'COMPLETED_OVERLAY_PATH_CHANGED')
        proof = {key: state[key] for key in ('childImage', 'overlaySha256', 'plannedConfigHash')}
        after = self.snapshot(state['childImage'], True, True, proof)
        self.transition(self.base, after, paths['overlay'], state['plannedConfigHash'], state['childImage'])
        need(after == state['after'], 'COMPLETED_CURRENT_STATE_CHANGED')
        return {'status': 'COMPLETED_READONLY_NOT_DEVICE_ACCEPTANCE', 'mutations': 0,
                'heartbeat': self.b.heartbeat(after['worker']['startedAt'], self.clock()), 'workerRecreated': False, 'uploadsEnabled': True}


def load_lineage(lease_pid):
    """Frozen constructors only; never call a predecessor runtime reader/action."""
    import types
    activation = ROOT / 'photo-pair-code-r1/photo_activation_pair_native.py'
    raw = activation.read_bytes()
    need(sha(raw) == '5069df0759312e2410bcfb05e94db00583af1cb6d87ab3c8dde62c161e22b8ec', 'FROZEN_ACTIVATION_REQUIRED')
    a = types.ModuleType('accepted_activation5069')
    a.__file__ = str(activation)
    exec(compile(raw, str(activation), 'exec'), a.__dict__)
    a.exact_path(activation)
    pwa_module = a.load_module(ROOT / 'pwa-onboarding-code-r1/pwa_release_native.py', PWA_HELPER_SHA, 'accepted_pwa21')
    photo_module = a.load_module(ROOT / 'photo-ui-code-r1/photo_ui_release_native.py', a.PHOTO_HELPER_SHA, 'accepted_photo')
    graph = a.load_module(ROOT / 'workergraph1.py', a.GRAPH_SHA, 'accepted_graph')
    x, l = photo_module.loaded(ROOT / 'incremental-features1', ROOT / 'ui-code-r1', ROOT / 'l12-code-r1')
    photo = photo_module.PhotoRelease(x, l, ROOT / 'photo-ui-code-r1')
    build = ROOT / '.worker-images-photo-r1/verified-pair-r1.json'
    runtime = ROOT / 'runtime-probe-r1-result.json'
    b = a.NativeBackend(photo, graph, build, sha(a.read(build)), runtime, sha(a.read(runtime)))
    reports_module = a.load_module(ROOT / 'reports-inventory-code-r1/reports_ui_release_native.py', pwa_module.REPORTS_HELPER_SHA, 'accepted_reports')
    reports = reports_module.ReportsRelease(a, b, ROOT / 'reports-inventory-code-r1', '853da750bd6012cee38af6fd1f9695eeb2d27c7dc9f4feb06cb1116071b1e650')
    push_module = a.load_module(ROOT / 'push-diagnostic-code-r1/push_diagnostic_release_native.py', pwa_module.PUSH_HELPER_SHA, 'accepted_push')
    push = push_module.PushDiagnosticRelease(a, b, reports, ROOT / 'push-diagnostic-code-r1/payload', pwa_module.PUSH_MANIFEST_SHA, lease_pid)
    k01_module = a.load_module(ROOT / 'k01-bot-code-r1/k01_release_native.py', pwa_module.K01_HELPER_SHA, 'accepted_k01')
    k01 = k01_module.K01Release(a, b, push, ROOT / 'k01-bot-code-r1/payload', pwa_module.K01_MANIFEST_SHA, lease_pid)
    pwa = pwa_module.PopupRelease(a, b, k01, ROOT / 'pwa-onboarding-code-r1/payload', PWA_MANIFEST_SHA, lease_pid)
    return a, b, pwa


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=('inspect-current', 'approve-current', 'apply', 'inspect'))
    parser.add_argument('--lease-pid', type=int, required=True)
    parser.add_argument('--decision-sha')
    parser.add_argument('--receipt-sha')
    parser.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    try:
        need(os.name == 'posix' and os.geteuid() == 0 and Path(__file__).resolve().parent == ROOT / CODE_NAME, 'NATIVE_ROOT_EXACT_CODE_DIRECTORY_REQUIRED')
        need(PAYLOAD_MANIFEST_SHA != UNFROZEN, 'DRAFT_NOT_FROZEN_NO_NATIVE_ACTION')
        a, b, pwa = load_lineage(args.lease_pid)
        release = EditorChatGuideRelease(a, b, pwa, ROOT / CODE_NAME / 'payload', PAYLOAD_MANIFEST_SHA, args.lease_pid)
        if args.operation == 'inspect-current':
            out = release.inspect_current()
        elif args.operation == 'approve-current':
            out = release.approve(args.apply)
        elif args.operation == 'apply':
            need(digest(args.decision_sha), 'EXPLICIT_DECISION_SHA_REQUIRED')
            out = release.apply(args.decision_sha, args.apply)
        else:
            need(digest(args.receipt_sha), 'EXPLICIT_RECEIPT_SHA_REQUIRED')
            out = release.inspect(args.receipt_sha)
        print(json.dumps(out, separators=(',', ':')))
        return 0
    except Exception as error:
        message = str(error)
        code = message if type(error) is ValueError and re.fullmatch('[A-Z][A-Z0-9_]{0,100}', message) else 'ACTION_REFUSED'
        print(json.dumps({'status': 'REFUSED_OR_UNKNOWN_INSPECT_PRIVATE_JOURNAL', 'code': code, 'messageSha256': sha(message.encode()),
                          'automaticRetry': False, 'automaticCodeRollback': False, 'workerRecreated': False, 'directDbWrites': 0, 'queueEdits': 0}, separators=(',', ':')))
        return 2


if __name__ == '__main__':
    sys.exit(main())
