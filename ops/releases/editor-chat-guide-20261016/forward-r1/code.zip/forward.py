"""Root-only forward entrypoint; freeze helper SHA only after recovery review."""
import hashlib
import json
import os
from pathlib import Path
import sys
import types

ROOT = Path('/opt/synapse/releases/palitra-app-20261015')
CODE = ROOT / 'palitra-editor-chat-guide-forward-code-r1'
HELPER_SHA = 'fdfec3945b8317d14e2e0f004f6152d03a1121dfaf9fe9712cc940de38c6152e'


def main():
    try:
        if HELPER_SHA == '0' * 64:
            raise ValueError('RECOVERY_NOT_FROZEN_NO_NATIVE_ACTION')
        if os.name != 'posix' or os.geteuid() != 0 or Path(__file__).resolve().parent != CODE:
            raise ValueError('EXACT_ROOT_FORWARD_CODE_REQUIRED')
        path = CODE / 'forward_recovery_native.py'
        for part in [*reversed(path.parents), path]:
            if part.is_symlink():
                raise ValueError('FORWARD_CODE_SYMLINK_REFUSED')
        raw = path.read_bytes()
        if hashlib.sha256(raw).hexdigest() != HELPER_SHA:
            raise ValueError('FROZEN_FORWARD_HELPER_REQUIRED')
        module = types.ModuleType('frozen_forward_recovery')
        module.__file__ = str(path)
        exec(compile(raw, str(path), 'exec'), module.__dict__)
        return module.main()
    except Exception as error:
        print(json.dumps({'status': 'FORWARD_ENTRY_REFUSED_NO_RETRY', 'messageSha256': hashlib.sha256(str(error).encode()).hexdigest(), 'builds': 0, 'oldJournalWrites': 0}))
        return 2


if __name__ == '__main__':
    sys.exit(main())
