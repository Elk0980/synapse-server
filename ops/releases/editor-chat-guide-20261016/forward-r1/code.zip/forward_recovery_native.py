"""Finish one sealed pre-UP attempt without rebuild, replay or old journal edits.

Only a Root-frozen seal and wrapper enable native actions. All inherited release
code is pinned; its apply/build/up methods are never called by this recovery.
"""
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys
import time
import types

ROOT = Path('/opt/synapse/releases/palitra-app-20261015')
OLD_CODE = ROOT / 'palitra-editor-chat-guide-code-r1'
CODE_NAME = 'palitra-editor-chat-guide-forward-code-r1'
NAME = 'palitra-editor-chat-guide-forward-r1'
PHASE = 'FORWARD_VERIFIED_CHILD_APPLIED_NOT_DEVICE_OR_CUSTOMER_ACCEPTANCE'
SCOPE = 'SEALED_STATIC_STOP_FD_MODES_AND_FIRST_CONTENT_UP_NO_REBUILD'
OLD_HELPER_SHA = '0ae393d971f63ab97721e240d52fcfd6b3eca34deb94e11ab313773f8d580a1c'
OLD_WRAPPER_SHA = '237f57af4e466d11742ee76e8564c89e52915192dafb011f46b1949d0143289d'
OLD_MANIFEST_SHA = '332bc67b1f6a4902ed859126d7b432a7a2a805dc2eb5b1cfc0d739f7693f9d51'
FAILED_DECISION_SHA = '49aae74b37a17f167e0c1bb0ffc97119643921eed1cf8d376b4380e9171a0354'
FAILED_JOURNAL_SHA = '864a012cdbd017338341c8d928e855ddbd3a0a1b57774423c80009f5d079daff'
CHILD = 'sha256:3348b3a24166772ac0a9802a8afe9e2d1662e9212a8ad6d8a556e199fb65b2cd'
UNFROZEN = '0' * 64
SEAL_SHA = '78499aff9f3d947a9ad0561e9aef70c84c23ef8ebe22247c5087b0e08e1b8ffa'
ROOT_USERS = {'', 'root', '0', '0:0', 'root:root'}
USER_FORMAT = '{{json (or (index .Config "User") "")}}'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def need(ok, code):
    if not ok:
        raise ValueError(code)


def digest(value):
    return type(value) is str and re.fullmatch('[0-9a-f]{64}', value) is not None


class NativeDirectoryOps:
    def open(self, path):
        need(os.name == 'posix' and hasattr(os, 'fchmod'), 'POSIX_DIRECTORY_FD_REQUIRED')
        return os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | getattr(os, 'O_CLOEXEC', 0))

    def facts(self, fd):
        row = os.fstat(fd)
        return {'device': row.st_dev, 'inode': row.st_ino, 'uid': row.st_uid, 'mode': stat.S_IMODE(row.st_mode), 'directory': stat.S_ISDIR(row.st_mode)}

    def names(self, fd):
        return os.listdir(fd)

    def fchmod(self, fd, mode):
        os.fchmod(fd, mode)
        os.fsync(fd)

    def close(self, fd):
        os.close(fd)


class NativeFileOps:
    def open(self, path):
        return os.open(path, os.O_RDWR | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_CLOEXEC', 0) | getattr(os, 'O_BINARY', 0), 0o600)

    def write(self, fd, raw):
        view = memoryview(raw)
        while view:
            count = os.write(fd, view)
            need(count > 0, 'PENDING_WRITE_INCOMPLETE')
            view = view[count:]

    def fchmod(self, fd, mode):
        need(os.name == 'posix' and hasattr(os, 'fchmod'), 'POSIX_FILE_FCHMOD_REQUIRED')
        os.fchmod(fd, mode)
        os.fsync(fd)

    def facts(self, fd):
        row = os.fstat(fd)
        return {'device': row.st_dev, 'inode': row.st_ino, 'uid': row.st_uid, 'mode': stat.S_IMODE(row.st_mode), 'regular': stat.S_ISREG(row.st_mode)}

    def mode(self, path):
        return stat.S_IMODE(path.stat().st_mode)

    def close(self, fd):
        os.close(fd)


def recovery_class(frozen):
    class ForwardRecovery(frozen.EditorChatGuideRelease):
        def __init__(self, a, b, pwa, payload, manifest_pin, lease_pid, seal_path, clock=time.time, directory_ops=None, file_ops=None):
            need(directory_ops is None or b.root != ROOT, 'NATIVE_DEFAULT_DIRECTORY_OPS_REQUIRED')
            need(file_ops is None or b.root != ROOT, 'NATIVE_DEFAULT_FILE_OPS_REQUIRED')
            self.directory_ops = directory_ops or NativeDirectoryOps()
            self.file_ops = file_ops or NativeFileOps()
            super().__init__(a, b, pwa, payload, manifest_pin, lease_pid, clock)
            need(sha(a.read(self.helper)) == OLD_HELPER_SHA and sha(a.read(self.wrapper)) == OLD_WRAPPER_SHA
                 and manifest_pin == OLD_MANIFEST_SHA, 'EXACT_FAILED_RELEASE_CODE_REQUIRED')
            self.old_paths = frozen.EditorChatGuideRelease.paths(self)
            need(digest(SEAL_SHA) and SEAL_SHA != UNFROZEN, 'RECOVERY_SEAL_NOT_FROZEN')
            self.seal_path = a.exact_path(seal_path)
            self.seal = a.pinned(self.seal_path, SEAL_SHA, True)
            need(type(self.seal) is dict and set(self.seal) == {'schema', 'failedJournalSha256', 'failedDecisionSha256', 'guideDirectory'}
                 and self.seal['schema'] == 1 and self.seal['failedJournalSha256'] == FAILED_JOURNAL_SHA
                 and self.seal['failedDecisionSha256'] == FAILED_DECISION_SHA, 'EXACT_RECOVERY_SEAL_REQUIRED')
            self.quarantine = self.seal['guideDirectory']
            need(type(self.quarantine) is dict and set(self.quarantine) == {'path', 'device', 'inode', 'mode', 'uid'}
                 and self.quarantine['path'] == str(self.guide_dir) and self.quarantine['mode'] == 0o700
                 and self.quarantine['uid'] == self.expected_uid()
                 and type(self.quarantine['device']) is int and self.quarantine['device'] >= 0
                 and type(self.quarantine['inode']) is int and self.quarantine['inode'] > 0, 'EXACT_QUARANTINED_DIRECTORY_REQUIRED')
            self.failed = a.pinned(self.old_paths['journal'], FAILED_JOURNAL_SHA, True)
            self.validate_failed()
            self.recovery_helper = a.exact_path(__file__)
            self.recovery_wrapper = a.exact_path(self.recovery_helper.parent / 'forward.py')
            self.recovery_helper_pin = sha(a.read(self.recovery_helper))
            self.recovery_wrapper_pin = sha(a.read(self.recovery_wrapper))
            self.pins.update({str(self.old_paths['journal']): FAILED_JOURNAL_SHA, str(self.old_paths['decision']): FAILED_DECISION_SHA,
                              str(self.seal_path): SEAL_SHA, str(self.recovery_helper): self.recovery_helper_pin,
                              str(self.recovery_wrapper): self.recovery_wrapper_pin})

        def expected_uid(self):
            return 0 if self.root == ROOT else (os.getuid() if hasattr(os, 'getuid') else 0)

        def validate_failed(self):
            value = self.failed
            keys = {'schema', 'name', 'phase', 'inputs', 'decisionSha256', 'before', 'static', 'guideDirectory', 'automaticRetry',
                    'automaticCodeRollback', 'workerRecreated', 'uploadsEnabled', 'directDbWrites', 'queueEdits', 'contextSha256', 'childImage'}
            need(type(value) is dict and set(value) == keys and value['schema'] == 1 and value['name'] == frozen.NAME
                 and value['phase'] == 'STATIC_STARTED_UNKNOWN' and value['childImage'] == CHILD
                 and value['guideDirectory'] is None and value['before'] == self.base
                 and value['decisionSha256'] == FAILED_DECISION_SHA and value['automaticRetry'] is False
                 and value['automaticCodeRollback'] is False and value['workerRecreated'] is False and value['uploadsEnabled'] is True
                 and value['directDbWrites'] == value['queueEdits'] == 0 and digest(value['contextSha256']), 'EXACT_PRE_UP_FAILED_JOURNAL_REQUIRED')
            expected = frozen.EditorChatGuideRelease.binding(self)
            inputs = value['inputs']
            need(type(inputs) is dict and type(inputs.get('freshLeasePid')) is int and inputs['freshLeasePid'] > 1
                 and {k: v for k, v in inputs.items() if k != 'freshLeasePid'} == {k: v for k, v in expected.items() if k != 'freshLeasePid'}, 'FAILED_BINDING_CHANGED')
            decision = self.a.pinned(self.old_paths['decision'], FAILED_DECISION_SHA, True)
            need(type(decision) is dict and set(decision) == {'schema', 'scope', 'name', 'rootApproved', 'observedAtUtc', 'inputs', 'before'}
                 and decision['schema'] == 1 and decision['scope'] == frozen.SCOPE and decision['name'] == frozen.NAME
                 and decision['rootApproved'] is True and decision['inputs'] == inputs and decision['before'] == self.base, 'FAILED_HISTORICAL_DECISION_CHANGED')
            need(type(value['static']) is list and len(value['static']) == 13, 'EXACT_UNWRITTEN_STATIC13_REQUIRED')
            for index, ((name, target), record) in enumerate(zip(self.static_targets(), value['static'])):
                wanted = self.records[name]
                keys = {'target', 'baseSha256', 'sha256', 'mode', 'backup', 'prepared', 'new', 'written'}
                need(type(record) is dict and set(record) == keys and record['target'] == str(target)
                     and record['baseSha256'] == wanted['beforeSha256'] and record['sha256'] == wanted['sha256']
                     and record['new'] is wanted['new'] and record['written'] is False
                     and type(record['mode']) is int and 0 <= record['mode'] <= 0o777
                     and record['prepared'] == str(self.old_paths['context'] / 'static' / str(index))
                     and record['backup'] == (None if wanted['new'] else str(self.old_paths['backup'] / str(index)))
                     and (not wanted['new'] or record['mode'] == 0o644), 'EXACT_FAILED_STATIC_TARGET_REQUIRED')

        def paths(self):
            return {key: self.root / (NAME + '-' + key + '.json') for key in ('decision', 'journal', 'overlay')}

        def directory_state(self, mode, empty=False):
            self.parents_guard()
            path = self.a.exact_path(self.guide_dir)
            fd = self.directory_ops.open(path)
            try:
                row = self.directory_ops.facts(fd)
                names = self.directory_ops.names(fd)
                expected = {k: self.quarantine[k] for k in ('device', 'inode', 'uid')}
                need(row.get('directory') is True and {k: row[k] for k in expected} == expected and row['mode'] == mode, 'SEALED_DIRECTORY_FD_CHANGED')
                now = self.a.exact_path(path).stat()
                need((now.st_dev, now.st_ino) == (row['device'], row['inode']), 'DIRECTORY_PATH_REPLACED')
                need(not names if empty else set(names) <= frozen.GUIDE, 'SEALED_DIRECTORY_NOT_EMPTY_OR_UNKNOWN_FILES')
                return {'path': str(path), **{k: row[k] for k in ('device', 'inode', 'mode', 'uid')}}, names
            finally:
                self.directory_ops.close(fd)

        def guide_facts(self):
            return self.directory_state(0o755)[0]

        def static_guard(self, changed):
            self.parents_guard()
            need(sha(self.a.read(self.fullscreen)) == frozen.FULLSCREEN_SHA, 'FULLSCREEN_MODULE_CHANGED')
            facts, names = self.directory_state(0o755 if changed else 0o700, empty=not changed)
            if changed:
                need(self.guide_created == facts and set(names) == frozen.GUIDE, 'EXACT_PUBLIC_GUIDE5_REQUIRED')
            for name, pin in (self.final_static if changed else self.before_static).items():
                path = Path(name)
                self.a.exact_path(path, True)
                if pin is None:
                    need(not os.path.lexists(path), 'NEW_STATIC_ABSENCE_CONFLICT')
                else:
                    need(sha(self.a.read(path)) == pin, 'FULL_STATIC_INVENTORY_CHANGED')
            for record in self.failed['static']:
                path = Path(record['target'])
                if changed or not record['new']:
                    need(self.file_ops.mode(path) == record['mode'], 'EXACT_STATIC_MODE_CHANGED')

        def staged_guard(self, image=True):
            self.stable()
            self.validate_failed()
            need(not os.path.lexists(self.old_paths['overlay']) and not os.path.lexists(str(self.old_paths['overlay']) + '.pending'), 'OLD_UP_OR_OVERLAY_ALREADY_EXISTS')
            alias = 'palitra-editor-chat-guide-base:' + frozen.NAME
            need(self.context(self.old_paths['context'], self.failed, alias, True) == self.failed['contextSha256'], 'SEALED_FAILED_CONTEXT_CHANGED')
            need(self.a.read(self.old_paths['context'] / 'image.id').decode().strip() == CHILD, 'FAILED_IID_CHANGED')
            for record in self.failed['static']:
                need(sha(self.a.read(Path(record['prepared']))) == record['sha256'], 'FAILED_PREPARED_CHANGED')
                if record['backup']:
                    need(sha(self.a.read(Path(record['backup']))) == record['baseSha256'], 'FAILED_BACKUP_CHANGED')
            if image:
                for reference in (CHILD, 'palitra-editor-chat-guide:' + frozen.NAME):
                    need(self.run(['docker', 'image', 'inspect', '--format', '{{.Id}}', reference]).decode().strip() == CHILD, 'EXACT_BUILT_CHILD_REQUIRED')
                need(self.run(['docker', 'image', 'inspect', '--format', '{{.Id}}', alias]).decode().strip() == frozen.CONTENT, 'FAILED_PARENT_ALIAS_CHANGED')
                parent = self.a.decode(self.run(['docker', 'image', 'inspect', '--format', '{{json .RootFS.Layers}}', frozen.CONTENT]))
                layers = self.a.decode(self.run(['docker', 'image', 'inspect', '--format', '{{json .RootFS.Layers}}', CHILD]))
                need(type(parent) is list and parent and type(layers) is list and layers[:len(parent)] == parent and len(layers) == len(parent) + 1, 'REUSED_CHILD_SINGLE_COPY_REQUIRED')
                need(self.photo.hashes(self.final_source, CHILD) == self.final_source, 'REUSED_CHILD_SOURCE209_CHANGED')
            users = {
                'current': self.a.decode(self.run(['docker', 'inspect', '--format', USER_FORMAT, 'synapse-content-1'])),
                'parent': self.a.decode(self.run(['docker', 'image', 'inspect', '--format', USER_FORMAT, frozen.CONTENT])),
                'child': self.a.decode(self.run(['docker', 'image', 'inspect', '--format', USER_FORMAT, CHILD]))
            }
            need(all(type(value) is str and value in ROOT_USERS for value in users.values()) and users['parent'] == users['child'], 'ROOT_SERVICE_READ_SCOPE_REQUIRED_NO_REBUILD')
            # COPY preserved root-owned private staging modes; root-only service
            # scope is required rather than modifying/rebuilding the child.
            app = self.old_paths['context'] / 'app'
            for path in [app, *app.rglob('*')]:
                self.a.exact_path(path)
                info = path.stat()
                need(info.st_uid == self.expected_uid() and (os.name != 'posix' or
                     (stat.S_ISDIR(info.st_mode) and stat.S_IMODE(info.st_mode) & 0o500 == 0o500)
                     or (stat.S_ISREG(info.st_mode) and stat.S_IMODE(info.st_mode) & 0o400 == 0o400)), 'ROOT_OWNED_READABLE_BUILT_CONTEXT_REQUIRED')
            return users

        def binding(self):
            return {**frozen.EditorChatGuideRelease.binding(self), 'failedJournalSha256': FAILED_JOURNAL_SHA,
                    'failedDecisionSha256': FAILED_DECISION_SHA, 'sealSha256': SEAL_SHA, 'recoveryHelperSha256': self.recovery_helper_pin,
                    'recoveryWrapperSha256': self.recovery_wrapper_pin, 'reusedChildImage': CHILD, 'guideDirectoryBefore': self.quarantine}

        def absent(self, decision=False):
            old = list(self.root.glob('palitra-editor-chat-guide-forward-r*-journal.json'))
            need(len(old) <= 32, 'BOUNDED_FORWARD_HISTORY_REQUIRED')
            for path in old:
                need(re.fullmatch('palitra-editor-chat-guide-forward-r[1-9][0-9]{0,3}-journal.json', path.name) is not None
                     and self.a.decode(self.a.read(path)).get('phase') == PHASE, 'UNKNOWN_FORWARD_HISTORY_NO_RETRY')
            for kind, path in self.paths().items():
                if kind == 'decision' and not decision:
                    continue
                self.a.exact_path(path, True)
                need(not os.path.lexists(path) and not os.path.lexists(str(path) + '.pending'), 'FORWARD_ATTEMPT_EXISTS_NO_REPLAY')

        def decision(self, pin):
            value = self.a.pinned(self.paths()['decision'], pin, True)
            need(set(value) == {'schema', 'name', 'scope', 'rootApproved', 'observedAtUtc', 'inputs', 'before', 'serviceUsers'}
                 and value['schema'] == 1 and value['name'] == NAME and value['scope'] == SCOPE and value['rootApproved'] is True
                 and value['inputs'] == self.binding() and value['before'] == self.base, 'EXACT_FORWARD_DECISION_REQUIRED')
            self.a.fresh(value['observedAtUtc'], self.clock())
            need(type(value['serviceUsers']) is dict and set(value['serviceUsers']) == {'current', 'parent', 'child'}
                 and all(x in ROOT_USERS for x in value['serviceUsers'].values()), 'FORWARD_SERVICE_USERS_REQUIRED')
            return value

        def inspect_current(self):
            self.baseline()
            users = self.staged_guard()
            return {'status': 'SEALED_PRE_UP_READONLY_NOT_APPROVED', 'mutations': 0, 'reusedChildImage': CHILD, 'serviceUsers': users,
                    'sourceFiles': 202, 'candidateSourceFiles': 209, 'staticFiles': 21, 'contentChainFiles': 21}

        def approve(self, apply=False):
            need(apply is True, 'EXPLICIT_FORWARD_APPROVAL_REQUIRED')
            self.absent(True)
            at = self.clock()
            before = self.baseline()
            users = self.staged_guard()
            self.lease()
            self.a.fresh(self.a.stamp(at), self.clock())
            value = {'schema': 1, 'name': NAME, 'scope': SCOPE, 'rootApproved': True, 'observedAtUtc': self.a.stamp(at),
                     'inputs': self.binding(), 'before': before, 'serviceUsers': users}
            self.a.write_new(self.paths()['decision'], value)
            return {'status': 'FORWARD_DECISION_READY_NOT_APPLIED', 'decisionSha256': sha(self.a.read(self.paths()['decision'])), 'runtimeWrites': 0}

        def normalize_empty_directory(self):
            self.parents_guard()
            self.directory_state(0o700, True)
            fd = self.directory_ops.open(self.a.exact_path(self.guide_dir))
            try:
                row = self.directory_ops.facts(fd)
                need(row['directory'] and {k: row[k] for k in ('device', 'inode', 'uid', 'mode')} == {k: self.quarantine[k] for k in ('device', 'inode', 'uid', 'mode')}
                     and not self.directory_ops.names(fd), 'LAST_EMPTY_DIRECTORY_FD_CHANGED')
                self.directory_ops.fchmod(fd, 0o755)
                after = self.directory_ops.facts(fd)
                need(after['mode'] == 0o755 and {k: after[k] for k in ('device', 'inode', 'uid')} == {k: row[k] for k in ('device', 'inode', 'uid')}
                     and not self.directory_ops.names(fd), 'DIRECTORY_FCHMOD_READBACK_FAILED')
            finally:
                self.directory_ops.close(fd)
            self.guide_created = self.guide_facts()

        def publish_static(self, record):
            target = Path(record['target'])
            self.parents_guard()
            need(self.guide_facts() == self.guide_created, 'PUBLIC_DIRECTORY_CHANGED')
            self.a.exact_path(target, True)
            raw = self.a.read(Path(record['prepared']))
            need(sha(raw) == record['sha256'], 'LAST_PREPARED_STATIC_CHANGED')
            pending = target.with_name(target.name + '.forward-r1-pending')
            self.a.exact_path(pending, True)
            fd = self.file_ops.open(pending)
            try:
                before = self.file_ops.facts(fd)
                need(before['regular'] and before['uid'] == self.expected_uid(), 'ROOT_OWNED_PENDING_FD_REQUIRED')
                self.file_ops.write(fd, raw)
                self.file_ops.fchmod(fd, record['mode'])
                after = self.file_ops.facts(fd)
                need(after['regular'] and after['mode'] == record['mode'] and {k: after[k] for k in ('device', 'inode', 'uid')} == {k: before[k] for k in ('device', 'inode', 'uid')}, 'PENDING_FCHMOD_READBACK_FAILED')
                info = self.a.exact_path(pending).stat()
                need((info.st_dev, info.st_ino) == (after['device'], after['inode']) and sha(self.a.read(pending)) == record['sha256'], 'PENDING_BYTES_OR_IDENTITY_CHANGED')
                self.file_ops.close(fd)
                fd = None
                self.parents_guard()
                info = self.a.exact_path(pending).stat()
                need((info.st_dev, info.st_ino) == (after['device'], after['inode']) and self.file_ops.mode(pending) == record['mode']
                     and sha(self.a.read(pending)) == record['sha256'], 'LAST_PENDING_IDENTITY_MODE_OR_BYTES_CHANGED')
                self.a.exact_path(target, True)
                if record['new']:
                    need(not os.path.lexists(target), 'NEW_STATIC_ABSENCE_CONFLICT')
                    os.link(pending, target, follow_symlinks=False)
                    pending.unlink()
                else:
                    need(sha(self.a.read(target)) == record['baseSha256'] and self.file_ops.mode(target) == record['mode'], 'STATIC_CAS_CONFLICT')
                    os.replace(pending, target)
                need(sha(self.a.read(target)) == record['sha256'] and self.file_ops.mode(target) == record['mode'], 'PUBLICATION_MODE_OR_SHA_READBACK_FAILED')
            finally:
                if fd is not None:
                    self.file_ops.close(fd)

        def apply(self, pin, apply=False):
            need(apply is True, 'EXPLICIT_FORWARD_APPLY_REQUIRED')
            self.absent()
            decision = self.decision(pin)
            before = self.baseline()
            need(self.staged_guard() == decision['serviceUsers'], 'APPROVED_SERVICE_USERS_CHANGED')
            self.decision(pin)
            self.lease()
            paths = self.paths()
            state = {'schema': 1, 'name': NAME, 'phase': 'FORWARD_DIRECTORY_STARTED_UNKNOWN', 'inputs': self.binding(),
                     'decisionSha256': pin, 'before': before, 'childImage': CHILD, 'static': copy.deepcopy(self.failed['static']),
                     'guideDirectory': None, 'serviceUsers': decision['serviceUsers'], 'automaticRetry': False,
                     'automaticCodeRollback': False, 'workerRecreated': False, 'uploadsEnabled': True,
                     'directDbWrites': 0, 'queueEdits': 0, 'builds': 0, 'oldJournalWrites': 0}
            self.a.write_new(paths['journal'], state)
            self.decision(pin)
            self.lease()
            self.normalize_empty_directory()
            self.update(paths['journal'], state, 'FORWARD_STATIC_STARTED_UNKNOWN', guideDirectory=self.guide_created)
            for record in state['static']:
                self.decision(pin)
                self.lease()
                self.publish_static(record)
                record['written'] = True
                self.a.replace(paths['journal'], state)
            self.static_guard(True)
            self.decision(pin)
            need(self.staged_guard() == decision['serviceUsers'], 'LAST_SERVICE_USERS_CHANGED')
            value = {'services': {'content': {'image': CHILD}}}
            self.a.write_new(paths['overlay'], value)
            overlay_pin = sha(self.a.read(paths['overlay']))
            planned = self.b.plan(before, 'content', paths['overlay'])
            self.update(paths['journal'], state, 'FORWARD_FIRST_CONTENT_UP_STARTED_UNKNOWN', overlay=str(paths['overlay']), overlaySha256=overlay_pin, plannedConfigHash=planned)
            self.baseline(True)
            self.decision(pin)
            self.lease()
            self.staged_guard(False)
            need(self.b.plan(before, 'content', paths['overlay']) == planned, 'LAST_FORWARD_PLAN_CHANGED')
            proof = {'childImage': CHILD, 'overlaySha256': overlay_pin, 'plannedConfigHash': planned}
            self.expected_metadata('content', CHILD, proof)
            self.b.up(before, 'content', paths['overlay'])
            after = self.snapshot(CHILD, True, True, proof)
            self.transition(before, after, paths['overlay'], planned, CHILD)
            need(self.staged_guard(False) == decision['serviceUsers'], 'AFTER_SERVICE_USERS_CHANGED')
            heartbeat = self.b.heartbeat(after['worker']['startedAt'], self.clock())
            need(heartbeat['freshAfterWorkerStart'] and self.snapshot(CHILD, True, True, proof) == after, 'FORWARD_AFTER_STATE_OR_HEARTBEAT_CHANGED')
            self.stable()
            self.lease()
            self.update(paths['journal'], state, PHASE, after=after, heartbeat=heartbeat, finishedAtUtc=self.a.stamp(self.clock()))
            return {'status': PHASE, 'journalSha256': sha(self.a.read(paths['journal'])), 'contentImage': CHILD,
                    'builds': 0, 'contentUps': 1, 'oldJournalWrites': 0, 'sourceFiles': 209, 'staticFiles': 26, 'contentChainFiles': 22,
                    'workerRecreated': False, 'uploadsEnabled': True, 'directDbWrites': 0, 'queueEdits': 0, 'automaticRetry': False}

        def inspect(self, pin):
            paths = self.paths()
            state = self.a.pinned(paths['journal'], pin, True)
            need(state.get('schema') == 1 and state.get('name') == NAME and state.get('phase') == PHASE
                 and state.get('inputs') == self.binding() and state.get('before') == self.base and state.get('childImage') == CHILD
                 and state.get('builds') == state.get('oldJournalWrites') == state.get('directDbWrites') == state.get('queueEdits') == 0
                 and state.get('workerRecreated') is False and state.get('uploadsEnabled') is True and state.get('automaticRetry') is False
                 and state.get('automaticCodeRollback') is False and state.get('overlay') == str(paths['overlay']), 'EXACT_FORWARD_COMPLETED_RECEIPT_REQUIRED')
            self.guide_created = state['guideDirectory']
            proof = {key: state[key] for key in ('childImage', 'overlaySha256', 'plannedConfigHash')}
            after = self.snapshot(CHILD, True, True, proof)
            self.transition(self.base, after, paths['overlay'], state['plannedConfigHash'], CHILD)
            need(after == state['after'] and self.staged_guard() == state['serviceUsers'], 'FORWARD_COMPLETED_INPUTS_CHANGED')
            return {'status': 'FORWARD_COMPLETED_READONLY_NOT_DEVICE_ACCEPTANCE', 'mutations': 0, 'builds': 0, 'oldJournalWrites': 0,
                    'heartbeat': self.b.heartbeat(after['worker']['startedAt'], self.clock())}

    return ForwardRecovery


def load_old():
    path = OLD_CODE / 'editor_chat_guide_release_native.py'
    for part in [*reversed(path.parents), path]:
        need(not part.is_symlink(), 'FROZEN_CODE_SYMLINK_REFUSED')
    raw = path.read_bytes()
    need(sha(raw) == OLD_HELPER_SHA, 'FROZEN_FAILED_HELPER_REQUIRED')
    module = types.ModuleType('frozen_failed_release')
    module.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=('inspect-current', 'approve-current', 'apply', 'inspect'))
    parser.add_argument('--lease-pid', required=True, type=int)
    parser.add_argument('--decision-sha')
    parser.add_argument('--receipt-sha')
    parser.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    try:
        need(SEAL_SHA != UNFROZEN, 'RECOVERY_NOT_FROZEN_NO_NATIVE_ACTION')
        need(os.name == 'posix' and os.geteuid() == 0 and Path(__file__).resolve().parent == ROOT / CODE_NAME, 'EXACT_ROOT_FORWARD_CODE_REQUIRED')
        old = load_old()
        a, b, pwa = old.load_lineage(args.lease_pid)
        release = recovery_class(old)(a, b, pwa, OLD_CODE / 'payload', OLD_MANIFEST_SHA, args.lease_pid, ROOT / CODE_NAME / 'RECOVERY_SEAL.json')
        if args.operation == 'inspect-current':
            out = release.inspect_current()
        elif args.operation == 'approve-current':
            out = release.approve(args.apply)
        elif args.operation == 'apply':
            need(digest(args.decision_sha), 'EXPLICIT_FORWARD_DECISION_SHA_REQUIRED')
            out = release.apply(args.decision_sha, args.apply)
        else:
            need(digest(args.receipt_sha), 'EXPLICIT_FORWARD_RECEIPT_SHA_REQUIRED')
            out = release.inspect(args.receipt_sha)
        print(json.dumps(out, separators=(',', ':')))
        return 0
    except Exception as error:
        message = str(error)
        code = message if type(error) is ValueError and re.fullmatch('[A-Z][A-Z0-9_]{0,100}', message) else 'FORWARD_ACTION_REFUSED'
        print(json.dumps({'status': 'FORWARD_REFUSED_OR_UNKNOWN_NO_AUTOMATIC_RETRY', 'code': code, 'messageSha256': sha(message.encode()),
                          'automaticRetry': False, 'automaticCodeRollback': False, 'builds': 0, 'oldJournalWrites': 0, 'workerRecreated': False}, separators=(',', ':')))
        return 2


if __name__ == '__main__':
    sys.exit(main())
