'use strict';
// Состояние и настройки — версии в существующей documents. Новых таблиц, прав и очередей нет.
const crypto = require('node:crypto');
const SITE = 'palitra', COMPANY = 'palitra-love', KEY = 'palitra-love/order-workflow';
const REQUIREMENTS = Object.freeze(['contact_confirmed', 'details_confirmed', 'payment_confirmed', 'photo_sent', 'handover_confirmed', 'feedback_requested']);
const CHANNELS = Object.freeze(['app', 'phone', 'telegram', 'whatsapp']);
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
const ID = /^[a-z][a-z0-9_-]{0,39}$/;
const fail = (status, message, code = 'VALIDATION') => { throw Object.assign(new Error(message), { status, code }); };
const clone = (v) => JSON.parse(JSON.stringify(v));
const digest = (v) => crypto.createHash('sha256').update(JSON.stringify(v)).digest('hex');
const obj = (v) => v && typeof v === 'object' && !Array.isArray(v);
const exact = (v, required, optional = []) => { if (!obj(v) || required.some(k => !Object.hasOwn(v, k)) || Object.keys(v).some(k => !required.includes(k) && !optional.includes(k))) fail(400, 'Неверный набор полей'); };
const text = (v, max, empty = false) => { if (typeof v !== 'string' || v.length > max || /[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/.test(v) || (!empty && !v.trim())) fail(400, 'Некорректный текст'); return v.trim(); };
const numericId = (v) => { if (!['number', 'string'].includes(typeof v) || (typeof v === 'string' && !/^[1-9]\d{0,14}$/.test(v))) fail(404, 'Заявка не найдена', 'ORDER'); const n = Number(v); if (!Number.isSafeInteger(n) || n < 1) fail(404, 'Заявка не найдена', 'ORDER'); return n; };
const DEFAULT = Object.freeze({
  autoReply: { enabled: true, text: 'Здравствуйте! Спасибо, что написали в Palitra Love. Менеджер скоро подключится. Расскажите, для кого и на какое событие подбираете шары.', questions: [] },
  stages: [
    { id: 'new', label: 'Новая заявка', hint: 'Свяжитесь удобным клиенту способом и уточните детали.', requirements: ['contact_confirmed', 'details_confirmed'] },
    { id: 'payment', label: 'Согласование и оплата', hint: 'Подтвердите оплату отдельной кнопкой после фактической проверки.', requirements: ['payment_confirmed'] },
    { id: 'preparing', label: 'Готовим заказ', hint: 'Отправьте клиенту фото готового заказа в приложении или выбранном мессенджере.', requirements: ['photo_sent'] },
    { id: 'handover', label: 'Доставка / выдача', hint: 'Подтвердите фактическую выдачу или доставку.', requirements: ['handover_confirmed'] },
    { id: 'feedback', label: 'Обратная связь', hint: 'Предложите оставить отзыв удобным способом.', requirements: ['feedback_requested'] },
    { id: 'done', label: 'Завершён', hint: 'История и переписка сохраняются.', requirements: [] },
  ],
});
function validateConfig(value) {
  exact(value, ['autoReply', 'stages']); exact(value.autoReply, ['enabled', 'text', 'questions']);
  if (typeof value.autoReply.enabled !== 'boolean') fail(400, 'Включение автоответа должно быть логическим');
  const autoReply = { enabled: value.autoReply.enabled, text: text(value.autoReply.text, 3000, !value.autoReply.enabled), questions: [] };
  if (!Array.isArray(value.autoReply.questions) || value.autoReply.questions.length > 6) fail(400, 'Не больше шести вопросов');
  const questionIds = new Set();
  for (const q of value.autoReply.questions) {
    exact(q, ['id', 'label', 'options']);
    if (!ID.test(q.id) || questionIds.has(q.id) || !Array.isArray(q.options) || q.options.length > 8) fail(400, 'Некорректный вопрос');
    questionIds.add(q.id); autoReply.questions.push({ id: q.id, label: text(q.label, 180), options: q.options.map(v => text(v, 100)) });
  }
  if (!Array.isArray(value.stages) || value.stages.length < 2 || value.stages.length > 20) fail(400, 'Нужно от двух до двадцати этапов');
  const stageIds = new Set();
  const stages = value.stages.map(s => {
    exact(s, ['id', 'label', 'hint', 'requirements']);
    if (!ID.test(s.id) || stageIds.has(s.id) || !Array.isArray(s.requirements) || s.requirements.some(r => !REQUIREMENTS.includes(r)) || new Set(s.requirements).size !== s.requirements.length) fail(400, 'Некорректные этапы или условия');
    stageIds.add(s.id); return { id: s.id, label: text(s.label, 100), hint: text(s.hint, 500, true), requirements: [...s.requirements] };
  });
  if (stages.at(-1).requirements.length) fail(400, 'Последний этап не должен требовать перехода дальше');
  const fullReply = [autoReply.text, ...autoReply.questions.map(q => `${q.label}${q.options.length ? ` (${q.options.join(' / ')})` : ''}`)].filter(Boolean).join('\n\n');
  if (fullReply.length > 4000) fail(400, 'Автоответ вместе с вопросами не должен превышать 4000 символов');
  return { autoReply, stages };
}
function canAccess(user, permission) {
  return Boolean(user && (user.role === 'owner' || (Array.isArray(user.companyCodes) && user.companyCodes.includes(COMPANY) && Array.isArray(user.permissions) && user.permissions.includes(permission))));
}
function createWorkflow({ db, transaction, siteOrders, getUser, now = Date.now }) {
  if (!db || typeof transaction !== 'function' || !siteOrders || typeof getUser !== 'function') throw new TypeError('Нужен штатный хост workflow');
  const latest = db.prepare('SELECT version, body FROM documents WHERE key=? ORDER BY version DESC LIMIT 1');
  const insert = db.prepare('INSERT INTO documents(key,version,created_at,author,body) VALUES(?,?,?,?,?)');
  const at = () => new Date(now()).toISOString();
  function actor(who, write = false, ownerOnly = false) {
    if (!who || !Number.isSafeInteger(who.id) || who.id < 1 || !Number.isSafeInteger(who.sessionVersion)) fail(403, 'Требуется действующая сессия', 'ACCESS');
    const user = getUser(who.id);
    if (!user || user.sessionVersion !== who.sessionVersion || !canAccess(user, write ? 'crm.edit' : 'crm.view') || (ownerOnly && user.role !== 'owner')) fail(403, 'Доступ изменился', 'ACCESS');
    return { id: user.id, label: String(user.displayName || user.login || user.id).slice(0, 100), role: user.role };
  }
  function load(key) {
    const row = latest.get(key); if (!row) return null;
    try { const value = JSON.parse(row.body); if (!obj(value) || value.schema !== 1) throw new Error(); return { ...value, revision: row.version }; }
    catch (_) { fail(503, 'Сохранённые этапы повреждены; обратитесь к администратору', 'STATE'); }
  }
  function save(key, previous, value, by) {
    const revision = (previous?.revision || 0) + 1;
    insert.run(key, revision, at(), `workflow:${by.id}:${by.label}`, JSON.stringify({ ...value, revision: undefined, schema: 1 }));
    return { ...value, revision, schema: 1 };
  }
  const configRecord = () => load(KEY) || { schema: 1, revision: 0, ...clone(DEFAULT), receipts: [] };
  const configView = r => ({ revision: r.revision, autoReply: clone(r.autoReply), stages: clone(r.stages) });
  function getConfig(who) { actor(who); return configView(configRecord()); }
  function mutation(body, required, optional = []) {
    exact(body, ['expectedRevision', 'requestId', ...required], optional);
    if (!Number.isSafeInteger(body.expectedRevision) || body.expectedRevision < 0 || typeof body.requestId !== 'string' || !UUID.test(body.requestId)) fail(400, 'Нужны revision и requestId');
  }
  function replay(record, who, body, action) {
    const hash = digest({ action, body });
    const old = (record.receipts || []).find(r => r.actorId === who.id && r.requestId === body.requestId);
    if (old && old.hash !== hash) fail(409, 'requestId уже использован для другого действия', 'REQUEST_CONFLICT');
    if (old) return { duplicate: true, hash };
    if (record.revision !== body.expectedRevision) fail(409, 'Этапы уже изменились. Обновите карточку.', 'REVISION');
    return { duplicate: false, hash };
  }
  function receipt(record, by, body, hash) { return [...(record.receipts || []), { actorId: by.id, requestId: body.requestId, hash }].slice(-256); }
  function putConfig(who, body) {
    mutation(body, ['config']); const config = validateConfig(body.config); actor(who, true, true);
    return transaction(() => {
      const by = actor(who, true, true), old = configRecord(), known = replay(old, by, body, 'config');
      if (known.duplicate) return { ...configView(old), duplicate: true };
      const saved = save(KEY, old, { ...config, receipts: receipt(old, by, body, known.hash) }, by);
      actor(who, true, true); return { ...configView(saved), duplicate: false };
    });
  }
  function orderContext(raw) {
    const id = numericId(raw), order = siteOrders.orderSummary(SITE, id);
    if (!order || order.id !== id) fail(404, 'Заявка не найдена', 'ORDER');
    const key = `${KEY}/orders/${id}`, config = configRecord();
    const current = load(key) || { schema: 1, revision: 0, configRevision: config.revision, stages: clone(config.stages), currentStageId: order.work?.status === 'done' ? config.stages.at(-1).id : config.stages[0].id, confirmations: [], history: [], receipts: [] };
    if (!current.stages.some(s => s.id === current.currentStageId)) fail(503, 'Текущий этап не найден', 'STATE');
    return { id, order, key, current };
  }
  function photos(orderId) {
    const threads = db.prepare('SELECT id FROM chat_threads WHERE site=? AND company_code=? AND order_id=? LIMIT 2').all(SITE, COMPANY, orderId);
    if (threads.length !== 1) return [];
    const threadId = threads[0].id;
    const native = db.prepare("SELECT a.id,m.id AS messageId,m.created_at AS createdAt FROM chat_thread_attachments a JOIN chat_thread_messages m ON m.id=a.message_id WHERE a.thread_id=? AND a.site=? AND a.company_code=? AND a.kind='photo' AND a.status='stored' AND m.thread_id=? AND m.direction='out' AND m.author_kind IN ('owner','manager') ORDER BY m.id DESC LIMIT 30").all(threadId, SITE, COMPANY, threadId)
      .map(r => ({ attachmentRef: `thread:${r.id}`, messageId: r.messageId, createdAt: r.createdAt, label: 'Отправленное фото в чате' }));
    const web = db.prepare("SELECT u.upload_uuid,m.id AS messageId,m.created_at AS createdAt FROM chat_web_uploads u JOIN chat_thread_messages m ON m.id=u.thread_message_id WHERE u.thread_id=? AND u.site=? AND u.company_code=? AND u.target_kind='thread' AND u.state='committed' AND u.kind='photo' AND m.thread_id=? AND m.direction='out' AND m.author_kind IN ('owner','manager') ORDER BY m.id DESC LIMIT 30").all(threadId, SITE, COMPANY, threadId)
      .map(r => ({ attachmentRef: `upload:${r.upload_uuid}`, messageId: r.messageId, createdAt: r.createdAt, label: 'Отправленное фото в приложении' }));
    return [...native, ...web].sort((a, b) => b.messageId - a.messageId).slice(0, 50);
  }
  function view(ctx, who) {
    const by = actor(who), s = ctx.current, index = s.stages.findIndex(stage => stage.id === s.currentStageId), stage = s.stages[index];
    const confirmations = s.confirmations.filter(c => c.stageId === stage.id);
    const missing = stage.requirements.filter(r => !confirmations.some(c => c.requirement === r));
    const nextStage = s.stages[index + 1];
    const cancelled = ctx.order.work?.status === 'cancelled';
    return { orderRef: `native-order:${ctx.id}`, revision: s.revision, configRevision: s.configRevision, currentStageId: s.currentStageId,
      stages: clone(s.stages), confirmations: clone(s.confirmations), history: clone(s.history), nextStage: nextStage ? { id: nextStage.id, label: nextStage.label } : null,
      terminal: !nextStage || cancelled, cancelled, canEdit: canAccess(getUser(by.id), 'crm.edit'), allowed: Boolean(nextStage && !cancelled && !missing.length && canAccess(getUser(by.id), 'crm.edit')), missing,
      availablePhotos: photos(ctx.id) };
  }
  function getOrder(who, id) { actor(who); const ctx = orderContext(id), result = view(ctx, who); actor(who); return result; }
  function change(who, raw, body, action) {
    mutation(body, action === 'confirm' ? ['requirement', 'channel', 'note'] : [], action === 'confirm' ? ['attachmentRef'] : []); actor(who, true);
    return transaction(() => {
      const by = actor(who, true), ctx = orderContext(raw), old = ctx.current, known = replay(old, by, body, action);
      if (known.duplicate) return { ...view(ctx, who), duplicate: true };
      if (ctx.order.work?.status === 'cancelled') fail(409, 'Отменённую заявку нельзя продвигать', 'CANCELLED');
      const index = old.stages.findIndex(s => s.id === old.currentStageId), stage = old.stages[index];
      if (index === old.stages.length - 1) fail(409, 'Заказ уже завершён', 'TERMINAL');
      const value = clone(old);
      if (action === 'confirm') {
        if (!stage.requirements.includes(body.requirement) || !CHANNELS.includes(body.channel)) fail(400, 'Условие не относится к текущему этапу');
        const note = text(body.note, 1000, body.channel === 'app');
        if (body.requirement === 'photo_sent' && body.channel === 'app') {
          if (!photos(ctx.id).some(p => p.attachmentRef === body.attachmentRef)) fail(409, 'Сначала отправьте фото в этот чат и выберите его', 'PHOTO_NOT_SENT');
        } else if (Object.hasOwn(body, 'attachmentRef')) fail(400, 'Вложение допустимо только для фото из чата');
        if (value.confirmations.some(c => c.stageId === stage.id && c.requirement === body.requirement)) fail(409, 'Это условие уже подтверждено', 'ALREADY_CONFIRMED');
        value.confirmations.push({ stageId: stage.id, requirement: body.requirement, channel: body.channel, note, at: at(), actor: { id: by.id, label: by.label }, ...(body.attachmentRef ? { attachmentRef: body.attachmentRef } : {}) });
      } else {
        const missing = stage.requirements.filter(r => !value.confirmations.some(c => c.stageId === stage.id && c.requirement === r));
        if (missing.length) fail(409, 'Сначала подтвердите условия текущего этапа', 'REQUIREMENTS');
        value.currentStageId = old.stages[index + 1].id;
        // Штатный список активных/истории использует прежний статус, а не отдельный реестр заказов.
        siteOrders.setWorkStatus(SITE, ctx.id, index + 1 === old.stages.length - 1 ? 'done' : 'in_work', by.label, { expected: ctx.order.work?.status || 'new' });
      }
      value.history.push({ action, stageId: stage.id, nextStageId: value.currentStageId, at: at(), actor: { id: by.id, label: by.label } });
      value.history = value.history.slice(-500); value.receipts = receipt(old, by, body, known.hash);
      actor(who, true); ctx.current = save(ctx.key, old, value, by); actor(who, true);
      return { ...view(ctx, who), duplicate: false };
    });
  }
  const threadReplyKey = threadId => `${KEY}/chat-autoreply/${threadId}`;
  const orderReplyKey = orderId => `${KEY}/order-autoreply/${orderId}`;
  const replyActor = { id: 0, label: 'Автоответ Palitra Love' };
  const replyText = reply => [reply.text, ...reply.questions.map(q => `${q.label}${q.options.length ? ` (${q.options.join(' / ')})` : ''}`)].filter(Boolean).join('\n\n');
  // Только новый canonical чат принятой заявки, в общей транзакции заявки/thread/grant.
  function onOrderThreadCreated({ thread, orderId, append } = {}) {
    if (db.isTransaction !== true) fail(503, 'Автоответ требует общей транзакции заявки', 'ORDER_REPLY_TRANSACTION');
    if (!thread || thread.site !== SITE || thread.company_code !== COMPANY || !Number.isSafeInteger(orderId) || orderId < 1
      || !Number.isSafeInteger(thread.id) || thread.id < 1 || thread.order_id !== orderId || typeof append !== 'function') fail(409, 'Заявка и чат автоответа не совпали', 'ORDER_REPLY_SCOPE');
    const canonical = db.prepare('SELECT id,site,company_code,order_id FROM chat_threads WHERE id=?').get(thread.id);
    const order = siteOrders.orderSummary(SITE, orderId);
    if (!canonical || canonical.site !== SITE || canonical.company_code !== COMPANY || canonical.order_id !== orderId
      || !order || order.id !== orderId) fail(409, 'Заявка и чат автоответа не совпали', 'ORDER_REPLY_SCOPE');
    const key = orderReplyKey(orderId), known = load(key);
    if (known) {
      if (known.orderId !== orderId || known.threadId !== thread.id) fail(409, 'Квитанция автоответа относится к другому чату', 'ORDER_REPLY_SCOPE');
      return { duplicate: true, outcome: known.outcome, replyMessageId: known.replyMessageId };
    }
    const previous = load(threadReplyKey(thread.id));
    if (previous) {
      const message = db.prepare('SELECT thread_id,direction,author_kind,source_channel FROM chat_thread_messages WHERE id=?').get(previous.replyMessageId);
      if (!message || message.thread_id !== thread.id || message.direction !== 'out' || message.author_kind !== 'manager' || message.source_channel !== 'app') fail(503, 'Сохранённый автоответ не подтверждён историей', 'STATE');
      save(key, null, { orderId, threadId: thread.id, outcome: 'legacy', replyMessageId: previous.replyMessageId, questions: clone(previous.questions || []) }, replyActor);
      return { duplicate: true, outcome: 'legacy', replyMessageId: previous.replyMessageId };
    }
    const config = configRecord(), reply = config.autoReply;
    const decision = { orderId, threadId: thread.id, configRevision: config.revision,
      outcome: reply.enabled ? 'stored' : 'disabled', replyMessageId: null, questions: reply.enabled ? clone(reply.questions) : [] };
    if (reply.enabled) {
      decision.replyMessageId = append(replyText(reply));
      save(threadReplyKey(thread.id), null, { replyMessageId: decision.replyMessageId, questions: decision.questions,
        orderId, configRevision: config.revision, trigger: 'order-created' }, replyActor);
    }
    // Выключенное правило тоже фиксируется: позднее включение не переигрывает прежнюю заявку.
    save(key, null, decision, replyActor);
    return { duplicate: false, outcome: decision.outcome, replyMessageId: decision.replyMessageId };
  }
  // Совместимость старых чатов: первый web-входящий, если по заявке ещё не было решения/автоответа.
  function onCustomerMessage({ thread, messageId, source, append }) {
    if (!thread || thread.site !== SITE || thread.company_code !== COMPANY || source !== 'web' || typeof append !== 'function') return;
    if (load(threadReplyKey(thread.id)) || (Number.isSafeInteger(thread.order_id) && thread.order_id > 0 && load(orderReplyKey(thread.order_id)))) return;
    const first = db.prepare("SELECT id FROM chat_thread_messages WHERE thread_id=? AND direction='in' AND author_kind='customer' ORDER BY id LIMIT 1").get(thread.id);
    if (!first || first.id !== messageId) return;
    const reply = configRecord().autoReply; if (!reply.enabled) return;
    const replyMessageId = append(replyText(reply));
    save(threadReplyKey(thread.id), null, { replyMessageId, questions: clone(reply.questions) }, replyActor);
  }
  function customerQuestions(thread) {
    if (!thread || thread.site !== SITE || thread.company_code !== COMPANY) return [];
    const snapshot = load(threadReplyKey(thread.id));
    return snapshot && Array.isArray(snapshot.questions) ? clone(snapshot.questions) : [];
  }
  return Object.freeze({ getConfig, putConfig, getOrder, confirm: (who, id, body) => change(who, id, body, 'confirm'), advance: (who, id, body) => change(who, id, body, 'advance'), onCustomerMessage, onOrderThreadCreated, customerQuestions });
}
function createWorkflowHttp({ workflow, requireSession, requireCsrf, readJson, origin }) {
  return async function handle(request, url, reply) {
    const match = /^\/content\/palitra\/workflow(?:\/orders\/([1-9]\d{0,14})(?:\/(confirm|advance))?)?$/.exec(url.pathname);
    if (!match) return false;
    const headers = { 'cache-control': 'no-store' }, before = requireSession(request), who = s => ({ id: s.user.id, sessionVersion: s.user.sessionVersion });
    const write = !['GET', 'HEAD'].includes(request.method);
    if (!canAccess(before.user, write ? 'crm.edit' : 'crm.view') || (write && !match[1] && before.user.role !== 'owner')) fail(403, 'Нет доступа к этапам Palitra Love', 'ACCESS');
    if (url.search) fail(400, 'Параметры адреса не поддерживаются');
    if (request.method === 'GET' && !match[2]) { reply(200, match[1] ? workflow.getOrder(who(before), match[1]) : workflow.getConfig(who(before)), headers); return true; }
    const method = match[1] ? 'POST' : 'PUT';
    if (request.method !== method || (match[1] && !match[2])) fail(405, 'Метод не поддерживается', 'METHOD');
    if (request.headers.origin !== origin) fail(403, 'Запрос с другого адреса запрещён', 'ORIGIN');
    requireCsrf(request, before);
    if (!/^application\/json(?:\s*;|$)/i.test(String(request.headers['content-type'] || ''))) fail(415, 'Ожидался JSON');
    const body = await readJson(request), fresh = requireSession(request);
    if (fresh.user.id !== before.user.id || fresh.user.sessionVersion !== before.user.sessionVersion) fail(403, 'Доступ изменился', 'ACCESS');
    requireCsrf(request, fresh);
    const result = !match[1] ? workflow.putConfig(who(fresh), body) : workflow[match[2]](who(fresh), match[1], body);
    reply(200, result, headers); return true;
  };
}
module.exports = { createWorkflow, createWorkflowHttp, validateConfig, canAccess, REQUIREMENTS, CHANNELS, DEFAULT };
