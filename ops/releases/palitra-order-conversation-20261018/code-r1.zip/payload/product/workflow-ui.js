/* Palitra Love: этапы, автоответ и установка. Данные только через внедрённый same-origin host.
   Этот модуль не даёт прав по роли экрана и не создаёт клиентов, чаты, уведомления или свою БД. */
'use strict';
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else Object.defineProperty(root, 'PalitraWorkflowUI', { value: api, writable: false });
})(typeof globalThis !== 'undefined' ? globalThis : this, () => {
  const REQUIREMENTS = Object.freeze({ contact_confirmed: 'Связались с клиентом', details_confirmed: 'Детали заказа согласованы', payment_confirmed: 'Оплата подтверждена', photo_sent: 'Фото отправлено клиенту', handover_confirmed: 'Заказ передан клиенту', feedback_requested: 'Отзыв запрошен' });
  const CHANNELS = Object.freeze({ app: 'Чат приложения', phone: 'Телефон', telegram: 'Telegram', whatsapp: 'WhatsApp' });
  const copy = (value) => JSON.parse(JSON.stringify(value));
  const idOk = (id) => Number.isSafeInteger(id) && id > 0;
  function create({ document: doc, window: win, request, onUnauthorized = () => {}, onChanged = () => {}, now = () => Date.now() }) {
    const h = (tag, props, ...children) => {
      const el = doc.createElement(tag);
      for (const [key, value] of Object.entries(props || {})) {
        if (value == null || value === false) continue;
        if (key === 'text') el.textContent = String(value);
        else if (['value', 'checked', 'disabled', 'selected'].includes(key)) el[key] = value;
        else if (key === 'class') el.className = value;
        else if (key.startsWith('on')) el.addEventListener(key.slice(2), value);
        else el.setAttribute(key, value === true ? '' : String(value));
      }
      for (const child of children.flat(Infinity)) if (child != null && child !== false) el.append(typeof child === 'object' ? child : String(child));
      return el;
    };
    const button = (text, onclick, props = {}) => h('button', { type: 'button', class: 'app-btn app-btn--ghost', text, onclick, ...props });
    const field = (label, input) => h('label', { class: 'field' }, h('span', { class: 'field__label', text: label }), input);
    const input = (value, oninput, props = {}) => h('input', { type: 'text', class: 'app-input', value, oninput: (e) => oninput(e.target.value), ...props });
    const textarea = (value, oninput, props = {}) => h('textarea', { rows: '3', class: 'app-input', value, oninput: (e) => oninput(e.target.value), ...props });
    const msg = (text, error = false) => h('p', { class: error ? 'app-error' : 'muted', role: error ? 'alert' : 'status', text });
    let identity = { key: '', role: '', member: false, permissions: [] }, epoch = 0;
    let settings = null;
    const orders = new Map();
    const questionnaires = new Map();
    let installEvent = null, installed = false, onboardingExpanded = false, pushStatus = '', installBusy = false;
    const onboardingRoots = new Set();
    const guideExpandedImages = new Set();
    const onboardingFocus = new WeakMap();
    const memoryPrefs = new Map();
    const notificationDefaults = Object.freeze({"installTitle": "Заказ всегда под рукой", "notificationTitle": "Уведомления Palitra Love", "installClientText": "Добавьте Palitra Love на главный экран, чтобы возвращаться в чат и отслеживать заказ. Это необязательно.", "installStaffText": "Закрепите приложение, чтобы быстро открывать заказы и переписку.", "installedText": "Приложение уже открыто с главного экрана. Выберите, хотите ли получать уведомления на этом устройстве.", "installButton": "Установить приложение", "installHelpButton": "Как добавить на главный экран", "installBusyText": "Подтвердите в браузере…", "deviceHeading": "Уведомления на этом устройстве", "enableButton": "Включить уведомления", "disableButton": "Отключить уведомления", "laterButton": "Позже", "neverButton": "Больше не предлагать", "pushUnavailableText": "Push-уведомления пока не подключены. Заказы и сообщения проверяйте в приложении. Установка сама по себе push не включает.", "iosInstallText": "Для push на iPhone/iPad сначала добавьте приложение на экран Домой и откройте его оттуда (iOS/iPadOS 16.4 или новее).", "permissionDeniedText": "Уведомления запрещены в браузере. Откройте настройки этого сайта → «Уведомления» и разрешите их, если хотите получать push.", "subscribedText": "Уведомления подключены на этом устройстве.", "unsubscribedText": "Уведомления отключены на этом устройстве.", "permissionPromptText": "Подтвердите разрешение браузера.", "unconfirmedText": "Подписка не подтверждена сервером. Push пока не включён.", "subscribeErrorText": "Не удалось подключить уведомления. Можно продолжить без них.", "closeLabel": "Закрыть предложение", "iosStep1": "Откройте эту страницу в Safari. Если вы пришли из Telegram или другой соцсети, откройте ссылку во внешнем браузере Safari.", "iosStep2": "Нажмите «Ещё» (…) внизу справа, затем «Поделиться». В другом виде Safari кнопка «Поделиться» может быть сразу на панели.", "iosStep3": "Выберите «На экран Домой». Если пункта нет, прокрутите список действий ниже.", "iosStep4": "Оставьте «Открывать как веб-приложение» включённым, нажмите «Добавить». Открывайте Palitra Love с нового значка.", "androidStep1": "Откройте страницу в Chrome и нажмите меню ⋮ вверху справа.", "androidStep2": "Выберите «Установить приложение» или «Добавить на главный экран». Название пункта зависит от версии Chrome.", "androidStep3": "Подтвердите установку и открывайте Palitra Love с нового значка.", "desktopStep1": "Откройте меню браузера ⋮ или ….", "desktopStep2": "Выберите «Установить приложение» или «Приложения» → «Установить этот сайт как приложение».", "desktopStep3": "Подтвердите установку и открывайте Palitra Love с нового значка.", "guideExampleText": "Пример интерфейса; название сайта и пункты меню могут отличаться. У вас будет Palitra Love.", "guideImageButton": "Увеличить изображение", "guideSourceLabel": "Официальная инструкция", "guideBackButton": "Вернуться к шагам"});
    const notificationLimits = Object.freeze({"installTitle": 160, "notificationTitle": 160, "installClientText": 2000, "installStaffText": 2000, "installedText": 2000, "installButton": 120, "installHelpButton": 120, "installBusyText": 120, "deviceHeading": 160, "enableButton": 120, "disableButton": 120, "laterButton": 120, "neverButton": 120, "pushUnavailableText": 2000, "iosInstallText": 2000, "permissionDeniedText": 2000, "subscribedText": 2000, "unsubscribedText": 2000, "permissionPromptText": 2000, "unconfirmedText": 2000, "subscribeErrorText": 2000, "closeLabel": 120, "iosStep1": 400, "iosStep2": 400, "iosStep3": 400, "iosStep4": 400, "androidStep1": 400, "androidStep2": 400, "androidStep3": 400, "desktopStep1": 400, "desktopStep2": 400, "desktopStep3": 400, "guideExampleText": 400, "guideImageButton": 120, "guideSourceLabel": 120, "guideBackButton": 120});
    let notificationTexts = {}, notificationLoadedAt = 0, notificationLoading = false;
    const txt = (key) => typeof notificationTexts[key] === 'string' ? notificationTexts[key] : notificationDefaults[key];
    async function loadNotificationTexts() {
      // Only fixed public-copy routes. Never fetch or publish the private Forms board.
      if (notificationLoading || notificationLoadedAt && now() - notificationLoadedAt < 30000 || typeof win.fetch !== 'function' || !win.location) return;
      const host = win.location.hostname;
      const path = host === 'palitra-love.ru' || host === 'palitra-love-draft-1.synapsebusiness.ru' ? '/love-app/notification-texts.json'
        : host === 'synapse.synapsebusiness.ru' ? '/content/palitra/notification-texts' : null;
      if (!path) return;
      notificationLoading = true; notificationLoadedAt = now();
      try {
        const response = await win.fetch(path, { method: 'GET', credentials: 'omit', cache: 'no-store', redirect: 'error' });
        if (!response.ok) return;
        const raw = await response.text(); if (raw.length > 131072) return;
        const body = JSON.parse(raw);
        if (!body || body.schema !== 1 || !Number.isSafeInteger(body.revision) || body.revision < 0 || !body.notificationTexts || typeof body.notificationTexts !== 'object' || Array.isArray(body.notificationTexts)) return;
        const safe = {};
        for (const key of Object.keys(body.notificationTexts)) {
          const value = body.notificationTexts[key];
          if (!Object.hasOwn(notificationLimits, key) || typeof value !== 'string' || Array.from(value).length > notificationLimits[key] || /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f-\u009f<>]/u.test(value)) return;
          if (notificationLimits[key] < 400 && /[\t\n\r]/u.test(value)) return;
          safe[key] = value;
        }
        if (new TextEncoder().encode(JSON.stringify(safe)).byteLength > 65536) return;
        if (JSON.stringify(safe) !== JSON.stringify(notificationTexts)) { notificationTexts = safe; repaintOnboarding(); }
      } catch (_) { /* Chat and explicit install/Push controls stay usable with defaults. */ }
      finally { notificationLoading = false; }
    }
    const nativeInstalled = () => installed || Boolean(win.navigator && win.navigator.standalone) || Boolean(win.matchMedia && win.matchMedia('(display-mode: standalone)').matches);
    function allowed(permission) { return identity.member === true && (identity.role === 'owner' || identity.permissions.includes(permission)); }
    const canRead = () => allowed('crm.view');
    const canWrite = () => allowed('crm.edit');
    const isOwner = () => identity.member === true && identity.role === 'owner';
    function setIdentity(next) {
      const sanitized = { key: typeof next.key === 'string' ? next.key : '', role: next.role || '', member: next.member === true, permissions: Array.isArray(next.permissions) ? next.permissions.filter((p) => typeof p === 'string') : [] };
      if (JSON.stringify(identity) !== JSON.stringify(sanitized)) { epoch++; settings = null; orders.clear(); questionnaires.clear(); for (const root of onboardingRoots) root.remove(); onboardingRoots.clear(); onboardingExpanded = false; pushStatus = ''; guideExpandedImages.clear(); }
      identity = sanitized;
    }
    async function call(path, method = 'GET', body) {
      if (!request) throw new Error('Этапы заказа ещё не подключены. Обновите страницу позже.');
      try { return await request(path, { method, ...(body === undefined ? {} : { body }) }); }
      catch (error) { if (error.status === 401) onUnauthorized(error); throw error; }
    }
    const requestId = () => win.crypto && typeof win.crypto.randomUUID === 'function' ? win.crypto.randomUUID() : 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => { const r = Math.floor(Math.random() * 16); return (c === 'x' ? r : (r & 3) | 8).toString(16); });
    function resultConfig(data) { const value = data && data.config || data; if (!value || !Number.isSafeInteger(value.revision) || !value.autoReply || !Array.isArray(value.stages)) throw new Error('Сервер не подтвердил настройки.'); return value; }
    function resultOrder(data, orderId) { const value = data && data.order || data; if (!value || value.orderRef !== `native-order:${orderId}` || !Number.isSafeInteger(value.revision) || !Array.isArray(value.stages) || !Array.isArray(value.missing)) throw new Error('Сервер не подтвердил этап именно этого заказа.'); return value; }
    function settingsPanel() {
      if (!isOwner()) return h('section', { class: 'card workflow', 'data-workflow': 'forbidden' }, msg('Настройки автоответа и этапов доступны собственнику.'));
      if (!settings) settings = { data: null, draft: null, loading: false, saving: false, error: '', message: '', pending: null, roots: new Set() };
      for (const old of settings.roots) if (!old.isConnected) settings.roots.delete(old);
      const root = h('section', { class: 'card workflow', 'data-workflow': 'settings' });
      settings.roots.add(root);
      paintSettings(root);
      if (!settings.data && !settings.loading && !settings.error) loadSettings();
      return root;
    }
    function paintAllSettings() { if (settings) for (const root of settings.roots) if (root.isConnected) paintSettings(root); }
    async function loadSettings({ replaceDraft = false } = {}) {
      const s = settings, token = epoch; if (!s || s.loading) return;
      s.loading = true; s.error = ''; paintAllSettings();
      try { const value = resultConfig(await call('/content/palitra/workflow')); if (token !== epoch || s !== settings) return; s.data = copy(value); if (!s.draft || replaceDraft) s.draft = copy(value); }
      catch (error) { if (token === epoch && s === settings) s.error = error.message; }
      finally { if (token === epoch && s === settings) { s.loading = false; paintAllSettings(); } }
    }
    function paintSettings(root) {
      const s = settings; if (!s) return;
      const header = h('h2', { class: 'text__title', text: 'Автоответ и этапы заказа' });
      if (s.pending && !s.saving) { root.replaceChildren(header, msg(s.error || 'Исход сохранения ещё не подтверждён.', true), msg('Ваш текст сохранён в этой вкладке. Повтор отправляет тот же запрос, чтобы не создать дубликат.'),
        button('Повторить то же сохранение', saveSettings), button('Перечитать с сервера', () => loadSettings()),
        button('Сверил результат — вернуться к правкам', () => { s.pending = null; s.error = ''; paintAllSettings(); })); return; }
      if (!s.draft) { root.replaceChildren(...[header, msg(s.loading ? 'Загружаем настройки…' : s.error || 'Нет настроек.', Boolean(s.error)), !s.loading ? button('Повторить чтение', () => loadSettings()) : null].filter(Boolean)); return; }
      const draft = s.draft, busy = s.saving;
      const auto = draft.autoReply;
      const questions = Array.isArray(auto.questions) ? auto.questions : (auto.questions = []);
      const area = h('div', { class: 'workflow__settings' }, header,
        h('h3', { text: 'Приветствие при новой заявке' }),
        h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: auto.enabled, disabled: busy, 'data-auto-enabled': '', onchange: (e) => { auto.enabled = e.target.checked; } }), 'Отправлять приветствие при создании каждой новой заявки'),
        field('Текст автоответа', textarea(auto.text || '', (v) => { auto.text = v; }, { maxlength: '3000', disabled: busy, 'data-auto-text': '' })),
        msg('Сообщение появляется в общем чате после создания каждой новой заявки. Первое сообщение клиента не требуется. Повторная отправка той же заявки не создаёт дубль.'),
        h('h3', { text: 'Необязательные вопросы' }),
        ...questions.map((q, i) => h('div', { class: 'workflow__row' }, field(`Вопрос ${i + 1}`, input(q.label, (v) => { q.label = v; }, { disabled: busy, maxlength: '180' })),
          field('Варианты ответа — по одному в строке', textarea((q.options || []).join('\n'), (v) => { q.options = v.split('\n').map((t) => t.trim()).filter(Boolean); }, { disabled: busy, maxlength: '1500' })),
          button('Удалить вопрос', () => { questions.splice(i, 1); paintAllSettings(); }, { disabled: busy }))),
        button('Добавить вопрос', () => { questions.push({ id: `question_${requestId().replace(/-/g, '').slice(0, 16)}`, label: '', options: [] }); paintAllSettings(); }, { disabled: busy || questions.length >= 6 }),
        h('h3', { text: 'Этапы продаж' }), msg('Условия относятся к текущему этапу. Переход откроется после подтверждений. Изменения настроек не переписывают цепочку уже начатого заказа.'),
        ...draft.stages.map((stage, i) => h('fieldset', { class: 'workflow__stage', disabled: busy },
          h('legend', { text: `Этап ${i + 1}` }), field('Название', input(stage.label, (v) => { stage.label = v; }, { disabled: busy, maxlength: '100' })),
          field('Подсказка менеджеру', textarea(stage.hint || '', (v) => { stage.hint = v; }, { disabled: busy, maxlength: '500' })),
          h('strong', { text: 'Для следующего этапа требуется' }), ...Object.entries(REQUIREMENTS).map(([key, label]) => h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: (stage.requirements || []).includes(key), disabled: busy,
            onchange: (e) => { stage.requirements = e.target.checked ? [...new Set([...(stage.requirements || []), key])] : (stage.requirements || []).filter((x) => x !== key); } }), label)),
          h('div', { class: 'workflow__buttons' }, button('↑ Выше', () => { [draft.stages[i - 1], draft.stages[i]] = [stage, draft.stages[i - 1]]; paintAllSettings(); }, { disabled: busy || i === 0, 'aria-label': `Этап ${i + 1} выше` }),
            button('↓ Ниже', () => { [draft.stages[i + 1], draft.stages[i]] = [stage, draft.stages[i + 1]]; paintAllSettings(); }, { disabled: busy || i === draft.stages.length - 1, 'aria-label': `Этап ${i + 1} ниже` }),
            button('Удалить этап', () => { draft.stages.splice(i, 1); paintAllSettings(); }, { disabled: busy || draft.stages.length <= 2 })))),
        button('Добавить этап', () => { draft.stages.push({ id: `stage_${requestId().replace(/-/g, '').slice(0, 16)}`, label: 'Новый этап', hint: '', requirements: [] }); paintAllSettings(); }, { disabled: busy || draft.stages.length >= 20 }),
        s.error ? msg(s.error, true) : null, s.message ? msg(s.message) : null,
        h('div', { class: 'workflow__buttons' }, button(busy ? 'Сохраняем…' : s.pending ? 'Повторить то же сохранение' : 'Сохранить настройки', saveSettings, { class: 'app-btn', disabled: busy, 'data-save-settings': '' }),
          button('Перечитать с сервера', () => loadSettings(), { disabled: busy }), button('Сбросить мои изменения', () => { s.draft = copy(s.data); s.error = ''; s.pending = null; paintAllSettings(); }, { disabled: busy })));
      root.replaceChildren(area);
    }
    async function saveSettings() {
      const s = settings, token = epoch; if (!s || s.saving || !isOwner()) return;
      if (s.draft.stages.some((x) => !x.label.trim()) || (s.draft.autoReply.enabled && !s.draft.autoReply.text.trim())) { s.error = 'Заполните названия этапов и текст включённого автоответа.'; paintAllSettings(); return; }
      if (s.draft.stages.at(-1).requirements.length) { s.error = 'Последний этап завершает цепочку. Уберите у него условия перехода или переместите его выше.'; paintAllSettings(); return; }
      if (s.draft.autoReply.questions.some((q) => !q.label.trim() || q.options.length > 8 || q.options.some((v) => v.length > 100))) { s.error = 'Укажите текст каждого вопроса. Можно до восьми вариантов, каждый до 100 символов.'; paintAllSettings(); return; }
      const body = s.pending || { expectedRevision: s.data.revision, requestId: requestId(), config: { autoReply: copy(s.draft.autoReply), stages: copy(s.draft.stages) } };
      s.pending = body; s.saving = true; s.error = ''; s.message = ''; paintAllSettings();
      try { const value = resultConfig(await call('/content/palitra/workflow', 'PUT', body)); if (token !== epoch || s !== settings) return; s.data = copy(value); s.draft = copy(value); s.pending = null; s.message = 'Настройки сохранены на сервере.'; }
      catch (error) { if (token !== epoch || s !== settings) return; s.error = error.status === 409 ? 'Настройки уже изменились. Ваш ввод сохранён. Перечитайте сервер, затем сверьте и сохраните изменения.' : `${error.message} Исход сохранения уточните чтением; повтор использует тот же запрос.`; if (error.status) s.pending = null; }
      finally { if (token === epoch && s === settings) { s.saving = false; paintAllSettings(); } }
    }
    function orderPanel(orderId) {
      if (!idOk(orderId) || !canRead()) return null;
      if (!orders.has(orderId)) orders.set(orderId, { data: null, loading: false, busy: false, readAt: 0, error: '', drafts: new Map(), pending: null, roots: new Set() });
      const s = orders.get(orderId), root = h('section', { class: 'card workflow', 'data-workflow-order': String(orderId) });
      for (const old of s.roots) if (!old.isConnected) s.roots.delete(old);
      s.roots.add(root); paintOrder(root, orderId);
      if (!s.loading && !s.busy && (!s.data || now() - s.readAt > 5000) && !s.error) loadOrder(orderId);
      return root;
    }
    function paintAllOrders(orderId) { const s = orders.get(orderId); if (s) for (const root of s.roots) if (root.isConnected) paintOrder(root, orderId); }
    async function loadOrder(orderId) {
      const s = orders.get(orderId), token = epoch; if (!s || s.loading) return;
      s.loading = true; s.error = ''; paintAllOrders(orderId);
      try { const data = resultOrder(await call(`/content/palitra/workflow/orders/${orderId}`), orderId); if (token !== epoch || orders.get(orderId) !== s) return; s.data = copy(data); s.readAt = now(); }
      catch (error) { if (token === epoch && orders.get(orderId) === s) s.error = error.message; }
      finally { if (token === epoch && orders.get(orderId) === s) { s.loading = false; paintAllOrders(orderId); } }
    }
    function paintOrder(root, orderId) {
      const s = orders.get(orderId); if (!s) return;
      const header = h('h3', { text: 'Этапы заказа' });
      if (!s.data) { root.replaceChildren(...[header, msg(s.loading ? 'Загружаем этапы…' : s.error || 'Нет данных этапов.', Boolean(s.error)), s.loading ? null : button('Повторить чтение', () => loadOrder(orderId))].filter(Boolean)); return; }
      const d = s.data, stage = d.stages.find((x) => x.id === d.currentStageId);
      const rows = (d.missing || []).filter((r) => Object.hasOwn(REQUIREMENTS, r));
      const children = [header, h('strong', { class: 'workflow__current', text: stage ? stage.label : 'Этап не определён' }), stage && stage.hint ? msg(stage.hint) : null,
        h('ol', { class: 'workflow__timeline' }, ...d.stages.map((st) => h('li', { class: st.id === d.currentStageId ? 'is-current' : '', 'aria-current': st.id === d.currentStageId ? 'step' : null, text: st.label }))),
        msg('Можно общаться в удобном клиенту канале. Подтвердите результат здесь — Дарья увидит его в истории заказа.')];
      for (const requirement of rows) {
        if (!s.drafts.has(requirement)) s.drafts.set(requirement, { channel: 'app', note: '', attachmentRef: '' });
        const draft = s.drafts.get(requirement), writable = canWrite() && d.canEdit !== false && !d.terminal && !s.busy;
        const select = h('select', { class: 'app-input', value: draft.channel, disabled: !writable, 'aria-label': `Канал: ${REQUIREMENTS[requirement]}`, onchange: (e) => { draft.channel = e.target.value; paintAllOrders(orderId); } },
          ...Object.entries(CHANNELS).map(([value, label]) => h('option', { value, text: label, ...(value === draft.channel ? { selected: true } : {}) })));
        const photos = Array.isArray(d.availablePhotos) ? d.availablePhotos : [];
        const photoChoice = requirement === 'photo_sent' && draft.channel === 'app' ? field('Уже отправленное фото в этом чате', h('select', { class: 'app-input', disabled: !writable, value: draft.attachmentRef,
          onchange: (e) => { draft.attachmentRef = e.target.value; } }, h('option', { value: '', text: 'Выберите отправленное фото' }),
          ...photos.map((photo) => h('option', { value: photo.attachmentRef, text: photo.label || `Фото ${photo.id}`, ...(photo.attachmentRef === draft.attachmentRef ? { selected: true } : {}) })))) : null;
        children.push(h('fieldset', { class: 'workflow__confirmation' }, h('legend', { text: REQUIREMENTS[requirement] }), field('Где подтвердили', select), photoChoice,
          requirement === 'photo_sent' && draft.channel === 'app' && !photos.length ? msg('Сначала отправьте фото клиенту. Затем обновите этапы. Выбор файла сам по себе отправку не подтверждает.') : null,
          field(draft.channel === 'app' ? 'Комментарий' : 'Что подтвердили с клиентом в этом канале', textarea(draft.note, (v) => { draft.note = v; }, { disabled: !writable, maxlength: '1000', 'aria-label': `Подтверждение: ${REQUIREMENTS[requirement]}` })),
          button(`Подтвердить: ${REQUIREMENTS[requirement].toLowerCase()}`, () => confirmOrder(orderId, requirement), { disabled: !writable, 'data-confirm': requirement })));
      }
      if (!canWrite()) children.push(msg('Вы можете просматривать заказ. Изменять этапы может сотрудник с правом редактирования CRM.'));
      children.push(s.error ? msg(s.error, true) : null,
        button(d.cancelled ? 'Заказ отменён' : d.terminal ? 'Заказ завершён' : d.nextStage ? `Следующий этап: ${d.nextStage.label}` : 'Завершить этап', () => mutateOrder(orderId, 'advance'),
          { class: 'app-btn', disabled: !canWrite() || s.busy || d.allowed !== true || d.terminal === true, 'data-advance': '' }),
        button(s.loading ? 'Обновляем…' : 'Обновить этапы', () => loadOrder(orderId), { disabled: s.loading || s.busy }),
        s.pending ? button('Повторить прежний запрос', () => mutateOrder(orderId, s.pending.action), { disabled: s.busy || !canWrite() }) : null,
        h('details', { class: 'workflow__history' }, h('summary', { text: 'История подтверждений' }), ...(d.confirmations || []).map((c) => h('p', { text: `${REQUIREMENTS[c.requirement] || c.requirement} · ${CHANNELS[c.channel] || c.channel} · ${c.actor && c.actor.label || 'Менеджер'} · ${c.at || ''}${c.note ? ` — ${c.note}` : ''}` }))));
      root.replaceChildren(...children.filter(Boolean));
    }
    function confirmOrder(orderId, requirement) {
      const s = orders.get(orderId), draft = s && s.drafts.get(requirement); if (!s || !draft || !canWrite()) return;
      if (s.pending) { s.error = 'Сначала уточните результат предыдущего действия или повторите прежний запрос.'; paintAllOrders(orderId); return; }
      if (draft.channel !== 'app' && !draft.note.trim()) { s.error = 'Опишите подтверждение клиента в выбранном канале.'; paintAllOrders(orderId); return; }
      if (requirement === 'photo_sent' && draft.channel === 'app' && !draft.attachmentRef) { s.error = 'Выберите фото, которое уже отправлено в этот чат.'; paintAllOrders(orderId); return; }
      mutateOrder(orderId, 'confirm', { requirement, channel: draft.channel, note: draft.note.trim(), ...(draft.channel === 'app' && draft.attachmentRef && requirement === 'photo_sent' ? { attachmentRef: draft.attachmentRef } : {}) });
    }
    async function mutateOrder(orderId, action, patch = {}) {
      const s = orders.get(orderId), token = epoch; if (!s || s.busy || !s.data || !canWrite()) return;
      if (s.pending && s.pending.action !== action) { s.error = 'Сначала уточните результат предыдущего действия чтением или повторите прежний запрос.'; paintAllOrders(orderId); return; }
      const body = s.pending ? s.pending.body : { expectedRevision: s.data.revision, requestId: requestId(), ...patch };
      s.pending = { action, body }; s.busy = true; s.error = ''; paintAllOrders(orderId);
      try { const result = resultOrder(await call(`/content/palitra/workflow/orders/${orderId}/${action}`, 'POST', body), orderId); if (token !== epoch || orders.get(orderId) !== s) return; s.data = copy(result); s.readAt = now(); s.pending = null; onChanged(orderId); }
      catch (error) { if (token !== epoch || orders.get(orderId) !== s) return; s.error = error.status === 409 ? 'Заказ изменился. Обновите этапы и проверьте текущие подтверждения.' : `${error.message} Проверьте результат обновлением; неизвестный запрос можно повторить без изменений.`; if (error.status) s.pending = null; }
      finally { if (token === epoch && orders.get(orderId) === s) { s.busy = false; paintAllOrders(orderId); } }
    }
    function questionnairePanel(key, items, send) {
      const questions = Array.isArray(items) ? items.filter((q) => q && typeof q.id === 'string' && typeof q.label === 'string').slice(0, 8) : [];
      if (!questions.length || typeof key !== 'string' || typeof send !== 'function') return null;
      if (!questionnaires.has(key)) questionnaires.set(key, { answers: {}, busy: false, sent: false, error: '', mounts: new Set() });
      const s = questionnaires.get(key), root = h('details', { class: 'card workflow questionnaire', 'data-questionnaire': key });
      for (const old of s.mounts) if (!old.root.isConnected) s.mounts.delete(old);
      const repaint = () => { for (const mount of s.mounts) if (mount.root.isConnected) mount.paint(); };
      const paint = () => {
        const content = [h('summary', { text: s.sent ? 'Ответы отправлены менеджеру' : 'Расскажите о празднике — по желанию' }), msg('Можно ответить на вопросы или сразу написать менеджеру в чате.')];
        if (!s.sent) {
          for (const question of questions) {
            if (!Object.hasOwn(s.answers, question.id)) s.answers[question.id] = '';
            const control = input(s.answers[question.id], (value) => { s.answers[question.id] = value; }, { disabled: s.busy, maxlength: '300', 'aria-label': question.label });
            const choices = Array.isArray(question.options) ? question.options.filter((x) => typeof x === 'string').slice(0, 12) : [];
            content.push(field(question.label, control));
            if (choices.length) content.push(h('div', { class: 'workflow__buttons' }, ...choices.map((value) => button(value, () => { s.answers[question.id] = value; control.value = value; }, { disabled: s.busy }))));
          }
          content.push(button(s.busy ? 'Отправляем ответы…' : 'Отправить ответы в этот чат', async () => {
            if (s.busy) return;
            const text = questions.map((q) => s.answers[q.id].trim() ? `${q.label}: ${s.answers[q.id].trim()}` : '').filter(Boolean).join('\n');
            if (!text) { s.error = 'Ответьте хотя бы на один вопрос или продолжите обычную переписку.'; paint(); return; }
            const token = epoch; s.busy = true; s.error = ''; paint();
            try { await send(text); if (token === epoch && questionnaires.get(key) === s) s.sent = true; }
            catch (error) { if (token === epoch && questionnaires.get(key) === s) s.error = error.message; }
            finally { if (token === epoch && questionnaires.get(key) === s) { s.busy = false; repaint(); } }
          }, { class: 'app-btn', disabled: s.busy, 'data-send-questionnaire': '' }));
        }
        if (s.error) content.push(msg(s.error, true));
        root.replaceChildren(...content);
      };
      s.mounts.add({ root, paint }); paint(); return root;
    }
    // Здесь сохраняется только выбор показа подсказки на устройстве. Это не авторизация и не подписка.
    function prefKey() { return `palitra:onboarding:v1:${identity.key || 'anonymous'}`; }
    function readPref() { try { return JSON.parse(win.localStorage.getItem(prefKey()) || '{}'); } catch (_) { return memoryPrefs.get(prefKey()) || {}; } }
    function savePref(value) { memoryPrefs.set(prefKey(), value); try { win.localStorage.setItem(prefKey(), JSON.stringify(value)); } catch (_) { /* приватный режим: память вкладки */ } }
    function onboardingPanel(role, moment, { force = false } = {}) {
      const staff = role === 'staff' || role === 'admin';
      if (!identity.key || (staff ? moment !== 'login' : role !== 'client' || moment !== 'chat')) return null;
      void loadNotificationTexts();
      const pref = readPref();
      if (!force && (pref.off === true || Number(pref.nextAt) > now())) return null;
      const provider = win.PalitraPushService;
      const needsPush = Boolean(provider && provider.deliveryReady === true && !(provider.state && provider.state.subscribed === true && provider.state.serverSaved === true));
      if (!force && !staff && nativeInstalled() && !needsPush) return null;
      for (const old of onboardingRoots) if (!old.isConnected) onboardingRoots.delete(old);
      // Both automatic offers and explicit settings float above the current page.
      if (!force && [...onboardingRoots].some((old) => old.isConnected && old.getAttribute('data-notification-settings') === 'true')) return null;
      if (force) for (const old of onboardingRoots) if (old.getAttribute('data-onboarding-popup') === 'true') { old.remove(); onboardingRoots.delete(old); }
      const root = h('section', { class: 'app-onboarding-popup', 'data-onboarding': role, 'data-onboarding-popup': 'true', ...(force ? { 'data-notification-settings': 'true' } : {}) });
      {
        onboardingFocus.set(root, doc.activeElement);
        root.addEventListener('click', (event) => { if (event.target === root) dismissOnboarding(root); });
        root.addEventListener('keydown', (event) => {
          if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); dismissOnboarding(root); return; }
          if (event.key !== 'Tab') return;
          const controls = [...root.querySelectorAll('button:not([disabled]), a[href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex="0"]')].filter((el) => !el.hidden);
          if (!controls.length) { event.preventDefault(); return; }
          const index = controls.indexOf(doc.activeElement);
          if (event.shiftKey && index <= 0) { event.preventDefault(); controls[controls.length - 1].focus(); }
          else if (!event.shiftKey && (index < 0 || index === controls.length - 1)) { event.preventDefault(); controls[0].focus(); }
        });
      }
      onboardingRoots.add(root); paintOnboarding(root, staff); return root;
    }
    function dismissOnboarding(root, off = false) {
      savePref(off ? { off: true } : { nextAt: now() + 86400000 });
      const popup = root.getAttribute('data-onboarding-popup') === 'true';
      const previous = onboardingFocus.get(root);
      root.remove(); onboardingRoots.delete(root);
      if (popup) {
        const composer = doc.querySelector('.chat__input');
        const fallback = composer && !composer.disabled ? composer : null;
        const target = previous && previous.isConnected && typeof previous.focus === 'function' && previous !== doc.body ? previous : fallback;
        if (target && typeof target.focus === 'function') target.focus();
      }
    }
    function repaintOnboarding() { for (const root of onboardingRoots) if (root.isConnected) paintOnboarding(root, root.getAttribute('data-onboarding') !== 'client'); }
    function installationGuide(ios) {
      const android = /Android/.test(win.navigator && win.navigator.userAgent || '');
      const platform = ios ? 'ios' : android ? 'android' : 'desktop';
      const total = ios ? 4 : 3;
      const source = ios ? 'https://support.apple.com/en-lamr/guide/iphone/iphea86e5236/26/ios/26'
        : `https://support.google.com/chrome/answer/9658361?hl=ru&co=GENIE.Platform%3D${android ? 'Android' : 'Desktop'}`;
      const guide = h('section', { class: 'app-guide', 'aria-label': 'Инструкция установки' });
      guide.append(h('p', { class: 'app-guide__example', text: txt('guideExampleText') }));
      const steps = h('ol', { class: 'app-onboarding__steps' });
      const assetRoot = win.location && String(win.location.pathname || '').startsWith('/love-app/') ? '/love-app/assets/install-guide/' : 'assets/install-guide/';
      function picture(file, style, alt, credit, marks = []) {
        const figure = h('figure', { class: `app-guide__figure${guideExpandedImages.has(file) ? ' is-expanded' : ''}` });
        const viewport = h('div', { class: `app-guide__picture app-guide__picture--${style}` }, h('img', { src: assetRoot + file, alt, loading: 'lazy', decoding: 'async' }));
        for (const mark of marks) viewport.append(h('span', { class: `app-guide__mark app-guide__mark--${mark}`, 'aria-hidden': 'true' }));
        const expand = button(txt(guideExpandedImages.has(file) ? 'guideBackButton' : 'guideImageButton'), () => {
          const wide = figure.classList.toggle('is-expanded');
          if (wide) guideExpandedImages.add(file); else guideExpandedImages.delete(file);
          expand.textContent = txt(wide ? 'guideBackButton' : 'guideImageButton');
          expand.setAttribute('aria-expanded', String(wide));
        }, { class: 'app-guide__zoom', 'aria-expanded': String(guideExpandedImages.has(file)), 'data-guide-image': file });
        figure.append(h('div', { class: 'app-guide__scroll', tabindex: '0', 'aria-label': 'Скриншот инструкции; увеличенное изображение можно прокручивать' }, viewport), expand, h('figcaption', { text: credit }));
        return figure;
      }
      for (let i = 1; i <= total; i++) {
        const step = h('li', {}, h('p', { text: txt(`${platform}Step${i}`) }));
        if (ios && i === 2) {
          // Icon reference, clearly separate from the real screenshots below.
          step.append(h('div', { class: 'app-guide__controls', 'aria-label': 'Значки кнопок Safari' }, h('span', { text: 'Ещё' }), h('b', { text: '•••' }), h('span', { text: '→' }), h('span', { text: 'Поделиться' }), h('b', { text: '↑' })));
        }
        if (ios && i === 3) step.append(picture('ios-share-steps.png', 'ios-share', 'Пример меню Safari: На экран Домой выделено красной рамкой.', 'Safari: пример предыдущего вида меню, CDC/NIOSH.'));
        if (ios && i === 4) step.append(picture('ios-add-home.png', 'ios-add', 'Safari: переключатель Open as Web App и кнопка Add. Это пример другого сайта.', 'Safari 26: скриншот WebKit. Add — Добавить.', ['add','toggle']));
        if (android && i === 2) step.append(picture('android-menu.png', 'android-menu', 'Меню Chrome: Add to Home screen отмечено стрелкой.', 'Chrome: пример Google, пункт Добавить на главный экран.'));
        if (android && i === 3) {
          step.append(picture('android-choice.png', 'android-choice', 'После добавления на главный экран выберите Install.', 'Chrome: пример Google, Install — Установить.'));
          step.append(picture('android-install.png', 'android-install', 'Окно установки Chrome: кнопка Install внизу справа.', 'Chrome: подтверждение установки, пример Google.', ['install']));
        }
        steps.append(step);
      }
      guide.append(steps, h('a', { class: 'app-guide__source', 'data-guide-source': '', href: source, target: '_blank', rel: 'noopener noreferrer', text: txt('guideSourceLabel') }));
      return guide;
    }
    function pushDiagnostic(error, fallback) {
      const code = error && typeof error.code === 'string' && /^[A-Z][A-Z0-9_]{0,63}$/.test(error.code) ? error.code : '';
      const status = error && Number.isInteger(error.status) && error.status >= 100 && error.status < 600 ? error.status : 0;
      const operation = error && ['capability', 'subscription', 'subscription/status'].includes(error.operation) ? error.operation : '';
      const message = error && error.name === 'PalitraPushError' && typeof error.message === 'string' ? error.message : fallback;
      const details = [code, status ? `HTTP ${status}` : '', operation].filter(Boolean).join(' · ');
      return message + (details ? ` (${details})` : '');
    }
    function paintOnboarding(root, staff) {
      const isInstalled = nativeInstalled();
      const ios = /iPad|iPhone|iPod/.test(win.navigator && win.navigator.userAgent || '') || /Macintosh/.test(win.navigator && win.navigator.userAgent || '') && Number(win.navigator && win.navigator.maxTouchPoints) > 1;
      const children = [h('h3', { text: isInstalled ? txt('notificationTitle') : txt('installTitle') }),
        msg(isInstalled ? txt('installedText') : staff ? txt('installStaffText') : txt('installClientText')),
        !isInstalled ? button(installBusy ? txt('installBusyText') : installEvent ? txt('installButton') : txt('installHelpButton'), async () => {
          if (!installEvent) { onboardingExpanded = !onboardingExpanded; repaintOnboarding(); return; }
          const event = installEvent; installEvent = null; installBusy = true; repaintOnboarding();
          try { await event.prompt(); await event.userChoice; } catch (_) { onboardingExpanded = true; }
          finally { installBusy = false; repaintOnboarding(); }
        }, { class: 'app-btn', disabled: installBusy, 'data-install': '' }) : null,
        !isInstalled && onboardingExpanded ? installationGuide(ios) : null];
      // Самого разрешения Notification недостаточно: без sender+subscription нельзя обещать push на закрытом сайте.
      const push = win.PalitraPushService;
      const configured = Boolean(push && push.deliveryReady === true && typeof push.getStatus === 'function' && typeof push.subscribe === 'function');
      const permission = win.Notification && win.Notification.permission;
      if (staff || configured || root.getAttribute('data-notification-settings') === 'true') {
        children.push(h('h4', { text: txt('deviceHeading') }));
        if (!configured) children.push(msg(push && push.lastError ? pushDiagnostic(push.lastError, txt('pushUnavailableText')) : txt('pushUnavailableText')));
        else if (ios && !isInstalled) children.push(msg(txt('iosInstallText')));
        else if (permission === 'denied') children.push(msg(txt('permissionDeniedText')));
        else if (push.state && push.state.subscribed === true && push.state.serverSaved === true) children.push(msg(txt('subscribedText')),
          button(txt('disableButton'), async () => { const token = epoch; try { await push.unsubscribe(); if (token === epoch) { pushStatus = txt('unsubscribedText'); repaintOnboarding(); } } catch (error) { if (token === epoch) { pushStatus = pushDiagnostic(error, txt('subscribeErrorText')); repaintOnboarding(); } } }, { 'data-disable-push': '' }));
        else children.push(button(txt('enableButton'), async () => {
          // subscribe запускается только этим явным нажатием. Провайдер обязан запросить разрешение,
          // создать browser subscription и подтвердить её сохранение на сервере для ТЕКУЩЕГО аккаунта.
          const token = epoch; pushStatus = txt('permissionPromptText'); repaintOnboarding();
          try { const receipt = await push.subscribe(); if (token !== epoch) return;
            pushStatus = receipt && receipt.serverSaved === true && receipt.subscribed === true ? txt('subscribedText') : txt('unconfirmedText');
            if (receipt && receipt.statusError) pushStatus += ' ' + pushDiagnostic(receipt.statusError, txt('unconfirmedText'));
          } catch (error) { if (token === epoch) pushStatus = pushDiagnostic(error, txt('subscribeErrorText')); }
          if (token === epoch) repaintOnboarding();
        }, { 'data-enable-push': '' }));
      }
      if (pushStatus) children.push(msg(pushStatus));
      children.push(h('div', { class: 'workflow__buttons' }, button(txt('laterButton'), () => dismissOnboarding(root), { 'data-onboarding-later': '' }),
        button(txt('neverButton'), () => dismissOnboarding(root, true), { 'data-onboarding-off': '' })));
      const content = children.filter(Boolean);
      if (root.getAttribute('data-onboarding-popup') !== 'true') { root.replaceChildren(...content); return; }
      const oldPanel = root.querySelector('.app-onboarding-popup__dialog');
      const scrollTop = oldPanel ? oldPanel.scrollTop : 0;
      const hadFocus = root.contains(doc.activeElement);
      const focusedGuide = hadFocus && doc.activeElement.getAttribute('data-guide-image');
      const focusedSource = hadFocus && doc.activeElement.hasAttribute('data-guide-source');
      const focusedAction = hadFocus ? ['data-install','data-enable-push','data-disable-push','data-onboarding-later','data-onboarding-off','data-onboarding-close'].find((key) => doc.activeElement.hasAttribute(key)) : null;
      const panel = h('div', { class: 'card app-onboarding app-onboarding-popup__dialog', role: 'dialog', 'aria-modal': 'true', 'aria-label': (isInstalled ? txt('notificationTitle') : txt('installTitle')) || (isInstalled ? notificationDefaults.notificationTitle : notificationDefaults.installTitle), tabindex: '-1' },
        button('×', () => dismissOnboarding(root), { class: 'app-onboarding-popup__close', 'aria-label': txt('closeLabel') || notificationDefaults.closeLabel, 'data-onboarding-close': '' }), ...content);
      root.replaceChildren(panel);
      panel.scrollTop = scrollTop;
      const token = epoch;
      Promise.resolve().then(() => {
        if (token !== epoch || !root.isConnected) return;
        const control = focusedGuide ? [...panel.querySelectorAll('[data-guide-image]')].find((el) => el.getAttribute('data-guide-image') === focusedGuide)
          : focusedSource ? panel.querySelector('[data-guide-source]') : focusedAction && panel.querySelector(`[${focusedAction}]`);
        if (control && !control.disabled) control.focus();
        else if (!root.contains(doc.activeElement)) panel.querySelector('button').focus();
      });
    }
    if (typeof win.addEventListener === 'function') {
      win.addEventListener('beforeinstallprompt', (event) => { event.preventDefault(); installEvent = event; repaintOnboarding(); });
      win.addEventListener('appinstalled', () => { installed = true; installEvent = null; repaintOnboarding(); });
      win.addEventListener('palitra:push-ready', repaintOnboarding);
    }
    return Object.freeze({ setIdentity, canRead, canWrite, isOwner, settingsPanel, orderPanel, questionnairePanel, onboardingPanel, reloadOrder: loadOrder });
  }
  return Object.freeze({ create, REQUIREMENTS, CHANNELS });
});
