"""UNFROZEN wrapper. Root supplies the accepted helper pin after QA."""
import hashlib
import json
import os
from pathlib import Path
import sys
import types

CODE = Path('/opt/synapse/releases/palitra-app-20261015/palitra-order-conversation-code-r2')
HELPER_SHA = '0df3ecbe6f939022d769875bdb8d59a8ffae3de84e5b54b6e982fcc1ffce21b2'


def main():
    try:
        if HELPER_SHA == '0' * 64: raise ValueError('DRAFT_NOT_FROZEN_NO_NATIVE_ACTION')
        if os.name != 'posix' or os.geteuid() != 0 or Path(__file__).resolve().parent != CODE: raise ValueError('EXACT_ROOT_NEW_NAMESPACE_REQUIRED')
        path = CODE / 'order_conversation_release_native.py'
        for item in [*reversed(path.parents), path]:
            if item.is_symlink(): raise ValueError('CODE_SYMLINK_REFUSED')
        raw = path.read_bytes()
        if hashlib.sha256(raw).hexdigest() != HELPER_SHA: raise ValueError('FROZEN_NEW_HELPER_REQUIRED')
        module = types.ModuleType('frozen_order_conversation'); module.__file__ = str(path)
        exec(compile(raw, str(path), 'exec'), module.__dict__)
        return module.main()
    except Exception as error:
        print(json.dumps({'status': 'ENTRY_REFUSED_NO_RETRY', 'messageSha256': hashlib.sha256(str(error).encode()).hexdigest()})); return 2


if __name__ == '__main__': sys.exit(main())
