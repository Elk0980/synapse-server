"""Root-only static release28 over exact completed27. No Docker writes or DB access.
Only current managed assets/order.js + assets/storefront.js; old receipts untouched.
The managed editor's manifest/SHA refusal remains unchanged.
"""
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys
import time
import types

ROOT = Path('/opt/synapse/releases/palitra-app-20261015')
NAME = 'palitra-cart-total-copy-r1'
CODE_NAME = 'palitra-cart-total-copy-code-r1'
PHASE = 'STATIC28_APPLIED_NOT_BROWSER_ACCEPTANCE'
PRIOR_CODE = ROOT / 'palitra-attach-paperclip-code-r1'
PRIOR_HELPER_SHA = '71c66f4ec3f068c2a17097f34465e4034d73e325173cfbb88c9e6def157fce87'
PRIOR_WRAPPER_SHA = '509f314e00cc561ad23344858c03471864fb905c1309822ca4ac2b728f700062'
PRIOR_RECEIPT_SHA = 'b8a16849f7d45229b75369389598d66f5ac9cb69443f07257cab590c8670029f'
CONTENT = 'sha256:b2e778ab95e28a56d2106b0c61532fb67c55181c5b160ae5aa6127fed8ab1b06'
MANIFEST_SHA = 'e2e8f0364c9df75d580391e6aba79ac7b227c2eb81a2b194552576336ec6bf87'
LOCK = '/opt/synapse/.palitra-app-release.lock'
PRODUCT = {'assets/order.js', 'assets/storefront.js'}
BEFORE = {
    'assets/order.js': '230f1c13bf7a78bb4f0c6d19455d1dcad39384ad0d3b600c48ce43d2018b6553',
    'assets/storefront.js': '973ee07c0565a04501390c468dc7d2f68a4ee363b4ce78ac3d6e3a15d56bcd80',
}
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def need(value, code):
    if not value:
        raise ValueError(code)


def digest(value):
    return type(value) is str and re.fullmatch('[0-9a-f]{64}', value) is not None


def load_current27(lease_pid):
    """Only frozen constructors and sealed completed contexts; no old action calls."""
    need(type(lease_pid) is int and lease_pid > 1, 'FRESH_ROOT_LEASE_REQUIRED')
    path = PRIOR_CODE / 'attach_paperclip_release_native.py'
    for item in [*reversed(path.parents), path, PRIOR_CODE / 'attach_paperclip.py']:
        need(not item.is_symlink(), 'HISTORICAL_CODE_SYMLINK_REFUSED')
    raw = path.read_bytes()
    need(sha(raw) == PRIOR_HELPER_SHA, 'EXACT_CHAIN27_HELPER_REQUIRED')
    need(sha((PRIOR_CODE / 'attach_paperclip.py').read_bytes()) == PRIOR_WRAPPER_SHA, 'EXACT_CHAIN27_WRAPPER_REQUIRED')
    prior = types.ModuleType('sealed_chain27'); prior.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), prior.__dict__)
    a, b, current26 = prior.load_current26(lease_pid)
    journal = ROOT / 'palitra-attach-paperclip-r1-journal.json'
    receipt = a.pinned(journal, PRIOR_RECEIPT_SHA, True)
    historical_pid = receipt.get('inputs', {}).get('freshLeasePid')
    need(type(historical_pid) is int and historical_pid > 1, 'COMPLETED27_LEASE_BINDING_REQUIRED')
    accepted = prior.AttachPaperclipRelease(a, b, current26, PRIOR_CODE / 'payload', prior.MANIFEST_SHA, historical_pid)
    need(receipt.get('schema') == 1 and receipt.get('name') == prior.NAME and receipt.get('phase') == prior.PHASE
         and receipt.get('inputs') == accepted.binding() and receipt.get('before') == accepted.base
         and receipt.get('childImage') == CONTENT and receipt.get('workerRecreated') is False and receipt.get('uploadsEnabled') is True
         and receipt.get('directDbWrites') == receipt.get('queueEdits') == receipt.get('oldJournalWrites') == 0
         and receipt.get('automaticRetry') is False and receipt.get('automaticCodeRollback') is False
         and type(receipt.get('static')) is list and len(receipt['static']) == 2
         and all(type(row) is dict and row.get('written') is True for row in receipt['static']), 'EXACT_COMPLETED27_RECEIPT_REQUIRED')
    proof = {key: receipt[key] for key in ('childImage', 'overlaySha256', 'plannedConfigHash')}
    need(receipt.get('overlay') == str(accepted.paths()['overlay'])
         and receipt['after']['containers']['content'] == accepted.expected_metadata('content', CONTENT, proof)
         and len(receipt['after']['containers']['content']['files']) == 27
         and receipt['after']['containers']['chat'] == accepted.base['containers']['chat']
         and all(receipt['after'][key] == accepted.base[key] for key in ('worker', 'selected', 'l12'))
         and receipt['after']['contentCid'] != accepted.base['contentCid'], 'EXACT_COMPLETED27_RUNTIME_REQUIRED')
    need(len(accepted.final_source) == 209 and len(accepted.final_static) == 26, 'EXACT_COMPLETED27_MAPS_REQUIRED')
    accepted.validate_source_modes(receipt.get('sourceModes'))

    def stable():
        accepted.stable()
        need(sha(a.read(journal)) == PRIOR_RECEIPT_SHA, 'COMPLETED27_RECEIPT_CHANGED')
        need(accepted.context_proof(receipt, True) == receipt['contextSha256'], 'COMPLETED27_CONTEXT_CHANGED')
        accepted.backup_guard(receipt)

    def guide_guard():
        current26.guide_guard()
        for row in receipt['static']:
            info = a.exact_path(row['target']).stat()
            need(stat.S_ISREG(info.st_mode) and info.st_uid == info.st_gid == 0
                 and stat.S_IMODE(info.st_mode) == row['mode'], 'COMPLETED27_STATIC_MODE_CHANGED')
        need(accepted.source_facts() == receipt['sourceModes'], 'COMPLETED27_SOURCE_MODE_CHANGED')

    stable()
    return types.SimpleNamespace(a=a, b=b, accepted=accepted, base=receipt['after'],
                                 source=dict(accepted.final_source), static=dict(accepted.final_static),
                                 stable=stable, guide_guard=guide_guard, files=prior.FileOps())


class StaticCopyRelease:
    def __init__(self, current, lease_pid, payload=None, manifest_pin=None, clock=time.time, completed=False):
        self.c, self.a, self.b, self.clock = current, current.a, current.b, clock
        self.root, self.run, self.files, self.lease_pid = self.b.root, self.b.run, current.files, lease_pid
        need(type(lease_pid) is int and lease_pid > 1, 'FRESH_ROOT_LEASE_REQUIRED')
        # Existing reader seam: fresh lease checks replace only the historical PID binding.
        self.b.lease = self.lease
        self.base = copy.deepcopy(current.base)
        self.source, self.before_static = dict(current.source), dict(current.static)
        need(len(self.source) == 209 and len(self.before_static) == 26
             and all(digest(v) for v in [*self.source.values(), *self.before_static.values()])
             and self.base['containers']['content']['image'] == CONTENT
             and len(self.base['containers']['content']['files']) == 27, 'EXACT27_SOURCE209_STATIC26_REQUIRED')
        roots = {str(Path(name).parent.parent) for name in self.before_static if Path(name).parts[-2:] == ('assets', 'order.js')}
        need(len(roots) == 1, 'ONE_TRACKED_MANAGED_ORDER_ROOT_REQUIRED')
        self.managed = self.a.exact_path(next(iter(roots)))
        if self.root == ROOT:
            need(re.fullmatch(r'/var/lib/docker/volumes/synapse_content_data/_data/projects/palitra-love/sites/site-44bbe13f1bad5e005b2a/versions/[0-9a-f]{64}', str(self.managed)) is not None,
                 'EXACT_EXISTING_MANAGED_VERSION_ROOT_REQUIRED')
        self.targets = {name: self.managed / name for name in sorted(PRODUCT)}
        self.parents = {str(p): self.directory_facts(p) for p in (self.root, self.managed, self.managed / 'assets')}
        self.final_static = dict(self.before_static)
        self.before_facts = {name: self.target_facts(path) for name, path in self.targets.items()}
        for name, row in self.before_facts.items():
            if not completed: need(row['sha256'] == BEFORE[name], 'EXACT_PUBLIC_BASE_REQUIRED')
            if str(self.targets[name]) in self.before_static:
                need(self.before_static[str(self.targets[name])] == BEFORE[name], 'TRACKED_MANAGED_BASE_CHANGED')
        self.helper = self.a.exact_path(__file__)
        self.pins = {str(self.helper): sha(self.a.read(self.helper))}
        self.payload, self.manifest_pin, self.records = None, manifest_pin, {}
        if payload is not None:
            need(digest(manifest_pin) and manifest_pin == MANIFEST_SHA, 'EXPLICIT_FROZEN_MANIFEST_SHA_REQUIRED')
            self.payload = self.a.exact_path(payload)
            need(self.payload.is_relative_to(self.root), 'PAYLOAD_INSIDE_RELEASE_ROOT_REQUIRED')
            manifest = self.a.pinned(self.payload / 'MANIFEST.json', manifest_pin)
            need(type(manifest) is dict and set(manifest) == {'schema', 'scope', 'records'} and manifest['schema'] == 1
                 and manifest['scope'] == 'PALITRA_CART_TOTAL_COPY_ONLY' and type(manifest['records']) is list
                 and len(manifest['records']) == 2, 'EXACT_STATIC_TWO_MANIFEST_REQUIRED')
            self.pins[str(self.payload / 'MANIFEST.json')] = manifest_pin
            for record in manifest['records']:
                self.accept(record, completed)
            need(set(self.records) == PRODUCT, 'EXACT_STATIC_TWO_RECORDS_REQUIRED')
            found = set()
            for path in self.payload.rglob('*'):
                self.a.exact_path(path)
                if path.is_file(): found.add(path.relative_to(self.payload).as_posix())
                else: need(path.is_dir() and path.relative_to(self.payload).as_posix() == 'product', 'CLOSED_PAYLOAD_DIRECTORY_REQUIRED')
            need(found == {'MANIFEST.json', 'product/order.js', 'product/storefront.js'}, 'CLOSED_STATIC_TWO_PAYLOAD_REQUIRED')
        need(len(self.final_static) in (26, 27), 'ONLY_EXPLICIT_STOREFRONT_MAP_EXTENSION_ALLOWED')
        need(not completed or self.payload is not None, 'COMPLETED_REQUIRES_EXACT_PAYLOAD')

    def accept(self, row, completed):
        need(type(row) is dict and set(row) == {'name', 'beforeSha256', 'beforeBytes', 'sha256', 'bytes', 'hunks'}, 'EXACT_STATIC_RECORD_REQUIRED')
        name = 'assets/' + row['name'] if type(row['name']) is str else ''
        need(name in PRODUCT and name not in self.records
             and all(digest(row[k]) for k in ('beforeSha256', 'sha256')) and row['beforeSha256'] == BEFORE[name] != row['sha256']
             and all(type(row[k]) is int and 0 < row[k] <= 2 * 1024 * 1024 for k in ('beforeBytes', 'bytes'))
             and type(row['hunks']) is list and 1 <= len(row['hunks']) <= 8,
             'EXACT_CHANGED_ROOT_STATIC_RECORD_REQUIRED')
        live = self.before_facts[name]
        need(live['sha256'] == row['sha256' if completed else 'beforeSha256'] and live['bytes'] == row['bytes' if completed else 'beforeBytes'], 'ACTUAL_STATIC_BYTES_MUST_MATCH_MANIFEST')
        payload = 'product/' + row['name']
        raw = self.a.read(self.payload / payload)
        need(len(raw) == row['bytes'] and sha(raw) == row['sha256'], 'PAYLOAD_SHA_OR_SIZE_CHANGED')
        old = raw
        for hunk in reversed(row['hunks']):
            need(type(hunk) is dict and set(hunk) == {'before', 'after'} and all(type(hunk[k]) is str and 0 < len(hunk[k]) <= 65536 for k in hunk), 'BOUNDED_TEXT_HUNK_REQUIRED')
            before, after = hunk['before'].encode(), hunk['after'].encode()
            need(before != after and old.count(after) == 1, 'REVERSE_UNIQUE_HUNK_REQUIRED')
            old = old.replace(after, before, 1)
        need(len(old) == row['beforeBytes'] and sha(old) == row['beforeSha256'], 'EXACT_RECONSTRUCTED_BASE_REQUIRED')
        for hunk in row['hunks']:
            before, after = hunk['before'].encode(), hunk['after'].encode()
            need(old.count(before) == 1, 'FORWARD_UNIQUE_HUNK_REQUIRED'); old = old.replace(before, after, 1)
        need(old == raw, 'EXACT_HUNK_ROUNDTRIP_REQUIRED')
        self.pins[str(self.payload / payload)] = row['sha256']
        self.records[name] = dict(row, path=name, payload=payload, **{k: live[k] for k in ('mode', 'uid', 'gid')})
        if completed: self.before_facts[name] = dict(live, sha256=row['beforeSha256'], bytes=row['beforeBytes'])
        self.final_static[str(self.targets[name])] = row['sha256']

    def directory_facts(self, path):
        info = self.a.exact_path(path).stat()
        need(stat.S_ISDIR(info.st_mode), 'REGULAR_PARENT_DIRECTORY_REQUIRED')
        return [info.st_dev, info.st_ino, info.st_uid, info.st_gid, stat.S_IMODE(info.st_mode)]

    def target_facts(self, path):
        path = self.a.exact_path(path)
        first = path.stat(); raw = self.a.read(path); last = path.stat()
        need(stat.S_ISREG(first.st_mode) and first.st_uid == first.st_gid == 0
             and (first.st_dev, first.st_ino, first.st_size, first.st_mtime_ns) == (last.st_dev, last.st_ino, last.st_size, last.st_mtime_ns)
             and len(raw) == first.st_size and 0 < len(raw) <= 2 * 1024 * 1024
             and self.files.mode(path) in (0o600, 0o644), 'STABLE_ROOT_STATIC_FACTS_REQUIRED')
        return {'sha256': sha(raw), 'bytes': len(raw), 'mode': self.files.mode(path), 'uid': first.st_uid, 'gid': first.st_gid}

    def paths(self):
        return {kind: self.root / (NAME + '-' + kind + ('.json' if kind in ('decision', 'journal') else '')) for kind in ('decision', 'journal', 'backup', 'prepared')}

    def lease(self):
        raw = self.run(['lslocks', '--noheadings', '--output', 'PID,PATH'])
        need(len(raw) <= 1048576, 'BOUNDED_LEASE_INVENTORY_REQUIRED')
        rows = [p for line in raw.decode().splitlines() if len(p := line.strip().split(maxsplit=1)) == 2 and p[1] == LOCK]
        need(rows == [[str(self.lease_pid), LOCK]], 'FRESH_EXCLUSIVE_ROOT_LEASE_REQUIRED')

    def stable(self):
        self.c.stable()
        for name, pin in self.pins.items(): need(sha(self.a.read(Path(name))) == pin, 'OWN_PINNED_INPUT_CHANGED')
        need({name: self.directory_facts(Path(name)) for name in self.parents} == self.parents, 'MANAGED_PARENT_IDENTITY_CHANGED')

    def static_guard(self, changed=False):
        self.c.guide_guard()
        for name, pin in (self.final_static if changed else self.before_static).items():
            need(sha(self.a.read(Path(name))) == pin, 'FULL_STATIC_MAP_CHANGED')
        for name, path in self.targets.items():
            expected = dict(self.before_facts[name])
            if changed: expected.update(sha256=self.records[name]['sha256'], bytes=self.records[name]['bytes'])
            need(self.target_facts(path) == expected, 'CUSTOMER_STATIC_FACTS_CHANGED')

    def snapshot(self, changed=False):
        self.stable(); self.lease()
        first = {s: self.c.accepted.metadata(s, self.base['containers'][s]) for s in ('content', 'chat')}
        worker = self.b.worker_facts(); selected = {s: self.b.a.selected(s) for s in ('content', 'chat')}
        flags = self.a.decode(self.run(['docker', 'exec', 'synapse-content-1', 'node', '-e', self.a.FLAGS_JS]))
        need(worker == self.base['worker'] and selected == self.base['selected'] and flags == self.base['l12'], 'WORKER_FLAGS_OR_SELECTION_CHANGED')
        for service, row in first.items():
            text = self.run(self.b._resolve_command(row, service)).decode('ascii').strip()
            need(re.fullmatch(re.escape(service) + r'\s+' + re.escape(row['configHash']), text) is not None, 'RESOLVED_CONFIG_HASH_CHANGED')
        self.b.graph(new=True); self.b.push_guard()
        need(self.b.photo.hashes(self.source) == self.source, 'FULL_SOURCE209_CHANGED')
        self.static_guard(changed)
        cid = self.b.photo.cid()
        last = {s: self.c.accepted.metadata(s, self.base['containers'][s]) for s in ('content', 'chat')}
        need(first == last and worker == self.b.worker_facts() and selected == {s: self.b.a.selected(s) for s in ('content', 'chat')}
             and cid == self.b.photo.cid(), 'CONCURRENT_RUNTIME_CHANGE')
        result = {'containers': last, 'selected': selected, 'worker': worker, 'contentCid': cid, 'l12': flags}
        need(result == self.base and self.b.heartbeat(worker['startedAt'], self.clock())['freshAfterWorkerStart'], 'EXACT_FRESH_RUNNING27_REQUIRED')
        self.stable(); self.lease()
        return result

    def binding(self):
        return {'priorReceiptSha256': PRIOR_RECEIPT_SHA, 'contentImage': CONTENT, 'manifestSha256': self.manifest_pin,
                'helperSha256': self.pins[str(self.helper)], 'freshLeasePid': self.lease_pid, 'managedRoot': str(self.managed),
                'parents': self.parents, 'beforeStatic': self.before_static, 'afterStatic': self.final_static, 'beforeFacts': self.before_facts}

    def absent(self, decision=False):
        for kind, path in self.paths().items():
            if kind == 'decision' and not decision: continue
            self.a.exact_path(path, True)
            need(not os.path.lexists(path) and not os.path.lexists(str(path) + '.pending'), 'OWN_ATTEMPT_EXISTS_NO_RETRY')
        for path in self.targets.values():
            pending = path.with_name(path.name + '.' + NAME + '.pending')
            self.a.exact_path(pending, True); need(not os.path.lexists(pending), 'OWN_STATIC_PENDING_EXISTS_NO_RETRY')

    def inspect_current(self):
        self.snapshot()
        return {'status': 'CURRENT27_STATIC_READONLY_NOT_APPROVED', 'managedRoot': str(self.managed),
                'sourceFiles': 209, 'staticFiles': 26, 'runtimeContentChainFiles': 27, 'staticMap': self.before_static,
                'customerFiles': {name: self.before_facts[name] | {'target': str(path), 'tracked': str(path) in self.before_static} for name, path in self.targets.items()}, 'mutations': 0}

    def approve(self, apply=False):
        need(apply is True and self.payload is not None, 'EXPLICIT_ROOT_MANIFEST_APPROVAL_REQUIRED')
        self.absent(True); at = self.clock(); self.snapshot(); self.a.fresh(self.a.stamp(at), self.clock())
        value = {'schema': 1, 'name': NAME, 'scope': 'EXACT27_TO_STATIC28_CUSTOMER_JS2', 'rootApproved': True,
                 'observedAtUtc': self.a.stamp(at), 'inputs': self.binding(), 'before': self.base}
        self.a.write_new(self.paths()['decision'], value)
        return {'status': 'STATIC28_DECISION_CREATED_NOT_APPLIED', 'decisionSha256': sha(self.a.read(self.paths()['decision'])), 'runtimeWrites': 0}

    def decision(self, pin):
        value = self.a.pinned(self.paths()['decision'], pin, True)
        need(type(value) is dict and set(value) == {'schema', 'name', 'scope', 'rootApproved', 'observedAtUtc', 'inputs', 'before'}
             and value['schema'] == 1 and value['name'] == NAME and value['scope'] == 'EXACT27_TO_STATIC28_CUSTOMER_JS2'
             and value['rootApproved'] is True and value['inputs'] == self.binding() and value['before'] == self.base, 'EXACT_STATIC28_DECISION_REQUIRED')
        self.a.fresh(value['observedAtUtc'], self.clock()); return value

    def artifacts_guard(self, rows):
        paths = self.paths()
        for kind in ('backup', 'prepared'):
            path = self.a.exact_path(paths[kind]); info = path.stat()
            need(stat.S_ISDIR(info.st_mode) and info.st_uid == info.st_gid == 0 and self.files.mode(path) == 0o700
                 and {p.name for p in path.iterdir()} == {'0', '1'}, 'EXACT_PRIVATE_TWO_ARTIFACTS_REQUIRED')
        expected = []
        for index, name in enumerate(sorted(PRODUCT)):
            record = self.records[name]
            expected.append({'target': str(self.targets[name]), 'path': name, 'backup': str(paths['backup'] / str(index)),
                             'prepared': str(paths['prepared'] / str(index)), 'beforeSha256': record['beforeSha256'], 'sha256': record['sha256']})
            for kind, pin, size in (('backup', record['beforeSha256'], record['beforeBytes']), ('prepared', record['sha256'], record['bytes'])):
                p = self.a.exact_path(paths[kind] / str(index)); info = p.stat(); raw = self.a.read(p)
                need(stat.S_ISREG(info.st_mode) and info.st_uid == info.st_gid == 0 and self.files.mode(p) == 0o600
                     and len(raw) == info.st_size == size and sha(raw) == pin, 'PRIVATE_ARTIFACT_SHA_MODE_CHANGED')
        need(rows == expected, 'EXACT_TWO_ARTIFACT_PATHS_REQUIRED')

    def apply(self, pin, apply=False):
        need(apply is True and self.payload is not None, 'EXPLICIT_ROOT_STATIC_APPLY_REQUIRED')
        self.absent(); self.decision(pin); self.snapshot()
        paths = self.paths()
        state = {'schema': 1, 'name': NAME, 'phase': 'STATIC28_STARTED_UNKNOWN', 'inputs': self.binding(), 'before': self.base,
                 'decisionSha256': pin, 'static': [], 'written': [], 'automaticRetry': False, 'automaticCodeRollback': False,
                 'workerRecreated': False, 'builds': 0, 'contentUps': 0, 'directDbWrites': 0, 'oldJournalWrites': 0}
        self.a.write_new(paths['journal'], state)
        for kind in ('backup', 'prepared'): self.files.directory(self.a.exact_path(paths[kind], True), 0o700)
        for index, name in enumerate(sorted(PRODUCT)):
            record = self.records[name]; old = self.a.read(self.targets[name]); new = self.a.read(self.payload / record['payload'])
            need(sha(old) == record['beforeSha256'] and len(old) == record['beforeBytes'] and sha(new) == record['sha256'], 'PRE_BACKUP_BYTES_CHANGED')
            self.files.write(paths['backup'] / str(index), old, 0o600); self.files.write(paths['prepared'] / str(index), new, 0o600)
            state['static'].append({'target': str(self.targets[name]), 'path': name, 'backup': str(paths['backup'] / str(index)),
                                    'prepared': str(paths['prepared'] / str(index)), 'beforeSha256': record['beforeSha256'], 'sha256': record['sha256']})
        self.artifacts_guard(state['static']); self.snapshot(); self.decision(pin)
        self.a.replace(paths['journal'], state)
        for row in state['static']:
            self.stable(); self.lease(); self.decision(pin); self.artifacts_guard(state['static'])
            for name, path in self.targets.items():
                expected = dict(self.before_facts[name])
                if name in state['written']: expected.update(sha256=self.records[name]['sha256'], bytes=self.records[name]['bytes'])
                need(self.target_facts(path) == expected, 'TWO_FILE_CAS_CONFLICT')
            target = self.targets[row['path']]; record = self.records[row['path']]
            pending = target.with_name(target.name + '.' + NAME + '.pending')
            raw = self.a.read(Path(row['prepared'])); self.files.write(self.a.exact_path(pending, True), raw, record['mode'])
            need(self.target_facts(pending) == {'sha256': record['sha256'], 'bytes': record['bytes'], 'mode': record['mode'], 'uid': record['uid'], 'gid': record['gid']}, 'PENDING_STATIC_FACTS_CHANGED')
            self.stable(); self.lease()
            need(self.target_facts(target) == self.before_facts[row['path']], 'LATE_STATIC_CAS_CONFLICT')
            os.replace(pending, target)
            need(self.target_facts(target)['sha256'] == record['sha256'], 'STATIC_READBACK_FAILED')
            state['written'].append(row['path']); self.a.replace(paths['journal'], state)
        self.artifacts_guard(state['static']); self.snapshot(True); self.decision(pin)
        state.update(phase=PHASE, after=self.base, finishedAtUtc=self.a.stamp(self.clock()))
        self.a.replace(paths['journal'], state)
        return {'status': PHASE, 'receiptSha256': sha(self.a.read(paths['journal'])), 'sourceFiles': 209, 'staticFiles': len(self.final_static),
                'staticFilesChanged': 2, 'runtimeContentChainFiles': 27, 'builds': 0, 'contentUps': 0, 'workerRecreated': False, 'directDbWrites': 0}

    def inspect(self, pin):
        need(self.payload is not None, 'EXACT_PAYLOAD_REQUIRED')
        state = self.a.pinned(self.paths()['journal'], pin, True)
        need(state.get('schema') == 1 and state.get('name') == NAME and state.get('phase') == PHASE
             and state.get('inputs') == self.binding() and state.get('before') == state.get('after') == self.base
             and state.get('written') == sorted(PRODUCT) and digest(state.get('decisionSha256'))
             and state.get('automaticRetry') is False and state.get('automaticCodeRollback') is False and state.get('workerRecreated') is False
             and all(state.get(k) == 0 for k in ('builds', 'contentUps', 'directDbWrites', 'oldJournalWrites')), 'OWN_COMPLETED_STATIC28_RECEIPT_REQUIRED')
        decision = self.a.pinned(self.paths()['decision'], state['decisionSha256'], True)
        need(decision.get('inputs') == self.binding() and decision.get('before') == self.base and decision.get('rootApproved') is True, 'SEALED_STATIC28_DECISION_CHANGED')
        self.artifacts_guard(state.get('static')); self.snapshot(True)
        return {'status': 'COMPLETED_STATIC28_READONLY', 'receiptSha256': pin, 'managedRoot': str(self.managed), 'staticMap': self.final_static,
                'runtimeContentChainFiles': 27, 'sourceFiles': 209, 'mutations': 0}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=('inspect-current', 'approve-current', 'apply', 'inspect'))
    parser.add_argument('--lease-pid', type=int, required=True)
    parser.add_argument('--manifest-sha'); parser.add_argument('--decision-sha'); parser.add_argument('--receipt-sha')
    parser.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    try:
        need(os.name == 'posix' and os.geteuid() == 0 and Path(__file__).resolve().parent == ROOT / CODE_NAME, 'EXACT_ROOT_NEW_NAMESPACE_REQUIRED')
        current = load_current27(args.lease_pid)
        payload = None if args.operation == 'inspect-current' else ROOT / CODE_NAME / 'payload'
        release = StaticCopyRelease(current, args.lease_pid, payload, args.manifest_sha, completed=args.operation == 'inspect')
        if args.operation == 'inspect-current': result = release.inspect_current()
        elif args.operation == 'approve-current': result = release.approve(args.apply)
        elif args.operation == 'apply':
            need(digest(args.decision_sha), 'EXPLICIT_DECISION_SHA_REQUIRED'); result = release.apply(args.decision_sha, args.apply)
        else:
            need(digest(args.receipt_sha), 'EXPLICIT_RECEIPT_SHA_REQUIRED'); result = release.inspect(args.receipt_sha)
        print(json.dumps(result, separators=(',', ':'))); return 0
    except Exception as error:
        code = str(error) if type(error) is ValueError and re.fullmatch('[A-Z][A-Z0-9_]{0,100}', str(error)) else 'STATIC28_REFUSED_OR_UNKNOWN'
        print(json.dumps({'status': 'REFUSED_OR_UNKNOWN_NO_AUTOMATIC_RETRY', 'code': code, 'messageSha256': sha(str(error).encode()),
                          'automaticRetry': False, 'automaticCodeRollback': False, 'oldJournalWrites': 0})); return 2


if __name__ == '__main__': sys.exit(main())
