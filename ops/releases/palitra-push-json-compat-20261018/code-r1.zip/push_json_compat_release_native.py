"""UNFROZEN Root-only successor: exact accepted24 -> own sealed25.

One existing backend source, no static writes. No database/subscription operation,
worker recreation, flags, authentication, rights, queues, timers or old journal writes.
Native operations are impossible until a separately reviewed manifest is frozen.
"""
import argparse
import base64
import copy
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys
import time
import types

ROOT = Path('/opt/synapse/releases/palitra-app-20261015')
NAME = 'palitra-push-json-compat-r1'
CODE_NAME = 'palitra-push-json-compat-code-r1'
PHASE = 'PUSH_JSON_COMPAT_APPLIED_NOT_DEVICE_SUBSCRIPTION_OR_DELIVERY_ACCEPTANCE'
SCOPE = 'EXACT_BACKEND1_SOURCE209_STATIC26_UNCHANGED_CHAIN24_TO_25'
UNFROZEN = '0' * 64
MANIFEST_SHA = 'e33c055dce7429e93a35b3df74bf052776e2ffe5906dc248c616cb8b64931d48'
PRIOR_CODE = ROOT / 'palitra-chat-push-consistency-code-r3'
PRIOR_HELPER_SHA = '0f6797addf504baa8bc284b3bc39d896278d8c1b552fe1d784f2ea8e0c091221'
PRIOR_WRAPPER_SHA = '846fe65e9df056b0df955fe99217676129a49b1d559d71c3a1707fbecc902d29'
PRIOR_RECEIPT_SHA = '5a8bb7e416d6a35bb50c5ceb1983452bf13e9b01f48a25d7a967976b09a50df5'
CONTENT = 'sha256:c436d56ae6a392cd9f0b14181584a1f944830f2bd2c6792e4deafdf0073712e0'
WORKER = 'sha256:d4d4d453ce2e3dc47d5e0962d62b95938f42c56ec73789fe76a324e0d2ff0508'
LOCK = '/opt/synapse/.palitra-app-release.lock'
BACKEND = 'palitra-push.cjs'
BEFORE_SHA = '58c563369670861a6626704bc16de2dd0d6be13177b65c67597935e86213b7a5'
BEFORE_BYTES = 19081
SOURCE_MODE_JS = "const s=require('fs').lstatSync('/app/palitra-push.cjs');console.log(JSON.stringify({regular:s.isFile(),uid:s.uid,gid:s.gid,mode:s.mode&511}));"
CHILD_CHECK_JS = "const p='/app/palitra-push.cjs',s=require('fs').lstatSync(p);if(!s.isFile()||s.uid!==0||s.gid!==0||(s.mode&511)!==420)process.exit(73);const r=require('child_process').spawnSync(process.execPath,['--check',p],{stdio:'inherit'});if(r.status!==0)process.exit(74);process.stdout.write('PRECHECK_OK');"
NAMES = {'backend/' + BACKEND}
USER_FORMAT = '{{json (or (index .Config "User") "")}}'
ROOT_USERS = {'', 'root', '0', '0:0', 'root:root'}
# All 26 existing static targets remain byte-for-byte and mode-for-mode unchanged.
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def need(value, code):
    if not value:
        raise ValueError(code)


def digest(value):
    return type(value) is str and re.fullmatch('[0-9a-f]{64}', value) is not None


def hunk_bytes(hunk):
    need(type(hunk) is dict and set(hunk) == {'before', 'after'}
         and all(type(hunk[k]) is str and 0 < len(hunk[k]) <= 3 * 1024 * 1024 for k in hunk), 'BOUNDED_BASE64_HUNK_REQUIRED')
    values = [base64.b64decode(hunk[key], validate=True) for key in ('before', 'after')]
    need(all(0 < len(raw) <= 2 * 1024 * 1024 and base64.b64encode(raw).decode('ascii') == hunk[key]
             for key, raw in zip(('before', 'after'), values)) and values[0] != values[1], 'CANONICAL_CHANGED_BYTE_HUNK_REQUIRED')
    return values


class FileOps:
    """Every new descriptor receives its exact mode despite umask077."""
    def write(self, path, raw, mode):
        flags = os.O_RDWR | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_CLOEXEC', 0) | getattr(os, 'O_BINARY', 0)
        fd = os.open(path, flags, 0o600)
        try:
            first = os.fstat(fd)
            need(stat.S_ISREG(first.st_mode), 'REGULAR_CREATED_FD_REQUIRED')
            view = memoryview(raw)
            while view:
                count = os.write(fd, view)
                need(count > 0, 'WRITE_INCOMPLETE')
                view = view[count:]
            self.set_mode(fd, mode)
            os.fsync(fd)
            last = os.fstat(fd)
            need((first.st_dev, first.st_ino, first.st_uid) == (last.st_dev, last.st_ino, last.st_uid)
                 and self.fd_mode(fd) == mode, 'CREATED_FD_MODE_READBACK_FAILED')
            return (last.st_dev, last.st_ino, last.st_uid)
        finally:
            os.close(fd)

    def set_mode(self, fd, mode):
        need(os.name == 'posix' and hasattr(os, 'fchmod'), 'POSIX_FCHMOD_REQUIRED')
        os.fchmod(fd, mode)

    def fd_mode(self, fd):
        return stat.S_IMODE(os.fstat(fd).st_mode)

    def mode(self, path):
        return stat.S_IMODE(path.stat().st_mode)

    def directory(self, path, mode):
        path.mkdir(mode=0o700)
        need(os.name == 'posix', 'POSIX_DIRECTORY_FD_REQUIRED')
        fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | getattr(os, 'O_CLOEXEC', 0))
        try:
            row = os.fstat(fd)
            need(stat.S_ISDIR(row.st_mode) and not os.listdir(fd), 'NEW_EMPTY_DIRECTORY_FD_REQUIRED')
            os.fchmod(fd, mode)
            os.fsync(fd)
            last = os.fstat(fd)
            need((last.st_dev, last.st_ino, last.st_uid) == (row.st_dev, row.st_ino, row.st_uid)
                 and stat.S_IMODE(last.st_mode) == mode, 'NEW_DIRECTORY_MODE_READBACK_FAILED')
        finally:
            os.close(fd)


class PushJsonCompatRelease:
    def __init__(self, a, b, current, payload, manifest_pin, lease_pid, clock=time.time, file_ops=None):
        self.a, self.b, self.current, self.photo = a, b, current, b.photo
        self.root, self.run, self.clock, self.lease_pid = b.root, b.run, clock, lease_pid
        need(type(lease_pid) is int and lease_pid > 1, 'FRESH_ROOT_LEASE_REQUIRED')
        need(file_ops is None or self.root != ROOT, 'NATIVE_DEFAULT_FILE_OPS_REQUIRED')
        self.files = file_ops or FileOps()
        self.b.lease = self.lease
        self.base = copy.deepcopy(current.base)
        self.before_source, self.before_static = dict(current.source), dict(current.static)
        need(len(self.before_source) == 209 and len(self.before_static) == 26
             and all(digest(v) for v in [*self.before_source.values(), *self.before_static.values()]), 'EXACT_CURRENT_SOURCE209_STATIC26_REQUIRED')
        need(self.base['containers']['content']['image'] == CONTENT and len(self.base['containers']['content']['files']) == 24
             and self.base['worker']['image'] == WORKER and self.base['selected']['content']['PALITRA_WEB_UPLOADS_ENABLED'] == 'true', 'EXACT_ACCEPTED_CURRENT24_REQUIRED')
        self.cabinet, self.editor = current.cabinet, current.editor
        self.parents = {str(p): self.facts(p) for p in (self.root, self.cabinet, self.editor)}
        self.payload = a.exact_path(payload)
        need(self.payload.is_relative_to(self.root), 'ROOT_PAYLOAD_REQUIRED')
        need(digest(manifest_pin) and MANIFEST_SHA != UNFROZEN and manifest_pin == MANIFEST_SHA, 'MANIFEST_NOT_FROZEN')
        self.manifest_pin = manifest_pin
        manifest = a.pinned(self.payload / 'MANIFEST.json', manifest_pin)
        need(type(manifest) is dict and set(manifest) == {'schema', 'status', 'records'} and manifest['schema'] == 1
             and manifest['status'] == SCOPE and type(manifest['records']) is list and len(manifest['records']) == 1, 'EXACT_ONE_BACKEND_PAYLOAD_REQUIRED')
        self.helper, self.wrapper = a.exact_path(__file__), a.exact_path(Path(__file__).parent / 'push_json_compat.py')
        self.pins = {str(self.helper): sha(a.read(self.helper)), str(self.wrapper): sha(a.read(self.wrapper)), str(self.payload / 'MANIFEST.json'): manifest_pin}
        self.records, self.targets = {}, {}
        self.final_source, self.final_static = dict(self.before_source), dict(self.before_static)
        for row in manifest['records']:
            self.accept(row)
        need(set(self.records) == NAMES and len(self.static_targets()) == 0
             and self.final_static == self.before_static
             and [key for key in self.before_source if self.before_source[key] != self.final_source[key]] == [BACKEND], 'EXACT_BACKEND1_STATIC0_EXISTING_REQUIRED')
        found = set()
        for path in self.payload.rglob('*'):
            a.exact_path(path)
            relative = path.relative_to(self.payload).as_posix()
            if path.is_file(): found.add(relative)
            else: need(path.is_dir() and relative in {'backend'}, 'CLOSED_PAYLOAD_DIRECTORY_REQUIRED')
        need(found == NAMES | {'MANIFEST.json'}, 'CLOSED_ONE_BACKEND_PAYLOAD_REQUIRED')

    def facts(self, path):
        row = self.a.exact_path(path).stat()
        need(stat.S_ISDIR(row.st_mode), 'EXACT_DIRECTORY_PARENT_REQUIRED')
        return [row.st_dev, row.st_ino, row.st_uid, stat.S_IMODE(row.st_mode)]

    def parents_guard(self):
        need({name: self.facts(Path(name)) for name in self.parents} == self.parents, 'STATIC_PARENT_IDENTITY_CHANGED')

    def target_map(self, name):
        need(name == 'backend/' + BACKEND, 'EXACT_BACKEND_TARGET_REQUIRED')
        return [('source', BACKEND)]

    def accept(self, row):
        need(type(row) is dict and set(row) == {'name', 'payload', 'beforeSha256', 'beforeBytes', 'sha256', 'bytes', 'hunks'}, 'EXACT_MANIFEST_RECORD_REQUIRED')
        name = row['name']
        need(type(name) is str and name in NAMES and name not in self.records and row['payload'] == name
             and all(digest(row[k]) for k in ('beforeSha256', 'sha256')) and row['beforeSha256'] != row['sha256']
             and all(type(row[k]) is int and 0 < row[k] <= 2 * 1024 * 1024 for k in ('beforeBytes', 'bytes'))
             and type(row['hunks']) is list and 1 <= len(row['hunks']) <= 256, 'EXACT_CHANGED_EXISTING_RECORD_REQUIRED')
        need((row['beforeSha256'], row['beforeBytes']) == (BEFORE_SHA, BEFORE_BYTES), 'EXACT_ACCEPTED_BACKEND_BASE_REQUIRED')
        raw = self.a.read(self.payload / name)
        need(len(raw) == row['bytes'] and sha(raw) == row['sha256'], 'PAYLOAD_CHANGED')
        old = raw
        for hunk in reversed(row['hunks']):
            before, after = hunk_bytes(hunk)
            need(old.count(after) == 1, 'REVERSE_UNIQUE_HUNK_REQUIRED')
            old = old.replace(after, before, 1)
        need(len(old) == row['beforeBytes'] and sha(old) == row['beforeSha256'] and self.patch(old, row) == raw, 'EXACT_RECONSTRUCTED_BASE_REQUIRED')
        targets = self.target_map(name)
        for kind, target in targets:
            before = self.before_source if kind == 'source' else self.before_static
            final = self.final_source if kind == 'source' else self.final_static
            need(before.get(target) == row['beforeSha256'], 'EXACT_ACCEPTED_TARGET_BASE_REQUIRED')
            final[target] = row['sha256']
        self.records[name], self.targets[name] = row, targets
        self.pins[str(self.payload / name)] = row['sha256']

    def patch(self, raw, row):
        need(len(raw) == row['beforeBytes'] and sha(raw) == row['beforeSha256'], 'ACTUAL_RAW_BASE_CHANGED')
        for hunk in row['hunks']:
            before, after = hunk_bytes(hunk)
            need(raw.count(before) == 1, 'FORWARD_UNIQUE_HUNK_REQUIRED')
            raw = raw.replace(before, after, 1)
        need(len(raw) == row['bytes'] and sha(raw) == row['sha256'], 'FINAL_BYTES_CHANGED')
        return raw

    def static_targets(self):
        return [(name, Path(target)) for name in sorted(self.targets) for kind, target in self.targets[name] if kind == 'static']

    def paths(self):
        return {key: self.root / (NAME + '-' + key + ('.json' if key in ('decision', 'journal', 'overlay') else '')) for key in ('decision', 'journal', 'overlay', 'context', 'backup')}

    def lease(self):
        raw = self.run(['lslocks', '--noheadings', '--output', 'PID,PATH'])
        need(len(raw) <= 1048576, 'BOUNDED_LEASE_INVENTORY_REQUIRED')
        rows = [line.strip().split(maxsplit=1) for line in raw.decode().splitlines() if len(line.strip().split(maxsplit=1)) == 2 and line.strip().split(maxsplit=1)[1] == LOCK]
        need(rows == [[str(self.lease_pid), LOCK]], 'FRESH_EXCLUSIVE_ROOT_LEASE_REQUIRED')

    def stable(self):
        self.current.stable()
        for name, pin in self.pins.items(): need(sha(self.a.read(Path(name))) == pin, 'PUSH_JSON_PINNED_INPUT_CHANGED')
        self.parents_guard()

    def absent(self, decision=False):
        for kind, path in self.paths().items():
            if kind == 'decision' and not decision: continue
            self.a.exact_path(path, True)
            need(not os.path.lexists(path) and not os.path.lexists(str(path) + '.pending'), 'ATTEMPT_EXISTS_NO_RETRY')

    def expected_metadata(self, service, content, proof):
        if service == 'chat': return copy.deepcopy(self.base['containers']['chat'])
        old = self.base['containers']['content']
        if content == CONTENT:
            need(proof is None, 'BASE_PROOF_MUST_BE_EMPTY')
            return copy.deepcopy(old)
        need(type(proof) is dict and set(proof) == {'childImage', 'overlaySha256', 'plannedConfigHash'} and proof['childImage'] == content
             and self.a.image(content) and content != CONTENT and digest(proof['overlaySha256']) and digest(proof['plannedConfigHash']), 'OWN_SEALED_CHILD_PROOF_REQUIRED')
        overlay = self.paths()['overlay']
        need(sha(self.a.read(overlay)) == proof['overlaySha256'] and self.a.decode(self.a.read(overlay)) == {'services': {'content': {'image': content}}}, 'OWN_SEALED_OVERLAY_CHANGED')
        files = old['files'] + [str(overlay)]
        need(len(old['files']) == 24 and len(files) == len(set(files)) == 25, 'EXACT_OWN_CHAIN25_REQUIRED')
        return dict(old, image=content, files=files, configFiles=','.join(files), filePins={**old['filePins'], str(overlay): proof['overlaySha256']}, configHash=proof['plannedConfigHash'])

    def metadata(self, service, expected):
        if service == 'chat':
            row = self.b.metadata(service)
        else:
            row = self.a.decode(self.run(['docker', 'inspect', '--format', self.a.LABELS, 'synapse-content-1']))
            need(type(row) is dict and set(row) == {'image', 'project', 'service', 'workingDir', 'configFiles', 'configHash', 'running', 'health'}
                 and type(row['configFiles']) is str and len(row['configFiles']) <= 65536, 'EXACT_CONTENT_LABELS_REQUIRED')
            files = row['configFiles'].split(',')
            need(files == expected['files'] and len(files) == len(set(files)) and len(files) in (24, 25), 'ONLY_EXACT_BASE24_OR_OWN25_REQUIRED')
            pins = {}
            for name in files:
                path = self.a.exact_path(name)
                need(path.suffix.lower() in ('.json', '.yml', '.yaml'), 'EXACT_COMPOSE_FILE_REQUIRED')
                pins[name] = sha(self.a.read(path))
            row.update(files=files, filePins=pins)
        need(row == expected, 'EXACT_METADATA_FILEPINS_CHANGED')
        return row

    def static_guard(self, changed):
        self.parents_guard()
        self.current.guide_guard()
        for name, pin in (self.final_static if changed else self.before_static).items():
            need(sha(self.a.read(Path(name))) == pin, 'FULL_STATIC26_CHANGED')
        self.modes()

    def snapshot(self, content=CONTENT, changed=False, proof=None, static_changed=None):
        self.stable(); self.lease()
        first = {s: self.metadata(s, self.expected_metadata(s, content, proof)) for s in ('content', 'chat')}
        worker = self.b.worker_facts()
        selected = {s: self.b.a.selected(s) for s in ('content', 'chat')}
        flags = self.a.decode(self.run(['docker', 'exec', 'synapse-content-1', 'node', '-e', self.a.FLAGS_JS]))
        need(worker == self.base['worker'] and selected == self.base['selected'] and flags == self.base['l12'], 'WORKER_FLAGS_OR_SELECTION_CHANGED')
        for service, row in first.items():
            text = self.run(self.b._resolve_command(row, service)).decode('ascii').strip()
            need(re.fullmatch(re.escape(service) + r'\s+' + re.escape(row['configHash']), text) is not None, 'RESOLVED_CONFIG_HASH_CHANGED')
        self.source_mode_guard()
        self.b.graph(new=True); self.b.push_guard()
        expected = self.final_source if changed else self.before_source
        need(self.photo.hashes(expected) == expected, 'FULL_SOURCE209_CHANGED')
        self.static_guard(changed if static_changed is None else static_changed)
        cid = self.photo.cid()
        last = {s: self.metadata(s, self.expected_metadata(s, content, proof)) for s in ('content', 'chat')}
        need(first == last and worker == self.b.worker_facts() and selected == {s: self.b.a.selected(s) for s in ('content', 'chat')}
             and cid == self.photo.cid(), 'CONCURRENT_RUNTIME_CHANGE')
        self.stable(); self.lease()
        return {'containers': last, 'selected': selected, 'worker': worker, 'contentCid': cid, 'l12': flags}

    def baseline(self):
        snap = self.snapshot()
        need(snap == self.base and self.b.heartbeat(snap['worker']['startedAt'], self.clock())['freshAfterWorkerStart'], 'FRESH_CURRENT24_REQUIRED')
        return snap

    def users(self, child=None):
        rows = {'current': self.a.decode(self.run(['docker', 'inspect', '--format', USER_FORMAT, 'synapse-content-1'])),
                'parent': self.a.decode(self.run(['docker', 'image', 'inspect', '--format', USER_FORMAT, CONTENT]))}
        if child: rows['child'] = self.a.decode(self.run(['docker', 'image', 'inspect', '--format', USER_FORMAT, child]))
        need(all(type(v) is str and v in ROOT_USERS for v in rows.values()) and (not child or rows['parent'] == rows['child']), 'ROOT_SERVICE_READ_SCOPE_REQUIRED')
        return rows

    def modes(self):
        # Source-only release: no selected public target and no public chmod.
        need(self.static_targets() == [] and self.final_static == self.before_static, 'STATIC_MUTATION_FORBIDDEN')
        return {}

    def binding(self):
        return {'priorReceiptSha256': PRIOR_RECEIPT_SHA, 'parentImage': CONTENT, 'workerImage': WORKER, 'manifestSha256': self.manifest_pin,
                'helperSha256': self.pins[str(self.helper)], 'wrapperSha256': self.pins[str(self.wrapper)], 'freshLeasePid': self.lease_pid, 'parents': self.parents}

    def decision(self, pin):
        value = self.a.pinned(self.paths()['decision'], pin, True)
        need(type(value) is dict and set(value) == {'schema', 'name', 'scope', 'rootApproved', 'observedAtUtc', 'inputs', 'before', 'staticModes', 'serviceUsers'}
             and value['schema'] == 1 and value['name'] == NAME and value['scope'] == SCOPE and value['rootApproved'] is True
             and value['inputs'] == self.binding() and value['before'] == self.base and value['serviceUsers'] == self.users(), 'EXACT_NEW_ROOT_DECISION_REQUIRED')
        self.a.fresh(value['observedAtUtc'], self.clock())
        need(type(value['staticModes']) is dict and set(value['staticModes']) == {str(p) for _, p in self.static_targets()}
             and value['staticModes'] == {}, 'EXACT_APPROVED_STATIC_MODES_REQUIRED')
        return value

    def inspect_current(self):
        self.baseline(); self.users()
        return {'status': 'CURRENT24_READONLY_NOT_APPROVED', 'sourceFiles': 209, 'staticFiles': 26, 'contentChainFiles': 24, 'mutations': 0}

    def approve(self, apply=False):
        need(apply is True, 'EXPLICIT_ROOT_APPROVAL_REQUIRED')
        self.absent(True); at = self.clock(); before = self.baseline()
        modes, users = self.modes(), self.users()
        self.a.fresh(self.a.stamp(at), self.clock())
        value = {'schema': 1, 'name': NAME, 'scope': SCOPE, 'rootApproved': True, 'observedAtUtc': self.a.stamp(at), 'inputs': self.binding(),
                 'before': before, 'staticModes': modes, 'serviceUsers': users}
        self.a.write_new(self.paths()['decision'], value)
        return {'status': 'NEW_DECISION_NOT_APPLIED', 'decisionSha256': sha(self.a.read(self.paths()['decision'])), 'runtimeWrites': 0}

    def context_proof(self, state, built=False):
        paths = self.paths(); alias = 'palitra-push-json-compat-base:' + NAME
        wanted = {'Dockerfile': sha(('FROM ' + alias + '\nCOPY app/ /app/\n').encode())}
        wanted.update({'app/' + target: self.records[name]['sha256'] for name in self.records for kind, target in self.targets[name] if kind == 'source'})
        wanted.update({'static/' + str(i): row['sha256'] for i, row in enumerate(state['static'])})
        actual = {}
        for path in paths['context'].rglob('*'):
            self.a.exact_path(path)
            name = path.relative_to(paths['context']).as_posix()
            if path.is_file():
                if built and name == 'image.id': continue
                actual[name] = sha(self.a.read(path))
            else: need(path.is_dir() and name in {'app'}, 'CLOSED_CONTEXT_DIRECTORIES_REQUIRED')
        need(actual == wanted, 'EXACT_CLOSED_CONTEXT_REQUIRED')
        return sha(json.dumps(sorted(actual.items()), separators=(',', ':')).encode())

    def update(self, state, phase, **fields):
        state.update(phase=phase, **fields); self.a.replace(self.paths()['journal'], state)

    def unused(self, tag):
        need(not self.run(['docker', 'image', 'ls', '--quiet', '--filter', 'reference=' + tag]).strip(), 'UNIQUE_NEW_IMAGE_TAG_REQUIRED')

    def backup_directory_facts(self):
        path = self.a.exact_path(self.paths()['backup']); row = path.stat()
        expected_uid = 0 if self.root == ROOT else (os.getuid() if hasattr(os, 'getuid') else row.st_uid)
        need(stat.S_ISDIR(row.st_mode) and row.st_uid == expected_uid and self.files.mode(path) == 0o700, 'PRIVATE_BACKUP_DIRECTORY_REQUIRED')
        return {'path': str(path), 'device': row.st_dev, 'inode': row.st_ino, 'uid': row.st_uid, 'mode': 0o700}

    def backup_directory_guard(self, sealed):
        self.parents_guard()
        need(type(sealed) is dict and set(sealed) == {'path', 'device', 'inode', 'uid', 'mode'}
             and sealed['path'] == str(self.paths()['backup']) and sealed['mode'] == 0o700
             and all(type(sealed[key]) is int for key in ('device', 'inode', 'uid', 'mode'))
             and self.backup_directory_facts() == sealed, 'BACKUP_DIRECTORY_IDENTITY_CHANGED')

    def backup_guard(self, state):
        need(state.get('static') == [], 'STATIC_MUTATION_FORBIDDEN')
        directory = state.get('backupDirectory'); self.backup_directory_guard(directory)
        row = state.get('sourceBackup')
        need(type(row) is dict and set(row) == {'target', 'baseSha256', 'bytes', 'backup', 'mode'}
             and row == {'target': BACKEND, 'baseSha256': BEFORE_SHA, 'bytes': BEFORE_BYTES,
                         'backup': str(self.paths()['backup'] / BACKEND), 'mode': 0o600}, 'EXACT_SOURCE_BACKUP_REQUIRED')
        need({path.name for path in self.paths()['backup'].iterdir()} == {BACKEND}, 'CLOSED_BACKUP_DIRECTORY_REQUIRED')
        path = self.a.exact_path(Path(row['backup']))
        flags = os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_CLOEXEC', 0) | getattr(os, 'O_BINARY', 0)
        fd = os.open(path, flags)
        try:
            first = os.fstat(fd)
            need(stat.S_ISREG(first.st_mode) and first.st_uid == directory['uid'] and self.files.fd_mode(fd) == 0o600
                 and first.st_size == BEFORE_BYTES, 'PRIVATE_REGULAR_BACKUP_REQUIRED')
            raw_hash = hashlib.sha256(); total = 0
            while True:
                raw = os.read(fd, 65536)
                if not raw: break
                total += len(raw); need(total <= BEFORE_BYTES, 'BACKUP_SIZE_CHANGED'); raw_hash.update(raw)
            last = os.fstat(fd); actual = self.a.exact_path(path).stat()
            identity = (first.st_dev, first.st_ino, first.st_uid)
            need(identity == (last.st_dev, last.st_ino, last.st_uid) == (actual.st_dev, actual.st_ino, actual.st_uid)
                 and stat.S_ISREG(actual.st_mode) and self.files.fd_mode(fd) == self.files.mode(path) == 0o600
                 and total == BEFORE_BYTES and raw_hash.hexdigest() == BEFORE_SHA, 'BACKUP_SHA_MODE_OR_IDENTITY_CHANGED')
        finally:
            os.close(fd)
        self.backup_directory_guard(directory)

    def source_mode_guard(self):
        facts = self.a.decode(self.run(['docker', 'exec', 'synapse-content-1', 'node', '-e', SOURCE_MODE_JS]))
        need(facts == {'regular': True, 'uid': 0, 'gid': 0, 'mode': 0o644}, 'EXACT_BACKEND_MODE_OWNER_REQUIRED')

    def build_preflight(self, child):
        # Parse one reviewed file in a disposable isolated image, without running product code.
        need(self.a.image(child) and child != CONTENT, 'EXACT_CHILD_FOR_PREFLIGHT_REQUIRED')
        output = self.run(['docker', 'run', '--rm', '--network=none', '--read-only', '--cap-drop=ALL',
                           '--security-opt=no-new-privileges', '--entrypoint=node', child, '-e', CHILD_CHECK_JS])
        need(output == b'PRECHECK_OK', 'CHILD_SYNTAX_MODE_PREFLIGHT_REQUIRED')

    def apply(self, pin, apply=False):
        need(apply is True, 'EXPLICIT_ROOT_APPLY_REQUIRED')
        self.absent(); decision = self.decision(pin); before = self.baseline()
        need(self.modes() == decision['staticModes'], 'APPROVED_MODES_CHANGED')
        self.users(); paths = self.paths(); alias = 'palitra-push-json-compat-base:' + NAME; tag = 'palitra-push-json-compat:' + NAME
        self.unused(alias); self.unused(tag)
        need(self.run(['docker', 'image', 'inspect', '--format', '{{.Id}}', CONTENT]).decode().strip() == CONTENT, 'EXACT_LOCAL_PARENT_REQUIRED')
        layers = self.a.decode(self.run(['docker', 'image', 'inspect', '--format', '{{json .RootFS.Layers}}', CONTENT]))
        need(type(layers) is list and layers, 'PARENT_LAYER_PROOF_REQUIRED')
        state = {'schema': 1, 'name': NAME, 'phase': 'CONTEXT_STARTED_UNKNOWN', 'inputs': self.binding(), 'decisionSha256': pin, 'before': before,
                 'static': [], 'workerRecreated': False, 'uploadsEnabled': True, 'directDbWrites': 0, 'queueEdits': 0, 'automaticRetry': False,
                 'automaticCodeRollback': False, 'oldJournalWrites': 0}
        self.a.write_new(paths['journal'], state)
        for path, mode in ((paths['context'], 0o700), (paths['backup'], 0o700), (paths['context'] / 'app', 0o755)):
            self.files.directory(self.a.exact_path(path, True), mode)
        self.backup_directory = self.backup_directory_facts(); state['backupDirectory'] = copy.deepcopy(self.backup_directory)
        record = self.records['backend/' + BACKEND]
        raw = self.run(['docker', 'exec', 'synapse-content-1', 'node', '-e', self.current.source_script, BACKEND])
        need(len(raw) <= 3 * 1024 * 1024, 'BOUNDED_SOURCE_BYTES_REQUIRED')
        old = base64.b64decode(raw, validate=True); patched = self.patch(old, record)
        self.files.write(paths['context'] / 'app' / BACKEND, patched, 0o644)
        self.files.write(paths['backup'] / BACKEND, old, 0o600)
        state['sourceBackup'] = {'target': BACKEND, 'baseSha256': BEFORE_SHA, 'bytes': BEFORE_BYTES,
                                 'backup': str(paths['backup'] / BACKEND), 'mode': 0o600}
        self.backup_guard(state)
        self.files.write(paths['context'] / 'Dockerfile', ('FROM ' + alias + '\nCOPY app/ /app/\n').encode(), 0o600)
        self.update(state, 'CONTEXT_READY_NOT_BUILT', contextSha256=self.context_proof(state))
        self.baseline(); self.decision(pin); self.lease(); self.unused(alias); self.unused(tag)
        self.run(['docker', 'image', 'tag', CONTENT, alias])
        need(self.run(['docker', 'image', 'inspect', '--format', '{{.Id}}', alias]).decode().strip() == CONTENT, 'NEW_PARENT_ALIAS_CHANGED')
        self.update(state, 'BUILD_STARTED_UNKNOWN'); self.decision(pin); self.lease()
        need(self.context_proof(state) == state['contextSha256']
             and self.run(['docker', 'image', 'inspect', '--format', '{{.Id}}', alias]).decode().strip() == CONTENT, 'LAST_BUILD_CONTEXT_OR_PARENT_CHANGED')
        self.run(['docker', 'build', '--network=none', '--pull=false', '--tag', tag, '--iidfile', str(paths['context'] / 'image.id'), str(paths['context'])])
        child = self.a.read(paths['context'] / 'image.id').decode().strip()
        need(self.a.image(child) and child != CONTENT and self.run(['docker', 'image', 'inspect', '--format', '{{.Id}}', tag]).decode().strip() == child, 'EXACT_NEW_CHILD_REQUIRED')
        child_layers = self.a.decode(self.run(['docker', 'image', 'inspect', '--format', '{{json .RootFS.Layers}}', child]))
        need(type(child_layers) is list and child_layers[:len(layers)] == layers and len(child_layers) == len(layers) + 1, 'ONE_EXACT_COPY_LAYER_REQUIRED')
        need(self.context_proof(state, True) == state['contextSha256'] and self.photo.hashes(self.final_source, child) == self.final_source, 'BUILT_FULL_SOURCE209_CHANGED')
        self.build_preflight(child)
        self.users(child); self.baseline(); self.decision(pin)
        self.backup_guard(state)
        self.update(state, 'BUILD_PREFLIGHT_PASSED_NOT_ACTIVATED', childImage=child)
        self.static_guard(False); self.stable(); self.decision(pin); self.users(child)
        self.a.write_new(paths['overlay'], {'services': {'content': {'image': child}}})
        overlay_pin = sha(self.a.read(paths['overlay'])); planned = self.b.plan(before, 'content', paths['overlay'])
        self.update(state, 'CONTENT_UP_STARTED_UNKNOWN', overlay=str(paths['overlay']), overlaySha256=overlay_pin, plannedConfigHash=planned)
        # Old source is still running; all existing static resources remain unchanged.
        need(self.snapshot(static_changed=True) == before, 'LAST_COMPLETE_BASE24_CHANGED')
        self.decision(pin); self.lease(); self.stable(); self.users(child)
        need(self.context_proof(state, True) == state['contextSha256'] and self.b.plan(before, 'content', paths['overlay']) == planned, 'LAST_SEALED_PLAN_OR_CONTEXT_CHANGED')
        proof = {'childImage': child, 'overlaySha256': overlay_pin, 'plannedConfigHash': planned}
        self.expected_metadata('content', child, proof)
        self.backup_guard(state)
        self.b.up(before, 'content', paths['overlay'])
        after = self.snapshot(child, True, proof)
        self.users(child)
        need(after['contentCid'] != before['contentCid'] and self.b.heartbeat(after['worker']['startedAt'], self.clock())['freshAfterWorkerStart']
             and self.snapshot(child, True, proof) == after, 'FRESH_STABLE_AFTER_REQUIRED')
        self.update(state, PHASE, after=after, finishedAtUtc=self.a.stamp(self.clock()))
        return {'status': PHASE, 'journalSha256': sha(self.a.read(paths['journal'])), 'contentImage': child, 'sourceFiles': 209, 'staticFiles': 26,
                'contentChainFiles': 25, 'sourceFilesChanged': 1, 'staticFilesChanged': 0, 'buildPreflight': 'NODE_CHECK_PASSED', 'builds': 1, 'contentUps': 1, 'workerRecreated': False, 'uploadsEnabled': True,
                'directDbWrites': 0, 'queueEdits': 0, 'oldJournalWrites': 0, 'automaticRetry': False}

    def inspect(self, pin):
        state = self.a.pinned(self.paths()['journal'], pin, True)
        need(state.get('schema') == 1 and state.get('name') == NAME and state.get('phase') == PHASE and state.get('inputs') == self.binding()
             and state.get('before') == self.base and state.get('workerRecreated') is False and state.get('uploadsEnabled') is True
             and state.get('directDbWrites') == state.get('queueEdits') == state.get('oldJournalWrites') == 0
             and state.get('automaticRetry') is False and state.get('automaticCodeRollback') is False
             and state.get('static') == [], 'OWN_COMPLETED_RECEIPT_REQUIRED')
        self.backup_guard(state)
        proof = {key: state[key] for key in ('childImage', 'overlaySha256', 'plannedConfigHash')}
        need(state.get('overlay') == str(self.paths()['overlay']) and self.context_proof(state, True) == state['contextSha256'], 'COMPLETED_CONTEXT_OR_OVERLAY_CHANGED')
        for row in state['static']:
            need(self.files.mode(Path(row['target'])) == row['mode'], 'COMPLETED_TARGET_MODE_CHANGED')
        need(self.snapshot(state['childImage'], True, proof) == state['after'], 'COMPLETED_RUNTIME_CHANGED')
        return {'status': 'COMPLETED25_READONLY_NOT_DEVICE_SUBSCRIPTION_OR_DELIVERY_ACCEPTANCE', 'mutations': 0, 'heartbeat': self.b.heartbeat(self.base['worker']['startedAt'], self.clock())}


def load_current24(lease_pid):
    """Read exact completed24 through its own pinned constructor; never replay old actions.

    The old receipt PID proves only the immutable binding, never a live lease.
    Every new native operation installs its own fresh explicit lease validator.
    """
    need(type(lease_pid) is int and lease_pid > 1, 'FRESH_ROOT_LEASE_REQUIRED')
    path = PRIOR_CODE / 'chat_push_release_native.py'
    for item in [*reversed(path.parents), path, PRIOR_CODE / 'chat_push.py']:
        need(not item.is_symlink(), 'HISTORICAL_CODE_SYMLINK_REFUSED')
    raw = path.read_bytes(); need(sha(raw) == PRIOR_HELPER_SHA, 'EXACT_CHAIN24_READER_HELPER_REQUIRED')
    need(sha((PRIOR_CODE / 'chat_push.py').read_bytes()) == PRIOR_WRAPPER_SHA, 'EXACT_CHAIN24_READER_WRAPPER_REQUIRED')
    prior = types.ModuleType('historical_chain24'); prior.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), prior.__dict__)
    a, b, current23 = prior.load_current(lease_pid)
    journal = ROOT / 'palitra-chat-push-consistency-r3-journal.json'
    receipt = a.pinned(journal, PRIOR_RECEIPT_SHA, True)
    historical_pid = receipt.get('inputs', {}).get('freshLeasePid')
    need(type(historical_pid) is int and historical_pid > 1, 'HISTORICAL_RECEIPT_LEASE_BINDING_REQUIRED')
    accepted = prior.ChatPushRelease(a, b, current23, PRIOR_CODE / 'payload', prior.MANIFEST_SHA, historical_pid)
    need(receipt.get('schema') == 1 and receipt.get('name') == prior.NAME and receipt.get('phase') == prior.PHASE
         and receipt.get('inputs') == accepted.binding() and receipt.get('before') == accepted.base
         and receipt.get('childImage') == CONTENT and receipt.get('workerRecreated') is False and receipt.get('uploadsEnabled') is True
         and receipt.get('directDbWrites') == receipt.get('queueEdits') == receipt.get('oldJournalWrites') == 0
         and receipt.get('automaticRetry') is False and receipt.get('automaticCodeRollback') is False
         and type(receipt.get('static')) is list and len(receipt['static']) == 5
         and all(type(row) is dict and row.get('written') is True for row in receipt['static']), 'EXACT_COMPLETED_CHAIN24_RECEIPT_REQUIRED')
    proof = {key: receipt[key] for key in ('childImage', 'overlaySha256', 'plannedConfigHash')}
    need(receipt.get('overlay') == str(accepted.paths()['overlay'])
         and receipt['after']['containers']['content'] == accepted.expected_metadata('content', CONTENT, proof)
         and len(receipt['after']['containers']['content']['files']) == 24
         and receipt['after']['containers']['chat'] == accepted.base['containers']['chat']
         and receipt['after']['worker'] == accepted.base['worker'] and receipt['after']['selected'] == accepted.base['selected']
         and receipt['after']['l12'] == accepted.base['l12']
         and receipt['after']['contentCid'] != accepted.base['contentCid'], 'EXACT_COMPLETED24_METADATA_REQUIRED')
    need(len(accepted.final_source) == 209 and len(accepted.final_static) == 26
         and accepted.final_source.get(BACKEND) == BEFORE_SHA, 'EXACT_CURRENT24_SOURCE209_STATIC26_BACKEND_REQUIRED')
    def stable():
        accepted.stable()
        need(sha(a.read(journal)) == PRIOR_RECEIPT_SHA, 'CHAIN24_COMPLETED_RECEIPT_CHANGED')
        need(accepted.context_proof(receipt, True) == receipt['contextSha256'], 'ACCEPTED24_CONTEXT_CHANGED')
        accepted.backup_guard(receipt)
    def guide_guard():
        current23.guide_guard()
        for row in receipt['static']:
            info = a.exact_path(row['target']).stat()
            need(stat.S_ISREG(info.st_mode) and info.st_uid == 0 and stat.S_IMODE(info.st_mode) == row['mode'], 'ACCEPTED24_STATIC_MODES_CHANGED')
    stable()
    current = types.SimpleNamespace(base=receipt['after'], source=accepted.final_source, static=accepted.final_static,
                                    cabinet=accepted.cabinet, editor=accepted.editor, stable=stable, guide_guard=guide_guard,
                                    source_script=current23.source_script)
    return a, b, current


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=('inspect-current', 'approve-current', 'apply', 'inspect'))
    parser.add_argument('--lease-pid', required=True, type=int)
    parser.add_argument('--decision-sha'); parser.add_argument('--receipt-sha'); parser.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    try:
        need(MANIFEST_SHA != UNFROZEN, 'DRAFT_NOT_FROZEN_NO_NATIVE_ACTION')
        need(os.name == 'posix' and os.geteuid() == 0 and Path(__file__).resolve().parent == ROOT / CODE_NAME, 'EXACT_ROOT_NEW_NAMESPACE_REQUIRED')
        a, b, current = load_current24(args.lease_pid)
        release = PushJsonCompatRelease(a, b, current, ROOT / CODE_NAME / 'payload', MANIFEST_SHA, args.lease_pid)
        if args.operation == 'inspect-current': result = release.inspect_current()
        elif args.operation == 'approve-current': result = release.approve(args.apply)
        elif args.operation == 'apply':
            need(digest(args.decision_sha), 'EXPLICIT_NEW_DECISION_SHA_REQUIRED'); result = release.apply(args.decision_sha, args.apply)
        else:
            need(digest(args.receipt_sha), 'EXPLICIT_OWN_RECEIPT_SHA_REQUIRED'); result = release.inspect(args.receipt_sha)
        print(json.dumps(result, separators=(',', ':'))); return 0
    except Exception as error:
        code = str(error) if type(error) is ValueError and re.fullmatch('[A-Z][A-Z0-9_]{0,100}', str(error)) else 'NEW_RELEASE_ACTION_REFUSED'
        print(json.dumps({'status': 'REFUSED_OR_UNKNOWN_NO_AUTOMATIC_RETRY', 'code': code, 'messageSha256': sha(str(error).encode()),
                          'automaticRetry': False, 'automaticCodeRollback': False, 'workerRecreated': False, 'oldJournalWrites': 0})); return 2


if __name__ == '__main__': sys.exit(main())
