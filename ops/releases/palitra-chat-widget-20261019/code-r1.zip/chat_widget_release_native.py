"""Root-final local installer33 draft. FINAL=true/MANIFEST0; NOT FROZEN, NOT INSTALLED.
Root-only future source210→211/static27/runtime31→32 with added source1 and managed existing CAS.
"""
import argparse
import base64
import copy
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import time
import types

ROOT = Path('/opt/synapse/releases/palitra-app-20261015')
NAME = 'palitra-chat-widget-r1'
CODE_NAME = 'palitra-chat-widget-code-r1'
PHASE = 'RELEASE33_WIDGET_APPLIED_NOT_CUSTOMER_ACCEPTANCE'
SCOPE = 'EXACT_WIDGET_SOURCE210_TO211_STATIC27_CHAIN31_TO32'
UNFROZEN = '0' * 64
MANIFEST_SHA = '8446c44d46d58e119764f9e9ce2e7e755585eb9f5d9953569fd7ce628d94d630'
FINAL = True
PRIOR_CODE = ROOT / 'palitra-chat-composer-bottom-code-r2'
PRIOR_HELPER_SHA = 'b77220d5b86cf4083257e87ae1e1c26c3f443a1b2e2b226ecbf9806bc4301d02'
PRIOR_WRAPPER_SHA = 'ea07d2cb3806ac5e690189d54594c36e6ddc9423609573727b2836a1e817c22d'
PRIOR_RECEIPT_SHA = 'e7eb294fa38908b8d1fbbaef2957511a2cbf4328163a83738751653718ed2be3'
PRIOR_DECISION_SHA = '4899b00d6a918498dbe288cb7c994bbe359aea4ab0fafc71fd86f88d6bc4cd89'
CONTENT = 'sha256:3176108f728bab2c4d9293bbe00e3cb205b003ca825ca9001c8a9b2e38c11e11'
CONTENT_CONFIRMED = True
WORKER = 'sha256:d4d4d453ce2e3dc47d5e0962d62b95938f42c56ec73789fe76a324e0d2ff0508'
LOCK = '/opt/synapse/.palitra-app-release.lock'
# No payload target names or pins selected until explicit Root-final.
EXISTING_SOURCE_LAYOUT = {'backend/customer-chat.js': 'customer-chat.js', 'backend/customer-chat-http.cjs': 'customer-chat-http.cjs', 'backend/palitra-host-adapter.cjs': 'palitra-host-adapter.cjs', 'legacy/palitra-chat.html': 'palitra-review-public/palitra-chat.html', 'legacy/palitra-chat.js': 'palitra-review-public/palitra-chat.js', 'legacy/palitra-chat.css': 'palitra-review-public/palitra-chat.css', 'product/shell.js': 'palitra-orders-public/shell.js', 'product/shell.css': 'palitra-orders-public/shell.css', 'product/synapse-bridge.js': 'palitra-orders-public/synapse-bridge.js'}
ADDED_SOURCE_LAYOUT = {'legacy/palitra-chat-widget.css': 'palitra-review-public/palitra-chat-widget.css'}
SOURCE_LAYOUT = {'backend/customer-chat.js': 'customer-chat.js', 'backend/customer-chat-http.cjs': 'customer-chat-http.cjs', 'backend/palitra-host-adapter.cjs': 'palitra-host-adapter.cjs', 'legacy/palitra-chat.html': 'palitra-review-public/palitra-chat.html', 'legacy/palitra-chat.js': 'palitra-review-public/palitra-chat.js', 'legacy/palitra-chat.css': 'palitra-review-public/palitra-chat.css', 'product/shell.js': 'palitra-orders-public/shell.js', 'product/shell.css': 'palitra-orders-public/shell.css', 'product/synapse-bridge.js': 'palitra-orders-public/synapse-bridge.js', 'legacy/palitra-chat-widget.css': 'palitra-review-public/palitra-chat-widget.css'}
# payload -> {root: 'cabinet'|'managed', path: exact relative path}; Root fills fixed mappings.
STATIC_LAYOUT = {'product/shell.js': {'root': 'cabinet', 'path': 'shell.js'}, 'product/shell.css': {'root': 'cabinet', 'path': 'shell.css'}, 'product/synapse-bridge.js': {'root': 'cabinet', 'path': 'synapse-bridge.js'}, 'storefront/storefront.js': {'root': 'managed', 'path': 'assets/storefront.js'}}
SOURCE_MODES = {'customer-chat.js': 420, 'customer-chat-http.cjs': 420, 'palitra-host-adapter.cjs': 384, 'palitra-review-public/palitra-chat.html': 420, 'palitra-review-public/palitra-chat.js': 420, 'palitra-review-public/palitra-chat.css': 420, 'palitra-orders-public/shell.js': 420, 'palitra-orders-public/shell.css': 420, 'palitra-orders-public/synapse-bridge.js': 420, 'palitra-review-public/palitra-chat-widget.css': 420}
KNOWN_STATIC_MODES = {'product/shell.js': 384, 'product/shell.css': 420, 'product/synapse-bridge.js': 384, 'storefront/storefront.js': 384}
NAMES = {'backend/customer-chat-http.cjs', 'backend/customer-chat.js', 'backend/palitra-host-adapter.cjs', 'legacy/palitra-chat-widget.css', 'legacy/palitra-chat.css', 'legacy/palitra-chat.html', 'legacy/palitra-chat.js', 'product/shell.css', 'product/shell.js', 'product/synapse-bridge.js', 'storefront/storefront.js'}
ABSENCE_JS = "const fs=require('fs'),p=JSON.parse(process.argv[1]),r={};if(!Array.isArray(p)||p.length!==1)throw Error('ONE_FIXED_ADDED_SOURCE');for(const n of p){try{fs.lstatSync('/app/'+n);throw Error('ADDED_SOURCE_PRESENT')}catch(e){if(e.code!=='ENOENT')throw e;r[n]=true}}process.stdout.write(JSON.stringify(r));"
SOURCE_FACTS_JS = "const fs=require('fs'),p=JSON.parse(process.argv[1]);console.log(JSON.stringify(Object.fromEntries(p.map(n=>{const s=fs.lstatSync('/app/'+n);if(!s.isFile())throw Error('REGULAR_SOURCE_REQUIRED');return[n,{uid:s.uid,gid:s.gid,mode:s.mode&511}]}))));"
CHILD_CHECK_JS = "const fs=require('fs'),cp=require('child_process'),m=JSON.parse(process.argv[1]);for(const[n,e]of Object.entries(m)){const p='/app/'+n,s=fs.lstatSync(p);if(!s.isFile()||s.uid!==e.uid||s.gid!==e.gid||(s.mode&511)!==e.mode)process.exit(73);if(/[.](?:js|cjs)$/.test(n)){const r=cp.spawnSync(process.execPath,['--check',p],{stdio:'inherit'});if(r.status!==0)process.exit(74)}}process.stdout.write('PRECHECK_OK');"
USER_FORMAT = '{{json (or (index .Config "User") "")}}'
ROOT_USERS = {'', 'root', '0', '0:0', 'root:root'}
# Exact accepted cabinet modes; no chmod migration or arbitrary mode selection.
ROOT_MANIFEST_SHA = 'dd82ce11f239823d005a0e05132f92b640776984f01013094d07e07e62c6d812'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def need(value, code):
    if not value:
        raise ValueError(code)


def digest(value):
    return type(value) is str and re.fullmatch('[0-9a-f]{64}', value) is not None


def hunk_bytes(hunk):
    need(type(hunk) is dict and set(hunk) == {'before', 'after'}
         and all(type(hunk[k]) is str and 0 < len(hunk[k]) <= 3 * 1024 * 1024 for k in hunk), 'BOUNDED_BASE64_HUNK_REQUIRED')
    values = [base64.b64decode(hunk[key], validate=True) for key in ('before', 'after')]
    need(all(0 < len(raw) <= 2 * 1024 * 1024 and base64.b64encode(raw).decode('ascii') == hunk[key]
             for key, raw in zip(('before', 'after'), values)) and values[0] != values[1], 'CANONICAL_CHANGED_BYTE_HUNK_REQUIRED')
    return values


class FileOps:
    """Every new descriptor receives its exact mode despite umask077."""
    def write(self, path, raw, mode):
        flags = os.O_RDWR | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_CLOEXEC', 0) | getattr(os, 'O_BINARY', 0)
        fd = os.open(path, flags, 0o600)
        try:
            first = os.fstat(fd)
            need(stat.S_ISREG(first.st_mode), 'REGULAR_CREATED_FD_REQUIRED')
            view = memoryview(raw)
            while view:
                count = os.write(fd, view)
                need(count > 0, 'WRITE_INCOMPLETE')
                view = view[count:]
            self.set_mode(fd, mode)
            os.fsync(fd)
            last = os.fstat(fd)
            need((first.st_dev, first.st_ino, first.st_uid) == (last.st_dev, last.st_ino, last.st_uid)
                 and self.fd_mode(fd) == mode, 'CREATED_FD_MODE_READBACK_FAILED')
            return (last.st_dev, last.st_ino, last.st_uid)
        finally:
            os.close(fd)

    def set_mode(self, fd, mode):
        need(os.name == 'posix' and hasattr(os, 'fchmod'), 'POSIX_FCHMOD_REQUIRED')
        os.fchmod(fd, mode)

    def fd_mode(self, fd):
        return stat.S_IMODE(os.fstat(fd).st_mode)

    def mode(self, path):
        return stat.S_IMODE(path.stat().st_mode)

    def directory(self, path, mode):
        path.mkdir(mode=0o700)
        need(os.name == 'posix', 'POSIX_DIRECTORY_FD_REQUIRED')
        fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | getattr(os, 'O_CLOEXEC', 0))
        try:
            row = os.fstat(fd)
            need(stat.S_ISDIR(row.st_mode) and not os.listdir(fd), 'NEW_EMPTY_DIRECTORY_FD_REQUIRED')
            os.fchmod(fd, mode)
            os.fsync(fd)
            last = os.fstat(fd)
            need((last.st_dev, last.st_ino, last.st_uid) == (row.st_dev, row.st_ino, row.st_uid)
                 and stat.S_IMODE(last.st_mode) == mode, 'NEW_DIRECTORY_MODE_READBACK_FAILED')
        finally:
            os.close(fd)


class ChatWidgetRelease:

    def __init__(self, a, b, current, payload, manifest_pin, lease_pid, clock=time.time, file_ops=None):
        self.a, self.b, self.current, self.photo = a, b, current, b.photo
        self.root, self.run, self.clock, self.lease_pid = b.root, b.run, clock, lease_pid
        need(type(lease_pid) is int and lease_pid > 1, 'FRESH_ROOT_LEASE_REQUIRED')
        need(file_ops is None or self.root != ROOT, 'NATIVE_DEFAULT_FILE_OPS_REQUIRED')
        self.files = file_ops or FileOps(); self.b.lease = self.lease
        self.base = copy.deepcopy(current.base)
        self.before_source, self.before_static = dict(current.source), dict(current.static)
        need(len(self.before_source) == 210 and len(self.before_static) == 27
             and all(digest(v) for v in [*self.before_source.values(), *self.before_static.values()])
             and digest(self.before_source.get('palitra-staff-advisories.cjs')), 'EXACT_SOURCE210_STATIC27_REQUIRED')
        need(self.base['containers']['content']['image'] == CONTENT and len(self.base['containers']['content']['files']) == 31
             and self.base['worker']['image'] == WORKER and self.base['selected']['content']['PALITRA_WEB_UPLOADS_ENABLED'] == 'true', 'EXACT_COMPLETED32_RUNTIME31_REQUIRED')
        need(digest(manifest_pin) and MANIFEST_SHA != UNFROZEN and manifest_pin == MANIFEST_SHA, 'MANIFEST_NOT_FROZEN')
        need(type(EXISTING_SOURCE_LAYOUT) is dict and bool(EXISTING_SOURCE_LAYOUT) and type(ADDED_SOURCE_LAYOUT) is dict and len(ADDED_SOURCE_LAYOUT) == 1
             and not set(EXISTING_SOURCE_LAYOUT) & set(ADDED_SOURCE_LAYOUT) and SOURCE_LAYOUT == {**EXISTING_SOURCE_LAYOUT, **ADDED_SOURCE_LAYOUT}
             and set(EXISTING_SOURCE_LAYOUT.values()) <= set(self.before_source) and not set(ADDED_SOURCE_LAYOUT.values()) & set(self.before_source)
             and NAMES == set(SOURCE_LAYOUT) | set(STATIC_LAYOUT) and not set(ADDED_SOURCE_LAYOUT) & set(STATIC_LAYOUT)
             and len(set(SOURCE_LAYOUT.values())) == len(SOURCE_LAYOUT), 'EXACT_ROOT_FINAL_EXISTING_AND_ONE_ADDED_SOURCE_LAYOUT_REQUIRED')
        need(type(STATIC_LAYOUT) is dict and bool(STATIC_LAYOUT) and set(SOURCE_MODES) == set(SOURCE_LAYOUT.values())
             and all(type(mode) is int and mode in (0o600, 0o644) for mode in SOURCE_MODES.values())
             and set(KNOWN_STATIC_MODES) == set(STATIC_LAYOUT) and all(type(mode) is int and mode in (0o600, 0o644) for mode in KNOWN_STATIC_MODES.values()), 'EXACT_ROOT_FINAL_SOURCE_STATIC_MODES_REQUIRED')
        for name in NAMES:
            path = PurePosixPath(name)
            need(type(name) is str and not path.is_absolute() and path.as_posix() == name and '..' not in path.parts and len(path.parts) == 2 and '\\' not in name and ':' not in name, 'FIXED_CLOSED_PAYLOAD_NAME_REQUIRED')
        for target in SOURCE_LAYOUT.values():
            path = PurePosixPath(target)
            need(type(target) is str and not path.is_absolute() and path.as_posix() == target and '..' not in path.parts and '\\' not in target and ':' not in target, 'FIXED_SOURCE_TARGET_REQUIRED')
        for spec in STATIC_LAYOUT.values():
            need(type(spec) is dict and set(spec) == {'root', 'path'} and spec['root'] in ('cabinet', 'managed') and type(spec['path']) is str, 'FIXED_STATIC_ROOT_REQUIRED')
            path = PurePosixPath(spec['path'])
            need(not path.is_absolute() and path.as_posix() == spec['path'] and '..' not in path.parts and '\\' not in spec['path'] and ':' not in spec['path'], 'FIXED_EXISTING_STATIC_TARGET_REQUIRED')
        need(sum(spec['root'] == 'managed' for spec in STATIC_LAYOUT.values()) == 1, 'EXACT_ONE_MANAGED_EXISTING_STOREFRONT_REQUIRED')
        self.managed, self.cabinet = a.exact_path(current.managed), a.exact_path(current.cabinet)
        self.root_manifest_path = a.exact_path(self.root / 'bundle-root-final/manifest.json')
        need(sha(a.read(self.root_manifest_path)) == ROOT_MANIFEST_SHA, 'EXACT_SIGNED_CUSTOMER_MANIFEST_REQUIRED')
        self.parents = {str(p): self.facts(p) for p in (self.root, self.cabinet, self.managed, self.managed / 'assets')}
        self.payload = a.exact_path(payload); need(self.payload.is_relative_to(self.root), 'ROOT_PAYLOAD_REQUIRED')
        self.manifest_pin = manifest_pin; manifest = a.pinned(self.payload / 'MANIFEST.json', manifest_pin)
        need(type(manifest) is dict and set(manifest) == {'schema', 'status', 'records', 'staticModes'} and type(manifest['schema']) is int and manifest['schema'] == 1
             and manifest['status'] == SCOPE and type(manifest['records']) is list and len(manifest['records']) == len(NAMES), 'EXACT_ROOT_FINAL_WIDGET_PAYLOADS_REQUIRED')
        self.mode_map = manifest['staticModes']
        need(type(self.mode_map) is dict and self.mode_map == KNOWN_STATIC_MODES, 'EXACT_PRESERVED_STATIC_MODE_MAP_REQUIRED')
        self.helper, self.wrapper = a.exact_path(__file__), a.exact_path(Path(__file__).parent / 'chat_widget.py')
        self.pins = {str(self.helper): sha(a.read(self.helper)), str(self.wrapper): sha(a.read(self.wrapper)), str(self.root_manifest_path): ROOT_MANIFEST_SHA, str(self.payload / 'MANIFEST.json'): manifest_pin}
        self.records, self.targets = {}, {}; self.final_source, self.final_static = dict(self.before_source), dict(self.before_static)
        for row in manifest['records']: self.accept(row)
        need(set(self.records) == NAMES and len(self.static_targets()) == len(STATIC_LAYOUT)
             and len({str(path) for _, path in self.static_targets()}) == len(STATIC_LAYOUT) and len(self.final_source) == 211
             and set(self.final_source) == set(self.before_source) | set(ADDED_SOURCE_LAYOUT.values()) and set(self.final_static) == set(self.before_static)
             and {key for key in self.before_source if self.before_source[key] != self.final_source[key]} == set(EXISTING_SOURCE_LAYOUT.values())
             and {key for key in self.before_static if self.before_static[key] != self.final_static[key]} == {str(path) for _, path in self.static_targets()}, 'EXACT_SOURCE210_TO211_STATIC27_CHANGED_MAPS_REQUIRED')
        self.parents.update({str(path.parent): self.facts(path.parent) for _, path in self.static_targets()})
        found, directories = set(), set()
        for path in self.payload.rglob('*'):
            a.exact_path(path); relative = path.relative_to(self.payload).as_posix()
            if path.is_file(): found.add(relative)
            else: need(path.is_dir(), 'REGULAR_PAYLOAD_DIRECTORY_REQUIRED'); directories.add(relative)
        wanted_dirs = {str(parent) for name in NAMES for parent in PurePosixPath(name).parents if str(parent) != '.'}
        need(found == NAMES | {'MANIFEST.json'} and directories == wanted_dirs, 'CLOSED_WIDGET_PAYLOAD_REQUIRED')
        self.active_decision_pin = None; self.static_written = set()

    def facts(self, path):
        row = self.a.exact_path(path).stat()
        need(stat.S_ISDIR(row.st_mode), 'EXACT_DIRECTORY_PARENT_REQUIRED')
        return [row.st_dev, row.st_ino, row.st_uid, row.st_gid, stat.S_IMODE(row.st_mode)]

    def parents_guard(self):
        need({name: self.facts(Path(name)) for name in self.parents} == self.parents, 'STATIC_PARENT_IDENTITY_CHANGED')


    def target_map(self, name):
        need(name in NAMES, 'EXACT_REVIEWED_WIDGET_TARGET_REQUIRED')
        result = [('source', SOURCE_LAYOUT[name])] if name in SOURCE_LAYOUT else []
        if name in STATIC_LAYOUT:
            spec = STATIC_LAYOUT[name]; root = self.cabinet if spec['root'] == 'cabinet' else self.managed
            target = root / spec['path']; need(target.is_relative_to(root), 'FIXED_STATIC_ROOT_BOUNDARY_REQUIRED')
            result.append(('static', str(target)))
        need(bool(result), 'EXACT_WIDGET_TARGET_MAPPING_REQUIRED'); return result

    def accept(self, row):
        if type(row) is dict and row.get('name') in ADDED_SOURCE_LAYOUT:
            need(set(row) == {'name', 'payload', 'sha256', 'bytes', 'added'} and row.get('added') is True and row['payload'] == row['name']
                 and row['name'] not in self.records and digest(row['sha256']) and type(row['bytes']) is int and 0 < row['bytes'] <= 2 * 1024 * 1024, 'EXACT_ADDED_SOURCE_RECORD_REQUIRED')
            target = ADDED_SOURCE_LAYOUT[row['name']]; need(target not in self.before_source, 'ADDED_SOURCE_MUST_NOT_BE_EXISTING')
            raw = self.a.read(self.payload / row['name']); need(len(raw) == row['bytes'] and sha(raw) == row['sha256'], 'ADDED_SOURCE_PAYLOAD_CHANGED')
            self.records[row['name']] = row; self.targets[row['name']] = self.target_map(row['name'])
            self.pins[str(self.payload / row['name'])] = row['sha256']; self.final_source[target] = row['sha256']; return
        need(type(row) is dict and set(row) == {'name', 'payload', 'beforeSha256', 'beforeBytes', 'sha256', 'bytes', 'hunks'}, 'EXACT_MANIFEST_RECORD_REQUIRED')
        name = row['name']
        need(type(name) is str and name in NAMES and name not in self.records and row['payload'] == name
             and all(digest(row[k]) for k in ('beforeSha256', 'sha256')) and row['beforeSha256'] != row['sha256']
             and all(type(row[k]) is int and 0 < row[k] <= 2 * 1024 * 1024 for k in ('beforeBytes', 'bytes'))
             and type(row['hunks']) is list and 1 <= len(row['hunks']) <= 256, 'EXACT_CHANGED_EXISTING_RECORD_REQUIRED')
        raw = self.a.read(self.payload / name)
        need(len(raw) == row['bytes'] and sha(raw) == row['sha256'], 'PAYLOAD_CHANGED')
        old = raw
        for hunk in reversed(row['hunks']):
            before, after = hunk_bytes(hunk)
            need(old.count(after) == 1, 'REVERSE_UNIQUE_HUNK_REQUIRED')
            old = old.replace(after, before, 1)
        need(len(old) == row['beforeBytes'] and sha(old) == row['beforeSha256'] and self.patch(old, row) == raw, 'EXACT_RECONSTRUCTED_BASE_REQUIRED')
        targets = self.target_map(name)
        for kind, target in targets:
            before = self.before_source if kind == 'source' else self.before_static
            final = self.final_source if kind == 'source' else self.final_static
            need(before.get(target) == row['beforeSha256'], 'EXACT_ACCEPTED_TARGET_BASE_REQUIRED')
            final[target] = row['sha256']
        self.records[name], self.targets[name] = row, targets
        self.pins[str(self.payload / name)] = row['sha256']

    def patch(self, raw, row):
        need(len(raw) == row['beforeBytes'] and sha(raw) == row['beforeSha256'], 'ACTUAL_RAW_BASE_CHANGED')
        for hunk in row['hunks']:
            before, after = hunk_bytes(hunk)
            need(raw.count(before) == 1, 'FORWARD_UNIQUE_HUNK_REQUIRED')
            raw = raw.replace(before, after, 1)
        need(len(raw) == row['bytes'] and sha(raw) == row['sha256'], 'FINAL_BYTES_CHANGED')
        return raw

    def static_targets(self):
        return [(name, Path(target)) for name in sorted(self.targets) for kind, target in self.targets[name] if kind == 'static']

    def paths(self):
        return {key: self.root / (NAME + '-' + key + ('.json' if key in ('decision', 'journal', 'overlay') else '')) for key in ('decision', 'journal', 'overlay', 'context', 'backup')}

    def lease(self):
        raw = self.run(['lslocks', '--noheadings', '--output', 'PID,PATH'])
        need(len(raw) <= 1048576, 'BOUNDED_LEASE_INVENTORY_REQUIRED')
        rows = [line.strip().split(maxsplit=1) for line in raw.decode().splitlines() if len(line.strip().split(maxsplit=1)) == 2 and line.strip().split(maxsplit=1)[1] == LOCK]
        need(rows == [[str(self.lease_pid), LOCK]], 'FRESH_EXCLUSIVE_ROOT_LEASE_REQUIRED')

    def stable(self):
        self.current.stable()
        for name, pin in self.pins.items(): need(sha(self.a.read(Path(name))) == pin, 'WIDGET_PINNED_INPUT_CHANGED')
        self.parents_guard()

    def absent(self, decision=False):
        for kind, path in self.paths().items():
            if kind == 'decision' and not decision: continue
            self.a.exact_path(path, True)
            need(not os.path.lexists(path) and not os.path.lexists(str(path) + '.pending'), 'ATTEMPT_EXISTS_NO_RETRY')
        for _, target in self.static_targets():
            pending = target.with_name(target.name + '.' + NAME + '.pending')
            self.a.exact_path(pending, True); need(not os.path.lexists(pending), 'OWN_STATIC_PENDING_EXISTS_NO_RETRY')


    def expected_metadata(self, service, content, proof):
        if service == 'chat': return copy.deepcopy(self.base['containers']['chat'])
        old = self.base['containers']['content']
        if content == CONTENT:
            need(proof is None, 'BASE_PROOF_MUST_BE_EMPTY'); return copy.deepcopy(old)
        need(type(proof) is dict and set(proof) == {'childImage', 'overlaySha256', 'plannedConfigHash'} and proof['childImage'] == content
             and self.a.image(content) and content != CONTENT and digest(proof['overlaySha256']) and digest(proof['plannedConfigHash']), 'OWN_SEALED_CHILD_PROOF_REQUIRED')
        overlay = self.paths()['overlay']
        need(sha(self.a.read(overlay)) == proof['overlaySha256'] and self.a.decode(self.a.read(overlay)) == {'services': {'content': {'image': content}}}, 'OWN_SEALED_OVERLAY_CHANGED')
        files = old['files'] + [str(overlay)]
        need(len(old['files']) == 31 and len(files) == len(set(files)) == 32, 'EXACT_OWN_CONTENT_CHAIN32_REQUIRED')
        return dict(old, image=content, files=files, configFiles=','.join(files), filePins={**old['filePins'], str(overlay): proof['overlaySha256']}, configHash=proof['plannedConfigHash'])

    def metadata(self, service, expected):
        if service == 'chat':
            row = self.b.metadata(service)
        else:
            row = self.a.decode(self.run(['docker', 'inspect', '--format', self.a.LABELS, 'synapse-content-1']))
            need(type(row) is dict and set(row) == {'image', 'project', 'service', 'workingDir', 'configFiles', 'configHash', 'running', 'health'}
                 and type(row['configFiles']) is str and len(row['configFiles']) <= 65536, 'EXACT_CONTENT_LABELS_REQUIRED')
            files = row['configFiles'].split(',')
            need(files == expected['files'] and len(files) == len(set(files)) and len(files) in (31, 32), 'ONLY_EXACT_RUNTIME31_OR_OWN32_REQUIRED')
            pins = {}
            for name in files:
                path = self.a.exact_path(name)
                need(path.suffix.lower() in ('.json', '.yml', '.yaml'), 'EXACT_COMPOSE_FILE_REQUIRED')
                pins[name] = sha(self.a.read(path))
            row.update(files=files, filePins=pins)
        need(row == expected, 'EXACT_METADATA_FILEPINS_CHANGED')
        return row

    def static_guard(self, changed):
        self.parents_guard(); self.current.guide_guard()
        if type(changed) is set:
            need(changed <= {str(path) for _, path in self.static_targets()}, 'EXACT_PARTIAL_STATIC_WRITES_REQUIRED')
            expected = dict(self.before_static)
            for name in changed: expected[name] = self.final_static[name]
        else:
            need(type(changed) is bool, 'EXACT_STATIC_GUARD_PHASE_REQUIRED')
            expected = self.final_static if changed else self.before_static
        for name, pin in expected.items(): need(sha(self.a.read(Path(name))) == pin, 'FULL_STATIC27_CHANGED')
        self.modes()


    def revision_guard(self):
        if self.root != ROOT:
            need(self.current.current_managed_root == str(self.managed), 'FIXTURE_CURRENT_REVISION_CHANGED'); return
        import sqlite3
        database = '/var/lib/docker/volumes/synapse_content_data/_data/content.sqlite'
        self.a.exact_path(database)
        connection = sqlite3.connect('file:' + database + '?mode=ro', uri=True, timeout=5)
        try:
            row = connection.execute('SELECT current_revision FROM site_workspaces WHERE site_id=?', ('site-44bbe13f1bad5e005b2a',)).fetchone()
        finally: connection.close()
        need(type(row) is tuple and len(row) == 1 and digest(row[0])
             and str(self.managed) == '/var/lib/docker/volumes/synapse_content_data/_data/projects/palitra-love/sites/site-44bbe13f1bad5e005b2a/versions/' + row[0],
             'FIXED_SITE_CURRENT_REVISION_CHANGED')

    def context_directories(self):
        return {'app', 'static'} | {'app/' + str(parent) for target in SOURCE_LAYOUT.values()
                                  for parent in PurePosixPath(target).parents if str(parent) != '.'}

    def snapshot(self, content=CONTENT, changed=False, proof=None, static_changed=None):
        self.stable(); self.lease(); self.revision_guard()
        first = {s: self.metadata(s, self.expected_metadata(s, content, proof)) for s in ('content', 'chat')}
        worker = self.b.worker_facts()
        selected = {s: self.b.a.selected(s) for s in ('content', 'chat')}
        flags = self.a.decode(self.run(['docker', 'exec', 'synapse-content-1', 'node', '-e', self.a.FLAGS_JS]))
        need(worker == self.base['worker'] and selected == self.base['selected'] and flags == self.base['l12'], 'WORKER_FLAGS_OR_SELECTION_CHANGED')
        for service, row in first.items():
            text = self.run(self.b._resolve_command(row, service)).decode('ascii').strip()
            need(re.fullmatch(re.escape(service) + r'\s+' + re.escape(row['configHash']), text) is not None, 'RESOLVED_CONFIG_HASH_CHANGED')
        self.b.graph(new=True); self.b.push_guard()
        if not changed: self.source_absence()
        expected = self.final_source if changed else self.before_source
        need(self.photo.hashes(expected) == expected, 'FULL_SOURCE210_CHANGED')
        self.static_guard(changed if static_changed is None else static_changed)
        cid = self.photo.cid()
        last = {s: self.metadata(s, self.expected_metadata(s, content, proof)) for s in ('content', 'chat')}
        need(first == last and worker == self.b.worker_facts() and selected == {s: self.b.a.selected(s) for s in ('content', 'chat')}
             and cid == self.photo.cid(), 'CONCURRENT_RUNTIME_CHANGE')
        self.stable(); self.lease()
        return {'containers': last, 'selected': selected, 'worker': worker, 'contentCid': cid, 'l12': flags}

    def baseline(self):
        snap = self.snapshot()
        need(snap == self.base and self.b.heartbeat(snap['worker']['startedAt'], self.clock())['freshAfterWorkerStart'], 'FRESH_COMPLETED32_RUNTIME31_REQUIRED')
        return snap

    def users(self, child=None):
        rows = {'current': self.a.decode(self.run(['docker', 'inspect', '--format', USER_FORMAT, 'synapse-content-1'])),
                'parent': self.a.decode(self.run(['docker', 'image', 'inspect', '--format', USER_FORMAT, CONTENT]))}
        if child: rows['child'] = self.a.decode(self.run(['docker', 'image', 'inspect', '--format', USER_FORMAT, child]))
        need(all(type(v) is str and v in ROOT_USERS for v in rows.values()) and (not child or rows['parent'] == rows['child']), 'ROOT_SERVICE_READ_SCOPE_REQUIRED')
        return rows

    def modes(self):
        result = {}
        for name, path in self.static_targets():
            row = self.a.exact_path(path).stat()
            expected_uid = 0 if self.root == ROOT else (os.getuid() if hasattr(os, 'getuid') else row.st_uid)
            need(stat.S_ISREG(row.st_mode) and row.st_uid == expected_uid and row.st_gid == 0, 'ROOT_OWNED_EXISTING_STATIC_REQUIRED')
            need(self.files.mode(path) == self.mode_map[name], 'EXACT_ACCEPTED_STATIC_MODE_MAP_REQUIRED')
            result[str(path)] = self.mode_map[name]
        return result


    def binding(self):
        return {'priorReceiptSha256': PRIOR_RECEIPT_SHA, 'parentImage': CONTENT, 'workerImage': WORKER, 'manifestSha256': self.manifest_pin,
                'helperSha256': self.pins[str(self.helper)], 'wrapperSha256': self.pins[str(self.wrapper)], 'freshLeasePid': self.lease_pid,
                'managedRoot': str(self.managed), 'parents': self.parents, 'sourceLayout': SOURCE_LAYOUT, 'staticLayout': STATIC_LAYOUT,
                'beforeSource': self.before_source, 'afterSource': self.final_source, 'beforeStatic': self.before_static, 'afterStatic': self.final_static}

    def decision(self, pin):
        value = self.a.pinned(self.paths()['decision'], pin, True)
        need(type(value) is dict and set(value) == {'schema', 'name', 'scope', 'rootApproved', 'observedAtUtc', 'inputs', 'before', 'staticModes', 'serviceUsers', 'sourceModes'}
             and value['schema'] == 1 and value['name'] == NAME and value['scope'] == SCOPE and value['rootApproved'] is True
             and value['inputs'] == self.binding() and value['before'] == self.base and value['serviceUsers'] == self.users()
             and value['sourceModes'] == self.source_facts(), 'EXACT_NEW_ROOT_DECISION_REQUIRED')
        self.a.fresh(value['observedAtUtc'], self.clock())
        need(type(value['staticModes']) is dict and set(value['staticModes']) == {str(p) for _, p in self.static_targets()}
             and all(type(v) is int and v == {str(path): self.mode_map[key] for key, path in self.static_targets()}[name] for name, v in value['staticModes'].items()), 'EXACT_APPROVED_STATIC_MODES_REQUIRED')
        return value

    def inspect_current(self):
        self.baseline(); self.users(); facts = self.source_facts()
        return {'status': 'CURRENT32_READONLY_NOT_APPROVED', 'sourceFiles': 210, 'staticFiles': 27, 'contentChainFiles': 31, 'mutations': 0,
                'sourceModes': {key: value for key, value in facts.items() if key in EXISTING_SOURCE_LAYOUT.values()},
                'addedSourceModeIntent': {key: value for key, value in facts.items() if key in ADDED_SOURCE_LAYOUT.values()},
                'sourceAbsent': self.source_absence(), 'staticModes': self.modes()}

    def approve(self, apply=False):
        need(apply is True, 'EXPLICIT_ROOT_APPROVAL_REQUIRED')
        self.absent(True); at = self.clock(); before = self.baseline()
        modes, users = self.modes(), self.users()
        self.a.fresh(self.a.stamp(at), self.clock())
        value = {'schema': 1, 'name': NAME, 'scope': SCOPE, 'rootApproved': True, 'observedAtUtc': self.a.stamp(at), 'inputs': self.binding(),
                 'before': before, 'staticModes': modes, 'serviceUsers': users, 'sourceModes': self.source_facts()}
        self.a.write_new(self.paths()['decision'], value)
        return {'status': 'NEW_DECISION_NOT_APPLIED', 'decisionSha256': sha(self.a.read(self.paths()['decision'])), 'runtimeWrites': 0}

    def context_proof(self, state, built=False):
        paths = self.paths(); alias = 'palitra-chat-widget-base:' + NAME
        wanted = {'Dockerfile': sha(('FROM ' + alias + '\nCOPY app/ /app/\n').encode())}
        wanted.update({'app/' + target: self.records[name]['sha256'] for name in self.records for kind, target in self.targets[name] if kind == 'source'})
        wanted.update({'static/' + str(i): row['sha256'] for i, row in enumerate(state['static'])})
        actual = {}
        for path in paths['context'].rglob('*'):
            self.a.exact_path(path)
            name = path.relative_to(paths['context']).as_posix()
            if path.is_file():
                if built and name == 'image.id': continue
                actual[name] = sha(self.a.read(path))
            else: need(path.is_dir() and name in self.context_directories(), 'CLOSED_CONTEXT_DIRECTORIES_REQUIRED')
        need(actual == wanted, 'EXACT_CLOSED_CONTEXT_REQUIRED')
        self.validate_source_modes(state.get('sourceModes'))
        for target, facts in state['sourceModes'].items():
            need(self.files.mode(paths['context'] / 'app' / target) == facts['mode'], 'CONTEXT_SOURCE_MODE_CHANGED')
        return sha(json.dumps(sorted(actual.items()), separators=(',', ':')).encode())

    def update(self, state, phase, **fields):
        state.update(phase=phase, **fields); self.a.replace(self.paths()['journal'], state)

    def unused(self, tag):
        need(not self.run(['docker', 'image', 'ls', '--quiet', '--filter', 'reference=' + tag]).strip(), 'UNIQUE_NEW_IMAGE_TAG_REQUIRED')

    def backup_directory_facts(self):
        path = self.a.exact_path(self.paths()['backup']); row = path.stat()
        expected_uid = 0 if self.root == ROOT else (os.getuid() if hasattr(os, 'getuid') else row.st_uid)
        need(stat.S_ISDIR(row.st_mode) and row.st_uid == expected_uid and self.files.mode(path) == 0o700, 'PRIVATE_BACKUP_DIRECTORY_REQUIRED')
        return {'path': str(path), 'device': row.st_dev, 'inode': row.st_ino, 'uid': row.st_uid, 'mode': 0o700}

    def backup_directory_guard(self, sealed):
        self.parents_guard()
        need(type(sealed) is dict and set(sealed) == {'path', 'device', 'inode', 'uid', 'mode'}
             and sealed['path'] == str(self.paths()['backup']) and sealed['mode'] == 0o700
             and all(type(sealed[key]) is int for key in ('device', 'inode', 'uid', 'mode'))
             and self.backup_directory_facts() == sealed, 'BACKUP_DIRECTORY_IDENTITY_CHANGED')

    def backup_row_guard(self, row, directory=None):
        directory = directory if directory is not None else getattr(self, 'backup_directory', None)
        self.backup_directory_guard(directory)
        need(type(row) is dict and set(row) == {'target', 'baseSha256', 'sha256', 'mode', 'prepared', 'backup', 'written'}, 'EXACT_BACKUP_ROW_REQUIRED')
        matches = [(i, name, path) for i, (name, path) in enumerate(self.static_targets()) if row['target'] == str(path)]
        need(len(matches) == 1, 'EXACT_BACKUP_TARGET_REQUIRED')
        index, name, target = matches[0]; record = self.records[name]
        need(row['baseSha256'] == record['beforeSha256'] and row['sha256'] == record['sha256']
             and row['prepared'] == str(self.paths()['context'] / 'static' / str(index))
             and row['backup'] == str(self.paths()['backup'] / str(index))
             and type(row['mode']) is int and row['mode'] == self.mode_map[name] and type(row['written']) is bool, 'EXACT_BACKUP_PATHS_AND_PINS_REQUIRED')
        path = self.a.exact_path(Path(row['backup']))
        flags = os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_CLOEXEC', 0) | getattr(os, 'O_BINARY', 0)
        fd = os.open(path, flags)
        try:
            first = os.fstat(fd)
            need(stat.S_ISREG(first.st_mode) and first.st_uid == directory['uid'] and self.files.fd_mode(fd) == 0o600
                 and first.st_size == record['beforeBytes'], 'PRIVATE_REGULAR_BACKUP_REQUIRED')
            raw_hash = hashlib.sha256(); total = 0
            while True:
                raw = os.read(fd, 65536)
                if not raw: break
                total += len(raw); need(total <= record['beforeBytes'], 'BACKUP_SIZE_CHANGED'); raw_hash.update(raw)
            last = os.fstat(fd); actual = self.a.exact_path(path).stat()
            identity = (first.st_dev, first.st_ino, first.st_uid)
            need(identity == (last.st_dev, last.st_ino, last.st_uid) == (actual.st_dev, actual.st_ino, actual.st_uid)
                 and stat.S_ISREG(actual.st_mode) and self.files.fd_mode(fd) == self.files.mode(path) == 0o600
                 and total == record['beforeBytes'] and raw_hash.hexdigest() == row['baseSha256'], 'BACKUP_SHA_MODE_OR_IDENTITY_CHANGED')
        finally:
            os.close(fd)
        self.backup_directory_guard(directory)

    def backup_guard(self, state):
        need(type(state.get('static')) is list and len(state['static']) == len(STATIC_LAYOUT)
             and [row.get('target') if type(row) is dict else None for row in state['static']] == [str(path) for _, path in self.static_targets()], 'EXACT_BACKUP_FIXED_FOUR_MAP_REQUIRED')
        directory = state.get('backupDirectory'); self.backup_directory_guard(directory)
        need({path.name for path in self.paths()['backup'].iterdir()} == {str(i) for i in range(len(STATIC_LAYOUT))} | {'source-' + str(i) for i in range(len(EXISTING_SOURCE_LAYOUT))}, 'CLOSED_BACKUP_DIRECTORY_REQUIRED')
        for row in state['static']: self.backup_row_guard(row, directory)
        self.source_backup_guard(state, directory)


    def publish(self, row):
        need(digest(self.active_decision_pin), 'ACTIVE_ROOT_DECISION_REQUIRED')
        self.backup_row_guard(row); self.snapshot(static_changed=set(self.static_written)); self.decision(self.active_decision_pin)
        self.parents_guard(); target = self.a.exact_path(row['target'])
        need(sha(self.a.read(target)) == row['baseSha256'] and self.files.mode(target) == row['mode'], 'STATIC_CAS_CONFLICT')
        raw = self.a.read(Path(row['prepared'])); need(sha(raw) == row['sha256'], 'PREPARED_STATIC_CHANGED')
        pending = target.with_name(target.name + '.' + NAME + '.pending')
        self.a.exact_path(pending, True)
        identity = self.files.write(pending, raw, row['mode'])
        info = self.a.exact_path(pending).stat()
        need((info.st_dev, info.st_ino, info.st_uid) == identity and self.files.mode(pending) == row['mode']
             and sha(self.a.read(pending)) == row['sha256'], 'PENDING_MODE_SHA_OR_IDENTITY_CHANGED')
        # Last complete CAS/lease/revision/TTL, after pending creation and before replacement.
        self.snapshot(static_changed=set(self.static_written)); self.decision(self.active_decision_pin); self.revision_guard(); self.lease()
        need(sha(self.a.read(target)) == row['baseSha256'] and self.files.mode(target) == row['mode'], 'LATE_STATIC_CAS_CONFLICT')
        os.replace(pending, target)
        need(sha(self.a.read(target)) == row['sha256'] and self.files.mode(target) == row['mode'], 'PUBLISHED_MODE_OR_SHA_CHANGED')
        self.static_written.add(str(target))

    def source_records(self):
        return {target: name for name, targets in self.targets.items() for kind, target in targets if kind == 'source'}

    def validate_source_modes(self, value):
        need(type(value) is dict and set(value) == set(self.source_records())
             and all(type(row) is dict and set(row) == {'uid', 'gid', 'mode'} and type(row['uid']) is int and type(row['gid']) is int and type(row['mode']) is int
                     and row['uid'] == row['gid'] == 0 and row['mode'] == SOURCE_MODES[target] for target, row in value.items()),
             'EXACT_ROOT_PRESERVED_SOURCE_MODE_MAP_REQUIRED')

    def source_facts(self, after=False):
        names = sorted(SOURCE_LAYOUT.values() if after else EXISTING_SOURCE_LAYOUT.values())
        value = self.a.decode(self.run(['docker', 'exec', 'synapse-content-1', 'node', '-e', SOURCE_FACTS_JS, json.dumps(names, separators=(',', ':'))]))
        need(type(value) is dict and set(value) == set(names), 'EXACT_SOURCE_MODE_PROJECTION_REQUIRED')
        if not after:
            value.update({target: {'uid': 0, 'gid': 0, 'mode': SOURCE_MODES[target]} for target in ADDED_SOURCE_LAYOUT.values()})
        self.validate_source_modes(value); return value



    def source_absence(self):
        targets = sorted(ADDED_SOURCE_LAYOUT.values()); need(len(targets) == 1, 'ONE_FIXED_ADDED_SOURCE_REQUIRED')
        result = self.a.decode(self.run(['docker', 'exec', 'synapse-content-1', 'node', '-e', ABSENCE_JS, json.dumps(targets, separators=(',', ':'))]))
        need(result == {target: True for target in targets}, 'EXACT_ADDED_SOURCE_MUST_BE_ABSENT'); return result

    def source_backup_guard(self, state, directory):
        rows = state.get('sourceBackups'); targets = sorted(EXISTING_SOURCE_LAYOUT.values())
        need(state.get('sourceAbsent') == {target: True for target in ADDED_SOURCE_LAYOUT.values()}, 'EXACT_SEALED_ADDED_SOURCE_ABSENCE_REQUIRED')
        need(type(rows) is list and len(rows) == len(EXISTING_SOURCE_LAYOUT), 'EXACT_EXISTING_SOURCE_BACKUPS_REQUIRED')
        self.validate_source_modes(state.get('sourceModes'))
        for index, row in enumerate(rows):
            record = self.records[self.source_records()[targets[index]]]
            expected = {'target': targets[index], 'baseSha256': record['beforeSha256'], 'bytes': record['beforeBytes'],
                        'backup': str(self.paths()['backup'] / ('source-' + str(index))), 'mode': 0o600}
            need(row == expected, 'EXACT_SOURCE_BACKUP_ROW_REQUIRED')
            path = self.a.exact_path(Path(row['backup']))
            flags = os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_CLOEXEC', 0) | getattr(os, 'O_BINARY', 0)
            fd = os.open(path, flags)
            try:
                first = os.fstat(fd); raw_hash = hashlib.sha256(); total = 0
                need(stat.S_ISREG(first.st_mode) and first.st_uid == directory['uid']
                     and self.files.fd_mode(fd) == 0o600 and first.st_size == row['bytes'], 'PRIVATE_SOURCE_BACKUP_REQUIRED')
                while True:
                    raw = os.read(fd, 65536)
                    if not raw: break
                    total += len(raw); need(total <= row['bytes'], 'SOURCE_BACKUP_SIZE_CHANGED'); raw_hash.update(raw)
                last = os.fstat(fd); actual = self.a.exact_path(path).stat()
                identity = (first.st_dev, first.st_ino, first.st_uid)
                need(identity == (last.st_dev, last.st_ino, last.st_uid) == (actual.st_dev, actual.st_ino, actual.st_uid)
                     and stat.S_ISREG(actual.st_mode) and self.files.fd_mode(fd) == self.files.mode(path) == 0o600
                     and total == row['bytes'] and raw_hash.hexdigest() == row['baseSha256'], 'SOURCE_BACKUP_SHA_MODE_IDENTITY_CHANGED')
            finally: os.close(fd)
        self.backup_directory_guard(directory)

    def build_preflight(self, child, source_modes):
        self.validate_source_modes(source_modes)
        need(self.a.image(child) and child != CONTENT, 'EXACT_CHILD_PREFLIGHT_REQUIRED')
        output = self.run(['docker', 'run', '--rm', '--network=none', '--read-only', '--cap-drop=ALL',
                           '--security-opt=no-new-privileges', '--entrypoint=node', child, '-e', CHILD_CHECK_JS,
                           json.dumps(source_modes, sort_keys=True, separators=(',', ':'))])
        need(output == b'PRECHECK_OK', 'CHILD_SYNTAX_MODE_PREFLIGHT_REQUIRED')

    def apply(self, pin, apply=False):
        need(apply is True, 'EXPLICIT_ROOT_APPLY_REQUIRED')
        self.absent(); decision = self.decision(pin); before = self.baseline(); self.active_decision_pin = pin
        need(self.modes() == decision['staticModes'], 'APPROVED_MODES_CHANGED')
        self.users(); paths = self.paths(); alias = 'palitra-chat-widget-base:' + NAME; tag = 'palitra-chat-widget:' + NAME
        self.unused(alias); self.unused(tag)
        need(self.run(['docker', 'image', 'inspect', '--format', '{{.Id}}', CONTENT]).decode().strip() == CONTENT, 'EXACT_LOCAL_PARENT_REQUIRED')
        layers = self.a.decode(self.run(['docker', 'image', 'inspect', '--format', '{{json .RootFS.Layers}}', CONTENT]))
        need(type(layers) is list and layers, 'PARENT_LAYER_PROOF_REQUIRED')
        state = {'schema': 1, 'name': NAME, 'phase': 'CONTEXT_STARTED_UNKNOWN', 'inputs': self.binding(), 'decisionSha256': pin, 'before': before,
                 'static': [], 'workerRecreated': False, 'uploadsEnabled': True, 'directDbWrites': 0, 'queueEdits': 0, 'automaticRetry': False,
                 'automaticCodeRollback': False, 'oldJournalWrites': 0, 'sourceModes': decision['sourceModes'], 'sourceBackups': [], 'sourceAbsent': self.source_absence()}
        self.a.write_new(paths['journal'], state)
        for path, mode in ((paths['context'], 0o700), (paths['backup'], 0o700)):
            self.files.directory(self.a.exact_path(path, True), mode)
        for relative in sorted(self.context_directories(), key=lambda value: (value.count('/'), value)):
            self.files.directory(self.a.exact_path(paths['context'] / relative, True), 0o700 if relative == 'static' else 0o755)
        self.backup_directory = self.backup_directory_facts(); state['backupDirectory'] = copy.deepcopy(self.backup_directory)
        source_records = self.source_records()
        for index, (target, name) in enumerate(sorted((target, name) for target, name in source_records.items() if name in EXISTING_SOURCE_LAYOUT)):
            record = self.records[name]
            raw = self.run(['docker', 'exec', 'synapse-content-1', 'node', '-e', self.current.source_script, target])
            need(len(raw) <= 3 * 1024 * 1024, 'BOUNDED_SOURCE_BYTES_REQUIRED')
            old = base64.b64decode(raw, validate=True); patched = self.patch(old, record)
            self.files.write(paths['context'] / 'app' / target, patched, decision['sourceModes'][target]['mode'])
            backup = paths['backup'] / ('source-' + str(index))
            self.files.write(backup, old, 0o600)
            state['sourceBackups'].append({'target': target, 'baseSha256': record['beforeSha256'], 'bytes': record['beforeBytes'],
                                           'backup': str(backup), 'mode': 0o600})
        for name, target in ADDED_SOURCE_LAYOUT.items():
            raw = self.a.read(self.payload / name); record = self.records[name]
            need(sha(raw) == record['sha256'] and len(raw) == record['bytes'], 'ADDED_SOURCE_PAYLOAD_CHANGED')
            self.files.write(paths['context'] / 'app' / target, raw, decision['sourceModes'][target]['mode'])
        for index, (name, target) in enumerate(self.static_targets()):
            old = self.a.read(target); patched = self.patch(old, self.records[name]); mode = decision['staticModes'][str(target)]
            prepared, backup = paths['context'] / 'static' / str(index), paths['backup'] / str(index)
            self.files.write(prepared, patched, 0o600); self.files.write(backup, old, 0o600)
            state['static'].append({'target': str(target), 'baseSha256': sha(old), 'sha256': sha(patched), 'mode': mode,
                                    'prepared': str(prepared), 'backup': str(backup), 'written': False})
        self.files.write(paths['context'] / 'Dockerfile', ('FROM ' + alias + '\nCOPY app/ /app/\n').encode(), 0o600)
        self.backup_guard(state)
        self.update(state, 'CONTEXT_READY_NOT_BUILT', contextSha256=self.context_proof(state))
        self.baseline(); self.decision(pin); self.lease(); self.unused(alias); self.unused(tag)
        self.run(['docker', 'image', 'tag', CONTENT, alias])
        need(self.run(['docker', 'image', 'inspect', '--format', '{{.Id}}', alias]).decode().strip() == CONTENT, 'NEW_PARENT_ALIAS_CHANGED')
        self.update(state, 'BUILD_STARTED_UNKNOWN'); self.decision(pin); self.lease()
        need(self.context_proof(state) == state['contextSha256']
             and self.run(['docker', 'image', 'inspect', '--format', '{{.Id}}', alias]).decode().strip() == CONTENT, 'LAST_BUILD_CONTEXT_OR_PARENT_CHANGED')
        self.run(['docker', 'build', '--network=none', '--pull=false', '--tag', tag, '--iidfile', str(paths['context'] / 'image.id'), str(paths['context'])])
        child = self.a.read(paths['context'] / 'image.id').decode().strip()
        need(self.a.image(child) and child != CONTENT and self.run(['docker', 'image', 'inspect', '--format', '{{.Id}}', tag]).decode().strip() == child, 'EXACT_NEW_CHILD_REQUIRED')
        child_layers = self.a.decode(self.run(['docker', 'image', 'inspect', '--format', '{{json .RootFS.Layers}}', child]))
        need(type(child_layers) is list and child_layers[:len(layers)] == layers and len(child_layers) == len(layers) + 1, 'ONE_EXACT_COPY_LAYER_REQUIRED')
        need(self.context_proof(state, True) == state['contextSha256'] and self.photo.hashes(self.final_source, child) == self.final_source, 'BUILT_FULL_SOURCE211_CHANGED')
        self.build_preflight(child, decision['sourceModes'])
        self.users(child); self.baseline(); self.decision(pin)
        self.backup_guard(state)
        self.update(state, 'STATIC_STARTED_UNKNOWN', childImage=child)
        for row in state['static']:
            self.decision(pin); self.lease(); self.publish(row); row['written'] = True; self.a.replace(paths['journal'], state)
        self.static_guard(True); self.stable(); self.decision(pin); self.users(child)
        self.a.write_new(paths['overlay'], {'services': {'content': {'image': child}}})
        overlay_pin = sha(self.a.read(paths['overlay'])); planned = self.b.plan(before, 'content', paths['overlay'])
        self.update(state, 'CONTENT_UP_STARTED_UNKNOWN', overlay=str(paths['overlay']), overlaySha256=overlay_pin, plannedConfigHash=planned)
        # Old source is still running while the already-published static inventory is new.
        need(self.snapshot(static_changed=True) == before, 'LAST_COMPLETE_RUNTIME31_STATIC32_CHANGED')
        self.decision(pin); self.lease(); self.stable(); self.users(child)
        need(self.context_proof(state, True) == state['contextSha256'] and self.b.plan(before, 'content', paths['overlay']) == planned, 'LAST_SEALED_PLAN_OR_CONTEXT_CHANGED')
        proof = {'childImage': child, 'overlaySha256': overlay_pin, 'plannedConfigHash': planned}
        self.expected_metadata('content', child, proof)
        self.backup_guard(state); self.revision_guard(); self.lease(); self.decision(pin)
        self.b.up(before, 'content', paths['overlay'])
        after = self.snapshot(child, True, proof)
        need(self.source_facts(True) == decision['sourceModes'], 'CHILD_RUNTIME_SOURCE_MODES_CHANGED')
        self.users(child)
        need(after['contentCid'] != before['contentCid'] and self.b.heartbeat(after['worker']['startedAt'], self.clock())['freshAfterWorkerStart']
             and self.snapshot(child, True, proof) == after, 'FRESH_STABLE_AFTER_REQUIRED')
        self.update(state, PHASE, after=after, finishedAtUtc=self.a.stamp(self.clock()))
        return {'status': PHASE, 'journalSha256': sha(self.a.read(paths['journal'])), 'contentImage': child, 'sourceFiles': 211, 'staticFiles': 27,
                'contentChainFiles': 32, 'sourceFilesChanged': len(SOURCE_LAYOUT), 'staticFilesChanged': len(STATIC_LAYOUT), 'builds': 1, 'contentUps': 1, 'workerRecreated': False, 'uploadsEnabled': True,
                'directDbWrites': 0, 'queueEdits': 0, 'oldJournalWrites': 0, 'automaticRetry': False}

    def inspect(self, pin):
        state = self.a.pinned(self.paths()['journal'], pin, True)
        need(state.get('schema') == 1 and state.get('name') == NAME and state.get('phase') == PHASE and state.get('inputs') == self.binding()
             and state.get('before') == self.base and state.get('workerRecreated') is False and state.get('uploadsEnabled') is True
             and state.get('directDbWrites') == state.get('queueEdits') == state.get('oldJournalWrites') == 0
             and state.get('automaticRetry') is False and state.get('automaticCodeRollback') is False
             and type(state.get('static')) is list and len(state['static']) == len(STATIC_LAYOUT) and all(x.get('written') is True for x in state['static']), 'OWN_COMPLETED_RECEIPT_REQUIRED')
        sealed = self.a.pinned(self.paths()['decision'], state.get('decisionSha256'), True)
        need(type(sealed) is dict and set(sealed) == {'schema', 'name', 'scope', 'rootApproved', 'observedAtUtc', 'inputs', 'before', 'staticModes', 'serviceUsers', 'sourceModes'}
             and sealed['schema'] == 1 and sealed['name'] == NAME and sealed['scope'] == SCOPE and sealed['rootApproved'] is True
             and sealed['inputs'] == self.binding() and sealed['before'] == self.base and sealed['sourceModes'] == state.get('sourceModes')
             and sealed['staticModes'] == {str(path): self.mode_map[name] for name, path in self.static_targets()}
             and sealed['serviceUsers'] == self.users(), 'OWN_SEALED_DECISION_CHANGED')
        self.backup_guard(state)
        proof = {key: state[key] for key in ('childImage', 'overlaySha256', 'plannedConfigHash')}
        need(state.get('overlay') == str(self.paths()['overlay']) and self.context_proof(state, True) == state['contextSha256'], 'COMPLETED_CONTEXT_OR_OVERLAY_CHANGED')
        for row in state['static']:
            need(self.files.mode(Path(row['target'])) == row['mode'], 'COMPLETED_TARGET_MODE_CHANGED')
        need(self.snapshot(state['childImage'], True, proof) == state['after']
             and self.source_facts(True) == state['sourceModes'], 'COMPLETED_RUNTIME_CHANGED')
        return {'status': 'COMPLETED33_READONLY_NOT_CUSTOMER_ACCEPTANCE', 'mutations': 0, 'heartbeat': self.b.heartbeat(self.base['worker']['startedAt'], self.clock())}







def load_current32(lease_pid):
    """Exact frozen32 constructors and immutable proofs only, no historical actions or snapshots."""
    need(type(lease_pid) is int and lease_pid > 1, 'FRESH_ROOT_LEASE_REQUIRED')
    path = PRIOR_CODE / 'chat_composer_bottom_release_native.py'; wrapper = PRIOR_CODE / 'chat_composer_bottom.py'
    for item in [*reversed(path.parents), path, wrapper]: need(not item.is_symlink(), 'HISTORICAL_CODE_SYMLINK_REFUSED')
    raw = path.read_bytes(); need(sha(raw) == PRIOR_HELPER_SHA and sha(wrapper.read_bytes()) == PRIOR_WRAPPER_SHA, 'EXACT_COMPLETED32_CODE_REQUIRED')
    prior = types.ModuleType('sealed_completed32'); prior.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), prior.__dict__)
    a, b, current31 = prior.load_current31(lease_pid)
    journal = ROOT / 'palitra-chat-composer-bottom-r2-journal.json'; receipt = a.pinned(journal, PRIOR_RECEIPT_SHA, True)
    historical_pid = receipt.get('inputs', {}).get('freshLeasePid')
    need(type(historical_pid) is int and historical_pid > 1, 'COMPLETED32_LEASE_BINDING_REQUIRED')
    accepted = prior.ChatComposerBottomRelease(a, b, current31, PRIOR_CODE / 'payload', prior.MANIFEST_SHA, historical_pid)
    need(receipt.get('schema') == 1 and receipt.get('name') == prior.NAME and receipt.get('phase') == prior.PHASE
         and receipt.get('inputs') == accepted.binding() and receipt.get('before') == accepted.base and receipt.get('childImage') == CONTENT
         and receipt.get('decisionSha256') == PRIOR_DECISION_SHA and receipt.get('workerRecreated') is False and receipt.get('uploadsEnabled') is True
         and receipt.get('directDbWrites') == receipt.get('queueEdits') == receipt.get('oldJournalWrites') == 0
         and receipt.get('automaticRetry') is False and receipt.get('automaticCodeRollback') is False
         and type(receipt.get('static')) is list and len(receipt['static']) == 2
         and all(type(row) is dict and row.get('written') is True for row in receipt['static']), 'EXACT_COMPLETED32_RECEIPT_REQUIRED')
    proof = {key: receipt[key] for key in ('childImage', 'overlaySha256', 'plannedConfigHash')}
    need(receipt.get('overlay') == str(accepted.paths()['overlay'])
         and receipt['after']['containers']['content'] == accepted.expected_metadata('content', CONTENT, proof)
         and len(receipt['after']['containers']['content']['files']) == 31
         and receipt['after']['containers']['chat'] == accepted.base['containers']['chat']
         and all(receipt['after'][key] == accepted.base[key] for key in ('worker', 'selected', 'l12'))
         and receipt['after']['contentCid'] != accepted.base['contentCid']
         and len(accepted.final_source) == 210 and len(accepted.final_static) == 27
         and digest(accepted.final_source.get('palitra-staff-advisories.cjs')), 'EXACT_COMPLETED32_RUNTIME_MAPS_REQUIRED')
    accepted.validate_source_modes(receipt.get('sourceModes'))
    sealed = a.pinned(accepted.paths()['decision'], PRIOR_DECISION_SHA, True)
    need(type(sealed) is dict and set(sealed) == {'schema', 'name', 'scope', 'rootApproved', 'observedAtUtc', 'inputs', 'before', 'staticModes', 'serviceUsers', 'sourceModes'}
         and sealed['schema'] == 1 and sealed['name'] == prior.NAME and sealed['scope'] == prior.SCOPE and sealed['rootApproved'] is True
         and sealed['inputs'] == accepted.binding() and sealed['before'] == accepted.base and sealed['sourceModes'] == receipt.get('sourceModes')
         and sealed['staticModes'] == {str(path): accepted.mode_map[path.name] for _, path in accepted.static_targets()}, 'EXACT_COMPLETED32_SEALED_DECISION_REQUIRED')

    def stable():
        accepted.stable()
        need(sha(a.read(journal)) == PRIOR_RECEIPT_SHA, 'COMPLETED32_RECEIPT_CHANGED')
        need(accepted.context_proof(receipt, True) == receipt['contextSha256'], 'COMPLETED32_CONTEXT_CHANGED')
        need(a.pinned(accepted.paths()['decision'], PRIOR_DECISION_SHA, True) == sealed, 'COMPLETED32_SEALED_DECISION_CHANGED')
        accepted.backup_guard(receipt)

    def guide_guard():
        current31.guide_guard(); accepted.modes()
        need(accepted.source_facts(True) == receipt['sourceModes'], 'COMPLETED32_SOURCE_MODE_CHANGED')

    stable()
    current = types.SimpleNamespace(base=copy.deepcopy(receipt['after']), source=dict(accepted.final_source), static=dict(accepted.final_static),
                                    cabinet=accepted.cabinet, managed=current31.managed, stable=stable, guide_guard=guide_guard, source_script=current31.source_script)
    return a, b, current


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=('inspect-current', 'approve-current', 'apply', 'inspect'))
    parser.add_argument('--lease-pid', required=True, type=int)
    parser.add_argument('--decision-sha'); parser.add_argument('--receipt-sha'); parser.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    try:
        need(FINAL is True and MANIFEST_SHA != UNFROZEN and CONTENT_CONFIRMED is True, 'INACTIVE_WIDGET33_NO_FINAL_LAYOUT_OR_PINS')
        need(os.name == 'posix' and os.geteuid() == 0 and Path(__file__).resolve().parent == ROOT / CODE_NAME, 'EXACT_ROOT_NEW_NAMESPACE_REQUIRED')
        a, b, current = load_current32(args.lease_pid)
        release = ChatWidgetRelease(a, b, current, ROOT / CODE_NAME / 'payload', MANIFEST_SHA, args.lease_pid)
        if args.operation == 'inspect-current': result = release.inspect_current()
        elif args.operation == 'approve-current': result = release.approve(args.apply)
        elif args.operation == 'apply':
            need(digest(args.decision_sha), 'EXPLICIT_NEW_DECISION_SHA_REQUIRED'); result = release.apply(args.decision_sha, args.apply)
        else:
            need(digest(args.receipt_sha), 'EXPLICIT_OWN_RECEIPT_SHA_REQUIRED'); result = release.inspect(args.receipt_sha)
        print(json.dumps(result, separators=(',', ':'))); return 0
    except Exception as error:
        code = str(error) if type(error) is ValueError and re.fullmatch('[A-Z][A-Z0-9_]{0,100}', str(error)) else 'WIDGET_RELEASE_REFUSED'
        print(json.dumps({'status': 'REFUSED_OR_UNKNOWN_NO_AUTOMATIC_RETRY', 'code': code, 'messageSha256': sha(str(error).encode()),
                          'automaticRetry': False, 'automaticCodeRollback': False, 'workerRecreated': False, 'oldJournalWrites': 0})); return 2


if __name__ == '__main__': sys.exit(main())
