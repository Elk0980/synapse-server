import hashlib,json,os,sys,types
from pathlib import Path
CODE=Path('/opt/synapse/releases/palitra-app-20261015/palitra-notify-update-20261020-r2-code')
HELPER_SHA='0e2a1f5487cb62578846d55f8d91bd2a9869afb8dca8f927bea0df5e7b9e9016'

def main():
 try:
  if HELPER_SHA is None:raise ValueError('DRAFT_NOT_FROZEN')
  if os.name!='posix' or os.geteuid()!=0 or Path(__file__).resolve().parent!=CODE:raise ValueError('EXACT_ROOT_NEW_NAMESPACE_REQUIRED')
  p=CODE/'release-native.py'
  if any(x.is_symlink() for x in [*p.parents,p]):raise ValueError('CODE_SYMLINK_REFUSED')
  raw=p.read_bytes()
  if hashlib.sha256(raw).hexdigest()!=HELPER_SHA:raise ValueError('FROZEN_HELPER_CHANGED')
  m=types.ModuleType('frozen_r11_release');m.__file__=str(p);exec(compile(raw,str(p),'exec'),m.__dict__);return m.main()
 except Exception as e:
  print(json.dumps({'status':'ENTRY_REFUSED_NO_RETRY','messageSha256':hashlib.sha256(str(e).encode()).hexdigest()}));return 2
if __name__=='__main__':sys.exit(main())
