"""Combined narrow notification/update-notice R2 successor of installed R7C. Separate native approval required.

Historical helpers/journals are read-only. Live report DB is never restored.
"""
import argparse
import base64
import copy
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import time
import types

FROZEN = True
TRAFFIC_HELPER_SHA = '2b44578d7b7fee9d779fe647c6d3b56eb5aa9d377f89b68f5aaed7230ca1127f'
QUEUE_MODULE_SHA = 'f46720163a8ec1f6ab75a45a86bc7dd951923e5755293acf537f87073e1df7d7'
GROUP_REVIEW_SHA = '222ba812eb92208765368f24966e85ca8217081ae8ef8ca9dd606e325b2c6b22'
EXPECTED_RECORDS = [{'beforeSha256': 'f9e51cb873d5cd8a098962bb49eef9d6903dcda0ac4dca37acb5f44116c1d941', 'beforeSourceSha256': 'f9e51cb873d5cd8a098962bb49eef9d6903dcda0ac4dca37acb5f44116c1d941', 'bytes': 270629, 'name': 'product/shell.js', 'sha256': 'c2e7301808f82a41bf4a5d94964ebc4ce07a97242455f14284e278a39c553be1', 'static': 'shell.js', 'target': 'palitra-orders-public/shell.js'}, {'beforeSha256': '90ab73b9297c0c0e25ca793e8475dbc52cd068566313ffb5137dff3be4789212', 'beforeSourceSha256': '90ab73b9297c0c0e25ca793e8475dbc52cd068566313ffb5137dff3be4789212', 'bytes': 59669, 'name': 'product/shell.css', 'sha256': '35e5ecaaca56b9f01db6b8dddcc6bef088c795acd4d0f46d83effbc1a0837fc7', 'static': 'shell.css', 'target': 'palitra-orders-public/shell.css'}, {'beforeSha256': 'b3fbf23c1e0dbd5c19cf62a258380f3a60b1eb7818be5bd1d328322f03c5e4b0', 'beforeSourceSha256': 'b3fbf23c1e0dbd5c19cf62a258380f3a60b1eb7818be5bd1d328322f03c5e4b0', 'bytes': 2529, 'name': 'product/cabinet.html', 'sha256': '65934139f9dfaf9ff6b3dc10dd92d7e7c9b779f74a99b987705297b17fd11d9c', 'static': 'cabinet.html', 'target': 'palitra-orders-public/cabinet.html'}, {'beforeSha256': 'bda9c24e09409b773fcd6d3ab517ca92bc0257c3a3781ffa8f92d7a2e640236c', 'beforeSourceSha256': 'bda9c24e09409b773fcd6d3ab517ca92bc0257c3a3781ffa8f92d7a2e640236c', 'bytes': 125763, 'name': 'backend/server.js', 'sha256': '1d07040b2c01f2e3ade56a59bb681f6858e29f950d642c69a2d552c30c18a876', 'static': None, 'target': 'server.js'}]
ROOT = Path('/opt/synapse/releases/palitra-app-20261015')
NAME = 'palitra-notify-update-20261020-r2'
CODE = ROOT / (NAME + '-code')
LOCK = '/opt/synapse/.palitra-app-release.lock'
PARENT = 'sha256:0c0b1efed97adc25871abcafcc58788f5b6aecbe4e10ebd260312b652c69ce3e'
MANIFEST_SHA = 'd321b06a1c30296179e6097739200a56a8d3208f4dfc34d40eaa1a387621b707'
ROLLBACK_SHA = '3c225c8945d79af8cd78922a3d9c2db18ff74c7c8910e233f16eda2e87020879'
DB_HELPER_SHA = '08456dc9fcfae875b22c631a461e0cedea5a702b5f8d43ae770de7cff6e78a63'
PRODUCT_REVIEW_SHA = '2bda32551047b6d952e20042004d6e1d6e69b9aca778cf61e4412066c33c6840'
PRODUCT_MANIFEST_SHA = 'c84380de6b63755451c9f1409c910579bca1adbd8a72383d8a0b4b5c6fd1b838'
MANAGED_HELPER_SHA = 'b01bf2eb4d3b943a79855bccec858ea11b8f6aa57b400cf6f252c3b35c4c079e'
MANAGED_PROBE_SHA = '6adf008d2a6016031b6ad6812c3550a557694293a9a855a92cfb64e6c964ca6f'
MANAGED_PROOF_SHA = '40ef3d261c68fcdca488a31da328e245f70066066bbc92cfebba28a4f19c453d'  # Root-created root0600 O_EXCL external proof; fill only after its native read.
MANAGED_PROOF_PATH = ROOT / 'multi-company-app-20261019-r7c-managed-proof.json'
MAP_OUTCOME_SHA = '7c206110ddb478f1be1221e689ea346e125b9e438096b59af39a7eb84ebc2c42'
REPORT_DB_HOST = Path('/var/lib/docker/volumes/synapse_content_data/_data/salon-reports.sqlite')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
digest = lambda value: isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value) is not None


def need(value, code):
    if not value:
        raise ValueError(code)


def private_report_db(value):
    return (type(value) is dict and set(value) == {'path', 'files'} and value['path'] == '/data/salon-reports.sqlite'
            and type(value['files']) is dict and set(value['files']) == {'db', 'wal', 'shm'} and value['files']['db'] is not None
            and all(row is None or type(row) is dict and row == {'uid': 0, 'mode': 0o600} for row in value['files'].values()))



CONTENT_HELPER_SHA = 'd6363b217d69a49751d875b00cf50776593d01160b386190edaac8bf537ab4be'
CONTENT_DB_HOST = REPORT_DB_HOST.with_name('content.sqlite')
TRAFFIC_DB_HOST = REPORT_DB_HOST.with_name('app-entry-stats.sqlite')
R7C_HELPER='3ed553c0abc38e301792b15558c9eb7cf1656fb53bb58fafcc162a363e5b3020'
R7C_RECEIPT='58a537f7adf44f36fe47c594a9856271cfb58ac6e8bc784ba6317b572b7e259d'
R7C_DECISION='2611b46313d9d56997f22220f910f46e33eb0c874231955eb0eb7d2cea3798f5'
R7C_WRITER=3093287
SUPPLEMENT_NAME='project-chat.js'

def _load_module(raw,path):
    module=types.ModuleType('exact_completed_r7c');module.__file__=str(path)
    exec(compile(raw,str(path),'exec'),module.__dict__);return module

def load_current_r7c(pid):
    need(type(pid) is int and pid>1 and pid not in (3093287,3124706,3093006,3092646,3091609,3091431), 'FRESH_R11_ACTUAL_INSPECTION_PID_REQUIRED')
    helper=ROOT/'multi-company-app-20261019-r7c-code/release-native.py'
    for path in [*reversed(helper.parents),helper]:need(not path.is_symlink(),'HISTORICAL_R7C_SYMLINK_REFUSED')
    raw=helper.read_bytes();need(sha(raw)==R7C_HELPER,'EXACT_UNMODIFIED_R7C_HELPER_REQUIRED')
    original=_load_module(raw,helper)
    a,b,prior,before_r7c=original.load_current_r6(pid)
    # Inspection mode retains original R7C writer binding while self.pid is this fresh inspector.
    accepted=original.Release(a,b,prior,before_r7c,pid,inspection_pin=R7C_RECEIPT)
    need(accepted.pid==pid and accepted.writer_pid==R7C_WRITER,'R7C_ACTUAL_INSPECTOR_AND_HISTORICAL_WRITER_REQUIRED')
    receipt=a.pinned(accepted.paths['journal'],R7C_RECEIPT,True)
    need(receipt.get('name')==original.NAME and receipt.get('phase')=='APPLIED_NOT_CUSTOMER_ACCEPTANCE'
         and receipt.get('inputs')==accepted.binding() and receipt.get('before')==accepted.base
         and receipt.get('childImage')==PARENT and receipt.get('decisionSha256')==R7C_DECISION
         and receipt.get('workerRecreated') is False and receipt.get('automaticRetry') is False
         and receipt.get('automaticCodeRollback') is False
         and receipt.get('contentSchemaObjectsCreated')==6
         and receipt.get('contentLegacyRowWrites')==receipt.get('activationRowsCreated')==0
         and receipt.get('mainDbRowDirectWrites')==receipt.get('queueEdits')==receipt.get('oldJournalWrites')==0,
         'EXACT_COMPLETED_R7C_RECEIPT_REQUIRED')
    decision=accepted.decision(R7C_DECISION,fresh=False)
    need(decision['sourceModes']==receipt['sourceModes'],'SEALED_R7C_SOURCE_MODES_REQUIRED')
    expected=copy.deepcopy(accepted.base['containers']['content']);overlay=str(accepted.paths['overlay']);chain=expected['files']+[overlay]
    need(len(chain)==len(set(chain))==39 and sha(a.read(accepted.paths['overlay']))==receipt['overlaySha256'],'SEALED_R7C_CHAIN39_REQUIRED')
    expected.update(image=PARENT,files=chain,configFiles=','.join(chain),filePins={**expected['filePins'],overlay:receipt['overlaySha256']},configHash=receipt['plannedConfigHash'])
    need(receipt['after']['containers']['content']==expected and receipt['after']['containers']['chat']==accepted.base['containers']['chat']
         and all(receipt['after'][k]==accepted.base[k] for k in ('selected','worker','l12'))
         and len(accepted.source)==235 and len(accepted.static)==41,'SEALED_R7C_FULL235_41_39_REQUIRED')
    need(receipt['inputs'].get('managedProofSha256')==MANAGED_PROOF_SHA and receipt['inputs'].get('managedProbeSha256')==MANAGED_PROBE_SHA
         and receipt['inputs'].get('mapOutcomeSha256')==MAP_OUTCOME_SHA
         and receipt['inputs'].get('managedSourceProof')==accepted.managed_guard.proof,'EXACT_R7C_MANAGED259_BINDING_REQUIRED')
    migration=receipt['contentMigration'];need(type(migration) is dict and migration.get('schemaObjects')==6
         and migration.get('legacyRowWrites')==migration.get('activationRows')==0
         and digest(migration.get('afterSchemaSha256')),'EXACT_INSTALLED_POST_SCHEMA_REQUIRED')
    def stable():
        # Only frozen history, backups and context. Never original snapshot/baseline/inspect/stable.
        accepted.current.stable()
        need(sha(a.read(helper))==R7C_HELPER and a.pinned(accepted.paths['journal'],R7C_RECEIPT,True)==receipt
             and a.pinned(accepted.paths['decision'],R7C_DECISION,True)==decision,'SEALED_R7C_HISTORY_CHANGED')
        for path,pin in accepted.pins.items():need(sha(a.read(Path(path)))==pin,'SEALED_R7C_CODE_OR_PROOF_CHANGED')
        for row in accepted.records.values():need(sha(a.read(original.CODE/'payload'/row['name']))==row['sha256'],'SEALED_R7C_PAYLOAD_CHANGED')
        accepted.acceptance(decision['rootAcceptanceSha256']);accepted.backups(receipt)
        need(accepted.context_proof(receipt,True)==receipt['contextSha256'],'SEALED_R7C_CONTEXT_CHANGED')
    stable()
    return a,b,prior,types.SimpleNamespace(base=copy.deepcopy(receipt['after']),source=dict(accepted.source),static=dict(accepted.static),
        cabinet=accepted.cabinet,managed=accepted.current.managed,stable=stable,source_script=accepted.current.source_script,
        managed_proof=copy.deepcopy(accepted.managed_guard.proof),content_migration=copy.deepcopy(migration),
        report_minimum=copy.deepcopy(receipt['reportDatabaseBackup']),observe_supplement=original.observe_source_supplement,
        supplement_mode=receipt['sourceModes'][SUPPLEMENT_NAME]['mode'],supplement_bytes=accepted.records['backend/project-chat.js']['bytes'])

def validate_records(manifest):
    need(type(manifest) is dict and set(manifest)=={'schema','build','records'} and manifest['schema']==1
         and manifest['build']=='synapse-company-app-20261020-update-notice-r2' and manifest['records']==EXPECTED_RECORDS
         and len(manifest['records'])==4,'EXACT_NOTIFY_UPDATE_R2_FOUR_FILE_MANIFEST_REQUIRED')
    result={}
    for row in manifest['records']:
        need(type(row) is dict and set(row)=={'name','target','sha256','bytes','beforeSha256','beforeSourceSha256','static'}
             and row['name'] not in result and digest(row['sha256']) and type(row['bytes']) is int and 0<row['bytes']<=2*1024*1024
             and digest(row['beforeSha256']) and row['beforeSourceSha256']==row['beforeSha256'],'EXACT_NOTIFY_UPDATE_RECORD_REQUIRED')
        if row['name']=='backend/server.js':need(row['target']=='server.js' and row['static'] is None,'EXACT_SERVER_TARGET_REQUIRED')
        else:
            name=row['name'][8:]
            need(row['name'] in ('product/shell.js','product/shell.css','product/cabinet.html') and row['static']==name
                 and row['target']=='palitra-orders-public/'+name,'EXACT_THREE_FRONTEND_TARGETS_REQUIRED')
        result[row['name']]=row
    need(sum(r['static'] is not None for r in result.values())==3,'EXACT_THREE_STATIC_REQUIRED')
    return result


def create_managed_guard(release):
    a=release.a
    raw=a.read(CODE/'managed-source.py');probe=a.read(CODE/'managed-source-probe.cjs')
    need(sha(raw)==MANAGED_HELPER_SHA and sha(probe)==MANAGED_PROBE_SHA,'EXACT_MANAGED_GUARD_CODE_REQUIRED')
    need(digest(MANAGED_PROOF_SHA),'MANAGED_SOURCE_PROOF_NOT_FROZEN')
    proof=a.pinned(MANAGED_PROOF_PATH,MANAGED_PROOF_SHA,True)
    outcome=a.pinned(CODE/'MAP_OUTCOME.json',MAP_OUTCOME_SHA)
    m=types.ModuleType('r7c_managed_source');m.__file__=str(CODE/'managed-source.py');exec(compile(raw,m.__file__,'exec'),m.__dict__)
    definition={'schema':1,'status':'FROZEN','probeSha256':MANAGED_PROBE_SHA,'mapOutcomeSha256':MAP_OUTCOME_SHA,'proof':proof}
    return m.ManagedSource(definition,outcome,release.current.managed,probe,release.run,a.decode,release.lease)

class Release:
    def __init__(self,a,b,prior,current,pid,inspection_pin=None):
        self.a,self.b,self.prior,self.current,self.pid=a,b,prior,current,pid
        self.run,self.files=b.run,prior.FileOps();self.base=copy.deepcopy(current.base)
        self.paths={n:ROOT/(NAME+'-'+n+('.json' if n in ('decision','journal','overlay') else '')) for n in ('decision','journal','overlay','context','backup')}
        self.inspection_pin,self.inspection_state,self.writer_pid=inspection_pin,None,pid
        if inspection_pin is not None:
            need(digest(inspection_pin),'EXPLICIT_OWN_INSPECTION_RECEIPT_REQUIRED')
            self.inspection_state=a.pinned(self.paths['journal'],inspection_pin,True)
            need(self.inspection_state.get('name')==NAME and self.inspection_state.get('phase')=='APPLIED_NOT_CUSTOMER_ACCEPTANCE','EXACT_OWN_COMPLETED_INSPECTION_PROOF_REQUIRED')
            self.writer_pid=self.inspection_state['inputs']['freshLeasePid']
            need(type(self.writer_pid) is int and self.writer_pid>1,'EXACT_HISTORICAL_WRITER_PID_REQUIRED')
        need(len(current.source)==235 and len(current.static)==41 and len(current.base['containers']['content']['files'])==39,'EXACT_R7C_FULL235_41_39_REQUIRED')
        self.cabinet=a.exact_path(current.cabinet)
        self.manifest=a.pinned(CODE/'payload/MANIFEST.json',MANIFEST_SHA);self.records=validate_records(self.manifest);self.source_records=dict(self.records)
        self.source,self.static=dict(current.source),dict(current.static);self.static_records,self.existing_sources,self.added_sources={},{},[]
        for row in self.records.values():
            raw=a.read(CODE/'payload'/row['name']);need(len(raw)==row['bytes'] and sha(raw)==row['sha256'],'PRODUCT_PAYLOAD_CHANGED')
            if row['beforeSourceSha256'] is None:
                need(row['target'] not in current.source,'NEW_SOURCE_COLLISION');self.added_sources.append(row['target'])
            else:
                need(current.source.get(row['target'])==row['beforeSourceSha256'],'SOURCE_BASE_R7C_MISMATCH');self.existing_sources[row['target']]=row
            self.source[row['target']]=row['sha256']
            if row['static'] is not None:
                target=str(self.cabinet/row['static']);need(current.static.get(target)==row['beforeSha256'],'STATIC_BASE_R7C_MISMATCH')
                self.static_records[target]=row;self.static[target]=row['sha256']
        need(len(self.source)==235 and len(self.static)==41 and len(self.existing_sources)==4 and len(self.added_sources)==0 and len(self.static_records)==3,'EXACT_R11_CLOSED_COUNTS_REQUIRED')
        self.pins={str(Path(__file__)):sha(Path(__file__).read_bytes()),str(CODE/'payload/MANIFEST.json'):MANIFEST_SHA,str(CODE/'ROLLBACK.md'):ROLLBACK_SHA,
            str(CODE/'traffic-db.py'):TRAFFIC_HELPER_SHA,str(CODE/'report-db.py'):DB_HELPER_SHA,str(CODE/'content-db.py'):CONTENT_HELPER_SHA,
            str(CODE/'GROUP_REVIEW.json'):GROUP_REVIEW_SHA,str(CODE/'PRODUCT_REVIEW.json'):PRODUCT_REVIEW_SHA,str(CODE/'PRODUCT_MANIFEST.json'):PRODUCT_MANIFEST_SHA,
            str(CODE/'managed-source.py'):MANAGED_HELPER_SHA,str(CODE/'managed-source-probe.cjs'):MANAGED_PROBE_SHA,str(CODE/'MAP_OUTCOME.json'):MAP_OUTCOME_SHA,str(MANAGED_PROOF_PATH):MANAGED_PROOF_SHA}
        modules={}
        for name,pin in [('report-db.py',DB_HELPER_SHA),('content-db.py',CONTENT_HELPER_SHA),('traffic-db.py',TRAFFIC_HELPER_SHA)]:
            raw=a.read(CODE/name);need(sha(raw)==pin,'FROZEN_DATABASE_GUARD_REQUIRED');m=types.ModuleType('r11_'+name);m.__file__=str(CODE/name);exec(compile(raw,m.__file__,'exec'),m.__dict__);modules[name]=m
        self.db=modules['report-db.py'].ReportDatabase(REPORT_DB_HOST,a.exact_path,self.files,self.data_mount)
        # No configure()/migrate(): only read, online backup and post-R7C schema guards.
        self.contentdb=modules['content-db.py'].ContentDatabase(CONTENT_DB_HOST,a.exact_path,self.files,self.content_data_mount)
        self.traffic=modules['traffic-db.py'].TrafficDatabase(TRAFFIC_DB_HOST,a.exact_path,self.files,self.content_data_mount,ROOT)
        product=a.pinned(CODE/'PRODUCT_REVIEW.json',PRODUCT_REVIEW_SHA);original=a.pinned(CODE/'PRODUCT_MANIFEST.json',PRODUCT_MANIFEST_SHA)
        need(product.get('status')=='ACCEPTED_CURRENT36_COMPATIBILITY_CODE_ONLY_NOT_INSTALLER' and product.get('build')=='synapse-company-app-20261020-update-notice-r2'
             and product.get('manifestSha256')==PRODUCT_MANIFEST_SHA and product.get('deltaFromInstalledR7C')==original.get('deltaFromInstalledR7C')==self.manifest['records']
             and product.get('installerAccepted') is False and product.get('runtimeApplyAuthorized') is False,'EXACT_COMBINED_R2_CODE_ONLY_REVIEW_REQUIRED')
        group=a.pinned(CODE/'GROUP_REVIEW.json',GROUP_REVIEW_SHA)
        server=self.records['backend/server.js']
        need(group.get('status')=='ACCEPTED_CURRENT36_COMPATIBILITY_CODE_ONLY_NOT_INSTALLER' and group.get('task')=='PALITRA_GROUP_ORDER_NOTIFY_OFF_20261020'
             and group.get('baseRelease')=='multi-company-app-20261019-r7c' and group.get('baseImage')==PARENT
             and group.get('files')==[{k:server[k] for k in ('name','target','beforeSha256','sha256','bytes')}]
             and group.get('installed') is False and group.get('installerAccepted') is False and group.get('runtimeApplyAuthorized') is False,'EXACT_ACTUAL_QUEUE_GROUP_REVIEW_R2_REQUIRED')
        need(group.get('queueModuleSha256')==QUEUE_MODULE_SHA and current.source.get('site-orders.js')==QUEUE_MODULE_SHA,'EXACT_R7C_SITE_ORDER_QUEUE_MODULE_REQUIRED')
        self.managed_guard=create_managed_guard(self)
        need(self.managed_guard.proof==current.managed_proof,'EXACT_R7C_MANAGED_PROOF_REQUIRED');b.lease=self.lease

    def lease(self):
        raw = self.run(['lslocks', '--noheadings', '--output', 'PID,PATH'])
        need(len(raw) <= 1048576, 'BOUNDED_LEASE_REQUIRED')
        rows = [r.strip().split(maxsplit=1) for r in raw.decode().splitlines() if len(r.strip().split(maxsplit=1)) == 2 and r.strip().split(maxsplit=1)[1] == LOCK]
        need(rows == [[str(self.pid), LOCK]], 'EXACT_OWN_SINGLE_WRITER_REQUIRED')

    def stable(self):
        self.current.stable()
        need(self.a.pinned(MANAGED_PROOF_PATH,MANAGED_PROOF_SHA,True)==self.managed_guard.proof,'SEALED_PRIVATE_MANAGED_PROOF_CHANGED')
        self.managed_guard.guard()
        for path,pin in self.pins.items():need(sha(self.a.read(Path(path)))==pin,'FROZEN_RECEIVER_CODE_CHANGED')
        for row in self.records.values():need(sha(self.a.read(CODE/'payload'/row['name']))==row['sha256'],'FROZEN_PRODUCT_CHANGED')
    def source_absence(self):
        if not self.added_sources:return
        script="const f=require('fs');for(const n of JSON.parse(process.argv[1])){try{f.lstatSync('/app/'+n);throw Error('NEW_SOURCE_ALREADY_EXISTS')}catch(e){if(e.code!=='ENOENT')throw e}}process.stdout.write('R11_NEW_SOURCES_ABSENT');"
        need(self.run(['docker','exec','synapse-content-1','node','-e',script,json.dumps(sorted(self.added_sources))])==b'R11_NEW_SOURCES_ABSENT','EXACT_R11_NEW_SOURCE_ABSENCE_REQUIRED')

    def traffic_checkpoint(self, state):
        current=self.traffic.guard(state['trafficDatabaseBackup'])
        if state['trafficDatabaseBackup']['status']=='ABSENT' and current['status']=='EXISTING':
            state['trafficDatabaseBackup']=self.traffic.backup(self.paths['backup']/'traffic.sqlite',current)
            need(state['trafficDatabaseBackup']['status']=='EXISTING','NEW_TRAFFIC_STORE_BACKUP_REQUIRED')
            self.update(state,state['phase'],trafficStoreAppearedDuringRelease=True)
        self.traffic.guard(state['trafficDatabaseBackup'])

    def supplement_guard(self,child=False):
        return self.current.observe_supplement(self.a,self.run,self.current.source_script,self.lease,
            self.current.source[SUPPLEMENT_NAME],self.current.supplement_mode,self.current.supplement_bytes)

    def metadata(self, child=None, proof=None):
        expected = copy.deepcopy(self.base['containers']['content'])
        if child:
            need(type(proof) is dict and set(proof) == {'overlaySha256', 'plannedConfigHash'}
                 and all(digest(v) for v in proof.values()) and child != PARENT and self.a.image(child), 'EXPLICIT_CHILD_PROOF_REQUIRED')
            overlay = str(self.paths['overlay']); files = expected['files'] + [overlay]
            need(len(files) == len(set(files)) == 40 and sha(self.a.read(Path(overlay))) == proof['overlaySha256'], 'EXACT_NEW_CHAIN40_REQUIRED')
            expected.update(image=child, files=files, configFiles=','.join(files), filePins={**expected['filePins'], overlay: proof['overlaySha256']}, configHash=proof['plannedConfigHash'])
        row = self.a.decode(self.run(['docker', 'inspect', '--format', self.a.LABELS, 'synapse-content-1']))
        need(type(row) is dict and row.get('configFiles') == expected['configFiles'], 'COMPOSE_CHAIN_CHANGED')
        row.update(files=list(expected['files']), filePins={name: sha(self.a.read(Path(name))) for name in expected['files']})
        need(row == expected and self.b.metadata('chat') == self.base['containers']['chat'], 'COMPLETE_RUNTIME_METADATA_CHANGED')
        return {'content': row, 'chat': copy.deepcopy(self.base['containers']['chat'])}

    def report_db(self):
        script = "const f=require('fs'),p=require('path');const n=p.join(p.dirname(process.env.DATABASE_PATH||'/data/content.sqlite'),'salon-reports.sqlite');if(n!=='/data/salon-reports.sqlite')throw Error('EXACT_DATA_PATH_REQUIRED');const out={path:n,files:{}};for(const[k,suffix]of [['db',''],['wal','-wal'],['shm','-shm']]){let s;try{s=f.lstatSync(n+suffix)}catch(e){if(e.code!=='ENOENT')throw e}if(s&&(!s.isFile()||s.isSymbolicLink()||s.nlink!==1))throw Error('REGULAR_REPORT_GROUP_REQUIRED');out.files[k]=s?{uid:s.uid,mode:s.mode&511}:null}console.log(JSON.stringify(out));"
        return self.a.decode(self.run(['docker', 'exec', 'synapse-content-1', 'node', '-e', script]))

    def users(self, child=None):
        result = {'current': self.a.decode(self.run(['docker', 'inspect', '--format', self.prior.USER_FORMAT, 'synapse-content-1'])),
                  'parent': self.a.decode(self.run(['docker', 'image', 'inspect', '--format', self.prior.USER_FORMAT, PARENT]))}
        if child: result['child'] = self.a.decode(self.run(['docker', 'image', 'inspect', '--format', self.prior.USER_FORMAT, child]))
        need(all(type(v) is str and v in self.prior.ROOT_USERS for v in result.values())
             and (not child or result['parent'] == result['child']), 'PRESERVED_ROOT_SERVICE_USER_REQUIRED')
        return result

    def source_modes(self, child=False):
        names = sorted((row['target'] for row in self.source_records.values()) if child else self.existing_sources)
        script = self.prior.SOURCE_FACTS_JS
        value = self.a.decode(self.run(['docker', 'exec', 'synapse-content-1', 'node', '-e', script, json.dumps(names)]))
        need(type(value) is dict and set(value) == set(names) and all(v.get('uid') == v.get('gid') == 0 and v.get('mode') in (0o600, 0o644) for v in value.values()), 'ROOT_SOURCE_MODES_REQUIRED')
        if not child:
            for name in self.added_sources: value[name] = {'uid': 0, 'gid': 0, 'mode': 0o644}
        return value

    def static_modes(self, changed=frozenset()):
        result = {}
        for target, row in self.static_records.items():
            path = self.a.exact_path(Path(target), row['beforeSha256'] is None and target not in changed)
            if row['beforeSha256'] is None and target not in changed:
                need(not os.path.lexists(path), 'NEW_STATIC_TARGET_ALREADY_EXISTS'); result[target] = 0o644; continue
            s = path.stat()
            need(stat.S_ISREG(s.st_mode) and s.st_uid == s.st_gid == 0 and stat.S_IMODE(s.st_mode) in (0o600, 0o644), 'EXACT_ROOT_STATIC_MODES_REQUIRED')
            result[target] = stat.S_IMODE(s.st_mode)
        return result

    def snapshot(self, child=None, changed=frozenset(), proof=None):
        self.stable(); self.lease()
        first = self.metadata(child, proof); worker = self.b.worker_facts(); selected = {s: self.b.a.selected(s) for s in ('content', 'chat')}
        flags = self.a.decode(self.run(['docker', 'exec', 'synapse-content-1', 'node', '-e', self.a.FLAGS_JS]))
        need(worker == self.base['worker'] and selected == self.base['selected'] and flags == self.base['l12'], 'WORKER_FLAGS_SELECTION_CHANGED')
        for service, row in first.items():
            value = self.run(self.b._resolve_command(row, service)).decode('ascii').strip()
            need(re.fullmatch(re.escape(service) + r'\s+' + re.escape(row['configHash']), value) is not None, 'RESOLVED_COMPOSE_HASH_CHANGED')
        self.b.graph(new=True); self.b.push_guard()
        source = self.source if child else self.current.source
        need(self.b.photo.hashes(source) == source, 'FULL_SOURCE_INVENTORY_CHANGED')
        self.supplement_guard(bool(child))
        if not child:self.source_absence()
        self.traffic.read()
        expected = dict(self.current.static)
        for target in changed: need(target in self.static_records, 'UNKNOWN_STATIC_TARGET'); expected[target] = self.static[target]
        for name, pin in expected.items(): need(sha(self.a.read(Path(name))) == pin, 'FULL_STATIC_INVENTORY_CHANGED')
        self.static_modes(changed)
        cid = self.b.photo.cid()
        need(first == self.metadata(child, proof) and worker == self.b.worker_facts() and selected == {s: self.b.a.selected(s) for s in ('content', 'chat')}
             and cid == self.b.photo.cid(), 'CONCURRENT_NATIVE_CHANGE')
        self.stable(); self.lease()
        return {'containers': first, 'selected': selected, 'worker': worker, 'contentCid': cid, 'l12': flags}

    def data_mount(self):
        mounts = self.a.decode(self.run(['docker','inspect','--format','{{json .Mounts}}','synapse-content-1']))
        need(type(mounts) is list, 'EXACT_DATA_MOUNT_LIST_REQUIRED')
        rows = [r for r in mounts if r.get('Destination') == '/data']
        need(len(rows) == 1 and rows[0].get('Type') == 'volume' and rows[0].get('Name') == 'synapse_content_data'
             and rows[0].get('Source') == str(REPORT_DB_HOST.parent) and rows[0].get('RW') is True, 'EXACT_EXISTING_REPORT_VOLUME_REQUIRED')

    def content_data_mount(self):
        self.data_mount()
        script="process.stdout.write(process.env.DATABASE_PATH||'/data/content.sqlite')"
        need(self.run(['docker','exec','synapse-content-1','node','-e',script])==b'/data/content.sqlite','EXACT_RUNNING_CONTENT_DATABASE_PATH_REQUIRED')

    def baseline(self):
        snap = self.snapshot()
        need(snap == self.base and self.b.heartbeat(snap['worker']['startedAt'], time.time())['freshAfterWorkerStart'], 'FRESH_EXACT_R7C_REQUIRED')
        need(private_report_db(self.report_db()), 'EXISTING_PRIVATE_REPORT_DB_REQUIRED')
        self.db.guard(self.current.report_minimum); self.contentdb.after_guard(self.current.content_migration); self.users()
        return snap

    def binding(self):
        return {'groupReview':GROUP_REVIEW_SHA,'queueModuleSha256':QUEUE_MODULE_SHA,'parentReceipt':R7C_RECEIPT,'parentImage':PARENT,'productReview':PRODUCT_REVIEW_SHA,'dbGuard':DB_HELPER_SHA,'contentDbGuard':CONTENT_HELPER_SHA,'trafficDbGuard':TRAFFIC_HELPER_SHA,
            'manifest':MANIFEST_SHA,'helper':self.pins[str(Path(__file__))],'freshLeasePid':self.writer_pid,
            'managedProofSha256':MANAGED_PROOF_SHA,'managedProbeSha256':MANAGED_PROBE_SHA,'mapOutcomeSha256':MAP_OUTCOME_SHA,'managedSourceProof':self.managed_guard.proof,
            'parentPostSchemaSha256':self.current.content_migration['afterSchemaSha256'],'sourceCounts':{'before':235,'after':235},
            'beforeSource':self.current.source,'afterSource':self.source,'beforeStatic':self.current.static,'afterStatic':self.static}
    def inspect_current(self):
        need(self.inspection_state is None,'OWN_INSPECTION_CANNOT_REUSE_PREFLIGHT');self.baseline()
        return {'status':'CURRENT_R7C_READONLY_NOT_APPROVED','sourceFiles':235,'staticFiles':41,'chainFiles':39,'candidateSourceFiles':235,'candidateStaticFiles':41,
            'sourceModes':self.source_modes(),'staticModes':self.static_modes(),'reportDatabaseBefore':self.report_db(),'contentSchemaObjectsCreated':0,'runtimeWrites':0}

    def acceptance(self, pin):
        value = self.a.pinned(CODE / 'ROOT_ACCEPTANCE.json', pin, True)
        need(type(value) is dict and value.get('status') == 'ACCEPTED_NOTIFY_UPDATE_R2_PRODUCT_AND_INSTALLER'
             and value.get('runtimeApplyAuthorized') is True and value.get('writerThreadId') == '01a0a408-4f98-7713-a652-e6a741da834c'
             and value.get('groupReviewSha256')==GROUP_REVIEW_SHA and value.get('queueModuleSha256')==QUEUE_MODULE_SHA
             and value.get('parentReceiptSha256') == R7C_RECEIPT and value.get('productReviewSha256') == PRODUCT_REVIEW_SHA
             and value.get('dbGuardSha256') == DB_HELPER_SHA and value.get('contentDbGuardSha256') == CONTENT_HELPER_SHA and value.get('trafficDbGuardSha256') == TRAFFIC_HELPER_SHA
             and value.get('installerStatus') == 'ACCEPTED_NOTIFY_UPDATE_R2_INSTALLER_AND_ROLLBACK'
              and value.get('manifestSha256') == MANIFEST_SHA
              and value.get('managedProofSha256') == MANAGED_PROOF_SHA and value.get('mapOutcomeSha256') == MAP_OUTCOME_SHA
              and value.get('managedProbeSha256') == MANAGED_PROBE_SHA and value.get('managedSourceProof') == self.managed_guard.proof
              and value.get('sourceCounts') == {'before':235,'after':235} and value.get('contentSchemaObjectsCreated') == 0 and value.get('parentPostSchemaSha256') == self.current.content_migration['afterSchemaSha256']
             and value.get('helperSha256') == self.pins[str(Path(__file__))]
             and value.get('rollbackSha256') == ROLLBACK_SHA
             and value.get('reviewerThreadId') == '01a0a408-4f98-7713-a652-e6a741da834c',
             'EXACT_PRODUCT_AND_INSTALLER_ROOT_ACCEPTANCE_REQUIRED')
        return value

    def unused(self, allow_decision=False):
        for name, path in self.paths.items():
            if name == 'decision' and allow_decision: continue
            self.a.exact_path(path, True)
            need(not os.path.lexists(path) and not os.path.lexists(str(path) + '.pending'), 'OWN_ATTEMPT_EXISTS_NO_RETRY')
        for target in self.static_records:
            pending = Path(target).with_name(Path(target).name + '.' + NAME + '.pending')
            self.a.exact_path(pending, True); need(not os.path.lexists(pending), 'OWN_STATIC_PENDING_EXISTS_NO_RETRY')

    def approve(self, acceptance_pin, apply=False):
        need(self.inspection_state is None, 'OWN_INSPECTION_CANNOT_APPROVE')
        need(apply is True and digest(acceptance_pin), 'EXPLICIT_ROOT_ACCEPTED_APPROVAL_REQUIRED')
        self.unused(); self.acceptance(acceptance_pin); before = self.baseline()
        value = {'schema': 1, 'name': NAME, 'inputs': self.binding(), 'before': before,
                 'observedAtUtc': self.a.stamp(time.time()), 'sourceModes': self.source_modes(), 'staticModes': self.static_modes(),
                 'rootAcceptanceSha256': acceptance_pin, 'reportDatabaseBefore': self.report_db(), 'reportDatabaseContentBefore': self.db.read(), 'contentDatabaseBefore': self.contentdb.read(), 'trafficDatabaseBefore':self.traffic.read(), 'serviceUsers': self.users()}
        self.a.write_new(self.paths['decision'], value)
        return {'status': 'NEW_DECISION_NOT_APPLIED', 'decisionSha256': sha(self.a.read(self.paths['decision'])), 'runtimeWrites': 0}

    def decision(self, pin, fresh=True):
        value = self.a.pinned(self.paths['decision'], pin, True)
        need(type(value) is dict and set(value) == {'schema', 'name', 'inputs', 'before', 'observedAtUtc', 'sourceModes', 'staticModes', 'rootAcceptanceSha256', 'reportDatabaseBefore', 'reportDatabaseContentBefore', 'contentDatabaseBefore', 'trafficDatabaseBefore', 'serviceUsers'}
             and value['schema'] == 1 and value['name'] == NAME and value['inputs'] == self.binding()
             and value['before'] == self.base and private_report_db(value['reportDatabaseBefore']),
             'EXACT_OWN_DECISION_REQUIRED')
        self.acceptance(value['rootAcceptanceSha256'])
        need(value['serviceUsers'] == self.users(), 'APPROVED_SERVICE_USERS_CHANGED')
        if fresh:
            self.a.fresh(value['observedAtUtc'], time.time())
            self.db.guard(value['reportDatabaseContentBefore']); self.contentdb.guard(value['contentDatabaseBefore']);self.traffic.guard(value['trafficDatabaseBefore'])
        return value

    def update(self, journal, phase, **fields):
        journal.update(phase=phase, **fields); self.a.replace(self.paths['journal'], journal)

    def context_proof(self, state, built=False):
        context = self.paths['context']
        wanted = {'Dockerfile': sha(('FROM ' + NAME + '-base\nCOPY app/ /app/\n').encode())}
        wanted.update({'app/' + row['target']: row['sha256'] for row in self.source_records.values()})
        wanted.update({'static/' + str(i): row['sha256'] for i, row in enumerate(state['static'])})
        actual = {}
        directories = {'app', 'static'} | {'app/' + str(p) for r in self.source_records.values() for p in PurePosixPath(r['target']).parents if str(p) != '.'}
        for path in context.rglob('*'):
            self.a.exact_path(path)
            if path.is_file():
                relative = path.relative_to(context).as_posix()
                if built and relative == 'image.id': continue
                actual[relative] = sha(self.a.read(path))
            else: need(path.is_dir() and path.relative_to(context).as_posix() in directories, 'UNEXPECTED_BUILD_DIRECTORY')
        need(actual == wanted, 'EXACT_CLOSED_BUILD_CONTEXT_REQUIRED')
        for target, mode in state['sourceModes'].items():
            need(self.files.mode(context / 'app' / target) == mode['mode'], 'SOURCE_CONTEXT_MODE_CHANGED')
        return sha(json.dumps(sorted(actual.items()), separators=(',', ':')).encode())

    def backups(self, state):
        directory = self.a.exact_path(self.paths['backup']); s = directory.stat()
        need(stat.S_ISDIR(s.st_mode) and s.st_uid == 0 and stat.S_IMODE(s.st_mode) == 0o700
             and state['backupIdentity'] == [s.st_dev, s.st_ino, s.st_uid], 'PRIVATE_BACKUP_DIRECTORY_CHANGED')
        need(len(state['sourceBackups']) == len(self.existing_sources)
             and {r['target']: r['baseSha256'] for r in state['sourceBackups']} == {k: v['beforeSourceSha256'] for k, v in self.existing_sources.items()}
             and len(state['static']) == len(self.static_records)
             and {r['target'] for r in state['static']} == set(self.static_records), 'EXACT_COMPLETE_BACKUP_INVENTORY_REQUIRED')
        for row in state['static']:
            record = self.static_records[row['target']]
            need(row['baseSha256'] == record['beforeSha256'] and row['sha256'] == record['sha256']
                 and (row['backup'] is None) == (record['beforeSha256'] is None), 'STATIC_BACKUP_RECORD_CHANGED')
        self.db.backup_guard(state['reportDatabaseBackup'])
        need(Path(state['reportDatabaseBackup']['path']) == directory / 'reports.sqlite', 'EXACT_REPORT_BACKUP_PATH_REQUIRED')
        self.contentdb.backup_guard(state['contentDatabaseBackup'])
        need(Path(state['contentDatabaseBackup']['path']) == directory / 'content.sqlite', 'EXACT_CONTENT_BACKUP_PATH_REQUIRED')
        self.traffic.backup_guard(state['trafficDatabaseBackup'])
        self.traffic.guard(state['trafficDatabaseBackup'])
        wanted = {'reports.sqlite', 'content.sqlite'}
        if state['trafficDatabaseBackup']['status']=='EXISTING':
            need(Path(state['trafficDatabaseBackup']['path'])==directory/'traffic.sqlite','EXACT_TRAFFIC_BACKUP_PATH_REQUIRED');wanted.add('traffic.sqlite')
        for row in state['sourceBackups'] + state['static']:
            if row['backup'] is None: continue
            p = Path(row['backup']); need(p.parent == directory, 'BACKUP_BOUNDARY_REQUIRED'); wanted.add(p.name)
            self.a.exact_path(p); info = p.stat()
            need(stat.S_ISREG(info.st_mode) and info.st_uid == 0 and self.files.mode(p) == 0o600
                 and sha(self.a.read(p)) == row['baseSha256'], 'PRIVATE_EXACT_BACKUP_CHANGED')
        need({p.name for p in directory.iterdir()} == wanted, 'CLOSED_BACKUP_DIRECTORY_REQUIRED')

    def publish(self, row, state, pin):
        self.backups(state); self.decision(pin); self.snapshot(changed=frozenset(state['written']))
        target = self.a.exact_path(Path(row['target']), row['baseSha256'] is None)
        if row['baseSha256'] is None: need(not os.path.lexists(target), 'ADDED_STATIC_COLLISION')
        else: need(sha(self.a.read(target)) == row['baseSha256'] and self.files.mode(target) == row['mode'], 'STATIC_CAS_CHANGED')
        raw = self.a.read(Path(row['prepared'])); need(sha(raw) == row['sha256'], 'PREPARED_STATIC_CHANGED')
        pending = target.with_name(target.name + '.' + NAME + '.pending')
        self.a.exact_path(pending, True); self.files.write(pending, raw, row['mode'])
        self.snapshot(changed=frozenset(state['written'])); self.decision(pin); self.lease()
        need(sha(self.a.read(pending)) == row['sha256'] and self.files.mode(pending) == row['mode'], 'STATIC_PENDING_CHANGED')
        if row['baseSha256'] is None:
            os.link(pending, target); os.unlink(pending)  # exclusive publication, never replace a newly appeared file
        else:
            need(sha(self.a.read(target)) == row['baseSha256'] and self.files.mode(target) == row['mode'], 'LAST_STATIC_CAS_CHANGED')
            os.replace(pending, target)
        state['written'].append(str(target))

    def apply(self, pin, apply=False):
        need(getattr(self,'inspection_state',None) is None, 'OWN_INSPECTION_CANNOT_APPLY')
        need(apply is True and digest(pin), 'EXPLICIT_OWN_APPLY_REQUIRED')
        self.unused(allow_decision=True); decision = self.decision(pin); before = self.baseline()
        need(self.source_modes() == decision['sourceModes'] and self.static_modes() == decision['staticModes'], 'APPROVED_FILE_MODES_CHANGED')
        alias, tag = NAME + '-base', NAME + '-content'
        for name in (alias, tag): need(not self.run(['docker', 'image', 'ls', '--quiet', '--filter', 'reference=' + name]).strip(), 'UNIQUE_NEW_IMAGE_ALIAS_REQUIRED')
        need(self.run(['docker', 'image', 'inspect', '--format', '{{.Id}}', PARENT]).decode().strip() == PARENT, 'EXACT_PARENT_IMAGE_REQUIRED')
        layers = self.a.decode(self.run(['docker', 'image', 'inspect', '--format', '{{json .RootFS.Layers}}', PARENT]))
        need(type(layers) is list and layers, 'EXACT_PARENT_LAYERS_REQUIRED')
        state = {'schema': 1, 'name': NAME, 'inputs': self.binding(), 'before': before, 'decisionSha256': pin, 'static': [],
                 'sourceBackups': [], 'written': [], 'sourceModes': decision['sourceModes'], 'automaticRetry': False,
                 'automaticCodeRollback': False, 'workerRecreated': False, 'mainDbRowDirectWrites': 0, 'queueEdits': 0, 'oldJournalWrites': 0,
                 'reportDatabaseBefore': decision['reportDatabaseBefore'], 'contentMigration':copy.deepcopy(self.current.content_migration), 'contentSchemaObjectsCreated':0, 'contentLegacyRowWrites':0, 'activationRowsCreated':0}
        self.a.write_new(self.paths['journal'], {**state, 'phase': 'CONTEXT_STARTED_UNKNOWN'})
        for path in (self.paths['context'], self.paths['backup']): self.files.directory(self.a.exact_path(path, True), 0o700)
        info = self.paths['backup'].stat(); state['backupIdentity'] = [info.st_dev, info.st_ino, info.st_uid]
        state['reportDatabaseBackup'] = self.db.backup(self.paths['backup'] / 'reports.sqlite', decision['reportDatabaseContentBefore'])
        state['contentDatabaseBackup'] = self.contentdb.backup(self.paths['backup'] / 'content.sqlite', decision['contentDatabaseBefore'])
        state['trafficDatabaseBackup']=self.traffic.backup(self.paths['backup']/'traffic.sqlite',decision['trafficDatabaseBefore'])
        self.update(state, 'DATABASE_BACKUP_SEALED_NOT_PUBLISHED')
        directories = {'app', 'static'} | {'app/' + str(p) for r in self.source_records.values() for p in PurePosixPath(r['target']).parents if str(p) != '.'}
        for relative in sorted(directories, key=lambda n: (n.count('/'), n)):
            self.files.directory(self.a.exact_path(self.paths['context'] / relative, True), 0o700 if relative == 'static' else 0o755)
        for target, row in sorted(self.existing_sources.items()):
            encoded = self.run(['docker', 'exec', 'synapse-content-1', 'node', '-e', self.current.source_script, target])
            need(len(encoded) < 3 * 1024 * 1024, 'BOUNDED_ORIGINAL_SOURCE_REQUIRED')
            raw = base64.b64decode(encoded, validate=True); need(sha(raw) == row['beforeSourceSha256'], 'SOURCE_BACKUP_BASE_CHANGED')
            backup = self.paths['backup'] / ('source-' + str(len(state['sourceBackups'])))
            self.files.write(backup, raw, 0o600); state['sourceBackups'].append({'target': target, 'baseSha256': row['beforeSourceSha256'], 'backup': str(backup)})
        for row in self.source_records.values():
            self.files.write(self.paths['context'] / 'app' / row['target'], self.a.read(CODE / 'payload' / row['name']), decision['sourceModes'][row['target']]['mode'])
        for target, row in sorted(self.static_records.items()):
            index = len(state['static']); prepared = self.paths['context'] / 'static' / str(index); backup = None
            raw = self.a.read(CODE / 'payload' / row['name']); self.files.write(prepared, raw, 0o600)
            if row['beforeSha256'] is not None:
                old = self.a.read(Path(target)); need(sha(old) == row['beforeSha256'], 'STATIC_BACKUP_BASE_CHANGED')
                backup = self.paths['backup'] / ('static-' + str(index)); self.files.write(backup, old, 0o600)
            state['static'].append({'target': target, 'baseSha256': row['beforeSha256'], 'sha256': row['sha256'], 'mode': decision['staticModes'][target],
                                    'backup': str(backup) if backup else None, 'prepared': str(prepared)})
        self.files.write(self.paths['context'] / 'Dockerfile', ('FROM ' + alias + '\nCOPY app/ /app/\n').encode(), 0o600)
        self.backups(state); self.update(state, 'CONTEXT_READY_NOT_BUILT', contextSha256=self.context_proof(state))
        self.baseline(); self.decision(pin); self.lease()
        self.run(['docker', 'image', 'tag', PARENT, alias]); need(self.run(['docker', 'image', 'inspect', '--format', '{{.Id}}', alias]).decode().strip() == PARENT, 'PARENT_ALIAS_CHANGED')
        self.update(state, 'BUILD_STARTED_UNKNOWN'); need(self.context_proof(state) == state['contextSha256'], 'LAST_CONTEXT_CHANGED')
        self.run(['docker', 'build', '--network=none', '--pull=false', '--tag', tag, '--iidfile', str(self.paths['context'] / 'image.id'), str(self.paths['context'])])
        child = self.a.read(self.paths['context'] / 'image.id').decode().strip()
        need(self.a.image(child) and child != PARENT and self.run(['docker', 'image', 'inspect', '--format', '{{.Id}}', tag]).decode().strip() == child, 'EXACT_CHILD_IMAGE_REQUIRED')
        child_layers = self.a.decode(self.run(['docker', 'image', 'inspect', '--format', '{{json .RootFS.Layers}}', child]))
        need(type(child_layers) is list and child_layers[:len(layers)] == layers and len(child_layers) == len(layers) + 1, 'ONE_COPY_LAYER_REQUIRED')
        need(self.context_proof(state, True) == state['contextSha256'] and self.b.photo.hashes(self.source, child) == self.source, 'FULL_CHILD_SOURCE_CHANGED')
        supplement_child_check = ";{const f=require('node:fs'),c=require('node:crypto'),p='/app/project-chat.js',s=f.lstatSync(p);if(!s.isFile()||s.isSymbolicLink()||s.nlink!==1||s.uid!==0||s.gid!==0||f.realpathSync(p)!==p||(s.mode&511)!==" + str(self.current.supplement_mode) + "||c.createHash('sha256').update(f.readFileSync(p)).digest('hex')!==" + json.dumps(self.source[SUPPLEMENT_NAME]) + ")throw Error('EXACT_CHILD_SOURCE_SUPPLEMENT_REQUIRED');}"
        script = self.prior.CHILD_CHECK_JS + supplement_child_check + ";const {DatabaseSync}=require('node:sqlite');const r=require('/app/company-app/runtime.cjs').create({db:new DatabaseSync(':memory:')});r.close();"
        output = self.run(['docker', 'run', '--rm', '--network=none', '--read-only', '--cap-drop=ALL', '--security-opt=no-new-privileges', '--entrypoint=node', child, '-e', script, json.dumps(decision['sourceModes'])])
        need(output == b'PRECHECK_OK', 'CHILD_SYNTAX_RUNTIME_PREFLIGHT_REQUIRED')
        self.users(child)
        self.baseline(); self.decision(pin); self.backups(state)
        self.update(state, 'STATIC_STARTED_UNKNOWN', childImage=child)
        for row in sorted(state['static'], key=lambda row: (Path(row['target']).name == 'cabinet.html', row['target'])):
            self.publish(row, state, pin); self.update(state, 'STATIC_STARTED_UNKNOWN')
        need(self.snapshot(changed=frozenset(state['written'])) == before, 'LAST_PARENT_WITH_PUBLISHED_STATIC_CHANGED')
        self.a.write_new(self.paths['overlay'], {'services': {'content': {'image': child}}})
        proof = {'overlaySha256': sha(self.a.read(self.paths['overlay'])), 'plannedConfigHash': self.b.plan(before, 'content', self.paths['overlay'])}
        self.update(state, 'CONTENT_UP_STARTED_UNKNOWN', **proof)
        self.decision(pin); self.lease(); self.backups(state); self.stable()
        need(self.context_proof(state, True) == state['contextSha256'] and self.b.plan(before, 'content', self.paths['overlay']) == proof['plannedConfigHash'], 'LAST_CONTEXT_OR_COMPOSE_PLAN_CHANGED')
        self.lease()
        self.backups(state)
        need(self.snapshot(changed=frozenset(state['written'])) == before, 'LAST_NATIVE_BASIS_CHANGED')
        need(private_report_db(self.report_db()), 'LAST_PRIVATE_REPORT_GROUP_REQUIRED')
        self.db.guard(state['reportDatabaseBackup'])
        self.lease()
        self.contentdb.guard(state['contentDatabaseBackup'])
        self.managed_guard.guard(); self.lease()
        state['contentMigration']=copy.deepcopy(self.current.content_migration)
        state['contentSchemaObjectsCreated']=0;state['contentLegacyRowWrites']=0;state['activationRowsCreated']=0
        self.update(state,'CONTENT_UP_STARTED_UNKNOWN')
        need(self.snapshot(changed=frozenset(state['written']))==before,'LAST_CODE_ONLY_NATIVE_BASIS_CHANGED')
        need(private_report_db(self.report_db()),'LAST_PRIVATE_REPORT_GROUP_REQUIRED')
        self.db.guard(state['reportDatabaseBackup']);self.contentdb.guard(state['contentDatabaseBackup']);self.contentdb.after_guard(state['contentMigration']);self.stable();self.lease()
        self.managed_guard.guard(); self.lease()
        self.traffic_checkpoint(state);self.lease()
        self.b.up(before, 'content', self.paths['overlay'])
        self.managed_guard.guard(); self.lease()
        after = self.snapshot(child, frozenset(state['written']), proof)
        need(after['contentCid'] != before['contentCid'] and self.source_modes(True) == decision['sourceModes'], 'EXACT_NEW_CONTENT_AND_MODES_REQUIRED')
        self.contentdb.after_guard(state['contentMigration'])
        report_db = self.report_db(); need(private_report_db(report_db), 'PRIVATE_REPORT_DB_PRESERVED_REQUIRED')
        self.db.guard(state['reportDatabaseBackup'])
        self.traffic_checkpoint(state);self.traffic.guard(state['trafficDatabaseBackup'])
        self.update(state, 'APPLIED_NOT_CUSTOMER_ACCEPTANCE', after=after, reportDatabaseAfter=report_db, finishedAtUtc=self.a.stamp(time.time()))
        return {'status': 'APPLIED_NOT_CUSTOMER_ACCEPTANCE', 'receiptSha256': sha(self.a.read(self.paths['journal'])), 'contentImage': child,
                'sourceFiles': 235, 'staticFiles': 41, 'chainFiles': 40, 'workerRecreated': False, 'mainDbRowDirectWrites': 0, 'contentSchemaObjectsCreated': 0, 'activationRowsCreated': 0, 'oldJournalWrites': 0}

    def inspect(self, pin):
        need(self.inspection_pin in (None,pin), 'EXACT_OWN_INSPECTION_PIN_REQUIRED')
        state = self.a.pinned(self.paths['journal'], pin, True)
        need(state.get('phase') == 'APPLIED_NOT_CUSTOMER_ACCEPTANCE' and state.get('name') == NAME
             and state.get('inputs') == self.binding() and state.get('before') == self.base
             and state.get('workerRecreated') is False and state.get('automaticRetry') is False
             and state.get('automaticCodeRollback') is False
             and state.get('contentSchemaObjectsCreated') == 0 and state.get('contentLegacyRowWrites') == state.get('activationRowsCreated') == 0
             and state.get('mainDbRowDirectWrites') == state.get('queueEdits') == state.get('oldJournalWrites') == 0,
             'EXACT_OWN_COMPLETED_RECEIPT_REQUIRED')
        self.decision(state['decisionSha256'], fresh=False); self.backups(state)
        need(self.context_proof(state, True) == state['contextSha256'] and set(state['written']) == set(self.static_records), 'SEALED_OWN_CONTEXT_AND_STATIC_REQUIRED')
        proof = {k: state[k] for k in ('overlaySha256', 'plannedConfigHash')}
        need(self.snapshot(state['childImage'], frozenset(state['written']), proof) == state['after']
             and private_report_db(self.report_db()), 'OWN_INSTALLATION_CHANGED')
        need(state.get('contentMigration')==self.current.content_migration,'EXACT_EXISTING_POST_R7C_SCHEMA_PROOF_REQUIRED')
        self.db.guard(state['reportDatabaseBackup']); self.contentdb.after_guard(state['contentMigration']);self.traffic.guard(state['trafficDatabaseBackup'])
        return {'status': 'OWN_COMPLETED_READONLY_NOT_CUSTOMER_ACCEPTANCE', 'sourceFiles': 235, 'staticFiles': 41, 'chainFiles': 40, 'runtimeWrites': 0}


def main():
    parser=argparse.ArgumentParser();parser.add_argument('operation',choices=['inspect-current','approve-current','apply','inspect']);parser.add_argument('--lease-pid',required=True,type=int)
    parser.add_argument('--acceptance-sha');parser.add_argument('--decision-sha');parser.add_argument('--receipt-sha');parser.add_argument('--apply',action='store_true');args=parser.parse_args()
    try:
        need(FROZEN is True and all(digest(pin) and pin!='0'*64 for pin in (MANIFEST_SHA,ROLLBACK_SHA,DB_HELPER_SHA,CONTENT_HELPER_SHA,TRAFFIC_HELPER_SHA,PRODUCT_REVIEW_SHA,PRODUCT_MANIFEST_SHA,GROUP_REVIEW_SHA,MANAGED_HELPER_SHA,MANAGED_PROBE_SHA,MANAGED_PROOF_SHA,MAP_OUTCOME_SHA)),'DRAFT_INSTALLER_NOT_FROZEN_NO_ACTION')
        need(os.name=='posix' and os.geteuid()==0 and Path(__file__).resolve().parent==CODE,'EXACT_RECEIVER_CODE_ROOT_REQUIRED')
        a,b,prior,current=load_current_r7c(args.lease_pid)
        release=Release(a,b,prior,current,args.lease_pid,inspection_pin=args.receipt_sha if args.operation=='inspect' else None)
        if args.operation=='inspect-current':result=release.inspect_current()
        elif args.operation=='approve-current':result=release.approve(args.acceptance_sha,args.apply)
        elif args.operation=='apply':result=release.apply(args.decision_sha,args.apply)
        else:result=release.inspect(args.receipt_sha)
        print(json.dumps(result,separators=(',',':')));return 0
    except Exception as error:
        code=str(error) if type(error) is ValueError and re.fullmatch('[A-Z][A-Z0-9_]{0,100}',str(error)) else 'NATIVE_RELEASE_REFUSED'
        print(json.dumps({'status':'REFUSED_OR_UNKNOWN_NO_AUTOMATIC_RETRY','code':code,'messageSha256':sha(str(error).encode()),'runtimeWritesNotAssumed':True}));return 2
if __name__=='__main__':raise SystemExit(main())
