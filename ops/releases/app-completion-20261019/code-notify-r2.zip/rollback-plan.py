"""Pure combined-scope code rollback plan. No I/O, sending or activation."""
from pathlib import PurePath
PARENT='sha256:0c0b1efed97adc25871abcafcc58788f5b6aecbe4e10ebd260312b652c69ce3e'
PROOF='40ef3d261c68fcdca488a31da328e245f70066066bbc92cfebba28a4f19c453d'
STATIC={'shell.js','shell.css','cabinet.html'}
SOURCES={'server.js','palitra-orders-public/shell.js','palitra-orders-public/shell.css','palitra-orders-public/cabinet.html'}
def plan(state):
 if state.get('name')!='palitra-notify-update-20261020-r2' or state.get('phase')!='APPLIED_NOT_CUSTOMER_ACCEPTANCE':raise ValueError('EXACT_COMPLETED_NOTIFY_UPDATE_R2_REQUIRED')
 if state.get('inputs',{}).get('parentImage')!=PARENT or state.get('contentSchemaObjectsCreated')!=0 or state.get('activationRowsCreated')!=0:raise ValueError('CODE_ONLY_NOTIFY_UPDATE_R2_REQUIRED')
 if state.get('inputs',{}).get('managedProofSha256')!=PROOF:raise ValueError('EXACT_MANAGED259_PROOF_REQUIRED')
 rows=state.get('static',[]);written=state.get('written',[])
 if len(rows)!=3 or {PurePath(r.get('target','')).name for r in rows}!=STATIC or len(written)!=3 or set(written)!={r['target'] for r in rows} or PurePath(written[-1]).name!='cabinet.html':raise ValueError('EXACT_THREE_STATIC_CABINET_LAST_REQUIRED')
 sources=state.get('sourceBackups',[])
 if len(sources)!=4 or {r.get('target') for r in sources}!=SOURCES:raise ValueError('EXACT_FOUR_SOURCE_BACKUPS_REQUIRED')
 if 'trafficDatabaseBackup' not in state:raise ValueError('THIRD_STORE_PRESERVATION_PROOF_REQUIRED')
 return {'status':'MANUAL_PLAN_NOT_AUTHORIZATION','parentImage':PARENT,'requiredFreshLease':True,'requiredNewRootAcceptance':True,'expectedComposeFiles':41,'expectedSourceFiles':235,'expectedStaticFiles':41,
  'requiredCurrentConsistentBackups':['content.sqlite','salon-reports.sqlite','app-entry-stats.sqlite IF CURRENTLY PRESENT, including committed WAL'],'liveDatabaseOperations':[],'dropTables':[],'restoreDatabases':[],
  'trafficStorePolicy':'KEEP CURRENT presence, complete schema, all current events/revisions and WAL; never restore historical absence or old backup',
  'contentSchemaMustRemain':state['contentMigration']['afterSchemaSha256'],'managedProofMustRemain':PROOF,'automaticRetry':False,'oldHelpersReplay':False,'staticReplacements':['shell.css','shell.js','cabinet.html'],'cabinetLast':True,
  'bareParentReenablesGroupOrderRoute':True,'bareParentRestoresOldUpdateNoticeBehavior':True,'explicitAuthorizationToReenableGroupRequired':True,'offPreservingRollbackNeedsSeparateReviewedCorrectiveImage':True}
