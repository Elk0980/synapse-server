"""R7C exact managed revision supplement; read-only, no history mutation."""
import json
import re

SITE='site-44bbe13f1bad5e005b2a'
HOST='/var/lib/docker/volumes/synapse_content_data/_data'
PREFIX='/data/projects/palitra-love/sites/'+SITE+'/versions/'
MAP_SHA='a4cc3b4ea7928e9a1734c591f7ac5036e75e9263b433fc624d66fadaf3038e89'
PRICE_SHA='79d62dd78fc00347758c248a2b733e407bdacccf6094fe0a8f3e69f01c7a5943'
OUTCOME_SHA='7c206110ddb478f1be1221e689ea346e125b9e438096b59af39a7eb84ebc2c42'

def need(ok,code):
    if not ok: raise ValueError(code)
def digest(v):return type(v) is str and re.fullmatch('[a-f0-9]{64}',v) is not None
def container_root(value):
    value=str(value)
    return '/data/'+value[len(HOST)+1:] if value.startswith(HOST+'/') else value
def validate(definition,outcome,historical_root,probe_sha):
    need(type(definition) is dict and set(definition)=={'schema','status','probeSha256','mapOutcomeSha256','proof'}
         and definition['schema']==1 and definition['status']=='FROZEN' and definition['probeSha256']==probe_sha
         and definition['mapOutcomeSha256']==OUTCOME_SHA,'EXACT_FROZEN_MANAGED_SUPPLEMENT_REQUIRED')
    need(outcome.get('status')=='PUBLISHED_AND_VERIFIED' and outcome.get('siteId')==SITE
         and outcome.get('draftVersion')==259 and outcome.get('baseVersion')==257
         and outcome.get('sourceSha256')==MAP_SHA and outcome.get('priceSha256')==PRICE_SHA
         and outcome.get('pricesChanged') is False and outcome.get('zoneDataChanged') is False
         and outcome.get('runtimeApp',{}).get('unchanged') is True,'EXACT_APPROVED_MAP_OUTCOME_REQUIRED')
    p=definition['proof'];need(type(p) is dict and set(p)=={'schema','siteId','companyCode','workspace','apiPrice','historical','current'}
         and p['schema']==1 and p['siteId']==SITE and p['companyCode']=='palitra-love','EXACT_MANAGED_PROOF_REQUIRED')
    api=p['apiPrice']
    need(type(api) is dict and set(api)=={'key','id','version','sha256','bytes'} and api['key']=='palitra/price'
         and type(api['id']) is int and api['id']>0 and type(api['version']) is int and api['version']>0
         and api['sha256']==PRICE_SHA and api['bytes']==94994,'EXACT_API_PRICE_DOCUMENT_REQUIRED')
    for kind in ('historical','current'):
        r=p[kind]
        need(type(r) is dict and digest(r.get('revision')) and r.get('root')==PREFIX+r['revision']
             and r.get('fileCount')==140 and digest(r.get('factsSha256')) and digest(r.get('directoriesSha256'))
             and digest(r.get('manifestSha256')) and type(r.get('manifestBytes')) is int and r['manifestBytes']>0
             and type(r.get('rootFacts')) is dict and set(r['rootFacts'])=={'uid','gid','mode'}
             and all(type(v) is int and v>=0 for v in r['rootFacts'].values())
             and type(r.get('mismatches')) is list and type(r.get('selected')) is dict,
             'EXACT_MANAGED_REVISION_140_REQUIRED')
        selected=r['selected'];price=r.get('pricePath')
        need(price=='data/price.json' and type(selected.get(price)) is dict and digest(selected[price].get('sha256'))
             and type(selected[price].get('bytes')) is int and selected[price]['bytes']>=0,'EXACT_MANAGED_PRICE_REQUIRED')
    old_price=p['historical']['selected']['data/price.json'];new_price=p['current']['selected']['data/price.json']
    need(old_price['sha256']==new_price['sha256'] and old_price['bytes']==new_price['bytes'],'STORED_PRICE_CHANGED_BETWEEN_REVISIONS')
    need(p['historical']['root']==container_root(historical_root) and p['historical']['version']==257
         and p['current']['version']==259 and p['current']['revision']!=p['historical']['revision'],
         'EXACT_HISTORICAL_AND_CURRENT_ROOTS_REQUIRED')
    need(p['workspace'].get('id')==SITE and p['workspace'].get('company_code')=='palitra-love'
         and p['workspace'].get('current_revision')==p['current']['revision'],'EXACT_MANAGED_DB_POINTER_REQUIRED')
    need(p['current']['mismatches']==[] and p['current']['selected'].get('dostavka-i-oplata/index.html',{}).get('sha256')==MAP_SHA,
         'EXACT_APPROVED_CURRENT_MAP_REQUIRED')
    mismatches=p['historical']['mismatches']
    need(len(mismatches)<=2 and len({r.get('path') for r in mismatches})==len(mismatches)
         and all(r.get('path') in ('assets/order.js','assets/storefront.js') for r in mismatches),
         'ONLY_SEALED_PREEXISTING_HISTORICAL_DRIFT_REQUIRED')
    return p

class ManagedSource:
    def __init__(self,definition,outcome,historical_root,probe_bytes,run,decode,lease_guard):
        import hashlib
        self.proof=validate(definition,outcome,historical_root,hashlib.sha256(probe_bytes).hexdigest())
        self.historical_root=str(historical_root);self.run=run;self.decode=decode;self.lease_guard=lease_guard
        self.script=probe_bytes.decode('utf-8')+"\n;process.stdout.write(JSON.stringify(module.exports.probe(process.argv[1])));"
    def guard(self):
        self.lease_guard()
        raw=self.run(['docker','exec','synapse-content-1','node','-e',self.script,self.historical_root])
        need(len(raw)<=128*1024,'BOUNDED_MANAGED_SOURCE_PROOF_REQUIRED')
        need(self.decode(raw)==self.proof,'CURRENT_OR_HISTORICAL_MANAGED_SOURCE_CHANGED')
        self.lease_guard();return self.proof
