"""Manager workspace successor of installed completed notify-r2; product bindings pending. Separate native approval required.

Historical helpers/journals are read-only. Live report DB is never restored.
"""
import argparse
import base64
import copy
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import time
import types

FROZEN = True
TRAFFIC_HELPER_SHA = '2b44578d7b7fee9d779fe647c6d3b56eb5aa9d377f89b68f5aaed7230ca1127f'
QUEUE_MODULE_SHA = 'f46720163a8ec1f6ab75a45a86bc7dd951923e5755293acf537f87073e1df7d7'
GROUP_REVIEW_SHA = '222ba812eb92208765368f24966e85ca8217081ae8ef8ca9dd606e325b2c6b22'
ROOT_PRODUCT_ACCEPTANCE_SHA = 'e5c6c8b6457393c78d16379485d3a5f0bc6a51ac8851e062049eda0da38ecb05'
EXPECTED_RECORDS = [{'beforeSha256': 'c2e7301808f82a41bf4a5d94964ebc4ce07a97242455f14284e278a39c553be1', 'beforeSourceSha256': 'c2e7301808f82a41bf4a5d94964ebc4ce07a97242455f14284e278a39c553be1', 'bytes': 303731, 'name': 'product/shell.js', 'sha256': '9e36a2380cfe1c2282e41e79af2b1d04f91f7cf4577d8b7cd505b3a62f5d2f71', 'static': 'shell.js', 'target': 'palitra-orders-public/shell.js'}, {'beforeSha256': '35e5ecaaca56b9f01db6b8dddcc6bef088c795acd4d0f46d83effbc1a0837fc7', 'beforeSourceSha256': '35e5ecaaca56b9f01db6b8dddcc6bef088c795acd4d0f46d83effbc1a0837fc7', 'bytes': 66236, 'name': 'product/shell.css', 'sha256': '4575282b2b0cd3eab10497fc687ed95ac4aece431b73daff710449c0c23f24d6', 'static': 'shell.css', 'target': 'palitra-orders-public/shell.css'}, {'beforeSha256': '78519ea84a19f9559f0a4042c6f328fe5cb35771948be2ac9f32f72b807b2e21', 'beforeSourceSha256': '78519ea84a19f9559f0a4042c6f328fe5cb35771948be2ac9f32f72b807b2e21', 'bytes': 32319, 'name': 'product/native-host.js', 'sha256': 'ace79570defa7feaf491d3b59a37718dee847b4436e614cf71a41ee0d78bbdf1', 'static': 'native-host.js', 'target': 'palitra-orders-public/native-host.js'}, {'beforeSha256': '65934139f9dfaf9ff6b3dc10dd92d7e7c9b779f74a99b987705297b17fd11d9c', 'beforeSourceSha256': '65934139f9dfaf9ff6b3dc10dd92d7e7c9b779f74a99b987705297b17fd11d9c', 'bytes': 2733, 'name': 'product/cabinet.html', 'sha256': 'a668c0c5392c9c0caa642ed42facd95384523a257a610c5323703e4fbb6bdd02', 'static': 'cabinet.html', 'target': 'palitra-orders-public/cabinet.html'}, {'beforeSha256': '1d07040b2c01f2e3ade56a59bb681f6858e29f950d642c69a2d552c30c18a876', 'beforeSourceSha256': '1d07040b2c01f2e3ade56a59bb681f6858e29f950d642c69a2d552c30c18a876', 'bytes': 129308, 'name': 'backend/server.js', 'sha256': 'c15bec303ac328bde1b7577e93d425b81f4637e2a2f4488be255b64b72bf0404', 'static': None, 'target': 'server.js'}, {'beforeSha256': '972bb6e141f8bf5dbf30a5b68b3e3d58fd19519cb9caeaf0a725b7628d5585b8', 'beforeSourceSha256': '972bb6e141f8bf5dbf30a5b68b3e3d58fd19519cb9caeaf0a725b7628d5585b8', 'bytes': 73272, 'name': 'product/workflow-ui.js', 'sha256': '499d626f365f2d4503df0a3732eaacab6919648e1668f2f3d6b451c6945c6720', 'static': 'workflow-ui.js', 'target': 'palitra-orders-public/workflow-ui.js'}, {'name': 'backend/palitra-manager-attention.cjs', 'target': 'palitra-manager-attention.cjs', 'static': None, 'beforeSha256': None, 'beforeSourceSha256': None, 'sha256': '63e17f5e1f758446e43f691f42869ed479b8a658e67ab5b908403bebb1360611', 'bytes': 14606}, {'name': 'backend/palitra-response-report.cjs', 'target': 'palitra-response-report.cjs', 'static': None, 'beforeSha256': None, 'beforeSourceSha256': None, 'sha256': '62ffa4bc34e041b906a06e5abb0b017c47bdc3fae975479c81307dd8d81e29f2', 'bytes': 12662}, {'name': 'product/palitra-response-report-ui.js', 'target': 'palitra-orders-public/palitra-response-report-ui.js', 'static': 'palitra-response-report-ui.js', 'beforeSha256': None, 'beforeSourceSha256': None, 'sha256': '2670a5fa7f35f77a2a7fbc602efa6031b453df939d2171d84dc02b7efa8c4961', 'bytes': 8636}, {'name': 'product/palitra-content-tasks-ui.js', 'target': 'palitra-orders-public/palitra-content-tasks-ui.js', 'static': 'palitra-content-tasks-ui.js', 'beforeSha256': None, 'beforeSourceSha256': None, 'sha256': 'd16fb528869644c0f97ac790340bd64a6b9079f1a9562c58f220b277263a11fc', 'bytes': 8964}, {'name': 'backend/palitra-workflow.cjs', 'target': 'palitra-workflow.cjs', 'static': None, 'beforeSha256': 'b103fed76f99e7d88cd9c68308cd2ec694ab34d484809cd021dbcb236f36dc49', 'beforeSourceSha256': 'b103fed76f99e7d88cd9c68308cd2ec694ab34d484809cd021dbcb236f36dc49', 'sha256': '36f7cb0f56e0058022be0815afc251f5ce96f874905dffbe783cffeb5264f112', 'bytes': 32186}]
ROOT = Path('/opt/synapse/releases/palitra-app-20261015')
NAME = 'palitra-darya-workspace-20261020-r2'
CODE = ROOT / (NAME + '-code')
LOCK = '/opt/synapse/.palitra-app-release.lock'
PARENT = 'sha256:40c8fc48d96478d65d87e72954a29731cbad9d64e11c2a68df92a86c9aee4717'
MANIFEST_SHA = '5b1fd2fe0e8354cdef1f6273c061b6bb74134efe2713c1610a54dc00d716e9b2'
ROLLBACK_SHA = 'a6d573a17162c750ad07f81c43c80fc8d4d154c24f4389bff1d33b3acb7cb035'
DB_HELPER_SHA = '08456dc9fcfae875b22c631a461e0cedea5a702b5f8d43ae770de7cff6e78a63'
PRODUCT_REVIEW_SHA = '57467101d22d8b11e93db549144d7fa5360d6cc832af960845079cae99efcc36'
PRODUCT_MANIFEST_SHA = '1f9acbae0840883199822bd8e86e01144407a2cf637f78522ea5b8e141a4a923'
MANAGED_HELPER_SHA = 'b01bf2eb4d3b943a79855bccec858ea11b8f6aa57b400cf6f252c3b35c4c079e'
MANAGED_PROBE_SHA = '6adf008d2a6016031b6ad6812c3550a557694293a9a855a92cfb64e6c964ca6f'
MANAGED_PROOF_SHA = '40ef3d261c68fcdca488a31da328e245f70066066bbc92cfebba28a4f19c453d'  # Root-created root0600 O_EXCL external proof; fill only after its native read.
MANAGED_PROOF_PATH = ROOT / 'multi-company-app-20261019-r7c-managed-proof.json'
MAP_OUTCOME_SHA = '7c206110ddb478f1be1221e689ea346e125b9e438096b59af39a7eb84ebc2c42'
REPORT_DB_HOST = Path('/var/lib/docker/volumes/synapse_content_data/_data/salon-reports.sqlite')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
digest = lambda value: isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value) is not None


def need(value, code):
    if not value:
        raise ValueError(code)


def private_report_db(value):
    return (type(value) is dict and set(value) == {'path', 'files'} and value['path'] == '/data/salon-reports.sqlite'
            and type(value['files']) is dict and set(value['files']) == {'db', 'wal', 'shm'} and value['files']['db'] is not None
            and all(row is None or type(row) is dict and row == {'uid': 0, 'mode': 0o600} for row in value['files'].values()))



CONTENT_HELPER_SHA = 'd6363b217d69a49751d875b00cf50776593d01160b386190edaac8bf537ab4be'
CONTENT_DB_HOST = REPORT_DB_HOST.with_name('content.sqlite')
TRAFFIC_DB_HOST = REPORT_DB_HOST.with_name('app-entry-stats.sqlite')
PARENT_RECEIPT='79c4657ca15402b34b36d51642f4e8565701f8ab1b06fc446e5d629e674172f3'
PARENT_DECISION='7a5911d19de707c5fc2c95b197ee99acc335f21abc6f418fac134613abd59fcc'
PARENT_LOADER_SHA='58296305f2ee805f4c390b0676cf8f573ee4d8f3cd9cd6b605c377fb10a71915'
GROUP_OFF_SERVER_SHA='1d07040b2c01f2e3ade56a59bb681f6858e29f950d642c69a2d552c30c18a876'
ATTENTION_TARGET='palitra-manager-attention.cjs'
ATTENTION_MODULE_SHA = '63e17f5e1f758446e43f691f42869ed479b8a658e67ab5b908403bebb1360611'
SUPPLEMENT_NAME='project-chat.js'
ATTENTION_DEPENDENCIES={'palitra-workflow.cjs': 'b103fed76f99e7d88cd9c68308cd2ec694ab34d484809cd021dbcb236f36dc49', 'customer-chat-native-adapter.cjs': '7ab038804f241488df31a19c9cc168d67f20331a82c79b07714a1dc2962e6eb3', 'client-dialogs.js': '21a4ac8c0796f85e4901c647028576d9a2fcd01aeb49d1b6d731ca7f09ecafcc', 'native-contact-followup.cjs': '685fa6cd5effb24c72adf9fec6fa001bc3e39351549165d27d1b320ab2f5caf0', 'customer-chat.js': '2cc2dbd6e24dfaca6876d03a131491660e805c59b3c35255de3574ce2c5f8d55'}
ATTENTION_PREFLIGHT_JS="'use strict';\nconst fs=require('node:fs'),crypto=require('node:crypto'),{DatabaseSync}=require('node:sqlite');\nlet db;\ntry {\n const modulePath='/app/palitra-manager-attention.cjs',dbPath='/data/content.sqlite';\n const expectedSha=process.argv[1];\n if(!/^[a-f0-9]{64}$/.test(expectedSha))throw Error('PIN');\n for(const path of [modulePath,dbPath]){const s=fs.lstatSync(path);if(!s.isFile()||s.isSymbolicLink()||s.nlink!==1||s.uid!==0||s.gid!==0||fs.realpathSync(path)!==path||![384,420].includes(s.mode&511))throw Error('PATH');}\n for(const suffix of ['-wal','-shm']){const path=dbPath+suffix;try{const s=fs.lstatSync(path);if(!s.isFile()||s.isSymbolicLink()||s.nlink!==1||s.uid!==0||s.gid!==0||fs.realpathSync(path)!==path)throw Error('SIDECAR');}catch(e){if(e.code!=='ENOENT')throw e;}}\n if(crypto.createHash('sha256').update(fs.readFileSync(modulePath)).digest('hex')!==expectedSha)throw Error('MODULE');\n const {createManagerAttention}=require(modulePath);\n if(typeof createManagerAttention!=='function')throw Error('EXPORT');\n db=new DatabaseSync(dbPath,{readOnly:true});\n const result=createManagerAttention({db,canAccess:()=>true}).read({id:0},{filter:'all',limit:1});\n const countKeys=['attention','firstContact','total','unanswered'];\n if(!result||Object.keys(result).sort().join(',')!=='asOf,companyCode,counts,filter,items,nextCursor,partial,schema,scopeKey'||result.schema!=='palitra-manager-attention/v1'||result.companyCode!=='palitra-love'||result.scopeKey!=='palitra'||result.filter!=='all'||result.partial!==false||typeof result.asOf!=='string'||!Number.isFinite(Date.parse(result.asOf))||new Date(result.asOf).toISOString()!==result.asOf||!result.counts||Object.keys(result.counts).sort().join(',')!==countKeys.join(',')||countKeys.some(k=>!Number.isSafeInteger(result.counts[k])||result.counts[k]<0)||result.counts.attention!==result.counts.unanswered+result.counts.firstContact||result.counts.attention>result.counts.total||!Array.isArray(result.items)||result.items.length!==Math.min(1,result.counts.total)||!(result.nextCursor===null||typeof result.nextCursor==='string'))throw Error('SHAPE');\n if(db.prepare('SELECT total_changes() AS changes').get().changes!==0)throw Error('WRITE');\n // Never print items, names, refs, text, cookies or the opaque cursor.\n process.stdout.write(JSON.stringify({schema:result.schema,companyCode:result.companyCode,scopeKey:result.scopeKey,filter:result.filter,partial:result.partial,asOf:result.asOf,counts:result.counts,itemsLength:result.items.length,nextCursor:result.nextCursor!==null}));\n} catch(_) {process.stdout.write(JSON.stringify({status:'ATTENTION_READONLY_PREFLIGHT_REFUSED'}));process.exitCode=2;}\nfinally {if(db)try{db.close();}catch(_){process.exitCode=2;}}\n"

RESPONSE_TARGET = 'palitra-response-report.cjs'
RESPONSE_MODULE_SHA = '62ffa4bc34e041b906a06e5abb0b017c47bdc3fae975479c81307dd8d81e29f2'
WORKFLOW_AFTER_SHA = '36f7cb0f56e0058022be0815afc251f5ce96f874905dffbe783cffeb5264f112'
AFTER_DEPENDENCIES = {**ATTENTION_DEPENDENCIES, 'palitra-workflow.cjs':WORKFLOW_AFTER_SHA}
ADDED_SOURCES = {ATTENTION_TARGET,RESPONSE_TARGET,'palitra-orders-public/palitra-response-report-ui.js','palitra-orders-public/palitra-content-tasks-ui.js'}
OBSERVATION_KEY = 'palitra-love/response-time-observation/v1'
RESPONSE_PREFLIGHT_JS = '"use strict";\nconst fs=require(\'node:fs\'),crypto=require(\'node:crypto\'),{DatabaseSync}=require(\'node:sqlite\');\nlet db;\ntry {\n const modulePath=\'/app/palitra-response-report.cjs\',dbPath=\'/data/content.sqlite\',expectedSha=process.argv[1];\n const key=\'palitra-love/response-time-observation/v1\',channels=[\'site\',\'telegram\',\'vk\',\'instagram\',\'youtube\',\'tiktok\'];\n if(!/^[a-f0-9]{64}$/.test(expectedSha))throw Error(\'PIN\');\n for(const path of [modulePath,dbPath]){const s=fs.lstatSync(path);if(!s.isFile()||s.isSymbolicLink()||s.nlink!==1||s.uid!==0||s.gid!==0||fs.realpathSync(path)!==path||![384,420].includes(s.mode&511))throw Error(\'PATH\');}\n for(const suffix of [\'-wal\',\'-shm\']){const path=dbPath+suffix;try{const s=fs.lstatSync(path);if(!s.isFile()||s.isSymbolicLink()||s.nlink!==1||s.uid!==0||s.gid!==0||fs.realpathSync(path)!==path)throw Error(\'SIDECAR\');}catch(e){if(e.code!==\'ENOENT\')throw e;}}\n if(crypto.createHash(\'sha256\').update(fs.readFileSync(modulePath)).digest(\'hex\')!==expectedSha)throw Error(\'MODULE\');\n const {createResponseReport}=require(modulePath);if(typeof createResponseReport!==\'function\')throw Error(\'EXPORT\');\n db=new DatabaseSync(dbPath,{readOnly:true});\n const rows=db.prepare(\'SELECT key,version,created_at,author,body FROM documents WHERE key=? ORDER BY version\').all(key);\n let observation={status:\'ABSENT\',documentSha256:null,startedAt:null};\n if(rows.length){\n  if(rows.length!==1)throw Error(\'OBSERVATION\');const row=rows[0],body=JSON.parse(row.body);\n  if(row.version!==1||row.author!==\'response-report:init\'||Object.keys(body).sort().join(\',\')!==\'observationStartedAt,schema\'||body.schema!==1||typeof body.observationStartedAt!==\'string\'||!Number.isFinite(Date.parse(body.observationStartedAt))||new Date(body.observationStartedAt).toISOString()!==body.observationStartedAt||row.created_at!==body.observationStartedAt)throw Error(\'OBSERVATION\');\n  observation={status:\'EXISTING\',documentSha256:crypto.createHash(\'sha256\').update(JSON.stringify(row)).digest(\'hex\'),startedAt:body.observationStartedAt};\n }\n const owner={id:1,sessionVersion:1,role:\'owner\'};\n const report=createResponseReport({db,transaction:()=>{throw Error(\'INITIALIZER_FORBIDDEN\')},getUser:()=>owner,channelState:()=>Object.fromEntries(channels.map(id=>[id,\'unobserved\']))});\n // Do not call initializeObservation; preparing a write statement is not executing it.\n const value=report.read(owner);\n const count=n=>Number.isSafeInteger(n)&&n>=0;\n if(!value||Object.keys(value).sort().join(\',\')!==\'asOf,channels,companyCode,coverage,observationStartedAt,range,schema\'||value.schema!==\'palitra-response-report/v1\'||value.companyCode!==\'palitra-love\'||!Number.isFinite(Date.parse(value.asOf))||new Date(value.asOf).toISOString()!==value.asOf||value.observationStartedAt!==observation.startedAt||!value.coverage||value.coverage.status!==(observation.status===\'EXISTING\'?\'observing\':\'not_started\')||value.coverage.beforeObservation!==\'excluded\'||!Array.isArray(value.channels)||value.channels.length!==6)throw Error(\'SHAPE\');\n for(let i=0;i<channels.length;i++){const c=value.channels[i];if(!c||c.id!==channels[i]||c.status!==\'unobserved\'||!count(c.first?.sampleCount)||!count(c.subsequent?.sampleCount)||!count(c.waiting?.count)||!count(c.beforeObservationWaiting?.count))throw Error(\'COUNTS\');}\n if(db.prepare(\'SELECT total_changes() AS changes\').get().changes!==0)throw Error(\'WRITE\');\n process.stdout.write(JSON.stringify({schema:value.schema,companyCode:value.companyCode,asOf:value.asOf,coverageStatus:value.coverage.status,observation,channels:value.channels.map(c=>({id:c.id,firstSamples:c.first.sampleCount,subsequentSamples:c.subsequent.sampleCount,waitingCount:c.waiting.count,beforeObservationWaitingCount:c.beforeObservationWaiting.count}))}));\n} catch(_) {process.stdout.write(JSON.stringify({status:\'RESPONSE_READONLY_PREFLIGHT_REFUSED\'}));process.exitCode=2;}\nfinally {if(db)try{db.close();}catch(_){process.exitCode=2;}}\n'

NEBO_ADAPTER_SHA = '601c6b8925dbb761465f3072cebb041731b40bb50420394a02df936c6016389c'
NEBO_BASIS_SHA = 'bcb5cefafdd9c6de48fab772fe4c0308dcdada273f9714c813f61c7831f02c6a'
NEBO_BASIS_PATH = ROOT/(NAME+'-nebo-basis.json')
NEBO_AUTH_SHA = 'b0dde548b7f252591858607604708d4d96847968e90f0147a50881c6a9ca074a'
NEBO_SUPPLEMENT_NAMES = ('auth-store.js','site-store.js','site-workspace-feature.js','site-workspaces.js')

def _load_module(raw,path):
    module=types.ModuleType('exact_manager_parent_basis');module.__file__=str(path)
    exec(compile(raw,str(path),'exec'),module.__dict__);return module

def load_current_notify_r2(pid):
    path=CODE/'parent-notify-r2.py'
    for part in [*reversed(path.parents),path]:need(not part.is_symlink(),'PARENT_LOADER_SYMLINK_REFUSED')
    raw=path.read_bytes();need(sha(raw)==PARENT_LOADER_SHA,'EXACT_MANAGER_PARENT_LOADER_REQUIRED')
    a,b,prior,current=_load_module(raw,path).load_current_notify_r2(pid)
    adapter=CODE/'nebo-basis-v5.py';raw=adapter.read_bytes();need(sha(raw)==NEBO_ADAPTER_SHA,'EXACT_NEBO_REBASE_ADAPTER_REQUIRED')
    return _load_module(raw,adapter).load(a,b,prior,current,pid,pin=NEBO_BASIS_SHA)

def validate_records(manifest):
    need(type(EXPECTED_RECORDS) is list and len(EXPECTED_RECORDS)==11,'PRODUCT_BINDINGS_PENDING')
    need(type(manifest) is dict and set(manifest)=={'schema','build','records'} and manifest['schema']==1
         and manifest['build']=='synapse-company-app-20261020-darya-workspace-r2' and manifest['records']==EXPECTED_RECORDS
         and len(manifest['records'])==11,'EXACT_DARYA_ELEVEN_FILE_MANIFEST_REQUIRED')
    expected={'product/'+n:('palitra-orders-public/'+n,n,False) for n in ('shell.js','shell.css','workflow-ui.js','native-host.js','cabinet.html')}
    expected.update({'backend/server.js':('server.js',None,False),'backend/palitra-workflow.cjs':('palitra-workflow.cjs',None,False),'backend/palitra-manager-attention.cjs':(ATTENTION_TARGET,None,True),'backend/palitra-response-report.cjs':(RESPONSE_TARGET,None,True)})
    expected.update({'product/'+n:('palitra-orders-public/'+n,n,True) for n in ('palitra-response-report-ui.js','palitra-content-tasks-ui.js')})
    result={}
    for row in manifest['records']:
        need(type(row) is dict and set(row)=={'name','target','sha256','bytes','beforeSha256','beforeSourceSha256','static'}
             and row['name'] in expected and row['name'] not in result and digest(row['sha256']) and type(row['bytes']) is int
             and 0<row['bytes']<=2*1024*1024,'EXACT_MANAGER_RECORD_REQUIRED')
        target,static,added=expected[row['name']]
        need(row['target']==target and row['static']==static,'EXACT_MANAGER_TARGET_REQUIRED')
        need((row['beforeSha256'] is None and row['beforeSourceSha256'] is None) if added else
             (digest(row['beforeSha256']) and row['beforeSourceSha256']==row['beforeSha256']),'EXACT_MANAGER_BEFORE_PIN_REQUIRED')
        result[row['name']]=row
    need(set(result)==set(expected) and sum(r['static'] is not None for r in result.values())==7,'EXACT_DARYA_ELEVEN_FILE_CLOSURE_REQUIRED')
    need(result['backend/server.js']['beforeSourceSha256']==GROUP_OFF_SERVER_SHA and result['backend/palitra-manager-attention.cjs']['sha256']==ATTENTION_MODULE_SHA and result['backend/palitra-response-report.cjs']['sha256']==RESPONSE_MODULE_SHA and result['backend/palitra-workflow.cjs']['beforeSourceSha256']==ATTENTION_DEPENDENCIES['palitra-workflow.cjs'] and result['backend/palitra-workflow.cjs']['sha256']==WORKFLOW_AFTER_SHA,'EXACT_MANAGER_GROUP_OFF_AND_ATTENTION_MODULE_REQUIRED')
    return result


def create_managed_guard(release):
    a=release.a
    raw=a.read(CODE/'managed-source.py');probe=a.read(CODE/'managed-source-probe.cjs')
    need(sha(raw)==MANAGED_HELPER_SHA and sha(probe)==MANAGED_PROBE_SHA,'EXACT_MANAGED_GUARD_CODE_REQUIRED')
    need(digest(MANAGED_PROOF_SHA),'MANAGED_SOURCE_PROOF_NOT_FROZEN')
    proof=a.pinned(MANAGED_PROOF_PATH,MANAGED_PROOF_SHA,True)
    outcome=a.pinned(CODE/'MAP_OUTCOME.json',MAP_OUTCOME_SHA)
    m=types.ModuleType('r7c_managed_source');m.__file__=str(CODE/'managed-source.py');exec(compile(raw,m.__file__,'exec'),m.__dict__)
    definition={'schema':1,'status':'FROZEN','probeSha256':MANAGED_PROBE_SHA,'mapOutcomeSha256':MAP_OUTCOME_SHA,'proof':proof}
    return m.ManagedSource(definition,outcome,release.current.managed,probe,release.run,a.decode,release.lease)

class Release:
    def __init__(self,a,b,prior,current,pid,inspection_pin=None):
        need(all(digest(pin) for pin in (MANIFEST_SHA,PRODUCT_REVIEW_SHA,PRODUCT_MANIFEST_SHA,ROOT_PRODUCT_ACCEPTANCE_SHA,NEBO_ADAPTER_SHA,NEBO_BASIS_SHA,ROLLBACK_SHA)),'PRODUCT_BINDINGS_PENDING')
        self.a,self.b,self.prior,self.current,self.pid=a,b,prior,current,pid
        self.run,self.files=b.run,prior.FileOps();self.base=copy.deepcopy(current.base)
        self.paths={n:ROOT/(NAME+'-'+n+('.json' if n in ('decision','journal','overlay') else '')) for n in ('decision','journal','overlay','context','backup')}
        self.inspection_pin,self.inspection_state,self.writer_pid=inspection_pin,None,pid
        if inspection_pin is not None:
            need(digest(inspection_pin),'EXPLICIT_OWN_INSPECTION_RECEIPT_REQUIRED')
            self.inspection_state=a.pinned(self.paths['journal'],inspection_pin,True)
            need(self.inspection_state.get('name')==NAME and self.inspection_state.get('phase')=='APPLIED_NOT_CUSTOMER_ACCEPTANCE','EXACT_OWN_COMPLETED_INSPECTION_PROOF_REQUIRED')
            self.writer_pid=self.inspection_state['inputs']['freshLeasePid']
            need(type(self.writer_pid) is int and self.writer_pid>1,'EXACT_HISTORICAL_WRITER_PID_REQUIRED')
        need(len(current.source)==235 and len(current.static)==41 and len(current.base['containers']['content']['files'])==41,'EXACT_REBASED_NEBO_FULL235_41_41_REQUIRED')
        need(getattr(current,'parent_image',None)==PARENT and getattr(current,'parent_chain_count',None)==41 and getattr(current,'nebo_rebase_pin',None)==NEBO_BASIS_SHA and 'auth-store.js' not in current.source and getattr(current,'auth_supplement',{}).get('sha256')==NEBO_AUTH_SHA,'EXACT_SEALED_NEBO_PARENT_REQUIRED')
        supplement_pins=getattr(current,'module_supplement_pins',None)
        need(type(supplement_pins) is dict and set(supplement_pins)==set(NEBO_SUPPLEMENT_NAMES) and all(digest(pin) for pin in supplement_pins.values()) and supplement_pins['auth-store.js']==NEBO_AUTH_SHA,'EXACT_PINNED_STAGE_SUPPLEMENT_BINDING_REQUIRED')
        need(type(getattr(current,'module_supplements',None)) is dict and set(current.module_supplements)==set(NEBO_SUPPLEMENT_NAMES) and not set(NEBO_SUPPLEMENT_NAMES).intersection(current.source) and all(type(current.module_supplements[name]) is dict and current.module_supplements[name].get('sha256')==pin for name,pin in supplement_pins.items()),'EXACT_SEALED_FOUR_PLATFORM_SUPPLEMENTS_REQUIRED')
        self.cabinet=a.exact_path(current.cabinet)
        self.manifest=a.pinned(CODE/'payload/MANIFEST.json',MANIFEST_SHA);self.records=validate_records(self.manifest);self.source_records=dict(self.records)
        self.source,self.static=dict(current.source),dict(current.static);self.static_records,self.existing_sources,self.added_sources={},{},[]
        for row in self.records.values():
            raw=a.read(CODE/'payload'/row['name']);need(len(raw)==row['bytes'] and sha(raw)==row['sha256'],'PRODUCT_PAYLOAD_CHANGED')
            if row['beforeSourceSha256'] is None:
                need(row['target'] not in current.source,'NEW_SOURCE_COLLISION');self.added_sources.append(row['target'])
            else:
                need(current.source.get(row['target'])==row['beforeSourceSha256'],'SOURCE_BASE_R7C_MISMATCH');self.existing_sources[row['target']]=row
            self.source[row['target']]=row['sha256']
            if row['static'] is not None:
                target=str(self.cabinet/row['static']);need(current.static.get(target)==row['beforeSha256'],'STATIC_BASE_R7C_MISMATCH')
                self.static_records[target]=row;self.static[target]=row['sha256']
        need(len(self.source)==239 and len(self.static)==43 and len(self.existing_sources)==7 and set(self.added_sources)==ADDED_SOURCES and len(self.added_sources)==4 and len(self.static_records)==7,'EXACT_R11_CLOSED_COUNTS_REQUIRED')
        self.pins={str(Path(__file__)):sha(Path(__file__).read_bytes()),str(CODE/'parent-notify-r2.py'):PARENT_LOADER_SHA,str(CODE/'nebo-basis-v5.py'):NEBO_ADAPTER_SHA,str(NEBO_BASIS_PATH):NEBO_BASIS_SHA,str(CODE/'payload/MANIFEST.json'):MANIFEST_SHA,str(CODE/'ROLLBACK.md'):ROLLBACK_SHA,
            str(CODE/'traffic-db.py'):TRAFFIC_HELPER_SHA,str(CODE/'report-db.py'):DB_HELPER_SHA,str(CODE/'content-db.py'):CONTENT_HELPER_SHA,
            str(CODE/'ROOT_PRODUCT_ACCEPTANCE.json'):ROOT_PRODUCT_ACCEPTANCE_SHA,str(CODE/'GROUP_REVIEW.json'):GROUP_REVIEW_SHA,str(CODE/'PRODUCT_REVIEW.json'):PRODUCT_REVIEW_SHA,str(CODE/'PRODUCT_MANIFEST.json'):PRODUCT_MANIFEST_SHA,
            str(CODE/'managed-source.py'):MANAGED_HELPER_SHA,str(CODE/'managed-source-probe.cjs'):MANAGED_PROBE_SHA,str(CODE/'MAP_OUTCOME.json'):MAP_OUTCOME_SHA,str(MANAGED_PROOF_PATH):MANAGED_PROOF_SHA}
        modules={}
        for name,pin in [('report-db.py',DB_HELPER_SHA),('content-db.py',CONTENT_HELPER_SHA),('traffic-db.py',TRAFFIC_HELPER_SHA)]:
            raw=a.read(CODE/name);need(sha(raw)==pin,'FROZEN_DATABASE_GUARD_REQUIRED');m=types.ModuleType('r11_'+name);m.__file__=str(CODE/name);exec(compile(raw,m.__file__,'exec'),m.__dict__);modules[name]=m
        self.db=modules['report-db.py'].ReportDatabase(REPORT_DB_HOST,a.exact_path,self.files,self.data_mount)
        # No configure()/migrate(): only read, online backup and post-R7C schema guards.
        self.contentdb=modules['content-db.py'].ContentDatabase(CONTENT_DB_HOST,a.exact_path,self.files,self.content_data_mount)
        self.traffic=modules['traffic-db.py'].TrafficDatabase(TRAFFIC_DB_HOST,a.exact_path,self.files,self.content_data_mount,ROOT)
        product=a.pinned(CODE/'PRODUCT_REVIEW.json',PRODUCT_REVIEW_SHA);original=a.pinned(CODE/'PRODUCT_MANIFEST.json',PRODUCT_MANIFEST_SHA)
        need(product.get('status')=='ROOT_REVIEW_PENDING_NOT_INSTALLED'
             and product.get('build')=='synapse-company-app-20261020-darya-workspace-r2'
             and product.get('manifestSha256')==PRODUCT_MANIFEST_SHA
             and product.get('deltaFromInstalledNotifyR2')==original.get('deltaFromInstalledNotifyR2')==self.manifest['records']
             and product.get('installerAccepted') is False and product.get('runtimeApplyAuthorized') is False,'EXACT_MANAGER_CODE_ONLY_REVIEW_REQUIRED')
        root_product=a.pinned(CODE/'ROOT_PRODUCT_ACCEPTANCE.json',ROOT_PRODUCT_ACCEPTANCE_SHA)
        need(root_product.get('status')=='ACCEPTED_CURRENT36_COMPATIBILITY' and root_product.get('productRootReviewAccepted') is True
             and root_product.get('runtimeApplyAuthorized') is False and root_product.get('productReviewReadySha256')==PRODUCT_REVIEW_SHA
             and root_product.get('productManifestSha256')==PRODUCT_MANIFEST_SHA,'EXACT_CODE_ONLY_ROOT_PRODUCT_ACCEPTANCE_REQUIRED')
        group=a.pinned(CODE/'GROUP_REVIEW.json',GROUP_REVIEW_SHA)
        need(group.get('status')=='ACCEPTED_CURRENT36_COMPATIBILITY_CODE_ONLY_NOT_INSTALLER'
             and group.get('task')=='PALITRA_GROUP_ORDER_NOTIFY_OFF_20261020'
             and group.get('baseRelease')=='multi-company-app-20261019-r7c'
             and group.get('files')==[{'name':'backend/server.js','target':'server.js','beforeSha256':'bda9c24e09409b773fcd6d3ab517ca92bc0257c3a3781ffa8f92d7a2e640236c','sha256':GROUP_OFF_SERVER_SHA,'bytes':125763}]
             and group.get('installed') is False and group.get('installerAccepted') is False and group.get('runtimeApplyAuthorized') is False,'EXACT_ACTUAL_QUEUE_GROUP_REVIEW_R2_REQUIRED')
        need(group.get('queueModuleSha256')==QUEUE_MODULE_SHA and current.source.get('site-orders.js')==QUEUE_MODULE_SHA
             and current.source.get('server.js')==GROUP_OFF_SERVER_SHA,'EXACT_NOTIFY_R2_GROUP_OFF_AND_QUEUE_REQUIRED')
        server=a.read(CODE/'payload/backend/server.js')
        need(server.count(b'groupNotificationSites: []')==1 and b"groupNotificationSites: ['palitra']" not in server,'MANAGER_MUST_PRESERVE_GROUP_NOTIFICATION_OFF')
        need(all(current.source.get(k)==pin for k,pin in ATTENTION_DEPENDENCIES.items()) and all(self.source.get(k)==pin for k,pin in AFTER_DEPENDENCIES.items()),'EXACT_ATTENTION_READONLY_SOURCE_DEPENDENCIES_REQUIRED')
        self.managed_guard=create_managed_guard(self)
        need(self.managed_guard.proof==current.managed_proof,'EXACT_R7C_MANAGED_PROOF_REQUIRED');b.lease=self.lease

    def lease(self):
        raw = self.run(['lslocks', '--noheadings', '--output', 'PID,PATH'])
        need(len(raw) <= 1048576, 'BOUNDED_LEASE_REQUIRED')
        rows = [r.strip().split(maxsplit=1) for r in raw.decode().splitlines() if len(r.strip().split(maxsplit=1)) == 2 and r.strip().split(maxsplit=1)[1] == LOCK]
        need(rows == [[str(self.pid), LOCK]], 'EXACT_OWN_SINGLE_WRITER_REQUIRED')

    def stable(self):
        self.current.stable()
        need(self.a.pinned(MANAGED_PROOF_PATH,MANAGED_PROOF_SHA,True)==self.managed_guard.proof,'SEALED_PRIVATE_MANAGED_PROOF_CHANGED')
        self.managed_guard.guard()
        for path,pin in self.pins.items():need(sha(self.a.read(Path(path)))==pin,'FROZEN_RECEIVER_CODE_CHANGED')
        for row in self.records.values():need(sha(self.a.read(CODE/'payload'/row['name']))==row['sha256'],'FROZEN_PRODUCT_CHANGED')
    def source_absence(self):
        if not self.added_sources:return
        script="const f=require('fs');for(const n of JSON.parse(process.argv[1])){try{f.lstatSync('/app/'+n);throw Error('NEW_SOURCE_ALREADY_EXISTS')}catch(e){if(e.code!=='ENOENT')throw e}}process.stdout.write('R11_NEW_SOURCES_ABSENT');"
        need(self.run(['docker','exec','synapse-content-1','node','-e',script,json.dumps(sorted(self.added_sources))])==b'R11_NEW_SOURCES_ABSENT','EXACT_R11_NEW_SOURCE_ABSENCE_REQUIRED')

    def traffic_checkpoint(self, state):
        current=self.traffic.guard(state['trafficDatabaseBackup'])
        if state['trafficDatabaseBackup']['status']=='ABSENT' and current['status']=='EXISTING':
            state['trafficDatabaseBackup']=self.traffic.backup(self.paths['backup']/'traffic.sqlite',current)
            need(state['trafficDatabaseBackup']['status']=='EXISTING','NEW_TRAFFIC_STORE_BACKUP_REQUIRED')
            self.update(state,state['phase'],trafficStoreAppearedDuringRelease=True)
        self.traffic.guard(state['trafficDatabaseBackup'])

    def attention_preflight(self,child):
        need(self.a.image(child) and child!=PARENT and self.source.get(ATTENTION_TARGET)==ATTENTION_MODULE_SHA,'EXACT_ATTENTION_CHILD_REQUIRED')
        self.lease();self.content_data_mount();self.contentdb.after_guard(self.current.content_migration)
        output=self.run(['docker','run','--rm','--network=none','--read-only','--cap-drop=ALL','--security-opt=no-new-privileges',
            '--mount','type=volume,source=synapse_content_data,target=/data,readonly','--entrypoint=node',child,'-e',ATTENTION_PREFLIGHT_JS,ATTENTION_MODULE_SHA])
        need(len(output)<=4096,'BOUNDED_ATTENTION_AGGREGATE_REQUIRED');value=self.a.decode(output)
        need(type(value) is dict and set(value)=={'schema','companyCode','scopeKey','filter','partial','asOf','counts','itemsLength','nextCursor'}
             and value['schema']=='palitra-manager-attention/v1' and value['companyCode']=='palitra-love' and value['scopeKey']=='palitra'
             and value['filter']=='all' and value['partial'] is False and type(value['asOf']) is str and len(value['asOf'])<=32
             and type(value['counts']) is dict and set(value['counts'])=={'total','attention','unanswered','firstContact'}
             and all(type(n) is int and 0<=n<=9007199254740991 for n in value['counts'].values())
             and value['counts']['attention']==value['counts']['unanswered']+value['counts']['firstContact']<=value['counts']['total']
             and type(value['itemsLength']) is int and value['itemsLength']==min(1,value['counts']['total'])
             and type(value['nextCursor']) is bool,'EXACT_READONLY_ATTENTION_AGGREGATE_REQUIRED')
        self.contentdb.after_guard(self.current.content_migration);self.lease()
        return sha(output)

    def response_preflight(self,child):
        need(self.a.image(child) and child!=PARENT and self.source.get(RESPONSE_TARGET)==RESPONSE_MODULE_SHA,'EXACT_RESPONSE_CHILD_REQUIRED')
        self.lease();self.content_data_mount();self.contentdb.after_guard(self.current.content_migration)
        output=self.run(['docker','run','--rm','--network=none','--read-only','--cap-drop=ALL','--security-opt=no-new-privileges',
            '--mount','type=volume,source=synapse_content_data,target=/data,readonly','--entrypoint=node',child,'-e',RESPONSE_PREFLIGHT_JS,RESPONSE_MODULE_SHA])
        need(len(output)<=4096,'BOUNDED_RESPONSE_AGGREGATE_REQUIRED');value=self.a.decode(output)
        channels=['site','telegram','vk','instagram','youtube','tiktok']
        need(type(value) is dict and set(value)=={'schema','companyCode','asOf','coverageStatus','observation','channels'}
             and value['schema']=='palitra-response-report/v1' and value['companyCode']=='palitra-love'
             and type(value['asOf']) is str and re.fullmatch(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z',value['asOf'])
             and type(value['observation']) is dict and set(value['observation'])=={'status','documentSha256','startedAt'}
             and type(value['channels']) is list and len(value['channels'])==6,'EXACT_READONLY_RESPONSE_AGGREGATE_REQUIRED')
        observation=value['observation']
        need((observation['status']=='ABSENT' and observation['documentSha256'] is observation['startedAt'] is None and value['coverageStatus']=='not_started')
             or (observation['status']=='EXISTING' and digest(observation['documentSha256']) and type(observation['startedAt']) is str
                 and re.fullmatch(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z',observation['startedAt']) and value['coverageStatus']=='observing'),'EXACT_OBSERVATION_SEAL_REQUIRED')
        for expected,row in zip(channels,value['channels']):
            need(type(row) is dict and set(row)=={'id','firstSamples','subsequentSamples','waitingCount','beforeObservationWaitingCount'} and row['id']==expected
                 and all(type(row[k]) is int and 0<=row[k]<=9007199254740991 for k in row if k!='id'),'EXACT_RESPONSE_COUNTS_REQUIRED')
        self.contentdb.after_guard(self.current.content_migration);self.lease()
        return value

    def observation_guard(self,before,after,boot=False):
        need(type(before) is dict and type(after) is dict,'EXACT_OBSERVATION_SEAL_REQUIRED')
        if before.get('status')=='EXISTING':need(after==before,'EXISTING_OBSERVATION_DOCUMENT_CHANGED')
        else:
            need(before=={'status':'ABSENT','documentSha256':None,'startedAt':None},'EXACT_OBSERVATION_ABSENCE_REQUIRED')
            if not boot:need(after==before,'OBSERVATION_CHANGED_BEFORE_FEATURE_BOOT')
            else:need(after.get('status')=='EXISTING' and set(after)=={'status','documentSha256','startedAt'} and digest(after['documentSha256']) and type(after['startedAt']) is str,'FEATURE_BOOT_OBSERVATION_NOT_VALIDATED')
        return after

    def supplement_guard(self,child=False):
        return self.current.observe_supplement(self.a,self.run,self.current.source_script,self.lease,
            self.current.source[SUPPLEMENT_NAME],self.current.supplement_mode,self.current.supplement_bytes)

    def metadata(self, child=None, proof=None):
        expected = copy.deepcopy(self.base['containers']['content'])
        if child:
            need(type(proof) is dict and set(proof) == {'overlaySha256', 'plannedConfigHash'}
                 and all(digest(v) for v in proof.values()) and child != PARENT and self.a.image(child), 'EXPLICIT_CHILD_PROOF_REQUIRED')
            overlay = str(self.paths['overlay']); files = expected['files'] + [overlay]
            need(len(files) == len(set(files)) == 42 and sha(self.a.read(Path(overlay))) == proof['overlaySha256'], 'EXACT_NEW_CHAIN42_REQUIRED')
            expected.update(image=child, files=files, configFiles=','.join(files), filePins={**expected['filePins'], overlay: proof['overlaySha256']}, configHash=proof['plannedConfigHash'])
        row = self.a.decode(self.run(['docker', 'inspect', '--format', self.a.LABELS, 'synapse-content-1']))
        need(type(row) is dict and row.get('configFiles') == expected['configFiles'], 'COMPOSE_CHAIN_CHANGED')
        row.update(files=list(expected['files']), filePins={name: sha(self.a.read(Path(name))) for name in expected['files']})
        need(row == expected and self.b.metadata('chat') == self.base['containers']['chat'], 'COMPLETE_RUNTIME_METADATA_CHANGED')
        return {'content': row, 'chat': copy.deepcopy(self.base['containers']['chat'])}

    def report_db(self):
        script = "const f=require('fs'),p=require('path');const n=p.join(p.dirname(process.env.DATABASE_PATH||'/data/content.sqlite'),'salon-reports.sqlite');if(n!=='/data/salon-reports.sqlite')throw Error('EXACT_DATA_PATH_REQUIRED');const out={path:n,files:{}};for(const[k,suffix]of [['db',''],['wal','-wal'],['shm','-shm']]){let s;try{s=f.lstatSync(n+suffix)}catch(e){if(e.code!=='ENOENT')throw e}if(s&&(!s.isFile()||s.isSymbolicLink()||s.nlink!==1))throw Error('REGULAR_REPORT_GROUP_REQUIRED');out.files[k]=s?{uid:s.uid,mode:s.mode&511}:null}console.log(JSON.stringify(out));"
        return self.a.decode(self.run(['docker', 'exec', 'synapse-content-1', 'node', '-e', script]))

    def users(self, child=None):
        result = {'current': self.a.decode(self.run(['docker', 'inspect', '--format', self.prior.USER_FORMAT, 'synapse-content-1'])),
                  'parent': self.a.decode(self.run(['docker', 'image', 'inspect', '--format', self.prior.USER_FORMAT, PARENT]))}
        if child: result['child'] = self.a.decode(self.run(['docker', 'image', 'inspect', '--format', self.prior.USER_FORMAT, child]))
        need(all(type(v) is str and v in self.prior.ROOT_USERS for v in result.values())
             and (not child or result['parent'] == result['child']), 'PRESERVED_ROOT_SERVICE_USER_REQUIRED')
        return result

    def source_modes(self, child=False):
        names = sorted((row['target'] for row in self.source_records.values()) if child else self.existing_sources)
        script = self.prior.SOURCE_FACTS_JS
        value = self.a.decode(self.run(['docker', 'exec', 'synapse-content-1', 'node', '-e', script, json.dumps(names)]))
        need(type(value) is dict and set(value) == set(names) and all(v.get('uid') == v.get('gid') == 0 and v.get('mode') in (0o600, 0o644) for v in value.values()), 'ROOT_SOURCE_MODES_REQUIRED')
        if not child:
            for name in self.added_sources: value[name] = {'uid': 0, 'gid': 0, 'mode': 0o644}
        return value

    def static_modes(self, changed=frozenset()):
        result = {}
        for target, row in self.static_records.items():
            path = self.a.exact_path(Path(target), row['beforeSha256'] is None and target not in changed)
            if row['beforeSha256'] is None and target not in changed:
                need(not os.path.lexists(path), 'NEW_STATIC_TARGET_ALREADY_EXISTS'); result[target] = 0o644; continue
            s = path.stat()
            need(stat.S_ISREG(s.st_mode) and s.st_uid == s.st_gid == 0 and stat.S_IMODE(s.st_mode) in (0o600, 0o644), 'EXACT_ROOT_STATIC_MODES_REQUIRED')
            result[target] = stat.S_IMODE(s.st_mode)
        return result

    def snapshot(self, child=None, changed=frozenset(), proof=None):
        self.stable(); self.lease()
        first = self.metadata(child, proof); worker = self.b.worker_facts(); selected = {s: self.b.a.selected(s) for s in ('content', 'chat')}
        flags = self.a.decode(self.run(['docker', 'exec', 'synapse-content-1', 'node', '-e', self.a.FLAGS_JS]))
        need(worker == self.base['worker'] and selected == self.base['selected'] and flags == self.base['l12'], 'WORKER_FLAGS_SELECTION_CHANGED')
        for service, row in first.items():
            value = self.run(self.b._resolve_command(row, service)).decode('ascii').strip()
            need(re.fullmatch(re.escape(service) + r'\s+' + re.escape(row['configHash']), value) is not None, 'RESOLVED_COMPOSE_HASH_CHANGED')
        self.b.graph(new=True); self.b.push_guard()
        source = self.source if child else self.current.source
        need(self.b.photo.hashes(source) == source, 'FULL_SOURCE_INVENTORY_CHANGED')
        self.supplement_guard(bool(child))
        if not child:self.source_absence()
        self.traffic.read()
        expected = dict(self.current.static)
        for target in changed: need(target in self.static_records, 'UNKNOWN_STATIC_TARGET'); expected[target] = self.static[target]
        for name, pin in expected.items(): need(sha(self.a.read(Path(name))) == pin, 'FULL_STATIC_INVENTORY_CHANGED')
        self.static_modes(changed)
        cid = self.b.photo.cid()
        need(first == self.metadata(child, proof) and worker == self.b.worker_facts() and selected == {s: self.b.a.selected(s) for s in ('content', 'chat')}
             and cid == self.b.photo.cid(), 'CONCURRENT_NATIVE_CHANGE')
        self.stable(); self.lease()
        return {'containers': first, 'selected': selected, 'worker': worker, 'contentCid': cid, 'l12': flags}

    def data_mount(self):
        mounts = self.a.decode(self.run(['docker','inspect','--format','{{json .Mounts}}','synapse-content-1']))
        need(type(mounts) is list, 'EXACT_DATA_MOUNT_LIST_REQUIRED')
        rows = [r for r in mounts if r.get('Destination') == '/data']
        need(len(rows) == 1 and rows[0].get('Type') == 'volume' and rows[0].get('Name') == 'synapse_content_data'
             and rows[0].get('Source') == str(REPORT_DB_HOST.parent) and rows[0].get('RW') is True, 'EXACT_EXISTING_REPORT_VOLUME_REQUIRED')

    def content_data_mount(self):
        self.data_mount()
        script="process.stdout.write(process.env.DATABASE_PATH||'/data/content.sqlite')"
        need(self.run(['docker','exec','synapse-content-1','node','-e',script])==b'/data/content.sqlite','EXACT_RUNNING_CONTENT_DATABASE_PATH_REQUIRED')

    def baseline(self):
        snap = self.snapshot()
        need(snap == self.base and self.b.heartbeat(snap['worker']['startedAt'], time.time())['freshAfterWorkerStart'], 'FRESH_EXACT_NEBO_NOTIFY_REQUIRED')
        need(private_report_db(self.report_db()), 'EXISTING_PRIVATE_REPORT_DB_REQUIRED')
        self.db.guard(self.current.report_minimum); self.contentdb.after_guard(self.current.content_migration); self.users()
        return snap

    def binding(self):
        return {'productRootAcceptance':ROOT_PRODUCT_ACCEPTANCE_SHA,'parentLoader':PARENT_LOADER_SHA,'neboAdapter':NEBO_ADAPTER_SHA,'neboBasis':NEBO_BASIS_SHA,'attentionModuleSha256':ATTENTION_MODULE_SHA,'attentionDependencies':ATTENTION_DEPENDENCIES,'afterDependencies':AFTER_DEPENDENCIES,'responseModuleSha256':RESPONSE_MODULE_SHA,'workflowModuleSha256':WORKFLOW_AFTER_SHA,'observationKey':OBSERVATION_KEY,'featureBootObservationAppendMaximum':1,'groupReview':GROUP_REVIEW_SHA,'queueModuleSha256':QUEUE_MODULE_SHA,'parentReceipt':PARENT_RECEIPT,'parentImage':PARENT,'productReview':PRODUCT_REVIEW_SHA,'dbGuard':DB_HELPER_SHA,'contentDbGuard':CONTENT_HELPER_SHA,'trafficDbGuard':TRAFFIC_HELPER_SHA,
            'manifest':MANIFEST_SHA,'helper':self.pins[str(Path(__file__))],'freshLeasePid':self.writer_pid,
            'managedProofSha256':MANAGED_PROOF_SHA,'managedProbeSha256':MANAGED_PROBE_SHA,'mapOutcomeSha256':MAP_OUTCOME_SHA,'managedSourceProof':self.managed_guard.proof,
            'parentPostSchemaSha256':self.current.content_migration['afterSchemaSha256'],'sourceCounts':{'before':235,'after':239},
            'beforeSource':self.current.source,'afterSource':self.source,'beforeStatic':self.current.static,'afterStatic':self.static}
    def inspect_current(self):
        need(self.inspection_state is None,'OWN_INSPECTION_CANNOT_REUSE_PREFLIGHT');self.baseline()
        return {'status':'CURRENT_NEBO_NOTIFY_READONLY_NOT_APPROVED','sourceFiles':235,'staticFiles':41,'chainFiles':41,'candidateSourceFiles':239,'candidateStaticFiles':43,
            'sourceModes':self.source_modes(),'staticModes':self.static_modes(),'reportDatabaseBefore':self.report_db(),'contentSchemaObjectsCreated':0,'runtimeWrites':0}

    def acceptance(self, pin):
        need(digest(ROOT_PRODUCT_ACCEPTANCE_SHA),'EXACT_CODE_ONLY_ROOT_PRODUCT_ACCEPTANCE_REQUIRED')
        value = self.a.pinned(CODE / 'ROOT_ACCEPTANCE.json', pin, True)
        need(type(value) is dict and value.get('status') == 'ACCEPTED_DARYA_WORKSPACE_R2_PRODUCT_AND_INSTALLER'
             and value.get('runtimeApplyAuthorized') is True and value.get('productRootReviewAccepted') is True and value.get('writerThreadId') == '01a0a408-4f98-7713-a652-e6a741da834c'
             and value.get('rootProductAcceptanceSha256')==ROOT_PRODUCT_ACCEPTANCE_SHA and value.get('parentLoaderSha256')==PARENT_LOADER_SHA and value.get('neboAdapterSha256')==NEBO_ADAPTER_SHA and value.get('neboBasisSha256')==NEBO_BASIS_SHA and value.get('parentImage')==PARENT and value.get('attentionModuleSha256')==ATTENTION_MODULE_SHA and value.get('attentionDependencies')==ATTENTION_DEPENDENCIES
             and value.get('afterDependencies')==AFTER_DEPENDENCIES and value.get('responseModuleSha256')==RESPONSE_MODULE_SHA and value.get('workflowModuleSha256')==WORKFLOW_AFTER_SHA
             and value.get('observationKey')==OBSERVATION_KEY and value.get('featureBootObservationAppendMaximum')==1
             and value.get('groupReviewSha256')==GROUP_REVIEW_SHA and value.get('queueModuleSha256')==QUEUE_MODULE_SHA
             and value.get('parentReceiptSha256') == PARENT_RECEIPT and value.get('productReviewSha256') == PRODUCT_REVIEW_SHA
             and value.get('dbGuardSha256') == DB_HELPER_SHA and value.get('contentDbGuardSha256') == CONTENT_HELPER_SHA and value.get('trafficDbGuardSha256') == TRAFFIC_HELPER_SHA
             and value.get('installerStatus') == 'ACCEPTED_DARYA_WORKSPACE_R2_INSTALLER_AND_ROLLBACK'
              and value.get('manifestSha256') == MANIFEST_SHA
              and value.get('managedProofSha256') == MANAGED_PROOF_SHA and value.get('mapOutcomeSha256') == MAP_OUTCOME_SHA
              and value.get('managedProbeSha256') == MANAGED_PROBE_SHA and value.get('managedSourceProof') == self.managed_guard.proof
              and value.get('sourceCounts') == {'before':235,'after':239} and value.get('contentSchemaObjectsCreated') == 0 and value.get('parentPostSchemaSha256') == self.current.content_migration['afterSchemaSha256']
             and value.get('helperSha256') == self.pins[str(Path(__file__))]
             and value.get('rollbackSha256') == ROLLBACK_SHA
             and value.get('reviewerThreadId') == '01a0a408-4f98-7713-a652-e6a741da834c',
             'EXACT_PRODUCT_AND_INSTALLER_ROOT_ACCEPTANCE_REQUIRED')
        return value

    def unused(self, allow_decision=False):
        for name, path in self.paths.items():
            if name == 'decision' and allow_decision: continue
            self.a.exact_path(path, True)
            need(not os.path.lexists(path) and not os.path.lexists(str(path) + '.pending'), 'OWN_ATTEMPT_EXISTS_NO_RETRY')
        for target in self.static_records:
            pending = Path(target).with_name(Path(target).name + '.' + NAME + '.pending')
            self.a.exact_path(pending, True); need(not os.path.lexists(pending), 'OWN_STATIC_PENDING_EXISTS_NO_RETRY')

    def approve(self, acceptance_pin, apply=False):
        need(self.inspection_state is None, 'OWN_INSPECTION_CANNOT_APPROVE')
        need(apply is True and digest(acceptance_pin), 'EXPLICIT_ROOT_ACCEPTED_APPROVAL_REQUIRED')
        self.unused(); self.acceptance(acceptance_pin); before = self.baseline()
        value = {'schema': 1, 'name': NAME, 'inputs': self.binding(), 'before': before,
                 'observedAtUtc': self.a.stamp(time.time()), 'sourceModes': self.source_modes(), 'staticModes': self.static_modes(),
                 'rootAcceptanceSha256': acceptance_pin, 'reportDatabaseBefore': self.report_db(), 'reportDatabaseContentBefore': self.db.read(), 'contentDatabaseBefore': self.contentdb.read(), 'trafficDatabaseBefore':self.traffic.read(), 'serviceUsers': self.users()}
        self.a.write_new(self.paths['decision'], value)
        return {'status': 'NEW_DECISION_NOT_APPLIED', 'decisionSha256': sha(self.a.read(self.paths['decision'])), 'runtimeWrites': 0}

    def decision(self, pin, fresh=True):
        value = self.a.pinned(self.paths['decision'], pin, True)
        need(type(value) is dict and set(value) == {'schema', 'name', 'inputs', 'before', 'observedAtUtc', 'sourceModes', 'staticModes', 'rootAcceptanceSha256', 'reportDatabaseBefore', 'reportDatabaseContentBefore', 'contentDatabaseBefore', 'trafficDatabaseBefore', 'serviceUsers'}
             and value['schema'] == 1 and value['name'] == NAME and value['inputs'] == self.binding()
             and value['before'] == self.base and private_report_db(value['reportDatabaseBefore']),
             'EXACT_OWN_DECISION_REQUIRED')
        self.acceptance(value['rootAcceptanceSha256'])
        need(value['serviceUsers'] == self.users(), 'APPROVED_SERVICE_USERS_CHANGED')
        if fresh:
            self.a.fresh(value['observedAtUtc'], time.time())
            self.db.guard(value['reportDatabaseContentBefore']); self.contentdb.guard(value['contentDatabaseBefore']);self.traffic.guard(value['trafficDatabaseBefore'])
        return value

    def update(self, journal, phase, **fields):
        journal.update(phase=phase, **fields); self.a.replace(self.paths['journal'], journal)

    def context_proof(self, state, built=False):
        context = self.paths['context']
        wanted = {'Dockerfile': sha(('FROM ' + NAME + '-base\nCOPY app/ /app/\n').encode())}
        wanted.update({'app/' + row['target']: row['sha256'] for row in self.source_records.values()})
        wanted.update({'static/' + str(i): row['sha256'] for i, row in enumerate(state['static'])})
        actual = {}
        directories = {'app', 'static'} | {'app/' + str(p) for r in self.source_records.values() for p in PurePosixPath(r['target']).parents if str(p) != '.'}
        for path in context.rglob('*'):
            self.a.exact_path(path)
            if path.is_file():
                relative = path.relative_to(context).as_posix()
                if built and relative == 'image.id': continue
                actual[relative] = sha(self.a.read(path))
            else: need(path.is_dir() and path.relative_to(context).as_posix() in directories, 'UNEXPECTED_BUILD_DIRECTORY')
        need(actual == wanted, 'EXACT_CLOSED_BUILD_CONTEXT_REQUIRED')
        for target, mode in state['sourceModes'].items():
            need(self.files.mode(context / 'app' / target) == mode['mode'], 'SOURCE_CONTEXT_MODE_CHANGED')
        return sha(json.dumps(sorted(actual.items()), separators=(',', ':')).encode())

    def backups(self, state):
        directory = self.a.exact_path(self.paths['backup']); s = directory.stat()
        need(stat.S_ISDIR(s.st_mode) and s.st_uid == 0 and stat.S_IMODE(s.st_mode) == 0o700
             and state['backupIdentity'] == [s.st_dev, s.st_ino, s.st_uid], 'PRIVATE_BACKUP_DIRECTORY_CHANGED')
        need(len(state['sourceBackups']) == len(self.existing_sources)
             and {r['target']: r['baseSha256'] for r in state['sourceBackups']} == {k: v['beforeSourceSha256'] for k, v in self.existing_sources.items()}
             and len(state['static']) == len(self.static_records)
             and {r['target'] for r in state['static']} == set(self.static_records), 'EXACT_COMPLETE_BACKUP_INVENTORY_REQUIRED')
        for row in state['static']:
            record = self.static_records[row['target']]
            need(row['baseSha256'] == record['beforeSha256'] and row['sha256'] == record['sha256']
                 and (row['backup'] is None) == (record['beforeSha256'] is None), 'STATIC_BACKUP_RECORD_CHANGED')
        self.db.backup_guard(state['reportDatabaseBackup'])
        need(Path(state['reportDatabaseBackup']['path']) == directory / 'reports.sqlite', 'EXACT_REPORT_BACKUP_PATH_REQUIRED')
        self.contentdb.backup_guard(state['contentDatabaseBackup'])
        need(Path(state['contentDatabaseBackup']['path']) == directory / 'content.sqlite', 'EXACT_CONTENT_BACKUP_PATH_REQUIRED')
        self.traffic.backup_guard(state['trafficDatabaseBackup'])
        self.traffic.guard(state['trafficDatabaseBackup'])
        wanted = {'reports.sqlite', 'content.sqlite'}
        if state['trafficDatabaseBackup']['status']=='EXISTING':
            need(Path(state['trafficDatabaseBackup']['path'])==directory/'traffic.sqlite','EXACT_TRAFFIC_BACKUP_PATH_REQUIRED');wanted.add('traffic.sqlite')
        for row in state['sourceBackups'] + state['static']:
            if row['backup'] is None: continue
            p = Path(row['backup']); need(p.parent == directory, 'BACKUP_BOUNDARY_REQUIRED'); wanted.add(p.name)
            self.a.exact_path(p); info = p.stat()
            need(stat.S_ISREG(info.st_mode) and info.st_uid == 0 and self.files.mode(p) == 0o600
                 and sha(self.a.read(p)) == row['baseSha256'], 'PRIVATE_EXACT_BACKUP_CHANGED')
        need({p.name for p in directory.iterdir()} == wanted, 'CLOSED_BACKUP_DIRECTORY_REQUIRED')

    def publish(self, row, state, pin):
        self.backups(state); self.decision(pin); self.snapshot(changed=frozenset(state['written']))
        target = self.a.exact_path(Path(row['target']), row['baseSha256'] is None)
        if row['baseSha256'] is None: need(not os.path.lexists(target), 'ADDED_STATIC_COLLISION')
        else: need(sha(self.a.read(target)) == row['baseSha256'] and self.files.mode(target) == row['mode'], 'STATIC_CAS_CHANGED')
        raw = self.a.read(Path(row['prepared'])); need(sha(raw) == row['sha256'], 'PREPARED_STATIC_CHANGED')
        pending = target.with_name(target.name + '.' + NAME + '.pending')
        self.a.exact_path(pending, True); self.files.write(pending, raw, row['mode'])
        self.snapshot(changed=frozenset(state['written'])); self.decision(pin); self.lease()
        need(sha(self.a.read(pending)) == row['sha256'] and self.files.mode(pending) == row['mode'], 'STATIC_PENDING_CHANGED')
        if row['baseSha256'] is None:
            os.link(pending, target); os.unlink(pending)  # exclusive publication, never replace a newly appeared file
        else:
            need(sha(self.a.read(target)) == row['baseSha256'] and self.files.mode(target) == row['mode'], 'LAST_STATIC_CAS_CHANGED')
            os.replace(pending, target)
        state['written'].append(str(target))

    def apply(self, pin, apply=False):
        need(getattr(self,'inspection_state',None) is None, 'OWN_INSPECTION_CANNOT_APPLY')
        need(apply is True and digest(pin), 'EXPLICIT_OWN_APPLY_REQUIRED')
        self.unused(allow_decision=True); decision = self.decision(pin); before = self.baseline()
        need(self.source_modes() == decision['sourceModes'] and self.static_modes() == decision['staticModes'], 'APPROVED_FILE_MODES_CHANGED')
        alias, tag = NAME + '-base', NAME + '-content'
        for name in (alias, tag): need(not self.run(['docker', 'image', 'ls', '--quiet', '--filter', 'reference=' + name]).strip(), 'UNIQUE_NEW_IMAGE_ALIAS_REQUIRED')
        need(self.run(['docker', 'image', 'inspect', '--format', '{{.Id}}', PARENT]).decode().strip() == PARENT, 'EXACT_PARENT_IMAGE_REQUIRED')
        layers = self.a.decode(self.run(['docker', 'image', 'inspect', '--format', '{{json .RootFS.Layers}}', PARENT]))
        need(type(layers) is list and layers, 'EXACT_PARENT_LAYERS_REQUIRED')
        state = {'schema': 1, 'name': NAME, 'inputs': self.binding(), 'before': before, 'decisionSha256': pin, 'static': [],
                 'sourceBackups': [], 'written': [], 'sourceModes': decision['sourceModes'], 'automaticRetry': False,
                 'automaticCodeRollback': False, 'workerRecreated': False, 'mainDbRowDirectWrites': 0, 'queueEdits': 0, 'oldJournalWrites': 0,
                 'reportDatabaseBefore': decision['reportDatabaseBefore'], 'contentMigration':copy.deepcopy(self.current.content_migration), 'contentSchemaObjectsCreated':0, 'contentLegacyRowWrites':0, 'activationRowsCreated':0}
        self.a.write_new(self.paths['journal'], {**state, 'phase': 'CONTEXT_STARTED_UNKNOWN'})
        for path in (self.paths['context'], self.paths['backup']): self.files.directory(self.a.exact_path(path, True), 0o700)
        info = self.paths['backup'].stat(); state['backupIdentity'] = [info.st_dev, info.st_ino, info.st_uid]
        state['reportDatabaseBackup'] = self.db.backup(self.paths['backup'] / 'reports.sqlite', decision['reportDatabaseContentBefore'])
        state['contentDatabaseBackup'] = self.contentdb.backup(self.paths['backup'] / 'content.sqlite', decision['contentDatabaseBefore'])
        state['trafficDatabaseBackup']=self.traffic.backup(self.paths['backup']/'traffic.sqlite',decision['trafficDatabaseBefore'])
        self.update(state, 'DATABASE_BACKUP_SEALED_NOT_PUBLISHED')
        directories = {'app', 'static'} | {'app/' + str(p) for r in self.source_records.values() for p in PurePosixPath(r['target']).parents if str(p) != '.'}
        for relative in sorted(directories, key=lambda n: (n.count('/'), n)):
            self.files.directory(self.a.exact_path(self.paths['context'] / relative, True), 0o700 if relative == 'static' else 0o755)
        for target, row in sorted(self.existing_sources.items()):
            encoded = self.run(['docker', 'exec', 'synapse-content-1', 'node', '-e', self.current.source_script, target])
            need(len(encoded) < 3 * 1024 * 1024, 'BOUNDED_ORIGINAL_SOURCE_REQUIRED')
            raw = base64.b64decode(encoded, validate=True); need(sha(raw) == row['beforeSourceSha256'], 'SOURCE_BACKUP_BASE_CHANGED')
            backup = self.paths['backup'] / ('source-' + str(len(state['sourceBackups'])))
            self.files.write(backup, raw, 0o600); state['sourceBackups'].append({'target': target, 'baseSha256': row['beforeSourceSha256'], 'backup': str(backup)})
        for row in self.source_records.values():
            self.files.write(self.paths['context'] / 'app' / row['target'], self.a.read(CODE / 'payload' / row['name']), decision['sourceModes'][row['target']]['mode'])
        for target, row in sorted(self.static_records.items()):
            index = len(state['static']); prepared = self.paths['context'] / 'static' / str(index); backup = None
            raw = self.a.read(CODE / 'payload' / row['name']); self.files.write(prepared, raw, 0o600)
            if row['beforeSha256'] is not None:
                old = self.a.read(Path(target)); need(sha(old) == row['beforeSha256'], 'STATIC_BACKUP_BASE_CHANGED')
                backup = self.paths['backup'] / ('static-' + str(index)); self.files.write(backup, old, 0o600)
            state['static'].append({'target': target, 'baseSha256': row['beforeSha256'], 'sha256': row['sha256'], 'mode': decision['staticModes'][target],
                                    'backup': str(backup) if backup else None, 'prepared': str(prepared)})
        self.files.write(self.paths['context'] / 'Dockerfile', ('FROM ' + alias + '\nCOPY app/ /app/\n').encode(), 0o600)
        self.backups(state); self.update(state, 'CONTEXT_READY_NOT_BUILT', contextSha256=self.context_proof(state))
        self.baseline(); self.decision(pin); self.lease()
        self.run(['docker', 'image', 'tag', PARENT, alias]); need(self.run(['docker', 'image', 'inspect', '--format', '{{.Id}}', alias]).decode().strip() == PARENT, 'PARENT_ALIAS_CHANGED')
        self.update(state, 'BUILD_STARTED_UNKNOWN'); need(self.context_proof(state) == state['contextSha256'], 'LAST_CONTEXT_CHANGED')
        self.run(['docker', 'build', '--network=none', '--pull=false', '--tag', tag, '--iidfile', str(self.paths['context'] / 'image.id'), str(self.paths['context'])])
        child = self.a.read(self.paths['context'] / 'image.id').decode().strip()
        need(self.a.image(child) and child != PARENT and self.run(['docker', 'image', 'inspect', '--format', '{{.Id}}', tag]).decode().strip() == child, 'EXACT_CHILD_IMAGE_REQUIRED')
        child_layers = self.a.decode(self.run(['docker', 'image', 'inspect', '--format', '{{json .RootFS.Layers}}', child]))
        need(type(child_layers) is list and child_layers[:len(layers)] == layers and len(child_layers) == len(layers) + 1, 'ONE_COPY_LAYER_REQUIRED')
        need(self.context_proof(state, True) == state['contextSha256'] and self.b.photo.hashes(self.source, child) == self.source, 'FULL_CHILD_SOURCE_CHANGED')
        supplement_child_check = ";{const f=require('node:fs'),c=require('node:crypto'),p='/app/project-chat.js',s=f.lstatSync(p);if(!s.isFile()||s.isSymbolicLink()||s.nlink!==1||s.uid!==0||s.gid!==0||f.realpathSync(p)!==p||(s.mode&511)!==" + str(self.current.supplement_mode) + "||c.createHash('sha256').update(f.readFileSync(p)).digest('hex')!==" + json.dumps(self.source[SUPPLEMENT_NAME]) + ")throw Error('EXACT_CHILD_SOURCE_SUPPLEMENT_REQUIRED');}"
        script = self.prior.CHILD_CHECK_JS + supplement_child_check + ";const {DatabaseSync}=require('node:sqlite');const r=require('/app/company-app/runtime.cjs').create({db:new DatabaseSync(':memory:')});r.close();"
        output = self.run(['docker', 'run', '--rm', '--network=none', '--read-only', '--cap-drop=ALL', '--security-opt=no-new-privileges', '--entrypoint=node', child, '-e', script, json.dumps(decision['sourceModes'])])
        need(output == b'PRECHECK_OK', 'CHILD_SYNTAX_RUNTIME_PREFLIGHT_REQUIRED')
        self.users(child)
        projection=self.attention_preflight(child)
        response=self.response_preflight(child)
        self.update(state,'CHILD_READONLY_PROJECTIONS_CHECKED',attentionReadOnlyValidated=True,attentionPreflightSha256=projection,responseReadOnlyValidated=True,responsePreflightSha256=sha(json.dumps(response,sort_keys=True).encode()),responseObservationBefore=response['observation'],featureBootObservationAppendMaximum=1)
        self.baseline(); self.decision(pin); self.backups(state)
        self.update(state, 'STATIC_STARTED_UNKNOWN', childImage=child)
        for row in sorted(state['static'], key=lambda row: (Path(row['target']).name == 'cabinet.html', row['target'])):
            self.publish(row, state, pin); self.update(state, 'STATIC_STARTED_UNKNOWN')
        need(self.snapshot(changed=frozenset(state['written'])) == before, 'LAST_PARENT_WITH_PUBLISHED_STATIC_CHANGED')
        self.a.write_new(self.paths['overlay'], {'services': {'content': {'image': child}}})
        proof = {'overlaySha256': sha(self.a.read(self.paths['overlay'])), 'plannedConfigHash': self.b.plan(before, 'content', self.paths['overlay'])}
        self.update(state, 'CONTENT_UP_STARTED_UNKNOWN', **proof)
        self.decision(pin); self.lease(); self.backups(state); self.stable()
        need(self.context_proof(state, True) == state['contextSha256'] and self.b.plan(before, 'content', self.paths['overlay']) == proof['plannedConfigHash'], 'LAST_CONTEXT_OR_COMPOSE_PLAN_CHANGED')
        self.lease()
        self.backups(state)
        need(self.snapshot(changed=frozenset(state['written'])) == before, 'LAST_NATIVE_BASIS_CHANGED')
        need(private_report_db(self.report_db()), 'LAST_PRIVATE_REPORT_GROUP_REQUIRED')
        self.db.guard(state['reportDatabaseBackup'])
        self.lease()
        self.contentdb.guard(state['contentDatabaseBackup'])
        self.managed_guard.guard(); self.lease()
        state['contentMigration']=copy.deepcopy(self.current.content_migration)
        state['contentSchemaObjectsCreated']=0;state['contentLegacyRowWrites']=0;state['activationRowsCreated']=0
        self.update(state,'CONTENT_UP_STARTED_UNKNOWN')
        need(self.snapshot(changed=frozenset(state['written']))==before,'LAST_CODE_ONLY_NATIVE_BASIS_CHANGED')
        need(private_report_db(self.report_db()),'LAST_PRIVATE_REPORT_GROUP_REQUIRED')
        self.db.guard(state['reportDatabaseBackup']);self.contentdb.guard(state['contentDatabaseBackup']);self.contentdb.after_guard(state['contentMigration']);self.stable();self.lease()
        self.managed_guard.guard(); self.lease()
        self.traffic_checkpoint(state);self.lease()
        projection=self.attention_preflight(child)
        response=self.response_preflight(child);self.observation_guard(state['responseObservationBefore'],response['observation'])
        self.update(state,'CONTENT_UP_STARTED_UNKNOWN',attentionReadOnlyValidated=True,attentionPreflightSha256=projection,responseReadOnlyValidated=True,responsePreflightSha256=sha(json.dumps(response,sort_keys=True).encode()))
        self.lease()
        need(self.snapshot(changed=frozenset(state['written']))==before,'LAST_ATTENTION_NATIVE_BASIS_CHANGED')
        self.b.up(before, 'content', self.paths['overlay'])
        self.managed_guard.guard(); self.lease()
        after = self.snapshot(child, frozenset(state['written']), proof)
        need(after['contentCid'] != before['contentCid'] and self.source_modes(True) == decision['sourceModes'], 'EXACT_NEW_CONTENT_AND_MODES_REQUIRED')
        self.contentdb.after_guard(state['contentMigration'])
        report_db = self.report_db(); need(private_report_db(report_db), 'PRIVATE_REPORT_DB_PRESERVED_REQUIRED')
        self.db.guard(state['reportDatabaseBackup'])
        self.traffic_checkpoint(state);self.traffic.guard(state['trafficDatabaseBackup'])
        response_after=self.response_preflight(child)
        observation=self.observation_guard(state['responseObservationBefore'],response_after['observation'],boot=True)
        self.update(state, 'APPLIED_NOT_CUSTOMER_ACCEPTANCE', after=after, reportDatabaseAfter=report_db,responseObservationAfter=observation,responsePostBootSha256=sha(json.dumps(response_after,sort_keys=True).encode()),featureObservationRowsAppended=1 if state['responseObservationBefore']['status']=='ABSENT' else 0, finishedAtUtc=self.a.stamp(time.time()))
        return {'status': 'APPLIED_NOT_CUSTOMER_ACCEPTANCE', 'receiptSha256': sha(self.a.read(self.paths['journal'])), 'contentImage': child,
                'sourceFiles': 239, 'staticFiles': 43, 'chainFiles': 42, 'workerRecreated': False, 'mainDbRowDirectWrites': 0, 'contentSchemaObjectsCreated': 0, 'activationRowsCreated': 0, 'oldJournalWrites': 0, 'featureObservationRowsAppended':state['featureObservationRowsAppended']}

    def inspect(self, pin):
        need(self.inspection_pin in (None,pin), 'EXACT_OWN_INSPECTION_PIN_REQUIRED')
        state = self.a.pinned(self.paths['journal'], pin, True)
        need(state.get('phase') == 'APPLIED_NOT_CUSTOMER_ACCEPTANCE' and state.get('name') == NAME
             and state.get('inputs') == self.binding() and state.get('before') == self.base
             and state.get('attentionReadOnlyValidated') is True and digest(state.get('attentionPreflightSha256'))
             and state.get('responseReadOnlyValidated') is True and digest(state.get('responsePreflightSha256')) and digest(state.get('responsePostBootSha256'))
             and state.get('featureBootObservationAppendMaximum')==1 and state.get('featureObservationRowsAppended') in (0,1)
             and state.get('workerRecreated') is False and state.get('automaticRetry') is False
             and state.get('automaticCodeRollback') is False
             and state.get('contentSchemaObjectsCreated') == 0 and state.get('contentLegacyRowWrites') == state.get('activationRowsCreated') == 0
             and state.get('mainDbRowDirectWrites') == state.get('queueEdits') == state.get('oldJournalWrites') == 0,
             'EXACT_OWN_COMPLETED_RECEIPT_REQUIRED')
        self.decision(state['decisionSha256'], fresh=False); self.backups(state)
        need(self.context_proof(state, True) == state['contextSha256'] and set(state['written']) == set(self.static_records), 'SEALED_OWN_CONTEXT_AND_STATIC_REQUIRED')
        proof = {k: state[k] for k in ('overlaySha256', 'plannedConfigHash')}
        need(self.snapshot(state['childImage'], frozenset(state['written']), proof) == state['after']
             and private_report_db(self.report_db()), 'OWN_INSTALLATION_CHANGED')
        need(state.get('contentMigration')==self.current.content_migration,'EXACT_EXISTING_POST_R7C_SCHEMA_PROOF_REQUIRED')
        self.db.guard(state['reportDatabaseBackup']); self.contentdb.after_guard(state['contentMigration']);self.traffic.guard(state['trafficDatabaseBackup'])
        response=self.response_preflight(state['childImage'])
        self.observation_guard(state['responseObservationBefore'],state['responseObservationAfter'],boot=True)
        need(self.observation_guard(state['responseObservationAfter'],response['observation'])==state['responseObservationAfter'] and state['featureObservationRowsAppended']==(1 if state['responseObservationBefore']['status']=='ABSENT' else 0),'EXACT_FEATURE_BOOT_OBSERVATION_PROOF_REQUIRED')
        return {'status': 'OWN_COMPLETED_READONLY_NOT_CUSTOMER_ACCEPTANCE', 'sourceFiles': 239, 'staticFiles': 43, 'chainFiles': 42, 'runtimeWrites': 0}


def main():
    parser=argparse.ArgumentParser();parser.add_argument('operation',choices=['inspect-current','approve-current','apply','inspect']);parser.add_argument('--lease-pid',required=True,type=int)
    parser.add_argument('--acceptance-sha');parser.add_argument('--decision-sha');parser.add_argument('--receipt-sha');parser.add_argument('--apply',action='store_true');args=parser.parse_args()
    try:
        need(FROZEN is True and all(digest(pin) and pin!='0'*64 for pin in (MANIFEST_SHA,ROLLBACK_SHA,DB_HELPER_SHA,CONTENT_HELPER_SHA,TRAFFIC_HELPER_SHA,PRODUCT_REVIEW_SHA,PRODUCT_MANIFEST_SHA,GROUP_REVIEW_SHA,MANAGED_HELPER_SHA,MANAGED_PROBE_SHA,MANAGED_PROOF_SHA,MAP_OUTCOME_SHA,PARENT_LOADER_SHA,ROOT_PRODUCT_ACCEPTANCE_SHA,NEBO_ADAPTER_SHA,NEBO_BASIS_SHA)),'DRAFT_INSTALLER_NOT_FROZEN_NO_ACTION')
        need(os.name=='posix' and os.geteuid()==0 and Path(__file__).resolve().parent==CODE,'EXACT_RECEIVER_CODE_ROOT_REQUIRED')
        a,b,prior,current=load_current_notify_r2(args.lease_pid)
        release=Release(a,b,prior,current,args.lease_pid,inspection_pin=args.receipt_sha if args.operation=='inspect' else None)
        if args.operation=='inspect-current':result=release.inspect_current()
        elif args.operation=='approve-current':result=release.approve(args.acceptance_sha,args.apply)
        elif args.operation=='apply':result=release.apply(args.decision_sha,args.apply)
        else:result=release.inspect(args.receipt_sha)
        print(json.dumps(result,separators=(',',':')));return 0
    except Exception as error:
        code=str(error) if type(error) is ValueError and re.fullmatch('[A-Z][A-Z0-9_]{0,100}',str(error)) else 'NATIVE_RELEASE_REFUSED'
        print(json.dumps({'status':'REFUSED_OR_UNKNOWN_NO_AUTOMATIC_RETRY','code':code,'messageSha256':sha(str(error).encode()),'runtimeWritesNotAssumed':True}));return 2
if __name__=='__main__':raise SystemExit(main())
