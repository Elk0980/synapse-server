"""Strict read-only NEBO basis adapter. No apply, SQL, grant or retry operation."""
import copy,hashlib,json,os,re,stat,types
from pathlib import Path
ROOT=Path('/opt/synapse/releases/palitra-app-20261015')
NEBO=Path('/opt/synapse/releases/nebo-project-20261020-r3')
NAME='palitra-darya-workspace-20261020-r2'
PROOF_PATH=ROOT/(NAME+'-nebo-basis.json')
PROOF_SHA=None
NOTIFY_IMAGE='sha256:c159821e06c4d8913d786ec31176812cce783031379ca9e288baae7beba5d7cf'
NEBO_IMAGE='sha256:40c8fc48d96478d65d87e72954a29731cbad9d64e11c2a68df92a86c9aee4717'
AUTH_BEFORE='8171611ed8c5cef7515740a81cc4b44151c63e036b600c2c932eee21ada94b8e'
AUTH_AFTER='b0dde548b7f252591858607604708d4d96847968e90f0147a50881c6a9ca074a'
CORE='2cc2dbd6e24dfaca6876d03a131491660e805c59b3c35255de3574ce2c5f8d55'
REGISTER_SHA='67d985d38ae2c5af02defb6f9fe0c9fac559e6e45b5bc6bac9c0d86be6588883'
LOCK='/opt/synapse/.palitra-app-release.lock'
NATIVE_ARTIFACT_PINS={'READY.json': 'e4c887c594b33557b7fa1be1bd74bb3199ba21692b71484ce2f551c615ed449e', 'AUDIT_CURRENT_R5.json': '25c164081e711d2715f9781e5e925fc64655f99d6d01606e3bad32d00da277a3', 'site-import/STAGED.json': '49d24e46b264bd965c43e5199370e6ea4ccb4b4a8d9a36a55032a8e76db482ec', 'site-import/FINAL_NATIVE.json': 'f38f30c16f70d63bef34d2550559acf75e7349406fc66c7506a7baecb295d249', 'nebo-company-overlay.json': 'd1363ca23d8cdb442064e6e6130faa5a63b5d0faeac666d6f9d29d0d1596180c'}
MODULE_NAMES=('auth-store.js','server.js','site-store.js','site-workspace-feature.js','site-workspaces.js')
SERVER_SHA='1d07040b2c01f2e3ade56a59bb681f6858e29f950d642c69a2d552c30c18a876'
SUPPLEMENT_NAMES=tuple(name for name in MODULE_NAMES if name!='server.js')
ARTIFACTS=('READY.json','AUDIT_CURRENT_R5.json','site-import/STAGED.json','site-import/FINAL_NATIVE.json','nebo-company-overlay.json')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
digest=lambda value:type(value) is str and re.fullmatch('[a-f0-9]{64}',value) is not None
def need(value,code):
    if not value:raise ValueError(code)
def lease(run,pid):
    need(type(pid) is int and pid>1 and pid not in (3134107,3151937,3153664,3153782),'FRESH_REBASE_ACTUAL_PID_REQUIRED')
    raw=run(['lslocks','--noheadings','--output','PID,PATH']);need(len(raw)<=1048576,'BOUNDED_LEASE_REQUIRED')
    rows=[line.strip().split(maxsplit=1) for line in raw.decode().splitlines() if len(line.strip().split(maxsplit=1))==2 and line.strip().split(maxsplit=1)[1]==LOCK]
    need(rows==[[str(pid),LOCK]],'EXACT_OWN_SINGLE_WRITER_REQUIRED')
def private(a,path,overlay=False):
    path=a.exact_path(path);info=path.stat()
    need(stat.S_ISREG(info.st_mode) and info.st_uid==info.st_gid==0 and info.st_nlink==1 and stat.S_IMODE(info.st_mode) in ((0o600,0o644) if overlay else (0o600,)),'PRIVATE_ROOT_SINGLELINK_NEBO_PROOF_REQUIRED')
    raw=a.read(path);need(len(raw)<=1024*1024,'BOUNDED_NEBO_PROOF_REQUIRED')
    return raw
def stage_module_pins(stage):
    # The caller authenticates STAGED bytes with NATIVE_ARTIFACT_PINS first.
    # No manually transcribed hashes for the three registry modules.
    need(type(stage) is dict and type(stage.get('moduleHashes')) is dict
         and set(stage['moduleHashes'])==set(MODULE_NAMES)
         and all(digest(pin) for pin in stage['moduleHashes'].values())
         and stage['moduleHashes']['auth-store.js']==AUTH_AFTER
         and stage['moduleHashes']['server.js']==SERVER_SHA,'EXACT_PINNED_STAGE_FIVE_MODULES_REQUIRED')
    return dict(stage['moduleHashes'])
def artifacts(a):
    for directory in (NEBO,NEBO/'site-import'):
        path=a.exact_path(directory);info=path.stat();need(stat.S_ISDIR(info.st_mode) and info.st_uid==info.st_gid==0 and stat.S_IMODE(info.st_mode)==0o700,'PRIVATE_NEBO_PROOF_DIRECTORY_REQUIRED')
    raw={name:private(a,NEBO/name,overlay=name=='nebo-company-overlay.json') for name in ARTIFACTS}
    value={name:a.decode(data) for name,data in raw.items()}
    ready=value['READY.json'];audit=value['AUDIT_CURRENT_R5.json'];stage=value['site-import/STAGED.json'];final=value['site-import/FINAL_NATIVE.json']
    need(ready.get('status')=='PREPARED_ONLY' and ready.get('baseImage')==NOTIFY_IMAGE and ready.get('nextImage')==NEBO_IMAGE and ready.get('authBefore')==AUTH_BEFORE and ready.get('authAfter')==AUTH_AFTER and ready.get('files')==395 and ready.get('delta')==['/app/auth-store.js'] and ready.get('helperSha')==REGISTER_SHA and ready.get('leasePid')==3153782,'EXACT_NEBO_REGISTER_R3_BASIS_REQUIRED')
    need(audit.get('status')=='SOURCE_AND_EFFECTIVE_CONFIG_VERIFIED' and audit.get('image')==NEBO_IMAGE and audit.get('authSha')==AUTH_AFTER and audit.get('sourceFiles')==395 and audit.get('sourceDelta')==['/app/auth-store.js'] and all(audit.get(k) is True for k in ('otherContainersExact','mountsExact','oldComposeFilesExact','effectiveEnvironmentValuesExact')) and audit.get('historicalInvariantRecovered')==[] and audit.get('historicalOrderHashMismatch') is True and audit.get('registryPermissionsChanged') is False and audit.get('databaseWrites')==0,'EXACT_NEBO_R5_EFFECTIVE_CONFIG_AUDIT_REQUIRED')
    need(stage.get('status')=='STAGED_NO_DATABASE_WRITES' and type(stage.get('moduleHashes')) is dict and set(stage['moduleHashes'])=={'server.js','site-store.js','site-workspaces.js','site-workspace-feature.js','auth-store.js'} and all(digest(pin) for pin in stage['moduleHashes'].values()),'EXACT_NEBO_SITE_STAGE_REQUIRED')
    need(final.get('status')=='FINAL_NATIVE_VERIFIED' and final.get('image')==NEBO_IMAGE and all(final.get(k) is True for k in ('all116FilesExact','sourceModulesExact','otherContainersExact','oldComposeExact')) and final.get('sqliteBackupQuickCheck')=='ok' and final.get('privateMaterialsFiles')==62 and final.get('caddyEdits')==final.get('extraRestarts')==0,'EXACT_NEBO_FINAL_NATIVE_REQUIRED')
    need(value['nebo-company-overlay.json']=={'services':{'content':{'image':NEBO_IMAGE}}},'EXACT_NEBO_CONTENT_ONLY_OVERLAY_REQUIRED')
    pins={name:sha(data) for name,data in raw.items()};need(pins==NATIVE_ARTIFACT_PINS,'EXACT_PERSONALLY_REVIEWED_NEBO_ARTIFACT_PINS_REQUIRED')
    stage_module_pins(stage)
    return pins,value

MODULE_FACTS_JS="const f=require('node:fs'),c=require('node:crypto'),names=JSON.parse(process.argv[1]),all=['auth-store.js','server.js','site-store.js','site-workspace-feature.js','site-workspaces.js'],extra=all.filter(n=>n!=='server.js');if(![JSON.stringify(all),JSON.stringify(extra)].includes(JSON.stringify(names)))throw Error('CLOSED_MODULE_SET_REQUIRED');const out={};for(const n of names){const p='/app/'+n,s=f.lstatSync(p);if(!s.isFile()||s.isSymbolicLink()||s.nlink!==1||s.uid!==0||s.gid!==0||f.realpathSync(p)!==p||![384,420].includes(s.mode&511))throw Error('REGULAR_ROOT_MODULE_REQUIRED');const raw=f.readFileSync(p);if(raw.length!==s.size)throw Error('MODULE_CHANGED_DURING_READ');out[n]={sha256:c.createHash('sha256').update(raw).digest('hex'),bytes:raw.length,uid:s.uid,gid:s.gid,mode:s.mode&511,nlink:s.nlink};}process.stdout.write(JSON.stringify(out));"
def source_coverage(source):
    need(type(source) is dict and len(source)==235 and source.get('customer-chat.js')==CORE
         and source.get('server.js')==SERVER_SHA and not set(SUPPLEMENT_NAMES).intersection(source),'EXACT_NATIVE_CONFIRMED_SOURCE235_COVERAGE_REQUIRED')
def validate_module_facts(value,names,expected):
    need(tuple(names) in (MODULE_NAMES,SUPPLEMENT_NAMES),'CLOSED_STAGE_OR_SUPPLEMENT_SET_REQUIRED')
    stage_module_pins({'moduleHashes':expected})
    need(type(value) is dict and set(value)==set(names),'EXACT_CLOSED_MODULE_FACTS_REQUIRED')
    for name in names:
        row=value[name]
        need(type(row) is dict and set(row)=={'sha256','bytes','uid','gid','mode','nlink'} and row['sha256']==expected[name]
             and all(type(row[k]) is int for k in ('bytes','uid','gid','mode','nlink'))
             and 0<row['bytes']<=2*1024*1024 and row['uid']==row['gid']==0 and row['nlink']==1 and row['mode'] in (0o600,0o644),'EXACT_ROOT_MODULE_SUPPLEMENT_REQUIRED')
    return value
def module_facts(a,b,names,expected):
    need(tuple(names) in (MODULE_NAMES,SUPPLEMENT_NAMES),'CLOSED_STAGE_OR_SUPPLEMENT_SET_REQUIRED')
    raw=b.run(['docker','exec','synapse-content-1','node','-e',MODULE_FACTS_JS,json.dumps(list(names),separators=(',',':'))])
    need(len(raw)<=4096,'BOUNDED_MODULE_SUPPLEMENTS_REQUIRED')
    return validate_module_facts(a.decode(raw),names,expected)


def metadata(a,b,run,sealed_files,sealed_pins):
    need(type(sealed_files) is list and len(sealed_files)==41 and all(type(name) is str for name in sealed_files)
         and len(set(sealed_files))==41 and type(sealed_pins) is dict and set(sealed_pins)==set(sealed_files)
         and all(digest(pin) for pin in sealed_pins.values()),'EXACT_SEALED_COMPOSE41_BASIS_REQUIRED')
    value=a.decode(run(['docker','inspect','--format',a.LABELS,'synapse-content-1']))
    need(type(value) is dict and type(value.get('configFiles')) is str,'EXACT_CONTENT_METADATA_REQUIRED')
    files=value['configFiles'].split(',')
    # Authenticate the entire ordered label against historical40 + pinned overlay
    # before resolving or reading any label-supplied path. Old paths need no guessed prefix.
    need(files==sealed_files,'EXACT_SEALED_COMPOSE41_CHAIN_REQUIRED')
    file_pins={name:sha(a.read(a.exact_path(Path(name)))) for name in sealed_files}
    need(file_pins==sealed_pins,'EXACT_SEALED_COMPOSE41_FILE_BYTES_REQUIRED')
    value.update(files=files,filePins=file_pins)
    return value
def effective_environment(a,b,run,current,content,ready):
    # Secret values stay only in memory, never in the proof, error or stdout.
    row=a.decode(run(['docker','inspect','synapse-content-1']))
    need(type(row) is list and len(row)==1 and row[0].get('Image')==NEBO_IMAGE,'EXACT_CURRENT_NEBO_IMAGE_REQUIRED');row=row[0]
    base=a.decode(run(['docker','image','inspect',NOTIFY_IMAGE]))
    need(type(base) is list and len(base)==1 and base[0].get('Id')==NOTIFY_IMAGE,'EXACT_NOTIFY_IMAGE_RETAINED_REQUIRED')
    actual_config=row['Config'];base_config=base[0]['Config']
    args=['docker','compose']+[v for path in content['files'] for v in ('-f',path)]+['config','--format','json']
    config=a.decode(run(args));effective=config['services']['content']
    need(effective.get('image')==NEBO_IMAGE,'EXACT_EFFECTIVE_NEBO_IMAGE_REQUIRED')
    pairs=actual_config.get('Env',[]);need(type(pairs) is list and all(type(v) is str and '=' in v for v in pairs),'EXACT_CURRENT_ENV_FORMAT_REQUIRED')
    actual=dict(v.split('=',1) for v in pairs);need(len(actual)==len(pairs),'DUPLICATE_CURRENT_ENV_REFUSED')
    expected=dict(v.split('=',1) for v in base_config.get('Env',[]));expected.update({k:str(v) for k,v in effective.get('environment',{}).items()});expected={k:v.replace('$$','$') for k,v in expected.items()}
    need(actual==expected,'CURRENT_ENV_EFFECTIVE_COMPOSE_CHANGED')
    mounts=[{k:m.get(k) for k in ('Type','Source','Destination','RW')} for m in row['Mounts']]
    # Full original metadata, all other containers and graph/Push are checked separately.
    need(len([m for m in mounts if m['Destination']=='/data' and m['Type']=='volume' and m['Source']=='/var/lib/docker/volumes/synapse_content_data/_data' and m['RW'] is True])==1,'EXACT_CURRENT_DATA_VOLUME_REQUIRED')
    rows=run(['docker','ps','--format','{{.Names}} {{.ID}}']).decode().splitlines()
    others=dict(line.split() for line in rows if not line.startswith('synapse-content-1 '))
    need(others==ready['otherContainers'],'NEBO_OTHER_CONTAINERS_CHANGED')
    return {'effectiveEnvironmentValuesExact':True,'otherContainersExact':True,'dataVolumeExact':True}
def observe(a,b,current,pid):
    run=b.run;lease(run,pid);current.stable()
    pins,values=artifacts(a);ready=values['READY.json'];source=dict(current.source)
    expected_modules=stage_module_pins(values['site-import/STAGED.json'])
    source_coverage(source)
    all_modules=module_facts(a,b,MODULE_NAMES,expected_modules);supplements={name:all_modules[name] for name in SUPPLEMENT_NAMES};auth=supplements['auth-store.js']
    need(b.photo.hashes(source)==source,'FULL_REBASED_SOURCE235_CHANGED')
    for target,pin in current.static.items():need(sha(a.read(a.exact_path(Path(target))))==pin,'FULL_STATIC41_CHANGED')
    old=current.base['containers']['content'];files=old['files']+[str(NEBO/'nebo-company-overlay.json')]
    need(len(old['files'])==40 and len(files)==41 and ready.get('composeFiles')==old['files'] and ready.get('composeSha')==old['filePins'],'EXACT_NEBO_OLD_CHAIN40_REQUIRED')
    sealed_pins={**old['filePins'],str(NEBO/'nebo-company-overlay.json'):pins['nebo-company-overlay.json']}
    content=metadata(a,b,run,files,sealed_pins)
    expected={**old,'image':NEBO_IMAGE,'files':files,'configFiles':','.join(files),'filePins':sealed_pins,'configHash':content.get('configHash')}
    need(digest(content.get('configHash')) and content==expected,'EXACT_ONLY_NEBO_CONTENT_METADATA_DELTA_REQUIRED')
    for service,row in [('content',content),('chat',current.base['containers']['chat'])]:
        value=run(b._resolve_command(row,service)).decode('ascii').strip();need(re.fullmatch(re.escape(service)+r'\s+'+re.escape(row['configHash']),value) is not None,'RESOLVED_COMPOSE_HASH_CHANGED')
    chat=b.metadata('chat');worker=b.worker_facts();selected={s:b.a.selected(s) for s in ('content','chat')};flags=a.decode(run(['docker','exec','synapse-content-1','node','-e',a.FLAGS_JS]))
    need(chat==current.base['containers']['chat'] and worker==current.base['worker'] and selected==current.base['selected'] and flags==current.base['l12'],'NEBO_OTHER_CURRENT_RESOURCES_CHANGED')
    b.graph(new=True);b.push_guard();environment=effective_environment(a,b,run,current,content,ready)
    cid=b.photo.cid();need(type(cid) is str and cid and cid!=current.base['contentCid'],'EXACT_RECREATED_NEBO_CONTENT_REQUIRED')
    snapshot={'containers':{'content':content,'chat':chat},'worker':worker,'selected':selected,'l12':flags,'contentCid':cid}
    need(metadata(a,b,run,files,sealed_pins)==content and b.worker_facts()==worker and b.photo.cid()==cid and b.photo.hashes(source)==source and artifacts(a)[0]==pins and module_facts(a,b,MODULE_NAMES,expected_modules)==all_modules,'CONCURRENT_NEBO_BASIS_CHANGED')
    current.stable();lease(run,pid)
    return {'schema':1,'status':'SEALED_NEBO_REBASED_BASIS_NOT_RUNTIME_AUTHORIZATION','notifyImage':NOTIFY_IMAGE,'image':NEBO_IMAGE,'sourceInventoryDelta':[],'authTransition':{'target':'auth-store.js','beforeSha256':AUTH_BEFORE,'sha256':AUTH_AFTER},'authSupplement':auth,'moduleSupplements':supplements,'source':source,'static':dict(current.static),'snapshot':snapshot,'artifactPins':pins,'checks':environment,'runtimeWrites':0,'databaseWrites':0,'historicalInvariantRecovered':False}
def validate(value,current,pins,expected_modules):
    source_coverage(current.source)
    need(type(value) is dict and 'moduleSupplements' in value,'EXACT_MODULE_SUPPLEMENT_PROOF_REQUIRED')
    validate_module_facts(value['moduleSupplements'],SUPPLEMENT_NAMES,expected_modules)
    need(value.get('authSupplement')==value['moduleSupplements']['auth-store.js'],'EXACT_AUTH_IN_FOUR_MODULE_SUPPLEMENTS_REQUIRED')
    need(type(value) is dict and set(value)=={'schema','status','notifyImage','image','sourceInventoryDelta','authTransition','authSupplement','moduleSupplements','source','static','snapshot','artifactPins','checks','runtimeWrites','databaseWrites','historicalInvariantRecovered'}
         and value['schema']==1 and value['status']=='SEALED_NEBO_REBASED_BASIS_NOT_RUNTIME_AUTHORIZATION' and value['notifyImage']==NOTIFY_IMAGE and value['image']==NEBO_IMAGE
         and value['sourceInventoryDelta']==[] and value['authTransition']=={'target':'auth-store.js','beforeSha256':AUTH_BEFORE,'sha256':AUTH_AFTER}
         and len(current.source)==235 and 'auth-store.js' not in current.source and current.source.get('customer-chat.js')==CORE
         and value['source']==current.source and type(value['authSupplement']) is dict and set(value['authSupplement'])=={'sha256','bytes','uid','gid','mode','nlink'} and value['authSupplement']['sha256']==AUTH_AFTER and type(value['authSupplement']['bytes']) is int and 0<value['authSupplement']['bytes']<=2*1024*1024 and value['authSupplement']['uid']==value['authSupplement']['gid']==0 and value['authSupplement']['nlink']==1 and value['authSupplement']['mode'] in (0o600,0o644) and len(current.static)==41 and value['static']==current.static
         and value['artifactPins']==pins and value['checks']=={'effectiveEnvironmentValuesExact':True,'otherContainersExact':True,'dataVolumeExact':True}
         and value['runtimeWrites']==value['databaseWrites']==0 and value['historicalInvariantRecovered'] is False,'EXACT_SEALED_NEBO_REBASE_REQUIRED')
    snapshot=value['snapshot'];need(type(snapshot) is dict and set(snapshot)==set(current.base),'EXACT_REBASE_SNAPSHOT_SHAPE_REQUIRED')
    old=current.base['containers']['content'];content=snapshot.get('containers',{}).get('content',{})
    files=old['files']+[str(NEBO/'nebo-company-overlay.json')]
    expected={**old,'image':NEBO_IMAGE,'files':files,'configFiles':','.join(files),'filePins':{**old['filePins'],str(NEBO/'nebo-company-overlay.json'):pins['nebo-company-overlay.json']},'configHash':content.get('configHash')}
    need(len(old['files'])==40 and len(files)==41 and content==expected and digest(content.get('configHash'))
         and type(snapshot.get('contentCid')) is str and snapshot['contentCid'] and snapshot['contentCid']!=current.base['contentCid']
         and snapshot=={**current.base,'containers':{'content':expected,'chat':current.base['containers']['chat']},'contentCid':snapshot['contentCid']},'EXACT_SEALED_NEBO_METADATA_REQUIRED')
def load(a,b,prior,current,pid,pin=PROOF_SHA):
    need(digest(pin),'EXACT_NATIVE_NEBO_REBASE_PROOF_PENDING')
    raw=private(a,PROOF_PATH);need(sha(raw)==pin,'EXACT_NEBO_REBASE_PROOF_CHANGED');value=a.decode(raw)
    lease(b.run,pid);pins,values=artifacts(a);expected_modules=stage_module_pins(values['site-import/STAGED.json']);validate(value,current,pins,expected_modules)
    need(module_facts(a,b,SUPPLEMENT_NAMES,expected_modules)==value['moduleSupplements'],'LIVE_FOUR_MODULE_SUPPLEMENTS_CHANGED')
    # Historical basis only: the successor's own snapshot/baseline/inspect checks live state.
    # Never call observe here: a completed child is intentionally no longer the NEBO image.
    def stable():
        current.stable();need(sha(private(a,PROOF_PATH))==pin and artifacts(a)[0]==value['artifactPins'],'SEALED_NEBO_HISTORY_CHANGED')
        need(module_facts(a,b,SUPPLEMENT_NAMES,expected_modules)==value['moduleSupplements'],'LIVE_FOUR_MODULE_SUPPLEMENTS_CHANGED')
    fields=vars(current).copy();fields.update(base=copy.deepcopy(value['snapshot']),source=dict(value['source']),static=dict(value['static']),stable=stable,parent_image=NEBO_IMAGE,parent_chain_count=41,nebo_rebase_pin=pin,auth_supplement=copy.deepcopy(value['authSupplement']),module_supplements=copy.deepcopy(value['moduleSupplements']),module_supplement_pins={name:expected_modules[name] for name in SUPPLEMENT_NAMES})
    return a,b,prior,types.SimpleNamespace(**fields)
