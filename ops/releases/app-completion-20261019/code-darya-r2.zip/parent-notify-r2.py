"""Read-only completed notify-r2 basis seam. No publication, approval or apply path.

The successor controller must provide its own new live snapshot and action-time guards.
Never compare the installed successor with an older live parent snapshot.
"""
import copy
import hashlib
from pathlib import Path
import re
import types
ROOT = Path('/opt/synapse/releases/palitra-app-20261015')
PARENT_NAME = 'palitra-notify-update-20261020-r2'
PARENT_IMAGE = 'sha256:c159821e06c4d8913d786ec31176812cce783031379ca9e288baae7beba5d7cf'
PARENT_HELPER = '0e2a1f5487cb62578846d55f8d91bd2a9869afb8dca8f927bea0df5e7b9e9016'
PARENT_ENTRY = '15c16be0e3d132fdc0416cb8fdec6175d12b1c828fbddc5b2243d2c6c71b75a1'
PARENT_RECEIPT = '79c4657ca15402b34b36d51642f4e8565701f8ab1b06fc446e5d629e674172f3'
PARENT_DECISION = '7a5911d19de707c5fc2c95b197ee99acc335f21abc6f418fac134613abd59fcc'
PARENT_WRITER = 3134107
RELEASED_PARENT_INSPECTOR = 3151937
QUEUE_SHA = 'f46720163a8ec1f6ab75a45a86bc7dd951923e5755293acf537f87073e1df7d7'
SERVER_SHA = '1d07040b2c01f2e3ade56a59bb681f6858e29f950d642c69a2d552c30c18a876'
MANAGED_PROOF_SHA = '40ef3d261c68fcdca488a31da328e245f70066066bbc92cfebba28a4f19c453d'
MANAGED_PROBE_SHA = '6adf008d2a6016031b6ad6812c3550a557694293a9a855a92cfb64e6c964ca6f'
MAP_OUTCOME_SHA = '7c206110ddb478f1be1221e689ea346e125b9e438096b59af39a7eb84ebc2c42'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
digest = lambda value: isinstance(value,str) and re.fullmatch('[0-9a-f]{64}',value) is not None

def need(value,code):
    if not value: raise ValueError(code)

def _load_module(raw,path):
    module=types.ModuleType('exact_completed_notify_r2');module.__file__=str(path)
    exec(compile(raw,str(path),'exec'),module.__dict__)
    return module

def load_current_notify_r2(pid):
    need(type(pid) is int and pid>1 and pid not in (PARENT_WRITER,RELEASED_PARENT_INSPECTOR,3093287,3124706,3093006,3092646,3091609,3091431),'FRESH_MANAGER_ACTUAL_INSPECTION_PID_REQUIRED')
    folder=ROOT/(PARENT_NAME+'-code');helper=folder/'release-native.py';entry=folder/'company-app.py'
    for path in [*reversed(helper.parents),helper,entry]:need(not path.is_symlink(),'HISTORICAL_NOTIFY_R2_SYMLINK_REFUSED')
    raw=helper.read_bytes();need(sha(raw)==PARENT_HELPER and sha(entry.read_bytes())==PARENT_ENTRY,'EXACT_UNMODIFIED_NOTIFY_R2_CODE_REQUIRED')
    original=_load_module(raw,helper)
    need(original.NAME==PARENT_NAME and original.CODE==folder and original.FROZEN is True,'EXACT_FROZEN_NOTIFY_R2_NAMESPACE_REQUIRED')
    a,b,prior,before_notify=original.load_current_r7c(pid)
    accepted=original.Release(a,b,prior,before_notify,pid,inspection_pin=PARENT_RECEIPT)
    need(accepted.pid==pid and accepted.writer_pid==PARENT_WRITER,'NOTIFY_R2_ACTUAL_INSPECTOR_AND_HISTORICAL_WRITER_REQUIRED')
    receipt=a.pinned(accepted.paths['journal'],PARENT_RECEIPT,True)
    need(receipt.get('name')==PARENT_NAME and receipt.get('phase')=='APPLIED_NOT_CUSTOMER_ACCEPTANCE'
         and receipt.get('inputs')==accepted.binding() and receipt.get('before')==accepted.base
         and receipt.get('childImage')==PARENT_IMAGE and receipt.get('decisionSha256')==PARENT_DECISION
         and receipt.get('workerRecreated') is False and receipt.get('automaticRetry') is False
         and receipt.get('automaticCodeRollback') is False and receipt.get('contentSchemaObjectsCreated')==0
         and receipt.get('contentLegacyRowWrites')==receipt.get('activationRowsCreated')==0
         and receipt.get('mainDbRowDirectWrites')==receipt.get('queueEdits')==receipt.get('oldJournalWrites')==0,
         'EXACT_COMPLETED_NOTIFY_R2_RECEIPT_REQUIRED')
    decision=accepted.decision(PARENT_DECISION,fresh=False)
    need(decision['sourceModes']==receipt['sourceModes'],'SEALED_NOTIFY_R2_SOURCE_MODES_REQUIRED')
    expected=copy.deepcopy(accepted.base);content=expected['containers']['content'];overlay=str(accepted.paths['overlay']);chain=content['files']+[overlay]
    need(len(chain)==len(set(chain))==40 and sha(a.read(accepted.paths['overlay']))==receipt['overlaySha256'],'SEALED_NOTIFY_R2_CHAIN40_REQUIRED')
    content.update(image=PARENT_IMAGE,files=chain,configFiles=','.join(chain),filePins={**content['filePins'],overlay:receipt['overlaySha256']},configHash=receipt['plannedConfigHash'])
    need(type(receipt.get('after')) is dict and type(receipt['after'].get('contentCid')) is str and receipt['after']['contentCid'] and receipt['after']['contentCid']!=accepted.base['contentCid'],'EXACT_COMPLETED_NOTIFY_R2_CONTENT_ID_REQUIRED')
    expected['contentCid']=receipt['after']['contentCid']
    need(receipt['after']==expected and len(accepted.source)==235 and len(accepted.static)==41,'SEALED_NOTIFY_R2_FULL235_41_40_REQUIRED')
    need(len(accepted.records)==4 and len(accepted.static_records)==3 and len(receipt.get('written',[]))==3
         and set(receipt['written'])==set(accepted.static_records) and Path(receipt['written'][-1]).name=='cabinet.html','SEALED_NOTIFY_R2_FOUR_PAYLOAD_THREE_STATIC_REQUIRED')
    need(accepted.source.get('server.js')==SERVER_SHA and accepted.source.get('site-orders.js')==QUEUE_SHA,'EXACT_NOTIFY_R2_GROUP_OFF_AND_ACTUAL_QUEUE_REQUIRED')
    need(receipt['inputs'].get('queueModuleSha256')==QUEUE_SHA and receipt['inputs'].get('managedProofSha256')==MANAGED_PROOF_SHA
         and receipt['inputs'].get('managedProbeSha256')==MANAGED_PROBE_SHA and receipt['inputs'].get('mapOutcomeSha256')==MAP_OUTCOME_SHA
         and receipt['inputs'].get('managedSourceProof')==accepted.managed_guard.proof,'EXACT_NOTIFY_R2_MANAGED259_BINDING_REQUIRED')
    migration=receipt['contentMigration']
    need(migration==accepted.current.content_migration and type(migration) is dict and migration.get('schemaObjects')==6
         and migration.get('legacyRowWrites')==migration.get('activationRows')==0 and digest(migration.get('afterSchemaSha256')),'EXACT_NOTIFY_R2_EXISTING_POST_SCHEMA_REQUIRED')
    def stable():
        # Sealed history/context/backup checks only. No accepted.snapshot/baseline/inspect/stable.
        accepted.current.stable()
        need(sha(a.read(helper))==PARENT_HELPER and sha(a.read(entry))==PARENT_ENTRY
             and a.pinned(accepted.paths['journal'],PARENT_RECEIPT,True)==receipt
             and a.pinned(accepted.paths['decision'],PARENT_DECISION,True)==decision
             and accepted.binding()==receipt['inputs'],'SEALED_NOTIFY_R2_HISTORY_CHANGED')
        for path,pin in accepted.pins.items():need(sha(a.read(Path(path)))==pin,'SEALED_NOTIFY_R2_CODE_OR_PROOF_CHANGED')
        for row in accepted.records.values():need(sha(a.read(original.CODE/'payload'/row['name']))==row['sha256'],'SEALED_NOTIFY_R2_PAYLOAD_CHANGED')
        accepted.acceptance(decision['rootAcceptanceSha256']);accepted.backups(receipt)
        need(accepted.context_proof(receipt,True)==receipt['contextSha256'],'SEALED_NOTIFY_R2_CONTEXT_CHANGED')
    stable()
    return a,b,prior,types.SimpleNamespace(base=copy.deepcopy(receipt['after']),source=dict(accepted.source),static=dict(accepted.static),
        cabinet=accepted.cabinet,managed=accepted.current.managed,stable=stable,source_script=accepted.current.source_script,
        managed_proof=copy.deepcopy(accepted.managed_guard.proof),content_migration=copy.deepcopy(migration),
        report_minimum=copy.deepcopy(receipt['reportDatabaseBackup']),observe_supplement=accepted.current.observe_supplement,
        supplement_mode=accepted.current.supplement_mode,supplement_bytes=accepted.current.supplement_bytes,
        parent_release=PARENT_NAME,parent_receipt=PARENT_RECEIPT,parent_decision=PARENT_DECISION,parent_image=PARENT_IMAGE,parent_chain_count=40)
