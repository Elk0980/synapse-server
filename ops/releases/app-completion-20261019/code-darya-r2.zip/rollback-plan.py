"""Pure combined-scope code rollback plan. No I/O, sending or activation."""
from pathlib import PurePath
PARENT = 'sha256:40c8fc48d96478d65d87e72954a29731cbad9d64e11c2a68df92a86c9aee4717'
PROOF='40ef3d261c68fcdca488a31da328e245f70066066bbc92cfebba28a4f19c453d'
STATIC={'shell.js','shell.css','workflow-ui.js','native-host.js','cabinet.html','palitra-response-report-ui.js','palitra-content-tasks-ui.js'}
SOURCES={'server.js','palitra-orders-public/shell.js','palitra-orders-public/shell.css','palitra-orders-public/workflow-ui.js','palitra-orders-public/native-host.js','palitra-orders-public/cabinet.html','palitra-workflow.cjs'}
def plan(state):
 if state.get('name')!='palitra-darya-workspace-20261020-r2' or state.get('phase')!='APPLIED_NOT_CUSTOMER_ACCEPTANCE':raise ValueError('EXACT_COMPLETED_NOTIFY_UPDATE_R2_REQUIRED')
 if state.get('inputs',{}).get('parentImage')!=PARENT or state.get('contentSchemaObjectsCreated')!=0 or state.get('activationRowsCreated')!=0:raise ValueError('CODE_ONLY_NOTIFY_UPDATE_R2_REQUIRED')
 if state.get('inputs',{}).get('managedProofSha256')!=PROOF:raise ValueError('EXACT_MANAGED259_PROOF_REQUIRED')
 rows=state.get('static',[]);written=state.get('written',[])
 if len(rows)!=7 or {PurePath(r.get('target','')).name for r in rows}!=STATIC or len(written)!=7 or set(written)!={r['target'] for r in rows} or PurePath(written[-1]).name!='cabinet.html':raise ValueError('EXACT_SEVEN_STATIC_CABINET_LAST_REQUIRED')
 sources=state.get('sourceBackups',[])
 if len(sources)!=7 or {r.get('target') for r in sources}!=SOURCES:raise ValueError('EXACT_SEVEN_SOURCE_BACKUPS_REQUIRED')
 added=[r for r in rows if r.get('baseSha256') is None]
 if {PurePath(r['target']).name for r in added}!={'palitra-response-report-ui.js','palitra-content-tasks-ui.js'} or any(r.get('backup') is not None for r in added):raise ValueError('EXACT_TWO_STATIC_ADDITIONS_REQUIRED')
 if state.get('featureBootObservationAppendMaximum')!=1 or state.get('featureObservationRowsAppended') not in (0,1) or state.get('responseObservationAfter',{}).get('status')!='EXISTING':raise ValueError('CURRENT_OBSERVATION_PRESERVATION_PROOF_REQUIRED')
 if 'trafficDatabaseBackup' not in state:raise ValueError('THIRD_STORE_PRESERVATION_PROOF_REQUIRED')
 return {'status':'MANUAL_PLAN_NOT_AUTHORIZATION','parentImage':PARENT,'requiredFreshLease':True,'requiredNewRootAcceptance':True,'expectedComposeFiles':43,'expectedSourceFiles':235,'expectedStaticFiles':41,
  'requiredCurrentConsistentBackups':['content.sqlite','salon-reports.sqlite','app-entry-stats.sqlite IF CURRENTLY PRESENT, including committed WAL'],'liveDatabaseOperations':[],'dropTables':[],'restoreDatabases':[],
  'trafficStorePolicy':'KEEP CURRENT presence, complete schema, all current events/revisions and WAL; never restore historical absence or old backup',
  'contentSchemaMustRemain':state['contentMigration']['afterSchemaSha256'],'managedProofMustRemain':PROOF,'automaticRetry':False,'oldHelpersReplay':False,'staticReplacements':['native-host.js','shell.css','shell.js','workflow-ui.js','cabinet.html'],'cabinetLast':True,'staticRemovalsOnlyUnderExactCurrentCAS':['palitra-content-tasks-ui.js','palitra-response-report-ui.js'],'observationDocumentPolicy':'KEEP CURRENT palitra-love/response-time-observation/v1 and every newer user document/version; never restore old documents or absence',
  'rebasedParentPreservesNeboRegistry':True,'notifyParentPreservesGroupOff':True,'notifyParentPreservesUpdateNoticeFix':True,'removeAddedModuleOnlyByReviewedWholeImageRollback':True}
