/* Read-only entry into the existing company calendar. No approval, publishing or message transport. */
'use strict';
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else Object.defineProperty(root, 'PalitraContentTasksUI', { value: api, writable: false });
})(typeof globalThis === 'undefined' ? window : globalThis, () => {
  const PLAN = 'https://synapse.synapsebusiness.ru/cabinet.html#content-factory/plan?company=palitra-love';
  const STATES = new Set(['missing', 'pending', 'ready', 'published', 'inactive']);
  const LABELS = { missing: 'Нужна доработка', pending: 'Ожидает решения', ready: 'Текущая версия готова в плане', published: 'Отмечено как опубликованное', inactive: 'Неактивный материал' };
  const PLATFORMS = { vk: 'ВКонтакте', telegram: 'Telegram', instagram: 'Instagram', tiktok: 'TikTok', youtube: 'YouTube', youtube_shorts: 'YouTube Shorts' };
  const day = value => typeof value === 'string' && /^\d{4}-\d\d-\d\d$/.test(value) && Number.isFinite(Date.parse(value)) && new Date(value).toISOString().slice(0, 10) === value;
  const positive = value => Number.isSafeInteger(value) && value > 0;
  function validate(value) {
    if (!value || value.companyCode !== 'palitra-love' || !day(value.from) || !day(value.to) || !day(value.today) || value.from > value.to || typeof value.timezone !== 'string' || !value.timezone || !Array.isArray(value.posts) || !Array.isArray(value.undated) || typeof value.truncated !== 'boolean' || typeof value.undatedTruncated !== 'boolean' || !Number.isSafeInteger(value.undatedTotal) || value.undatedTotal < value.undated.length || !value.coverage || !['current_plan', 'none'].includes(value.coverage.basis) || !value.summary) throw new Error('CONTENT_INVALID');
    const seen = new Set();
    for (const post of [...value.posts, ...value.undated]) {
      if (!post || post.companyCode !== value.companyCode || !positive(post.id) || !positive(post.revision) || seen.has(post.id) || typeof post.title !== 'string' || !(post.effectiveDate === null || day(post.effectiveDate)) || !post.calendarReadiness || !STATES.has(post.calendarReadiness.state) || !Array.isArray(post.calendarReadiness.issues) || !post.calendarReadiness.issues.every(issue => typeof issue === 'string') || !Array.isArray(post.calendarReadiness.platforms)) throw new Error('CONTENT_INVALID');
      for (const platform of post.calendarReadiness.platforms) if (!platform || typeof platform.platform !== 'string' || !STATES.has(platform.state) || !Array.isArray(platform.issues) || !platform.issues.every(issue => typeof issue === 'string')) throw new Error('CONTENT_INVALID');
      seen.add(post.id);
    }
    if (value.posts.some(post => post.effectiveDate === null || post.effectiveDate < value.from || post.effectiveDate > value.to) || value.undated.some(post => post.effectiveDate !== null)) throw new Error('CONTENT_INVALID');
    return value;
  }
  const formatDay = value => value.split('-').reverse().join('.');
  function create({ document: doc, window: win, read } = {}) {
    if (!doc || !win || typeof read !== 'function') throw new TypeError('Нужен разрешённый источник контента');
    const h = (tag, props, ...children) => { const node = doc.createElement(tag); for (const [key, value] of Object.entries(props || {})) { if (key === 'text') node.textContent = value; else if (key === 'onclick') node.addEventListener('click', value); else if (key === 'disabled') node.disabled = Boolean(value); else node.setAttribute(key, value); } for (const child of children.flat(Infinity)) if (child != null && child !== false) node.append(child); return node; };
    const link = (text, href, label = text) => h('a', { class: 'app-btn app-btn--ghost', href, target: '_blank', rel: 'noopener noreferrer', 'aria-label': label, text });
    const element = h('section', { class: 'manager-workspace', 'data-content-tasks': '', 'aria-label': 'Контент на неделю' });
    let current = null, controller = null, seq = 0, disposed = false, loading = false, error = '';
    function card(post) {
      const readiness = post.calendarReadiness, platforms = [...new Set(readiness.platforms.map(platform => PLATFORMS[platform.platform] || platform.platform))];
      const uncertain = post.status === 'needs_review' || post.status === 'failed' || post.deliveries?.some(delivery => ['needs_review', 'failed'].includes(delivery.status));
      const reason = uncertain ? 'Нужна проверка результата на площадке' : readiness.issues.find(Boolean) || LABELS[readiness.state];
      return h('article', { class: 'card', 'data-content-post': String(post.id), 'data-revision': String(post.revision) },
        h('p', { class: 'muted', text: post.effectiveDate ? formatDay(post.effectiveDate) : 'Дата не назначена' }), h('h3', { class: 'text__title', text: post.title.trim() || `Материал №${post.id}` }),
        h('p', { class: 'muted', text: platforms.length ? platforms.join(' · ') : 'Площадка не выбрана' }), h('p', { role: 'status', text: reason }),
        link('Открыть материал', `${PLAN}&post=${post.id}&revision=${post.revision}`, `Открыть материал: ${post.title.trim() || `№${post.id}`}, версия ${post.revision}`));
    }
    function paint() {
      const children = [h('div', { class: 'manager-workspace__heading' }, h('h1', { class: 'text__title', text: 'Контент на неделю' }), h('button', { type: 'button', class: 'app-btn app-btn--ghost', disabled: loading, 'aria-label': error ? 'Повторить загрузку контента' : 'Обновить контент на неделю', onclick: () => { void refresh(); }, text: loading ? 'Загружаем…' : error ? 'Повторить' : 'Обновить' }))];
      if (loading) children.push(h('p', { role: 'status', text: 'Загружаем материалы недели…' }));
      if (error) children.push(h('p', { class: 'app-error', role: 'alert', text: error }));
      if (current) {
        children.push(h('p', { class: 'muted', text: `${formatDay(current.from)} — ${formatDay(current.to)} · ${current.timezone === 'Europe/Moscow' ? 'Московское время' : current.timezone}` }));
        if (current.coverage.basis === 'none') children.push(h('p', { class: 'muted', text: 'Текущий контент-план в этом чтении не подтверждён.' }));
        if (current.truncated) children.push(h('p', { class: 'muted', role: 'status', text: 'Список недели неполный. Остальные материалы доступны в штатном плане.' }));
        if (!current.posts.length) children.push(h('p', { role: 'status', text: current.truncated ? 'В загруженной части списка материалов нет.' : 'На эту неделю материалов нет.' }));
        else children.push(...current.posts.map(card));
        if (current.undatedTotal) children.push(h('h2', { class: 'text__title', text: 'Без даты' }), ...current.undated.slice(0, 5).map(card));
        if (current.undatedTruncated || current.undatedTotal > Math.min(5, current.undated.length)) children.push(h('p', { class: 'muted', role: 'status', text: `Без даты: ${current.undatedTotal}. Показана часть материалов; остальные — в штатном плане.` }));
      }
      element.replaceChildren(...children);
    }
    async function refresh() {
      if (disposed || doc.hidden) return;
      controller?.abort(); const own = new win.AbortController(), ticket = ++seq; controller = own; current = null; error = ''; loading = true; paint();
      try { const value = validate(await read({ signal: own.signal })); if (disposed || ticket !== seq || own.signal.aborted) return; current = value; }
      catch (_) { if (disposed || ticket !== seq || own.signal.aborted) return; current = null; error = 'Не удалось загрузить контент. Повторите чтение.'; }
      finally { if (!disposed && ticket === seq && !own.signal.aborted) { loading = false; controller = null; paint(); } }
    }
    function visibility() { if (doc.hidden) { seq++; controller?.abort(); controller = null; current = null; loading = false; paint(); } else void refresh(); }
    function dispose() { if (disposed) return; disposed = true; seq++; controller?.abort(); controller = null; current = null; element.replaceChildren(); doc.removeEventListener('visibilitychange', visibility); }
    doc.addEventListener('visibilitychange', visibility); paint(); void refresh();
    return Object.freeze({ element, refresh, dispose });
  }
  return Object.freeze({ create });
});
