'use strict';

// Read-only Palitra CRM projection. The host owns authentication and supplies its existing
// company permission check; this module deliberately has no schema or workflow initialiser.
const SITE = 'palitra';
const COMPANY = 'palitra-love';
const SCHEMA = 'palitra-manager-attention/v1';
const WORKFLOW_PREFIX = `${COMPANY}/order-workflow/orders/`;
const FOLLOWUP_PREFIX = `${COMPANY}/order-contact-followup/v1/`;

function fail(status, code, message) {
  throw Object.assign(new Error(message), { status, code });
}
function iso(value) {
  if (typeof value !== 'string' || !Number.isFinite(Date.parse(value))) fail(503, 'ATTENTION_SOURCE_DATE', 'Некорректная дата источника');
  return new Date(Date.parse(value)).toISOString();
}
function object(value) { return value && typeof value === 'object' && !Array.isArray(value); }
function positiveId(value) { return Number.isSafeInteger(value) && value > 0; }
function documentValue(row) {
  if (!row) return null;
  try { const value = JSON.parse(row.body); if (object(value) && value.schema === 1) return value; }
  catch (_) { /* Refuse to call corrupt saved state complete. */ }
  fail(503, 'ATTENTION_SOURCE_DOCUMENT', 'Некорректный сохранённый документ');
}
function parseQuery(query, current) {
  const input = query === undefined ? {} : query;
  if (!object(input) || Object.keys(input).some(key => !['filter', 'limit', 'cursor'].includes(key)))
    fail(400, 'ATTENTION_QUERY', 'Некорректный запрос');
  const filter = input.filter === undefined ? 'attention' : input.filter;
  if (filter !== 'all' && filter !== 'attention') fail(400, 'ATTENTION_FILTER', 'Некорректный фильтр');
  const limit = input.limit === undefined ? 30 : Number(input.limit);
  if (!Number.isSafeInteger(limit) || limit < 1 || limit > 100 ||
      (typeof input.limit === 'string' && !/^[1-9]\d{0,2}$/.test(input.limit)))
    fail(400, 'ATTENTION_LIMIT', 'Некорректный размер страницы');
  let after = null, asOf = new Date(current).toISOString();
  if (input.cursor !== undefined) {
    if (typeof input.cursor !== 'string' || input.cursor.length > 512 || !/^[A-Za-z0-9_-]+$/.test(input.cursor))
      fail(400, 'ATTENTION_CURSOR', 'Некорректный курсор');
    try {
      const data = JSON.parse(Buffer.from(input.cursor, 'base64url').toString('utf8'));
      if (!object(data) || Object.keys(data).sort().join(',') !== 'asOf,basisAt,filter,key,priority,scope,v' ||
          data.v !== 1 || data.scope !== COMPANY || data.filter !== filter ||
          typeof data.key !== 'string' || !/^(?:order|thread|legacy):[1-9]\d*$/.test(data.key) ||
          (data.priority !== 0 && data.priority !== 1) ||
          iso(data.asOf) !== data.asOf || iso(data.basisAt) !== data.basisAt ||
          Date.parse(data.asOf) > current) throw new Error('cursor');
      asOf = data.asOf; after = { priority: data.priority, basisAt: data.basisAt, key: data.key };
    } catch (_) { fail(400, 'ATTENTION_CURSOR', 'Некорректный курсор'); }
  }
  return { filter, limit, after, asOf };
}
function cursorFor(filter, asOf, item) {
  return Buffer.from(JSON.stringify({ v: 1, scope: COMPANY, filter, asOf,
    priority: priority(item), basisAt: item.basisAt, key: item.key })).toString('base64url');
}
function priority(item) { return item.reason ? 0 : 1; }
function compare(a, b) { return priority(a) - priority(b) || a.basisAt.localeCompare(b.basisAt) || a.key.localeCompare(b.key); }
function latestStage(work) {
  if (!work) return { workflowState: 'uninitialized', stage: null, terminal: false, contactConfirmed: false };
  if (!Array.isArray(work.stages) || typeof work.currentStageId !== 'string' || !Array.isArray(work.confirmations))
    fail(503, 'ATTENTION_SOURCE_WORKFLOW', 'Некорректные этапы заявки');
  const current = work.stages.find(stage => stage && stage.id === work.currentStageId);
  if (!current || typeof current.label !== 'string') fail(503, 'ATTENTION_SOURCE_WORKFLOW', 'Текущий этап не найден');
  const transitions = Array.isArray(work.history) ? work.history.filter(h => h && h.nextStageId === current.id && h.action === 'advance') : [];
  const at = transitions.length ? iso(transitions[transitions.length - 1].at) : null;
  return {
    workflowState: 'stored', stage: { id: current.id, label: current.label, since: at },
    terminal: work.stages.at(-1)?.id === current.id,
    contactConfirmed: work.confirmations.some(c => c && c.requirement === 'contact_confirmed'),
  };
}
function createManagerAttention({ db, orders, workflow, canAccess, now = Date.now } = {}) {
  if (!db || typeof db.prepare !== 'function' || typeof canAccess !== 'function' || typeof now !== 'function')
    throw new TypeError('Existing read-only CRM host required');
  // `orders` and `workflow` are intentionally not called: some workflow reads initialise old documents.
  void orders; void workflow;
  const listOrders = db.prepare(`SELECT o.id,o.name,o.created_at,w.status AS work_status
    FROM site_orders o LEFT JOIN site_order_work w ON w.order_id=o.id
    WHERE o.site=? AND o.company_code=? AND o.created_at<=? ORDER BY o.id`);
  const listWeb = db.prepare(`SELECT id,order_id,created_at,last_message_at FROM chat_threads
    WHERE site=? AND company_code=? AND created_at<=? ORDER BY id`);
  const listLegacy = db.prepare(`SELECT id,order_id,display_name,created_at,last_message_at FROM client_dialogs
    WHERE company_code=? AND created_at<=? ORDER BY id`);
  const webCustomer = db.prepare(`SELECT m.id,m.created_at FROM chat_thread_messages m
    JOIN chat_threads t ON t.id=m.thread_id
    WHERE m.thread_id=? AND t.site=? AND t.company_code=? AND m.created_at<=? AND m.id>?
      AND m.direction='in' AND m.author_kind='customer'
      AND NOT EXISTS (SELECT 1 FROM chat_thread_requests r WHERE r.message_id=m.id AND r.thread_id=m.thread_id
        AND r.actor_kind='web' AND r.actor_ref='session:' || m.web_session_id
        AND r.request_id='checkout-order:' || t.order_id)
    ORDER BY m.id ASC LIMIT 1`);
  const lastWebHuman = db.prepare(`SELECT m.id,m.created_at FROM chat_thread_messages m
    JOIN chat_threads t ON t.id=m.thread_id
    LEFT JOIN chat_message_deliveries d ON d.message_id=m.id AND d.channel='customer_telegram'
    WHERE m.thread_id=? AND t.site=? AND t.company_code=? AND m.created_at<=?
      AND m.direction='out' AND (m.author_kind='owner' OR (m.author_kind='manager' AND m.source_channel='manager_telegram'))
      AND (d.id IS NULL OR (d.status='sent' AND d.updated_at<=?))
    ORDER BY m.id DESC LIMIT 1`);
  const legacyCustomer = db.prepare(`SELECT m.id,m.created_at FROM client_dialog_messages m
    JOIN client_dialogs d ON d.id=m.dialog_id
    WHERE m.dialog_id=? AND d.company_code=? AND m.company_code=d.company_code AND m.bot_key=d.bot_key
      AND m.created_at<=? AND m.id>? AND m.direction='in' AND m.author_type='client'
    ORDER BY m.id ASC LIMIT 1`);
  const lastLegacyHuman = db.prepare(`SELECT m.id,m.created_at FROM client_dialog_messages m
    JOIN client_dialogs d ON d.id=m.dialog_id
    WHERE m.dialog_id=? AND d.company_code=? AND m.company_code=d.company_code AND m.bot_key=d.bot_key
      AND m.created_at<=? AND m.direction='out' AND m.author_type='operator' AND m.delivery_status='sent'
    ORDER BY m.id DESC LIMIT 1`);
  const latestDocument = db.prepare('SELECT body FROM documents WHERE key=? AND created_at<=? ORDER BY version DESC LIMIT 1');

  function read(sessionUser, rawQuery = {}) {
    if (canAccess(sessionUser, 'crm.view') !== true) fail(403, 'ATTENTION_ACCESS', 'Нет доступа к заявкам Palitra Love');
    const current = now();
    if (!Number.isSafeInteger(current) || current < 0) fail(503, 'ATTENTION_CLOCK', 'Некорректное время сервера');
    const query = parseQuery(rawQuery, current);
    const orderMap = new Map(), closedOrderIds = new Set();
    for (const row of listOrders.all(SITE, COMPANY, query.asOf)) {
      const createdAt = iso(row.created_at);
      const work = documentValue(latestDocument.get(WORKFLOW_PREFIX + row.id, query.asOf));
      const wf = latestStage(work);
      if (row.work_status === 'done' || row.work_status === 'cancelled' || wf.terminal) {
        closedOrderIds.add(row.id); continue;
      }
      orderMap.set(row.id, {
        key: `order:${row.id}`, kind: 'order', orderRef: `native-order:${row.id}`, threadRef: null, dialogRef: null,
        threadRefs: [], dialogRefs: [], attentionRef: null,
        customerLabel: String(row.name || '').slice(0, 100), reason: null, basisAt: wf.stage?.since || createdAt,
        dueAt: null, deadlineKind: null, workflowState: wf.workflowState, stage: wf.stage,
        _createdAt: createdAt, _contactConfirmed: wf.contactConfirmed, _customerSeen: false, _humanSeen: false,
        _pendingInbound: [], _lastActivity: createdAt,
      });
    }
    const loose = [];
    function addConversation({ id, orderId, kind, createdAt, lastActivity, label, firstCustomer, pendingCustomer, human }) {
      if (closedOrderIds.has(orderId)) return;
      // A legacy conversation can outlive an old/missing order. Retain it without an
      // order reference; never dereference or expose an inconsistent foreign order.
      const linked = orderMap.has(orderId);
      const entry = linked ? orderMap.get(orderId) : {
        key: `${kind}:${id}`, kind: kind === 'thread' ? 'web-thread' : 'legacy-dialog',
        orderRef: null, threadRef: null, dialogRef: null, customerLabel: label,
        threadRefs: [], dialogRefs: [], attentionRef: null,
        reason: null, basisAt: createdAt, dueAt: null, deadlineKind: null,
        workflowState: 'uninitialized', stage: null, _createdAt: createdAt,
        _contactConfirmed: false, _customerSeen: false, _humanSeen: false,
        _pendingInbound: [], _lastActivity: createdAt,
      };
      const ref = `${kind}:${id}`;
      if (kind === 'thread') {
        entry.threadRefs.push(ref); if (!entry.threadRef) entry.threadRef = ref;
      } else {
        entry.dialogRefs.push(ref); if (!entry.dialogRef) entry.dialogRef = ref;
      }
      if (!entry.customerLabel && label) entry.customerLabel = label;
      if (firstCustomer) entry._customerSeen = true;
      if (pendingCustomer) entry._pendingInbound.push({ at: iso(pendingCustomer.created_at), ref });
      if (human) entry._humanSeen = true;
      const savedActivity = lastActivity ? iso(lastActivity) : createdAt;
      const activity = savedActivity <= query.asOf ? savedActivity : createdAt;
      if (activity > entry._lastActivity) entry._lastActivity = activity;
      if (!linked) loose.push(entry);
    }
    for (const row of listWeb.all(SITE, COMPANY, query.asOf)) {
      const createdAt = iso(row.created_at);
      const human = lastWebHuman.get(row.id, SITE, COMPANY, query.asOf, query.asOf);
      addConversation({ id: row.id, orderId: row.order_id, kind: 'thread', createdAt,
        lastActivity: row.last_message_at, label: '',
        firstCustomer: webCustomer.get(row.id, SITE, COMPANY, query.asOf, 0),
        pendingCustomer: webCustomer.get(row.id, SITE, COMPANY, query.asOf, human?.id || 0), human });
    }
    for (const row of listLegacy.all(COMPANY, query.asOf)) {
      const createdAt = iso(row.created_at);
      const human = lastLegacyHuman.get(row.id, COMPANY, query.asOf);
      addConversation({ id: row.id, orderId: row.order_id, kind: 'legacy', createdAt,
        lastActivity: row.last_message_at, label: String(row.display_name || '').slice(0, 100),
        firstCustomer: legacyCustomer.get(row.id, COMPANY, query.asOf, 0),
        pendingCustomer: legacyCustomer.get(row.id, COMPANY, query.asOf, human?.id || 0), human });
    }
    const entries = [...orderMap.values(), ...loose];
    for (const entry of entries) {
      if (entry._pendingInbound.length) {
        const first = entry._pendingInbound.sort((a, b) => a.at.localeCompare(b.at) || a.ref.localeCompare(b.ref))[0];
        entry.reason = 'unanswered'; entry.basisAt = first.at; entry.attentionRef = first.ref;
      } else if (entry.orderRef && !entry._customerSeen && !entry._humanSeen && !entry._contactConfirmed) {
        entry.reason = 'first-contact'; entry.basisAt = entry._createdAt;
        const event = documentValue(latestDocument.get(FOLLOWUP_PREFIX + entry.orderRef.slice('native-order:'.length), query.asOf));
        if (event && event.site === SITE && event.companyCode === COMPANY &&
            event.orderId === Number(entry.orderRef.slice('native-order:'.length)) &&
            entry.threadRefs.includes(`thread:${event.threadId}`) && ['waiting', 'emitted'].includes(event.state) &&
            typeof event.dueAt === 'string') {
          entry.dueAt = iso(event.dueAt); entry.deadlineKind = 'customer-first-reply';
        }
      } else if (!entry.orderRef) entry.basisAt = entry._lastActivity;
      entry.ageSeconds = Math.max(0, Math.floor((Date.parse(query.asOf) - Date.parse(entry.basisAt)) / 1000));
      delete entry._createdAt; delete entry._contactConfirmed; delete entry._customerSeen;
      delete entry._humanSeen; delete entry._pendingInbound; delete entry._lastActivity;
    }
    const counts = { total: entries.length, attention: 0, unanswered: 0, firstContact: 0 };
    for (const item of entries) {
      if (item.reason) counts.attention++;
      if (item.reason === 'unanswered') counts.unanswered++;
      if (item.reason === 'first-contact') counts.firstContact++;
    }
    const filtered = query.filter === 'attention' ? entries.filter(item => item.reason) : entries;
    filtered.sort(compare);
    const remaining = query.after ? filtered.filter(item => compare(item, { ...query.after, reason: query.after.priority === 0 ? 'cursor' : null }) > 0) : filtered;
    const items = remaining.slice(0, query.limit);
    if (canAccess(sessionUser, 'crm.view') !== true) fail(403, 'ATTENTION_ACCESS', 'Доступ изменился');
    return { schema: SCHEMA, companyCode: COMPANY, scopeKey: SITE, filter: query.filter,
      asOf: query.asOf, partial: false, counts, items,
      nextCursor: remaining.length > items.length ? cursorFor(query.filter, query.asOf, items.at(-1)) : null };
  }
  return Object.freeze({ read });
}

module.exports = { createManagerAttention };
