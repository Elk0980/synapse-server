import hashlib,json,os,sys,types
from pathlib import Path
CODE=Path('/opt/synapse/releases/palitra-app-20261015/multi-company-app-20261019-r7b-code')
HELPER_SHA='5610ff8008b25b334c184388873d3633df5e9a92fa409c96ab7dca42bb441ff9'

def main():
 try:
  if HELPER_SHA is None:raise ValueError('DRAFT_NOT_FROZEN')
  if os.name!='posix' or os.geteuid()!=0 or Path(__file__).resolve().parent!=CODE:raise ValueError('EXACT_ROOT_NEW_NAMESPACE_REQUIRED')
  p=CODE/'release-native.py'
  if any(x.is_symlink() for x in [*p.parents,p]):raise ValueError('CODE_SYMLINK_REFUSED')
  raw=p.read_bytes()
  if hashlib.sha256(raw).hexdigest()!=HELPER_SHA:raise ValueError('FROZEN_HELPER_CHANGED')
  m=types.ModuleType('frozen_r7b_release');m.__file__=str(p);exec(compile(raw,str(p),'exec'),m.__dict__);return m.main()
 except Exception as e:
  print(json.dumps({'status':'ENTRY_REFUSED_NO_RETRY','messageSha256':hashlib.sha256(str(e).encode()).hexdigest()}));return 2
if __name__=='__main__':sys.exit(main())
