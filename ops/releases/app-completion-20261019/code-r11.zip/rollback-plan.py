"""Pure R11 -> R7C code rollback plan. Does not perform any I/O or activation."""
PARENT='sha256:0c0b1efed97adc25871abcafcc58788f5b6aecbe4e10ebd260312b652c69ce3e'
PROOF='40ef3d261c68fcdca488a31da328e245f70066066bbc92cfebba28a4f19c453d'
def plan(state):
 if state.get('name')!='multi-company-app-20261019-r11' or state.get('phase')!='APPLIED_NOT_CUSTOMER_ACCEPTANCE':raise ValueError('EXACT_COMPLETED_R11_REQUIRED')
 if state.get('inputs',{}).get('parentImage')!=PARENT or state.get('contentSchemaObjectsCreated')!=0 or state.get('activationRowsCreated')!=0:raise ValueError('CODE_ONLY_R11_REQUIRED')
 if state.get('inputs',{}).get('managedProofSha256')!=PROOF:raise ValueError('EXACT_MANAGED259_PROOF_REQUIRED')
 if len(state.get('static',[]))!=4 or any(r.get('baseSha256') is None for r in state['static']):raise ValueError('EXACT_FOUR_STATIC_REPLACEMENTS_REQUIRED')
 if 'trafficDatabaseBackup' not in state:raise ValueError('THIRD_STORE_PRESERVATION_PROOF_REQUIRED')
 return {'status':'MANUAL_PLAN_NOT_AUTHORIZATION','parentImage':PARENT,'requiredFreshLease':True,'requiredNewRootAcceptance':True,'expectedComposeFiles':41,'expectedSourceFiles':235,'expectedStaticFiles':41,
  'requiredCurrentConsistentBackups':['content.sqlite','salon-reports.sqlite','app-entry-stats.sqlite IF CURRENTLY PRESENT, including committed WAL'],'liveDatabaseOperations':[],'dropTables':[],'restoreDatabases':[],
  'trafficStorePolicy':'KEEP CURRENT presence, complete schema, all current events/revisions and WAL; never restore historical absence or old backup',
  'contentSchemaMustRemain':state['contentMigration']['afterSchemaSha256'],'managedProofMustRemain':PROOF,'automaticRetry':False,'oldHelpersReplay':False,
  'staticReplacements':[{'target':r['target'],'expectedCurrentSha256':r['sha256'],'restoreSha256':r['baseSha256'],'backup':r['backup']} for r in state['static']]}
