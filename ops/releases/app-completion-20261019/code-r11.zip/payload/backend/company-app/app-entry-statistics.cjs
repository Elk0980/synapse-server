'use strict';
// Separate private SQLite: authenticated entrances, never people, orders, money or attribution proof.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {DatabaseSync}=require('node:sqlite');
const {period}=require('./customer-reports.cjs');
const SOURCES=Object.freeze({'2gis':'2ГИС',telegram:'Telegram',vk:'ВКонтакте',instagram:'Instagram',youtube:'YouTube',tiktok:'TikTok',max:'MAX',yandex_maps:'Яндекс Карты',yandex:'Яндекс',google:'Google',whatsapp:'WhatsApp',other:'Другой источник',unknown:'Неизвестный источник'});
const COMPANIES=new Set(['alvi','avokado']),UUID=/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
const NAME='app-entry-stats.sqlite',MAX_EVENTS=50000;
const SQL=Object.freeze([
 `CREATE TABLE app_entry_meta_v1(singleton INTEGER PRIMARY KEY CHECK(singleton=1),schema_version INTEGER NOT NULL CHECK(schema_version=1),enabled_at TEXT NOT NULL,revision INTEGER NOT NULL CHECK(revision>=0),last_at TEXT NOT NULL)`,
 `CREATE TABLE app_entry_events_v1(company_code TEXT NOT NULL CHECK(company_code IN ('alvi','avokado')),request_id TEXT NOT NULL,payload_sha256 TEXT NOT NULL,source TEXT NOT NULL,created_at TEXT NOT NULL,revision INTEGER NOT NULL UNIQUE,PRIMARY KEY(company_code,request_id))`,
 `CREATE INDEX app_entry_period_v1 ON app_entry_events_v1(company_code,created_at,source)`
]);
const fail=(status,code)=>{throw Object.assign(new Error(code),{status,code});};
const need=(ok,code,status=503)=>{if(!ok)fail(status,code);};
const sha=raw=>crypto.createHash('sha256').update(raw).digest('hex');
const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
const time=v=>typeof v==='string'&&/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$/.test(v)&&Number.isFinite(Date.parse(v))&&new Date(v).toISOString()===v;
const payload=source=>sha(JSON.stringify({source}));
function checkedEvent(company,b){
 need(COMPANIES.has(company),'ENTRY_COMPANY',403);
 need(b&&typeof b==='object'&&!Array.isArray(b)&&Object.keys(b).sort().join(',')==='requestId,source'&&typeof b.requestId==='string'&&UUID.test(b.requestId)&&typeof b.source==='string'&&Object.hasOwn(SOURCES,b.source),'ENTRY_BODY',400);
 return{requestId:b.requestId,source:b.source};
}
function schema(db){return db.prepare("SELECT type,name,tbl_name,sql FROM sqlite_schema WHERE name NOT LIKE 'sqlite_%' ORDER BY name").all();}
const expectedSchema=SQL.map(sql=>({type:sql.startsWith('CREATE INDEX')?'index':'table',name:sql.split(/[ (]/)[2],tbl_name:sql.startsWith('CREATE INDEX')?'app_entry_events_v1':sql.split(/[ (]/)[2],sql})).sort((a,b)=>a.name.localeCompare(b.name));
function readState(db,now){
 const objects=schema(db);if(!objects.length)return null;
 need(same(objects,expectedSchema),'ENTRY_SCHEMA_CHANGED');
 need(db.prepare('PRAGMA quick_check').get().quick_check==='ok','ENTRY_DATABASE_INTEGRITY');
 const metadata=db.prepare('SELECT * FROM app_entry_meta_v1').all();need(metadata.length===1,'ENTRY_METADATA');const m=metadata[0];
 need(m.singleton===1&&m.schema_version===1&&Number.isSafeInteger(m.revision)&&m.revision>=0&&m.revision<=MAX_EVENTS&&time(m.enabled_at)&&time(m.last_at)&&m.enabled_at<=m.last_at&&m.last_at<=now,'ENTRY_METADATA');
 const events=db.prepare('SELECT * FROM app_entry_events_v1 ORDER BY revision LIMIT ?').all(MAX_EVENTS+1);need(events.length===m.revision,'ENTRY_REVISION');let last=m.enabled_at;
 for(let i=0;i<events.length;i++){
  const e=events[i];need(COMPANIES.has(e.company_code)&&typeof e.request_id==='string'&&UUID.test(e.request_id)&&typeof e.source==='string'&&Object.hasOwn(SOURCES,e.source)&&e.payload_sha256===payload(e.source)&&time(e.created_at)&&e.created_at>=last&&e.created_at<=m.last_at&&e.revision===i+1,'ENTRY_EVENT_INVALID');last=e.created_at;
 }
 need(last===m.last_at,'ENTRY_LAST_TIMESTAMP');return{metadata:m,events};
}
function calculate(state,company,query,at){
 if(!state)return null;const p=period(query,at),enabledAt=state.metadata.enabled_at;
 const unobserved=p.untilAt<=enabledAt||p.fromAt>=at||at<enabledAt;
 const rows=state.events.filter(e=>e.company_code===company&&e.created_at<=at),counts=new Map(Object.keys(SOURCES).map(k=>[k,0]));
 for(const e of rows)if(e.created_at>=p.fromAt&&e.created_at<p.untilAt)counts.set(e.source,counts.get(e.source)+1);
 const total=unobserved?null:[...counts.values()].reduce((n,c)=>n+c,0);
 return{contract:'app-entry-statistics/v1',companyCode:company,period:p,metric:'entrances',status:unobserved?'unobserved':'partial',enabledAt,updatedAt:rows.at(-1)?.created_at||enabledAt,total,
  coverage:{kind:'authenticated-app-entries',fromAt:enabledAt,observedThrough:at,complete:false},
  sources:Object.entries(SOURCES).map(([key,label])=>({key,label,count:unobserved?null:counts.get(key),percent:unobserved?null:total?Math.round(counts.get(key)/total*1000)/10:0,updatedAt:rows.findLast(e=>e.source===key)?.created_at||enabledAt}))};
}
function createProvider({open,clock=()=>new Date().toISOString()}={}){
 need(typeof open==='function','ENTRY_DATABASE_FACTORY_REQUIRED');let closed=false,busy=false,lastClock=null,sealed=null;
 function now(){const at=clock();need(time(at)&&(!lastClock||at>=lastClock),'ENTRY_SERVER_CLOCK');lastClock=at;return at;}
 function checkPrefix(s){
  if(sealed)need(s&&s.metadata.enabled_at===sealed.enabledAt&&s.metadata.revision>=sealed.revision&&sha(JSON.stringify(s.events.slice(0,sealed.revision)))===sealed.sha,'ENTRY_HISTORY_CHANGED');
 }
 function seal(s){if(s)sealed={enabledAt:s.metadata.enabled_at,revision:s.metadata.revision,sha:sha(JSON.stringify(s.events))};}
 const receipt=(e,replayed)=>({contract:'app-entry-receipt/v1',companyCode:e.company_code,requestId:e.request_id,source:e.source,acceptedAt:e.created_at,revision:e.revision,replayed});
 function operation(write,beforeCommit,fn){
  need(!closed&&!busy,'ENTRY_INSTANCE_UNAVAILABLE');busy=true;let connection=null,transaction=false;
  try{
   let at=now();if(write)beforeCommit();connection=open(write);if(!connection){need(!write,'ENTRY_DATABASE_UNAVAILABLE');return fn(null,at,null).value;}
   connection.guard();const db=connection.db;db.exec(write?'BEGIN IMMEDIATE':'BEGIN');transaction=true;
   at=now();
   let s=readState(db,at);checkPrefix(s);
   const result=fn(s,at,db);if(write)beforeCommit();connection.guard();db.exec('COMMIT');transaction=false;
   if(result.state)seal(result.state);else seal(s);return result.value;
  }catch(e){if(transaction)try{connection.db.exec('ROLLBACK');}catch{}throw e;}
  finally{try{connection?.release?.();}finally{busy=false;}}
 }
 return Object.freeze({
  record(company,body,{beforeCommit=()=>{}}={}){
   checkedEvent(company,body);return operation(true,beforeCommit,(s,at,db)=>{
    if(!s){for(const sql of SQL)db.exec(sql);db.prepare('INSERT INTO app_entry_meta_v1 VALUES(1,1,?,0,?)').run(at,at);s={metadata:{singleton:1,schema_version:1,enabled_at:at,revision:0,last_at:at},events:[]};}
    const old=s.events.find(e=>e.company_code===company&&e.request_id===body.requestId);
    if(old){need(old.payload_sha256===payload(body.source)&&old.source===body.source,'ENTRY_REQUEST_MISMATCH',409);return{value:receipt(old,true),state:s};}
    need(s.events.length<MAX_EVENTS,'ENTRY_CAPACITY');
    const revision=s.metadata.revision+1;
    db.prepare('INSERT INTO app_entry_events_v1 VALUES(?,?,?,?,?,?)').run(company,body.requestId,payload(body.source),body.source,at,revision);
    need(db.prepare('UPDATE app_entry_meta_v1 SET revision=?,last_at=? WHERE singleton=1 AND revision=? AND last_at=?').run(revision,at,s.metadata.revision,s.metadata.last_at).changes===1,'ENTRY_CAS_CHANGED');
    const next=readState(db,at),e=next.events.at(-1);return{value:receipt(e,false),state:next};
   });
  },
  read(company,query={},at){need(COMPANIES.has(company),'ENTRY_COMPANY',403);return operation(false,()=>{},(s,serverNow)=>{
   at=at===undefined?serverNow:at;need(time(at)&&at<=serverNow,'ENTRY_REPORT_CLOCK');period(query,at);return{value:calculate(s,company,query,at),state:s};
  });},
  close(){closed=true;}
 });
}
const identity=s=>({dev:String(s.dev),ino:String(s.ino),uid:s.uid,gid:s.gid,mode:s.mode&0o777});
// No chmod/chown fallback. Tests can explicitly inject POSIX metadata over isolated Windows fixtures.
function createPathGuard(filePath,{fsImpl=fs,processIdentity=process}={}){
 need(processIdentity.platform==='linux'&&processIdentity.geteuid()===0,'ENTRY_NATIVE_ROOT_POSIX_REQUIRED');
 need(typeof filePath==='string'&&path.isAbsolute(filePath)&&path.basename(filePath)===NAME&&path.normalize(filePath)===filePath,'ENTRY_EXACT_PATH');
 const f=fsImpl,dir=path.dirname(filePath);let fileIdentity=null;
 function directory(){
  for(let p=dir;;p=path.dirname(p)){const s=f.lstatSync(p);need(s.isDirectory()&&!s.isSymbolicLink()&&s.uid===0&&s.gid===0&&(s.mode&0o022)===0,'ENTRY_DIRECTORY_UNSAFE');if(path.dirname(p)===p)break;}
  need(f.realpathSync(dir)===dir,'ENTRY_DIRECTORY_REALPATH');return identity(f.lstatSync(dir));
 }
 const directoryIdentity=directory();
 function inspect(){
  need(same(directory(),directoryIdentity),'ENTRY_DIRECTORY_CHANGED');const files={};
  for(const suffix of ['', '-wal','-shm','-journal']){
   const p=filePath+suffix;let s;try{s=f.lstatSync(p);}catch(e){if(e.code==='ENOENT'){files[suffix||'db']=null;continue;}throw e;}
   need(s.isFile()&&!s.isSymbolicLink()&&s.nlink===1&&s.uid===0&&s.gid===0&&(s.mode&0o777)===0o600&&f.realpathSync(p)===p,'ENTRY_PRIVATE_FILE_REQUIRED');files[suffix||'db']=identity(s);
  }
  if(!files.db)need(Object.values(files).every(x=>x===null),'ENTRY_ORPHAN_SIDECAR');
  if(fileIdentity)need(files.db&&same(files.db,fileIdentity),'ENTRY_DATABASE_REPLACED');else if(files.db)fileIdentity=files.db;
  return{path:filePath,directoryIdentity,files};
 }
 return Object.freeze({inspect,create(){
  const before=inspect();if(before.files.db)return before;
  let fd;try{fd=f.openSync(filePath,f.constants.O_CREAT|f.constants.O_EXCL|f.constants.O_WRONLY|f.constants.O_NOFOLLOW,0o600);f.fsyncSync(fd);}catch(e){if(e.code!=='EEXIST')throw e;}finally{if(fd!==undefined)f.closeSync(fd);}
  const d=f.openSync(dir,f.constants.O_RDONLY|f.constants.O_DIRECTORY|f.constants.O_NOFOLLOW);try{f.fsyncSync(d);}finally{f.closeSync(d);}return inspect();
 }});
}
function createFileProvider({filePath,clock}={}){
 const guard=createPathGuard(filePath);
 return createProvider({clock,open(write){const group=write?guard.create():guard.inspect();if(!group.files.db)return null;
  const db=new DatabaseSync(filePath,{readOnly:!write});
  try{
   db.exec('PRAGMA busy_timeout=5000');if(write){db.exec('PRAGMA journal_mode=WAL;PRAGMA synchronous=FULL');need(db.prepare('PRAGMA journal_mode').get().journal_mode==='wal'&&db.prepare('PRAGMA synchronous').get().synchronous===2,'ENTRY_WAL_DURABILITY_REQUIRED');}
   else need(db.prepare('PRAGMA journal_mode').get().journal_mode==='wal','ENTRY_WAL_REQUIRED');
   guard.inspect();return{db,guard:()=>guard.inspect(),release:()=>db.close()};
  }catch(e){db.close();throw e;}
 }});
}
// Pure code-only descriptor: execution, backup and rollback belong to a separately reviewed installer.
const backupDefinition=Object.freeze({contract:'app-entry-sqlite-backup/v1',name:NAME,files:['db','-wal','-shm','-journal'],schema:SQL,privateMode:0o600,owner:0,group:0,
 absent:'seal entire group absent; never create on inspection',existing:'online consistent SQLite backup includes committed WAL; quick_check; root0600 singlelink backup in root0700 directory',
 preserve:'retain all old events and revisions; permit only validated append transactions; do not compare late full DB hash with old live baseline',
 rollback:'preserve current stats DB and all new entrances; never restore an old DB or remove tables/events; preserve content.sqlite and salon-reports.sqlite too',
 recovery:'SQLite WAL recovery; no persistent PID/writer file and no manual stale-lock cleanup'});
module.exports={createProvider,createFileProvider,createPathGuard,readState,checkedEvent,SOURCES,SQL,MAX_EVENTS,NAME,backupDefinition};
