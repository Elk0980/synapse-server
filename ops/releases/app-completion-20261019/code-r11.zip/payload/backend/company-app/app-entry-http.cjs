'use strict';
const {checkedEvent}=require('./app-entry-statistics.cjs');
const MAX_BODY=1024,ORIGIN='https://synapse.synapsebusiness.ru',MAX_READ_MS=15000;
const fail=(status,code)=>{throw Object.assign(new Error(code),{status,code});};
const permitted=(u,c)=>Boolean(u&&['owner','editor'].includes(u.role)&&Array.isArray(u.companyCodes)&&u.companyCodes.includes(c));
function flatJson(text){
 let i=0;const whitespace=()=>{while(/[ \t\r\n]/.test(text[i]||'')&&i<text.length)i++;};
 const token=()=>{whitespace();const re=/"(?:\\["\\/bfnrt]|\\u[0-9a-fA-F]{4}|[^"\\\u0000-\u001f])*"/y;re.lastIndex=i;const m=re.exec(text);if(!m)fail(400,'ENTRY_JSON');i=re.lastIndex;return JSON.parse(m[0]);};
 const char=c=>{whitespace();if(text[i++]!==c)fail(400,'ENTRY_JSON');};const out=Object.create(null);char('{');
 while(true){const k=token();if(Object.hasOwn(out,k))fail(400,'ENTRY_DUPLICATE_FIELD');char(':');out[k]=token();whitespace();if(text[i]!==',')break;i++;}
 char('}');whitespace();if(i!==text.length)fail(400,'ENTRY_JSON');return out;
}
async function readEntryJson(request,{monotonic=()=>performance.now(),started=monotonic(),deadlineMs=MAX_READ_MS,timers={setTimeout,clearTimeout}}={}){
 if(!/^application\/json(?:\s*;\s*charset=utf-8)?$/i.test(request.headers['content-type']||''))fail(415,'ENTRY_JSON_REQUIRED');
 if(request.headers['content-encoding']&&request.headers['content-encoding']!=='identity')fail(415,'ENTRY_ENCODING');
 const length=request.headers['content-length'];if(length!==undefined&&(!/^\d+$/.test(String(length))||Number(length)>MAX_BODY))fail(413,'ENTRY_BODY_LIMIT');
 if(!Number.isSafeInteger(deadlineMs)||deadlineMs<1||deadlineMs>MAX_READ_MS)fail(503,'ENTRY_DEADLINE_CONFIG');
 const expired=()=>{const elapsed=monotonic()-started;return !Number.isFinite(elapsed)||elapsed<0||elapsed>=deadlineMs;};
 let size=0,timer=null,iterator,finished=false,rejectStop;const chunks=[];
 const stop=new Promise((_,reject)=>{rejectStop=reject;});
 // A rejection can arrive before next() is raced; always retain a rejection handler.
 stop.catch(()=>{});
 const interrupt=(status,code)=>rejectStop(Object.assign(new Error(code),{status,code}));
 function onBodyAborted(){interrupt(400,'ENTRY_BODY_INTERRUPTED');}
 function onBodyError(){interrupt(400,'ENTRY_BODY_INTERRUPTED');}
 function onBodyClose(){if(!request.complete)interrupt(400,'ENTRY_BODY_INTERRUPTED');}
 try{
  if(request.aborted||request.destroyed&&!request.complete)fail(400,'ENTRY_BODY_INTERRUPTED');
  if(expired())fail(408,'ENTRY_BODY_EXPIRED');
  request.on?.('aborted',onBodyAborted);request.on?.('error',onBodyError);request.on?.('close',onBodyClose);
  timer=timers.setTimeout(()=>interrupt(408,'ENTRY_BODY_EXPIRED'),Math.max(1,Math.ceil(deadlineMs-(monotonic()-started))));
  iterator=request[Symbol.asyncIterator]();
  while(true){
   if(expired())fail(408,'ENTRY_BODY_EXPIRED');
   // The race attaches rejection handlers to every outstanding next(), including
   // one that rejects after timeout/abort. Never await a stalled iterator.return().
   const item=await Promise.race([Promise.resolve().then(()=>iterator.next()),stop]);
   if(item.done){finished=true;break;}
   const raw=Buffer.from(item.value);size+=raw.length;if(size>MAX_BODY)fail(413,'ENTRY_BODY_LIMIT');chunks.push(raw);
  }
  if(request.aborted||request.destroyed&&!request.complete)fail(400,'ENTRY_BODY_INTERRUPTED');
  if(expired())fail(408,'ENTRY_BODY_EXPIRED');if(length!==undefined&&Number(length)!==size)fail(400,'ENTRY_BODY_LENGTH');
 }catch(e){if(e.status)throw e;fail(400,'ENTRY_BODY_INTERRUPTED');}
 finally{
  if(timer!==null)timers.clearTimeout(timer);
  if(!finished){
   // Cancel the real HTTP upload/read so its socket does not outlive the deadline.
   // Destroy without an error argument; the rejected read already carries the code.
   try{request.destroy?.();}catch{}
   try{Promise.resolve(iterator?.return?.()).catch(()=>{});}catch{}
  }
  request.removeListener?.('aborted',onBodyAborted);request.removeListener?.('error',onBodyError);request.removeListener?.('close',onBodyClose);
 }
 let text;try{text=new TextDecoder('utf-8',{fatal:true}).decode(Buffer.concat(chunks));}catch{fail(400,'ENTRY_UTF8');}
 return flatJson(text);
}
async function handle({request,url,reply,requireSession,requireCsrf,origin,traffic,monotonic=()=>performance.now()}){
 const m=/^\/content\/(alvi|avokado)\/app-entry$/.exec(url.pathname);if(!m)return false;
 if(request.method!=='POST')fail(405,'ENTRY_POST_ONLY');if(url.search)fail(400,'ENTRY_QUERY_FORBIDDEN');
 const company=m[1],first=requireSession(request);if(!permitted(first.user,company))fail(403,'ENTRY_FORBIDDEN');
 if(origin!==ORIGIN||request.headers.origin!==ORIGIN)fail(403,'ENTRY_ORIGIN');requireCsrf(request,first);
 const started=monotonic(),body=await readEntryJson(request,{monotonic,started});checkedEvent(company,body);
 const verify=()=>{if(request.aborted||request.destroyed&&!request.complete)fail(400,'ENTRY_BODY_INTERRUPTED');if(monotonic()-started>MAX_READ_MS)fail(408,'ENTRY_BODY_EXPIRED');
  const fresh=requireSession(request);if(fresh.user.id!==first.user.id||fresh.user.sessionVersion!==first.user.sessionVersion||!permitted(fresh.user,company))fail(403,'ENTRY_ACCESS_CHANGED');
  if(origin!==ORIGIN||request.headers.origin!==ORIGIN)fail(403,'ENTRY_ORIGIN');requireCsrf(request,fresh);};
 verify();if(!traffic)fail(503,'ENTRY_PROVIDER_NOT_CONFIGURED');const result=traffic.record(company,body,{beforeCommit:verify});
 reply(200,result,{'cache-control':'private, no-store','vary':'Cookie','x-content-type-options':'nosniff'});return true;
}
module.exports={handle,readEntryJson,permitted,MAX_BODY,MAX_READ_MS};
