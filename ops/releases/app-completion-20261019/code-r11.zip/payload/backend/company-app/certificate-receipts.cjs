'use strict';
// Calendar-day receipts, independently sourced. Never client cash rows or LTV.
const branches=Object.freeze({alvi:989844,avokado:375899});
const SOURCE='salon-certificate-receipts-without-buyer/v1',METRIC='certificate-receipts-without-buyer-metric/v1';
const MAX=9223372036854775807n,MAX_COUNT=BigInt(Number.MAX_SAFE_INTEGER);
const dateFormat=new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Irkutsk',year:'numeric',month:'2-digit',day:'2-digit'});
const localDay=at=>dateFormat.format(new Date(at));
const fail=()=>{throw Object.assign(new Error('Оплаты сертификатов не прошли проверку источника и дат'),{status:400});};
const object=v=>Boolean(v&&typeof v==='object'&&!Array.isArray(v)&&[Object.prototype,null].includes(Object.getPrototypeOf(v)));
function fields(v,names){if(!object(v)||Object.keys(v).length!==names.length||Object.keys(v).some(k=>!names.includes(k)))fail();}
function day(v){if(typeof v!=='string'||!/^\d{4}-\d\d-\d\d$/.test(v)||!Number.isFinite(Date.parse(v+'T00:00:00Z'))||new Date(v+'T00:00:00Z').toISOString().slice(0,10)!==v)fail();return v;}
function time(v){return typeof v==='string'&&/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{3})?Z$/.test(v)&&Number.isFinite(Date.parse(v))&&new Date(v).toISOString()===(v.includes('.')?v:v.slice(0,-1)+'.000Z');}
function amount(v){if(typeof v!=='string'||!/^(0|[1-9]\d{0,18})$/.test(v))fail();const n=BigInt(v);if(n>MAX)fail();return n;}
const count=n=>Number.isSafeInteger(n)&&n>=0;
function validate(company,s,now=new Date().toISOString()){
 fields(s,['contract','companyCode','branchId','source','scope','currency','fromDay','throughDay','capturedAt','receivedKopecks','paymentCount','paidSaleDocumentCount','days','refundsComplete','netKopecks','includeInCustomerLtv','buyerAbsenceVerifiedFromPaidSaleForm','filledBuyerButUnresolvedClientIdIncluded']);
 if(!branches[company]||s.contract!==SOURCE||s.companyCode!==company||s.branchId!==branches[company]||s.source!=='yclients-ui'||s.scope!=='gift_certificate_receipts_without_recorded_buyer'||s.currency!=='RUB'||!time(now)||!time(s.capturedAt)||Date.parse(s.capturedAt)>Date.parse(now)||s.refundsComplete!==false||s.netKopecks!==null||s.includeInCustomerLtv!==false||s.buyerAbsenceVerifiedFromPaidSaleForm!==true||s.filledBuyerButUnresolvedClientIdIncluded!==false)fail();
 if(day(s.fromDay)!=='2000-01-01'||day(s.throughDay)<s.fromDay||s.throughDay>localDay(s.capturedAt)||!count(s.paymentCount)||!count(s.paidSaleDocumentCount)||s.paidSaleDocumentCount>s.paymentCount||!Array.isArray(s.days)||s.days.length>36600)fail();
 let total=0n,payments=0n,previous='';
 for(const row of s.days){
  fields(row,['day','receivedKopecks','payments']);day(row.day);
  const received=amount(row.receivedKopecks);
  if(row.day<s.fromDay||row.day>s.throughDay||row.day<=previous||received===0n||!count(row.payments)||row.payments===0||received<BigInt(row.payments))fail();
  previous=row.day;total+=received;payments+=BigInt(row.payments);
  if(total>MAX||payments>MAX_COUNT)fail();
 }
 if(total!==amount(s.receivedKopecks)||payments!==BigInt(s.paymentCount)||(s.paymentCount===0)!==(s.paidSaleDocumentCount===0))fail();
 return s;
}
function attach(out,s,now=new Date().toISOString()){
 const metric={contract:METRIC,companyCode:out.companyCode,branchId:branches[out.companyCode],currency:'RUB',receivedKopecks:null,paymentCount:null,paidSaleDocumentCount:null,complete:false,reason:'SOURCE_UNAVAILABLE',fromDay:null,asOfDay:null,sourceCutoffDay:null,capturedAt:null,refundsComplete:false,netKopecks:null,includeInCustomerLtv:false};
 out.certificateReceiptsWithoutBuyer=metric;
 if(s===undefined)return out;
 validate(out.companyCode,s,now);
 const cut=[out.period.to,localDay(now),s.throughDay].sort()[0];
 Object.assign(metric,{fromDay:s.fromDay,asOfDay:cut,sourceCutoffDay:s.throughDay,capturedAt:s.capturedAt});
 if(cut<s.fromDay){metric.reason='BEFORE_SOURCE_COVERAGE';return out;}
 let total=0n,payments=0n;
 for(const row of s.days)if(row.day<=cut){total+=BigInt(row.receivedKopecks);payments+=BigInt(row.payments);}
 Object.assign(metric,{receivedKopecks:total.toString(),paymentCount:Number(payments),paidSaleDocumentCount:cut===s.throughDay?s.paidSaleDocumentCount:null,complete:true,reason:null});
 return out;
}
module.exports={validate,attach,branches,SOURCE,METRIC,MAX};
