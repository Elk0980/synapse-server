"""Pure reviewable plan only. No shell, DB connection, writes or replay."""
PARENT='sha256:40c5bb71533969256a518f3c97fac28484ae2fb43e987fd34642be3e3d4860b3'
def plan(state):
    if state.get('name')!='multi-company-app-20261019-r7' or state.get('phase')!='APPLIED_NOT_CUSTOMER_ACCEPTANCE':raise ValueError('EXACT_COMPLETED_R7_REQUIRED')
    if state.get('inputs',{}).get('parentImage')!=PARENT:raise ValueError('EXACT_PARENT_REQUIRED')
    if state.get('contentMigration',{}).get('legacyRowWrites')!=0:raise ValueError('ADDITIVE_MIGRATION_PROOF_REQUIRED')
    return {'status':'MANUAL_PLAN_NOT_AUTHORIZATION','parentImage':PARENT,'requiredFreshLease':True,'requiredNewRootAcceptance':True,'oldHelpersReplay':False,'automaticRetry':False,'expectedComposeFiles':40,
       'requiredCurrentConsistentBackups':['content.sqlite','salon-reports.sqlite'],
       'liveDatabaseOperations':[],'dropTables':[],'restoreDatabases':[],
       'contentSchemaMustRemain':state['contentMigration']['afterSchemaSha256'],
       'staticReplacements':[{'target':r['target'],'expectedCurrentSha256':r['sha256'],'restoreSha256':r['baseSha256'],'backup':r['backup']} for r in state['static'] if r['baseSha256'] is not None],
       'retainedUnreferencedStatic':[r['target'] for r in state['static'] if r['baseSha256'] is None]}
