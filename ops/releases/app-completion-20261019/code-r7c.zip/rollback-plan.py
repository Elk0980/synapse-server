"""Pure reviewable plan only. No shell, DB connection, writes or replay."""
PARENT='sha256:40c5bb71533969256a518f3c97fac28484ae2fb43e987fd34642be3e3d4860b3'
def plan(state):
    if state.get('name')!='multi-company-app-20261019-r7c' or state.get('phase')!='APPLIED_NOT_CUSTOMER_ACCEPTANCE':raise ValueError('EXACT_COMPLETED_R7C_REQUIRED')
    if state.get('inputs',{}).get('parentImage')!=PARENT:raise ValueError('EXACT_PARENT_REQUIRED')
    managed=state['inputs'].get('managedSourceProof')
    managed_sha=state['inputs'].get('managedProofSha256')
    if not isinstance(managed,dict) or managed.get('current',{}).get('version')!=259 or not isinstance(managed_sha,str) or len(managed_sha)!=64 or any(c not in 'abcdef0123456789' for c in managed_sha) or state['inputs'].get('mapOutcomeSha256')!='7c206110ddb478f1be1221e689ea346e125b9e438096b59af39a7eb84ebc2c42':raise ValueError('EXACT_MANAGED_ROLLBACK_BASIS_REQUIRED')
    counts={'sealed':227,'supplementalExisting':1,'before':228,'after':235}
    if state['inputs'].get('sourceCounts')!=counts:raise ValueError('EXACT_SUPPLEMENTAL_INVENTORY_REQUIRED')
    supplement=state['inputs'].get('sourceSupplement',{})
    if supplement.get('path')!='project-chat.js' or supplement.get('sha256')!='f60b18567b81c8ed0ea28e1609c208d75fa78e95bad3cbbd6d24ea595d9bbf44' or supplement.get('mode')!=0o600 or supplement.get('bytes')!=179739:raise ValueError('EXACT_EXISTING_SOURCE_SUPPLEMENT_REQUIRED')
    if state.get('contentMigration',{}).get('legacyRowWrites')!=0:raise ValueError('ADDITIVE_MIGRATION_PROOF_REQUIRED')
    return {'status':'MANUAL_PLAN_NOT_AUTHORIZATION','parentImage':PARENT,'requiredFreshLease':True,'requiredNewRootAcceptance':True,'oldHelpersReplay':False,'automaticRetry':False,'expectedComposeFiles':40,'expectedParentSourceFiles':228,'expectedChildSourceFiles':235,
       'requiredCurrentConsistentBackups':['content.sqlite','salon-reports.sqlite'],'sourceSupplementToPreserve':supplement,
       'managedSourceMustRemain':managed,'managedProofSha256':managed_sha,'mapOutcomeSha256':state['inputs']['mapOutcomeSha256'],
       'liveDatabaseOperations':[],'dropTables':[],'restoreDatabases':[],
       'contentSchemaMustRemain':state['contentMigration']['afterSchemaSha256'],
       'staticReplacements':[{'target':r['target'],'expectedCurrentSha256':r['sha256'],'restoreSha256':r['baseSha256'],'backup':r['backup']} for r in state['static'] if r['baseSha256'] is not None],
       'retainedUnreferencedStatic':[r['target'] for r in state['static'] if r['baseSha256'] is None]}
