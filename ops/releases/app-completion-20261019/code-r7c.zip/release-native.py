"""R7C supplemental-inventory successor of installed R6. Separate native approval required.

Historical helpers/journals are read-only. Live report DB is never restored.
"""
import argparse
import base64
import copy
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import time
import types

FROZEN = True
ROOT = Path('/opt/synapse/releases/palitra-app-20261015')
NAME = 'multi-company-app-20261019-r7c'
CODE = ROOT / (NAME + '-code')
LOCK = '/opt/synapse/.palitra-app-release.lock'
PARENT = 'sha256:40c5bb71533969256a518f3c97fac28484ae2fb43e987fd34642be3e3d4860b3'
MANIFEST_SHA = 'af7bd62072e4a6eb369b46e04ca6c7dc5a4c3bc2e9350a605483af12fc551b0d'
ROLLBACK_SHA = '62bfb699e248e22560aac5386d2b157d931bfbabcac1fde3ce3066038cf537da'
DB_HELPER_SHA = '08456dc9fcfae875b22c631a461e0cedea5a702b5f8d43ae770de7cff6e78a63'
PRODUCT_REVIEW_SHA = 'c45c91f084c3f5a5b08a21cea3f79cc99ca294e77ab48c77cb1c1ebccffdc971'
PRODUCT_MANIFEST_SHA = 'b594f37643edd9beebfce3f15b94a0cce52c133fc7dc81d6bcd675fb338c9c94'
MANAGED_HELPER_SHA = 'b01bf2eb4d3b943a79855bccec858ea11b8f6aa57b400cf6f252c3b35c4c079e'
MANAGED_PROBE_SHA = '6adf008d2a6016031b6ad6812c3550a557694293a9a855a92cfb64e6c964ca6f'
MANAGED_PROOF_SHA = '40ef3d261c68fcdca488a31da328e245f70066066bbc92cfebba28a4f19c453d'  # Root-created root0600 O_EXCL external proof; fill only after its native read.
MANAGED_PROOF_PATH = ROOT / (NAME + '-managed-proof.json')
MAP_OUTCOME_SHA = '7c206110ddb478f1be1221e689ea346e125b9e438096b59af39a7eb84ebc2c42'
REPORT_DB_HOST = Path('/var/lib/docker/volumes/synapse_content_data/_data/salon-reports.sqlite')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
digest = lambda value: isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value) is not None


def need(value, code):
    if not value:
        raise ValueError(code)


def private_report_db(value):
    return (type(value) is dict and set(value) == {'path', 'files'} and value['path'] == '/data/salon-reports.sqlite'
            and type(value['files']) is dict and set(value['files']) == {'db', 'wal', 'shm'} and value['files']['db'] is not None
            and all(row is None or type(row) is dict and row == {'uid': 0, 'mode': 0o600} for row in value['files'].values()))



CONTENT_HELPER_SHA = 'd6363b217d69a49751d875b00cf50776593d01160b386190edaac8bf537ab4be'
CONTENT_MIGRATION_SHA = '84e3e34c782a36f555a850cff6ea761823ef625059d1c782f5039f328dc27100'
NATIVE_CABINET_CSS_HOST = '/opt/synapse/sites/synapse/cabinet/project-chat.css'
NATIVE_CABINET_CSS_BEFORE = '1e5ef9181c969bf0b3a664a7c35029cc4d07c5768c1f8aae5238efeaebed3ce6'
NATIVE_CABINET_HOST = '/opt/synapse/sites/synapse/cabinet/project-chat.js'  # Fresh host-path/hash proof required, no assumed path.
NATIVE_CABINET_BEFORE = '25a733a2c96de6bb4ac72d527c4c204b6024254ce3f0d11fba4de77d81008b92'
R6_HELPER = '1f4b048551ba20309e129212a269ed53765cd99997802ee2b16d6985cfc46de0'
R6_RECEIPT = '70c0489236d120a84074b3a45acacc21c3e26e3fe42408b8324af8439280d0ea'
R6_DECISION = '2a9013bb448bbf81ac836838cc2af66743d19ea1895f996fc96486680e9e11fd'
R6_IMAGE = PARENT
CONTENT_DB_HOST = REPORT_DB_HOST.with_name('content.sqlite')
def load_current_r6(pid):
    need(type(pid) is int and pid > 1 and pid not in (3015977,3031696,3045034,3065621,3077369,3088926,3090987,3091431,3091609), 'FRESH_R7C_WRITER_LEASE_REQUIRED')
    folder = ROOT / 'multi-company-app-20261019-r6-code'
    helper = folder / 'release-native.py'
    for p in [*reversed(helper.parents),helper]:
        need(not p.is_symlink(), 'HISTORICAL_R6_SYMLINK_REFUSED')
    raw = helper.read_bytes()
    need(sha(raw) == R6_HELPER, 'EXACT_UNMODIFIED_R6_HELPER_REQUIRED')
    original = types.ModuleType('unmodified_completed_r6'); original.__file__ = str(helper)
    exec(compile(raw,str(helper),'exec'),original.__dict__)
    # Exact original loader retains its immutable R3/36 ancestry proof. It does
    # not call old inspect/snapshot or compare current live sources to old R3.
    a,b,prior,base_r3 = original.load_current_r5(pid)
    journal = ROOT / 'multi-company-app-20261019-r6-journal.json'
    receipt = a.pinned(journal,R6_RECEIPT,True)
    accepted = original.Release(a,b,prior,base_r3,3077369)
    need(receipt.get('name') == original.NAME and receipt.get('phase') == 'APPLIED_NOT_CUSTOMER_ACCEPTANCE'
         and receipt.get('inputs') == accepted.binding() and receipt.get('before') == accepted.base
         and receipt.get('childImage') == R6_IMAGE and receipt.get('decisionSha256') == R6_DECISION
         and receipt.get('workerRecreated') is False and receipt.get('automaticRetry') is False
         and receipt.get('automaticCodeRollback') is False
         and receipt.get('mainDbDirectWrites') == receipt.get('queueEdits') == receipt.get('oldJournalWrites') == 0,
         'EXACT_COMPLETED_R6_RECEIPT_REQUIRED')
    decision = accepted.decision(R6_DECISION,fresh=False)
    need(decision['sourceModes'] == receipt['sourceModes'], 'SEALED_R6_SOURCE_MODES_REQUIRED')
    expected = copy.deepcopy(accepted.base['containers']['content'])
    overlay = str(accepted.paths['overlay']); chain = expected['files'] + [overlay]
    need(len(chain) == len(set(chain)) == 38 and sha(a.read(accepted.paths['overlay'])) == receipt['overlaySha256'], 'SEALED_R6_CHAIN38_REQUIRED')
    expected.update(image=R6_IMAGE,files=chain,configFiles=','.join(chain),
                    filePins={**expected['filePins'],overlay:receipt['overlaySha256']},configHash=receipt['plannedConfigHash'])
    need(receipt['after']['containers']['content'] == expected
         and receipt['after']['containers']['chat'] == accepted.base['containers']['chat']
         and all(receipt['after'][k] == accepted.base[k] for k in ('selected','worker','l12'))
         and len(accepted.source) == 227 and len(accepted.static) == 33,
         'SEALED_R6_FULL227_33_38_REQUIRED')

    def stable():
        # These are historical seals only, never old current-live snapshot.
        accepted.stable()
        need(sha(a.read(helper)) == R6_HELPER and sha(a.read(journal)) == R6_RECEIPT
             and a.pinned(accepted.paths['decision'],R6_DECISION,True) == decision, 'SEALED_R6_HISTORY_CHANGED')
        accepted.acceptance(decision['rootAcceptanceSha256'])
        need(accepted.context_proof(receipt,True) == receipt['contextSha256'], 'SEALED_R6_CONTEXT_CHANGED')
        accepted.backups(receipt)

    stable()
    current = types.SimpleNamespace(base=copy.deepcopy(receipt['after']),source=dict(accepted.source),static=dict(accepted.static),
        cabinet=accepted.cabinet,managed=base_r3.managed,stable=stable,source_script=base_r3.source_script,accepted=base_r3.accepted)
    return a,b,prior,current


def validate_records(manifest):
    need(type(manifest) is dict and set(manifest)=={'schema','build','records'} and manifest['schema']==1 and manifest['build']=='synapse-company-app-20261019-r7','CLOSED_R7_MANIFEST_REQUIRED')
    frontend={'shell.js','shell.css','cabinet.html','customer-reports-ui.js'}
    added={'team-chat.html','team-chat.css','team-chat-drafts.js','team-chat-host.js','team-chat-renderer.js','team-chat-start.js'}
    backend={'company-app/customer-reports.cjs','company-app/customer-report-cache.cjs','project-chat.js','project-chat-work-queue.js'}
    expected={**{'product/'+n:('palitra-orders-public/'+n,n,n in added) for n in frontend|added},**{'backend/'+n:(n,None,n=='project-chat-work-queue.js') for n in backend},'native-cabinet/project-chat.js':('external-cabinet/project-chat.js',None,False),'native-cabinet/project-chat.css':('external-cabinet/project-chat.css',None,False)}
    need(type(manifest['records']) is list and len(manifest['records'])==16,'EXACT_R7_SIXTEEN_RECORDS_REQUIRED')
    result={}
    for row in manifest['records']:
        need(type(row) is dict and set(row)=={'name','target','sha256','bytes','beforeSha256','beforeSourceSha256','static'} and row['name'] in expected and row['name'] not in result,'CLOSED_R7_RECORD_REQUIRED')
        target,static,added_file=expected[row['name']]
        need(row['target']==target and row['static']==static and digest(row['sha256']) and type(row['bytes']) is int and 0<row['bytes']<=2*1024*1024,'CLOSED_R7_TARGET_REQUIRED')
        need((row['beforeSourceSha256'] is None)==(added_file or target is None),'EXACT_R7_SOURCE_KIND_REQUIRED')
        if target is not None and not added_file: need(digest(row['beforeSourceSha256']),'EXACT_R7_SOURCE_BASE_REQUIRED')
        external=target.startswith('external-cabinet/')
        if (static is None and not external) or added_file: need(row['beforeSha256'] is None,'EXACT_R7_STATIC_KIND_REQUIRED')
        else: need(digest(row['beforeSha256']),'EXACT_R7_STATIC_BASE_REQUIRED')
        if target=='project-chat.js': need(row['beforeSourceSha256']=='f60b18567b81c8ed0ea28e1609c208d75fa78e95bad3cbbd6d24ea595d9bbf44','EXACT_NATIVE_PROJECT_CHAT_REQUIRED')
        if external: need(row['beforeSha256']==row['beforeSourceSha256']==(NATIVE_CABINET_CSS_BEFORE if target.endswith('.css') else NATIVE_CABINET_BEFORE),'EXACT_NATIVE_CABINET_BYTES_REQUIRED')
        result[row['name']]=row
    return result


# Sealed R6 inventory remains exactly 227 entries. This one existing native
# source was absent from that historic inventory; its bytes were read-only
# verified by Root. Its mode is observed now and bound to the new decision.
SUPPLEMENT_NAME = 'project-chat.js'
SUPPLEMENT_SHA = 'f60b18567b81c8ed0ea28e1609c208d75fa78e95bad3cbbd6d24ea595d9bbf44'
SUPPLEMENT_MODE = 0o600  # Fresh Root read-only native stat; never chmod.
SUPPLEMENT_BYTES = 179739
SUPPLEMENT_FACTS_JS = """const f=require('node:fs'),c=require('node:crypto');const p='/app/project-chat.js',s=f.lstatSync(p);if(!s.isFile()||s.isSymbolicLink()||s.nlink!==1||f.realpathSync(p)!==p)throw Error('SUPPLEMENT_REGULAR_SINGLE_LINK_REQUIRED');const b=f.readFileSync(p);console.log(JSON.stringify({path:'project-chat.js',sha256:c.createHash('sha256').update(b).digest('hex'),bytes:b.length,uid:s.uid,gid:s.gid,mode:s.mode&511,nlink:s.nlink,regular:s.isFile(),symlink:s.isSymbolicLink(),canonical:f.realpathSync(p)===p}));"""

def observe_source_supplement(a, run, source_script, lease_guard, expected_sha=SUPPLEMENT_SHA, expected_mode=SUPPLEMENT_MODE, expected_bytes=SUPPLEMENT_BYTES):
    lease_guard()
    command = ['docker', 'exec', 'synapse-content-1', 'node', '-e']
    first = a.decode(run(command + [SUPPLEMENT_FACTS_JS]))
    fields = {'path','sha256','bytes','uid','gid','mode','nlink','regular','symlink','canonical'}
    need(type(first) is dict and set(first) == fields
         and first['path'] == SUPPLEMENT_NAME and first['sha256'] == expected_sha
         and type(first['bytes']) is int and 0 < first['bytes'] <= 2 * 1024 * 1024
         and (expected_bytes is None or first['bytes'] == expected_bytes)
         and type(first['uid']) is int and first['uid'] == 0
         and type(first['gid']) is int and first['gid'] == 0
         and type(first['mode']) is int and first['mode'] in (0o600,0o644)
         and (expected_mode is None or first['mode'] == expected_mode)
         and type(first['nlink']) is int and first['nlink'] == 1
         and first['regular'] is True and first['symlink'] is False and first['canonical'] is True,
         'EXACT_EXISTING_SOURCE_SUPPLEMENT_REQUIRED')
    # Retain the established native source reader as a second independent byte
    # check, bracketed by identical metadata/hash observations.
    encoded = run(command + [source_script, SUPPLEMENT_NAME])
    need(len(encoded) < 3 * 1024 * 1024, 'BOUNDED_SUPPLEMENT_SOURCE_REQUIRED')
    raw = base64.b64decode(encoded, validate=True)
    need(len(raw) == first['bytes'] and sha(raw) == expected_sha, 'SUPPLEMENT_SOURCE_BYTES_CHANGED')
    need(a.decode(run(command + [SUPPLEMENT_FACTS_JS])) == first, 'SUPPLEMENT_CHANGED_DURING_READ')
    lease_guard()
    return first


def create_managed_guard(release):
    a=release.a
    raw=a.read(CODE/'managed-source.py');probe=a.read(CODE/'managed-source-probe.cjs')
    need(sha(raw)==MANAGED_HELPER_SHA and sha(probe)==MANAGED_PROBE_SHA,'EXACT_MANAGED_GUARD_CODE_REQUIRED')
    need(digest(MANAGED_PROOF_SHA),'MANAGED_SOURCE_PROOF_NOT_FROZEN')
    proof=a.pinned(MANAGED_PROOF_PATH,MANAGED_PROOF_SHA,True)
    outcome=a.pinned(CODE/'MAP_OUTCOME.json',MAP_OUTCOME_SHA)
    m=types.ModuleType('r7c_managed_source');m.__file__=str(CODE/'managed-source.py');exec(compile(raw,m.__file__,'exec'),m.__dict__)
    definition={'schema':1,'status':'FROZEN','probeSha256':MANAGED_PROBE_SHA,'mapOutcomeSha256':MAP_OUTCOME_SHA,'proof':proof}
    return m.ManagedSource(definition,outcome,release.current.managed,probe,release.run,a.decode,release.lease)

class Release:
    def __init__(self,a,b,prior,current,pid,inspection_pin=None):
        self.a,self.b,self.prior,self.current,self.pid=a,b,prior,current,pid
        self.run,self.files=b.run,prior.FileOps();self.base=copy.deepcopy(current.base)
        self.paths={n:ROOT/(NAME+'-'+n+('.json' if n in ('decision','journal','overlay') else '')) for n in ('decision','journal','overlay','context','backup')}
        self.inspection_pin = inspection_pin
        self.inspection_state = None
        self.writer_pid = pid
        if inspection_pin is not None:
            need(digest(inspection_pin), 'EXPLICIT_OWN_INSPECTION_RECEIPT_REQUIRED')
            self.inspection_state = a.pinned(self.paths['journal'],inspection_pin,True)
            need(type(self.inspection_state) is dict and self.inspection_state.get('name') == NAME
                 and self.inspection_state.get('phase') == 'APPLIED_NOT_CUSTOMER_ACCEPTANCE'
                 and type(self.inspection_state.get('inputs')) is dict, 'EXACT_OWN_COMPLETED_INSPECTION_PROOF_REQUIRED')
            historical_pid = self.inspection_state['inputs'].get('freshLeasePid')
            need(type(historical_pid) is int and historical_pid > 1, 'EXACT_HISTORICAL_WRITER_PID_REQUIRED')
            # Binding identifies the original writer. The live lease always
            # uses self.pid, which remains this inspector's fresh own PID.
            self.writer_pid = historical_pid
        self.cabinet=a.exact_path(current.cabinet)
        need(type(NATIVE_CABINET_HOST) is str and NATIVE_CABINET_HOST.startswith('/opt/synapse/sites/') and NATIVE_CABINET_HOST.endswith('/cabinet/project-chat.js'),'NATIVE_CABINET_TARGET_UNCONFIRMED')
        native=a.exact_path(Path(NATIVE_CABINET_HOST))
        if self.inspection_state is None: need(sha(a.read(native))==NATIVE_CABINET_BEFORE,'FRESH_NATIVE_CABINET_CAS_REQUIRED')
        need(type(NATIVE_CABINET_CSS_HOST) is str and NATIVE_CABINET_CSS_HOST==str(native.with_suffix('.css')),'NATIVE_CABINET_CSS_TARGET_UNCONFIRMED')
        native_css=a.exact_path(Path(NATIVE_CABINET_CSS_HOST))
        if self.inspection_state is None: need(sha(a.read(native_css))==NATIVE_CABINET_CSS_BEFORE,'FRESH_NATIVE_CABINET_CSS_CAS_REQUIRED')
        need(len(current.source)==227 and len(current.static)==33 and len(current.base['containers']['content']['files'])==38,'EXACT_R6_FULL227_33_38_REQUIRED')
        self.sealed_source = dict(current.source)
        need(SUPPLEMENT_NAME not in self.sealed_source, 'SUPPLEMENT_MUST_BE_ABSENT_FROM_SEALED_HISTORY')
        current.stable(); self.lease()
        if self.inspection_state is None:
            need(self.b.photo.hashes(self.sealed_source) == self.sealed_source, 'SEALED_R6_SOURCE227_CHANGED')
            self.source_supplement = observe_source_supplement(a,self.run,current.source_script,self.lease)
        else:
            # A pinned completed receipt carries the before-proof. Read-only
            # own inspect must validate current child bytes in snapshot(child),
            # not demand already-replaced parent bytes from the live container.
            inputs = self.inspection_state['inputs']
            proof = inputs.get('sourceSupplement')
            need(inputs.get('parentImage') == PARENT and inputs.get('sealedBeforeSource') == self.sealed_source
                 and inputs.get('beforeSource') == {**self.sealed_source,SUPPLEMENT_NAME:SUPPLEMENT_SHA}
                 and inputs.get('sourceCounts') == {'sealed':227,'supplementalExisting':1,'before':228,'after':235}
                 and proof == {'path':SUPPLEMENT_NAME,'sha256':SUPPLEMENT_SHA,'bytes':SUPPLEMENT_BYTES,
                     'uid':0,'gid':0,'mode':SUPPLEMENT_MODE,'nlink':1,'regular':True,'symlink':False,'canonical':True},
                 'EXACT_SEALED_BEFORE_SUPPLEMENT_REQUIRED')
            self.source_supplement = dict(proof)
        # Only a new local current-view copy is extended; historical objects,
        # accepted.source, receipts and their 227-entry guards stay untouched.
        self.current = current = copy.copy(current)
        current.source = {**self.sealed_source,SUPPLEMENT_NAME:SUPPLEMENT_SHA}
        current.static={**current.static,str(native):NATIVE_CABINET_BEFORE,str(native_css):NATIVE_CABINET_CSS_BEFORE}
        need(len(current.source) == 228, 'EXACT_CURRENT_SOURCE228_REQUIRED')
        self.manifest=a.pinned(CODE/'payload/MANIFEST.json',MANIFEST_SHA);self.records=validate_records(self.manifest)
        self.source_records={n:r for n,r in self.records.items() if not r['target'].startswith('external-cabinet/')}
        self.source,self.static=dict(current.source),dict(current.static)
        self.static_records,self.existing_sources,self.added_sources={},{},[]
        for row in self.records.values():
            raw=a.read(CODE/'payload'/row['name']);need(len(raw)==row['bytes'] and sha(raw)==row['sha256'],'PRODUCT_PAYLOAD_CHANGED')
            target=row['target'];external=target.startswith('external-cabinet/')
            if not external:
                need(current.source.get(target)==row['beforeSourceSha256'],'SOURCE_BASE_R6_MISMATCH')
                if row['beforeSourceSha256'] is None:self.added_sources.append(target)
                else:self.existing_sources[target]=row
                self.source[target]=row['sha256']
            if row['static'] or external:
                path=(str(native_css) if target.endswith('.css') else str(native)) if external else str(self.cabinet/row['static'])
                need(current.static.get(path)==row['beforeSha256'],'STATIC_BASE_R6_MISMATCH')
                self.static[path]=row['sha256'];self.static_records[path]=row
        need(len(self.source)==235 and len(self.static)==41 and len(self.added_sources)==7 and len(self.existing_sources)==7 and len(self.static_records)==12,'EXACT_R7C_CLOSED_COUNTS_REQUIRED')
        self.pins={str(Path(__file__)):sha(Path(__file__).read_bytes()),str(CODE/'payload/MANIFEST.json'):MANIFEST_SHA,str(CODE/'ROLLBACK.md'):ROLLBACK_SHA,str(CODE/'report-db.py'):DB_HELPER_SHA,str(CODE/'content-db.py'):CONTENT_HELPER_SHA,str(CODE/'CONTENT_MIGRATION.json'):CONTENT_MIGRATION_SHA,str(CODE/'PRODUCT_REVIEW.json'):PRODUCT_REVIEW_SHA,str(CODE/'PRODUCT_MANIFEST.json'):PRODUCT_MANIFEST_SHA}
        modules={}
        for name,pin in [('report-db.py',DB_HELPER_SHA),('content-db.py',CONTENT_HELPER_SHA)]:
            raw=a.read(CODE/name);need(sha(raw)==pin,'FROZEN_DATABASE_GUARD_REQUIRED')
            m=types.ModuleType('r7_'+name);m.__file__=str(CODE/name);exec(compile(raw,m.__file__,'exec'),m.__dict__);modules[name]=m
        self.db=modules['report-db.py'].ReportDatabase(REPORT_DB_HOST,a.exact_path,self.files,self.data_mount)
        migration=a.pinned(CODE/'CONTENT_MIGRATION.json',CONTENT_MIGRATION_SHA)
        self.contentdb=modules['content-db.py'].ContentDatabase(CONTENT_DB_HOST,a.exact_path,self.files,self.content_data_mount).configure(migration,self.lease)
        product=a.pinned(CODE/'PRODUCT_REVIEW.json',PRODUCT_REVIEW_SHA);original=a.pinned(CODE/'PRODUCT_MANIFEST.json',PRODUCT_MANIFEST_SHA)
        need(product.get('deltaFromInstalledR6')==self.manifest['records'] and original.get('deltaFromInstalledR6')==self.manifest['records'],'EXACT_ACCEPTED_R7_PRODUCT_REQUIRED')
        self.pins.update({str(CODE/'managed-source.py'):MANAGED_HELPER_SHA,str(CODE/'managed-source-probe.cjs'):MANAGED_PROBE_SHA,
                          str(CODE/'MAP_OUTCOME.json'):MAP_OUTCOME_SHA,str(MANAGED_PROOF_PATH):MANAGED_PROOF_SHA})
        self.managed_guard=create_managed_guard(self)
        b.lease=self.lease

    def lease(self):
        raw = self.run(['lslocks', '--noheadings', '--output', 'PID,PATH'])
        need(len(raw) <= 1048576, 'BOUNDED_LEASE_REQUIRED')
        rows = [r.strip().split(maxsplit=1) for r in raw.decode().splitlines() if len(r.strip().split(maxsplit=1)) == 2 and r.strip().split(maxsplit=1)[1] == LOCK]
        need(rows == [[str(self.pid), LOCK]], 'EXACT_OWN_SINGLE_WRITER_REQUIRED')

    def stable(self):
        self.current.stable()
        need(self.a.pinned(MANAGED_PROOF_PATH,MANAGED_PROOF_SHA,True)==self.managed_guard.proof,'SEALED_PRIVATE_MANAGED_PROOF_CHANGED')
        self.managed_guard.guard()  # Both immutable historical files and exact current pointer/files.
        need(len(self.sealed_source) == 227 and SUPPLEMENT_NAME not in self.sealed_source
             and self.current.source == {**self.sealed_source,SUPPLEMENT_NAME:SUPPLEMENT_SHA}, 'SEALED_SUPPLEMENT_BINDING_CHANGED')
        for p, pin in self.pins.items(): need(sha(self.a.read(Path(p))) == pin, 'FROZEN_RECEIVER_CODE_CHANGED')
        for row in self.records.values(): need(sha(self.a.read(CODE / 'payload' / row['name'])) == row['sha256'], 'FROZEN_PRODUCT_CHANGED')

    def supplement_guard(self, child=False):
        value = observe_source_supplement(self.a,self.run,self.current.source_script,self.lease,
                    self.source[SUPPLEMENT_NAME] if child else SUPPLEMENT_SHA,self.source_supplement['mode'],
                    self.records['backend/project-chat.js']['bytes'] if child else SUPPLEMENT_BYTES)
        if child:
            need(value['bytes'] == self.records['backend/project-chat.js']['bytes'], 'CHILD_SUPPLEMENT_SIZE_CHANGED')
        else:
            need(value == self.source_supplement, 'APPROVED_SOURCE_SUPPLEMENT_CHANGED')
        return value

    def metadata(self, child=None, proof=None):
        expected = copy.deepcopy(self.base['containers']['content'])
        if child:
            need(type(proof) is dict and set(proof) == {'overlaySha256', 'plannedConfigHash'}
                 and all(digest(v) for v in proof.values()) and child != PARENT and self.a.image(child), 'EXPLICIT_CHILD_PROOF_REQUIRED')
            overlay = str(self.paths['overlay']); files = expected['files'] + [overlay]
            need(len(files) == len(set(files)) == 39 and sha(self.a.read(Path(overlay))) == proof['overlaySha256'], 'EXACT_NEW_CHAIN39_REQUIRED')
            expected.update(image=child, files=files, configFiles=','.join(files), filePins={**expected['filePins'], overlay: proof['overlaySha256']}, configHash=proof['plannedConfigHash'])
        row = self.a.decode(self.run(['docker', 'inspect', '--format', self.a.LABELS, 'synapse-content-1']))
        need(type(row) is dict and row.get('configFiles') == expected['configFiles'], 'COMPOSE_CHAIN_CHANGED')
        row.update(files=list(expected['files']), filePins={name: sha(self.a.read(Path(name))) for name in expected['files']})
        need(row == expected and self.b.metadata('chat') == self.base['containers']['chat'], 'COMPLETE_RUNTIME_METADATA_CHANGED')
        return {'content': row, 'chat': copy.deepcopy(self.base['containers']['chat'])}

    def report_db(self):
        script = "const f=require('fs'),p=require('path');const n=p.join(p.dirname(process.env.DATABASE_PATH||'/data/content.sqlite'),'salon-reports.sqlite');if(n!=='/data/salon-reports.sqlite')throw Error('EXACT_DATA_PATH_REQUIRED');const out={path:n,files:{}};for(const[k,suffix]of [['db',''],['wal','-wal'],['shm','-shm']]){let s;try{s=f.lstatSync(n+suffix)}catch(e){if(e.code!=='ENOENT')throw e}if(s&&(!s.isFile()||s.isSymbolicLink()||s.nlink!==1))throw Error('REGULAR_REPORT_GROUP_REQUIRED');out.files[k]=s?{uid:s.uid,mode:s.mode&511}:null}console.log(JSON.stringify(out));"
        return self.a.decode(self.run(['docker', 'exec', 'synapse-content-1', 'node', '-e', script]))

    def users(self, child=None):
        result = {'current': self.a.decode(self.run(['docker', 'inspect', '--format', self.prior.USER_FORMAT, 'synapse-content-1'])),
                  'parent': self.a.decode(self.run(['docker', 'image', 'inspect', '--format', self.prior.USER_FORMAT, PARENT]))}
        if child: result['child'] = self.a.decode(self.run(['docker', 'image', 'inspect', '--format', self.prior.USER_FORMAT, child]))
        need(all(type(v) is str and v in self.prior.ROOT_USERS for v in result.values())
             and (not child or result['parent'] == result['child']), 'PRESERVED_ROOT_SERVICE_USER_REQUIRED')
        return result

    def source_modes(self, child=False):
        names = sorted((row['target'] for row in self.source_records.values()) if child else self.existing_sources)
        script = self.prior.SOURCE_FACTS_JS
        value = self.a.decode(self.run(['docker', 'exec', 'synapse-content-1', 'node', '-e', script, json.dumps(names)]))
        need(type(value) is dict and set(value) == set(names) and all(v.get('uid') == v.get('gid') == 0 and v.get('mode') in (0o600, 0o644) for v in value.values()), 'ROOT_SOURCE_MODES_REQUIRED')
        if not child:
            for name in self.added_sources: value[name] = {'uid': 0, 'gid': 0, 'mode': 0o644}
        return value

    def static_modes(self, changed=frozenset()):
        result = {}
        for target, row in self.static_records.items():
            path = self.a.exact_path(Path(target), row['beforeSha256'] is None and target not in changed)
            if row['beforeSha256'] is None and target not in changed:
                need(not os.path.lexists(path), 'NEW_STATIC_TARGET_ALREADY_EXISTS'); result[target] = 0o644; continue
            s = path.stat()
            need(stat.S_ISREG(s.st_mode) and s.st_uid == s.st_gid == 0 and stat.S_IMODE(s.st_mode) in (0o600, 0o644), 'EXACT_ROOT_STATIC_MODES_REQUIRED')
            result[target] = stat.S_IMODE(s.st_mode)
        return result

    def snapshot(self, child=None, changed=frozenset(), proof=None):
        self.stable(); self.lease()
        first = self.metadata(child, proof); worker = self.b.worker_facts(); selected = {s: self.b.a.selected(s) for s in ('content', 'chat')}
        flags = self.a.decode(self.run(['docker', 'exec', 'synapse-content-1', 'node', '-e', self.a.FLAGS_JS]))
        need(worker == self.base['worker'] and selected == self.base['selected'] and flags == self.base['l12'], 'WORKER_FLAGS_SELECTION_CHANGED')
        for service, row in first.items():
            value = self.run(self.b._resolve_command(row, service)).decode('ascii').strip()
            need(re.fullmatch(re.escape(service) + r'\s+' + re.escape(row['configHash']), value) is not None, 'RESOLVED_COMPOSE_HASH_CHANGED')
        self.b.graph(new=True); self.b.push_guard()
        source = self.source if child else self.current.source
        need(self.b.photo.hashes(source) == source, 'FULL_SOURCE_INVENTORY_CHANGED')
        if not child:
            need(self.b.photo.hashes(self.sealed_source) == self.sealed_source, 'SEALED_R6_SOURCE227_CHANGED')
        self.supplement_guard(bool(child))
        if not child:
            check = "const f=require('fs');for(const n of JSON.parse(process.argv[1])){let s;try{s=f.lstatSync('/app/'+n)}catch(e){if(e.code!=='ENOENT')throw e}if(s)throw Error('ADDED_SOURCE_ALREADY_EXISTS')}process.stdout.write('ABSENT');"
            need(self.run(['docker', 'exec', 'synapse-content-1', 'node', '-e', check, json.dumps(self.added_sources)]) == b'ABSENT', 'ADDED_SOURCE_COLLISION')
        expected = dict(self.current.static)
        for target in changed: need(target in self.static_records, 'UNKNOWN_STATIC_TARGET'); expected[target] = self.static[target]
        for name, pin in expected.items(): need(sha(self.a.read(Path(name))) == pin, 'FULL_STATIC_INVENTORY_CHANGED')
        self.static_modes(changed)
        cid = self.b.photo.cid()
        need(first == self.metadata(child, proof) and worker == self.b.worker_facts() and selected == {s: self.b.a.selected(s) for s in ('content', 'chat')}
             and cid == self.b.photo.cid(), 'CONCURRENT_NATIVE_CHANGE')
        self.stable(); self.lease()
        return {'containers': first, 'selected': selected, 'worker': worker, 'contentCid': cid, 'l12': flags}

    def data_mount(self):
        mounts = self.a.decode(self.run(['docker','inspect','--format','{{json .Mounts}}','synapse-content-1']))
        need(type(mounts) is list, 'EXACT_DATA_MOUNT_LIST_REQUIRED')
        rows = [r for r in mounts if r.get('Destination') == '/data']
        need(len(rows) == 1 and rows[0].get('Type') == 'volume' and rows[0].get('Name') == 'synapse_content_data'
             and rows[0].get('Source') == str(REPORT_DB_HOST.parent) and rows[0].get('RW') is True, 'EXACT_EXISTING_REPORT_VOLUME_REQUIRED')

    def content_data_mount(self):
        self.data_mount()
        script="process.stdout.write(process.env.DATABASE_PATH||'/data/content.sqlite')"
        need(self.run(['docker','exec','synapse-content-1','node','-e',script])==b'/data/content.sqlite','EXACT_RUNNING_CONTENT_DATABASE_PATH_REQUIRED')

    def baseline(self):
        snap = self.snapshot()
        need(snap == self.base and self.b.heartbeat(snap['worker']['startedAt'], time.time())['freshAfterWorkerStart'], 'FRESH_EXACT_R6_REQUIRED')
        need(private_report_db(self.report_db()), 'EXISTING_PRIVATE_REPORT_DB_REQUIRED')
        self.db.read(); self.contentdb.read(); self.users()
        return snap

    def binding(self):
        return {'parentReceipt': R6_RECEIPT, 'parentImage': PARENT, 'productReview': PRODUCT_REVIEW_SHA, 'dbGuard': DB_HELPER_SHA, 'contentDbGuard': CONTENT_HELPER_SHA, 'contentMigration': CONTENT_MIGRATION_SHA, 'manifest': MANIFEST_SHA, 'helper': self.pins[str(Path(__file__))],
                'freshLeasePid': self.writer_pid, 'sealedBeforeSource': self.sealed_source, 'sourceSupplement': self.source_supplement,
                'managedProofSha256':MANAGED_PROOF_SHA,'managedProbeSha256':MANAGED_PROBE_SHA,'mapOutcomeSha256':MAP_OUTCOME_SHA,
                'managedSourceProof':self.managed_guard.proof,
                'sourceCounts': {'sealed':227,'supplementalExisting':1,'before':228,'after':235},
                'beforeSource': self.current.source, 'afterSource': self.source,
                'beforeStatic': self.current.static, 'afterStatic': self.static}

    def inspect_current(self):
        need(self.inspection_state is None, 'OWN_INSPECTION_CANNOT_REUSE_PREFLIGHT')
        self.baseline()
        return {'status': 'CURRENT_R6_READONLY_NOT_APPROVED', 'sourceFiles': 228, 'sealedSourceFiles': 227, 'supplementalExistingSourceFiles': 1, 'staticFiles': 35, 'chainFiles': 38,
                'candidateSourceFiles': 235, 'sourceSupplement': self.source_supplement, 'candidateStaticFiles': 41, 'sourceModes': self.source_modes(), 'staticModes': self.static_modes(),
                'reportDatabaseBefore': self.report_db(), 'runtimeWrites': 0}

    def acceptance(self, pin):
        value = self.a.pinned(CODE / 'ROOT_ACCEPTANCE.json', pin, True)
        need(type(value) is dict and value.get('status') == 'ACCEPTED_R7C_PRODUCT_AND_INSTALLER'
             and value.get('runtimeApplyAuthorized') is True and value.get('writerThreadId') == '01a0a408-4f98-7713-a652-e6a741da834c'
             and value.get('parentReceiptSha256') == R6_RECEIPT and value.get('productReviewSha256') == PRODUCT_REVIEW_SHA
             and value.get('dbGuardSha256') == DB_HELPER_SHA and value.get('contentDbGuardSha256') == CONTENT_HELPER_SHA and value.get('contentMigrationSha256') == CONTENT_MIGRATION_SHA
             and value.get('installerStatus') == 'ACCEPTED_NATIVE_R7C_INSTALLER_AND_ROLLBACK'
              and value.get('manifestSha256') == MANIFEST_SHA
              and value.get('managedProofSha256') == MANAGED_PROOF_SHA and value.get('mapOutcomeSha256') == MAP_OUTCOME_SHA
              and value.get('managedProbeSha256') == MANAGED_PROBE_SHA and value.get('managedSourceProof') == self.managed_guard.proof
              and value.get('sourceSupplement') == self.source_supplement
              and value.get('sourceCounts') == {'sealed':227,'supplementalExisting':1,'before':228,'after':235}
             and value.get('helperSha256') == self.pins[str(Path(__file__))]
             and value.get('rollbackSha256') == ROLLBACK_SHA
             and value.get('reviewerThreadId') == '01a0a408-4f98-7713-a652-e6a741da834c',
             'EXACT_PRODUCT_AND_INSTALLER_ROOT_ACCEPTANCE_REQUIRED')
        return value

    def unused(self, allow_decision=False):
        for name, path in self.paths.items():
            if name == 'decision' and allow_decision: continue
            self.a.exact_path(path, True)
            need(not os.path.lexists(path) and not os.path.lexists(str(path) + '.pending'), 'OWN_ATTEMPT_EXISTS_NO_RETRY')
        for target in self.static_records:
            pending = Path(target).with_name(Path(target).name + '.' + NAME + '.pending')
            self.a.exact_path(pending, True); need(not os.path.lexists(pending), 'OWN_STATIC_PENDING_EXISTS_NO_RETRY')

    def approve(self, acceptance_pin, apply=False):
        need(self.inspection_state is None, 'OWN_INSPECTION_CANNOT_APPROVE')
        need(apply is True and digest(acceptance_pin), 'EXPLICIT_ROOT_ACCEPTED_APPROVAL_REQUIRED')
        self.unused(); self.acceptance(acceptance_pin); before = self.baseline()
        value = {'schema': 1, 'name': NAME, 'inputs': self.binding(), 'before': before,
                 'observedAtUtc': self.a.stamp(time.time()), 'sourceModes': self.source_modes(), 'staticModes': self.static_modes(),
                 'rootAcceptanceSha256': acceptance_pin, 'reportDatabaseBefore': self.report_db(), 'reportDatabaseContentBefore': self.db.read(), 'contentDatabaseBefore': self.contentdb.read(), 'serviceUsers': self.users()}
        self.a.write_new(self.paths['decision'], value)
        return {'status': 'NEW_DECISION_NOT_APPLIED', 'decisionSha256': sha(self.a.read(self.paths['decision'])), 'runtimeWrites': 0}

    def decision(self, pin, fresh=True):
        value = self.a.pinned(self.paths['decision'], pin, True)
        need(type(value) is dict and set(value) == {'schema', 'name', 'inputs', 'before', 'observedAtUtc', 'sourceModes', 'staticModes', 'rootAcceptanceSha256', 'reportDatabaseBefore', 'reportDatabaseContentBefore', 'contentDatabaseBefore', 'serviceUsers'}
             and value['schema'] == 1 and value['name'] == NAME and value['inputs'] == self.binding()
             and value['before'] == self.base and private_report_db(value['reportDatabaseBefore']),
             'EXACT_OWN_DECISION_REQUIRED')
        self.acceptance(value['rootAcceptanceSha256'])
        need(value['serviceUsers'] == self.users(), 'APPROVED_SERVICE_USERS_CHANGED')
        if fresh:
            self.a.fresh(value['observedAtUtc'], time.time())
            self.db.guard(value['reportDatabaseContentBefore']); self.contentdb.guard(value['contentDatabaseBefore'])
        return value

    def update(self, journal, phase, **fields):
        journal.update(phase=phase, **fields); self.a.replace(self.paths['journal'], journal)

    def context_proof(self, state, built=False):
        context = self.paths['context']
        wanted = {'Dockerfile': sha(('FROM ' + NAME + '-base\nCOPY app/ /app/\n').encode())}
        wanted.update({'app/' + row['target']: row['sha256'] for row in self.source_records.values()})
        wanted.update({'static/' + str(i): row['sha256'] for i, row in enumerate(state['static'])})
        actual = {}
        directories = {'app', 'static'} | {'app/' + str(p) for r in self.source_records.values() for p in PurePosixPath(r['target']).parents if str(p) != '.'}
        for path in context.rglob('*'):
            self.a.exact_path(path)
            if path.is_file():
                relative = path.relative_to(context).as_posix()
                if built and relative == 'image.id': continue
                actual[relative] = sha(self.a.read(path))
            else: need(path.is_dir() and path.relative_to(context).as_posix() in directories, 'UNEXPECTED_BUILD_DIRECTORY')
        need(actual == wanted, 'EXACT_CLOSED_BUILD_CONTEXT_REQUIRED')
        for target, mode in state['sourceModes'].items():
            need(self.files.mode(context / 'app' / target) == mode['mode'], 'SOURCE_CONTEXT_MODE_CHANGED')
        return sha(json.dumps(sorted(actual.items()), separators=(',', ':')).encode())

    def backups(self, state):
        directory = self.a.exact_path(self.paths['backup']); s = directory.stat()
        need(stat.S_ISDIR(s.st_mode) and s.st_uid == 0 and stat.S_IMODE(s.st_mode) == 0o700
             and state['backupIdentity'] == [s.st_dev, s.st_ino, s.st_uid], 'PRIVATE_BACKUP_DIRECTORY_CHANGED')
        need(len(state['sourceBackups']) == len(self.existing_sources) == 7
             and {r['target']: r['baseSha256'] for r in state['sourceBackups']} == {k: v['beforeSourceSha256'] for k, v in self.existing_sources.items()}
             and len(state['static']) == len(self.static_records) == 12
             and {r['target'] for r in state['static']} == set(self.static_records), 'EXACT_COMPLETE_BACKUP_INVENTORY_REQUIRED')
        for row in state['static']:
            record = self.static_records[row['target']]
            need(row['baseSha256'] == record['beforeSha256'] and row['sha256'] == record['sha256']
                 and (row['backup'] is None) == (record['beforeSha256'] is None), 'STATIC_BACKUP_RECORD_CHANGED')
        self.db.backup_guard(state['reportDatabaseBackup'])
        need(Path(state['reportDatabaseBackup']['path']) == directory / 'reports.sqlite', 'EXACT_REPORT_BACKUP_PATH_REQUIRED')
        self.contentdb.backup_guard(state['contentDatabaseBackup'])
        need(Path(state['contentDatabaseBackup']['path']) == directory / 'content.sqlite', 'EXACT_CONTENT_BACKUP_PATH_REQUIRED')
        wanted = {'reports.sqlite', 'content.sqlite'}
        for row in state['sourceBackups'] + state['static']:
            if row['backup'] is None: continue
            p = Path(row['backup']); need(p.parent == directory, 'BACKUP_BOUNDARY_REQUIRED'); wanted.add(p.name)
            self.a.exact_path(p); info = p.stat()
            need(stat.S_ISREG(info.st_mode) and info.st_uid == 0 and self.files.mode(p) == 0o600
                 and sha(self.a.read(p)) == row['baseSha256'], 'PRIVATE_EXACT_BACKUP_CHANGED')
        need({p.name for p in directory.iterdir()} == wanted, 'CLOSED_BACKUP_DIRECTORY_REQUIRED')

    def publish(self, row, state, pin):
        self.backups(state); self.decision(pin); self.snapshot(changed=frozenset(state['written']))
        target = self.a.exact_path(Path(row['target']), row['baseSha256'] is None)
        if row['baseSha256'] is None: need(not os.path.lexists(target), 'ADDED_STATIC_COLLISION')
        else: need(sha(self.a.read(target)) == row['baseSha256'] and self.files.mode(target) == row['mode'], 'STATIC_CAS_CHANGED')
        raw = self.a.read(Path(row['prepared'])); need(sha(raw) == row['sha256'], 'PREPARED_STATIC_CHANGED')
        pending = target.with_name(target.name + '.' + NAME + '.pending')
        self.a.exact_path(pending, True); self.files.write(pending, raw, row['mode'])
        self.snapshot(changed=frozenset(state['written'])); self.decision(pin); self.lease()
        need(sha(self.a.read(pending)) == row['sha256'] and self.files.mode(pending) == row['mode'], 'STATIC_PENDING_CHANGED')
        if row['baseSha256'] is None:
            os.link(pending, target); os.unlink(pending)  # exclusive publication, never replace a newly appeared file
        else:
            need(sha(self.a.read(target)) == row['baseSha256'] and self.files.mode(target) == row['mode'], 'LAST_STATIC_CAS_CHANGED')
            os.replace(pending, target)
        state['written'].append(str(target))

    def apply(self, pin, apply=False):
        need(getattr(self,'inspection_state',None) is None, 'OWN_INSPECTION_CANNOT_APPLY')
        need(apply is True and digest(pin), 'EXPLICIT_OWN_APPLY_REQUIRED')
        self.unused(allow_decision=True); decision = self.decision(pin); before = self.baseline()
        need(self.source_modes() == decision['sourceModes'] and self.static_modes() == decision['staticModes'], 'APPROVED_FILE_MODES_CHANGED')
        alias, tag = NAME + '-base', NAME + '-content'
        for name in (alias, tag): need(not self.run(['docker', 'image', 'ls', '--quiet', '--filter', 'reference=' + name]).strip(), 'UNIQUE_NEW_IMAGE_ALIAS_REQUIRED')
        need(self.run(['docker', 'image', 'inspect', '--format', '{{.Id}}', PARENT]).decode().strip() == PARENT, 'EXACT_PARENT_IMAGE_REQUIRED')
        layers = self.a.decode(self.run(['docker', 'image', 'inspect', '--format', '{{json .RootFS.Layers}}', PARENT]))
        need(type(layers) is list and layers, 'EXACT_PARENT_LAYERS_REQUIRED')
        state = {'schema': 1, 'name': NAME, 'inputs': self.binding(), 'before': before, 'decisionSha256': pin, 'static': [],
                 'sourceBackups': [], 'written': [], 'sourceModes': decision['sourceModes'], 'automaticRetry': False,
                 'automaticCodeRollback': False, 'workerRecreated': False, 'mainDbRowDirectWrites': 0, 'queueEdits': 0, 'oldJournalWrites': 0,
                 'reportDatabaseBefore': decision['reportDatabaseBefore']}
        self.a.write_new(self.paths['journal'], {**state, 'phase': 'CONTEXT_STARTED_UNKNOWN'})
        for path in (self.paths['context'], self.paths['backup']): self.files.directory(self.a.exact_path(path, True), 0o700)
        info = self.paths['backup'].stat(); state['backupIdentity'] = [info.st_dev, info.st_ino, info.st_uid]
        state['reportDatabaseBackup'] = self.db.backup(self.paths['backup'] / 'reports.sqlite', decision['reportDatabaseContentBefore'])
        state['contentDatabaseBackup'] = self.contentdb.backup(self.paths['backup'] / 'content.sqlite', decision['contentDatabaseBefore'])
        self.update(state, 'DATABASE_BACKUP_SEALED_NOT_PUBLISHED')
        directories = {'app', 'static'} | {'app/' + str(p) for r in self.source_records.values() for p in PurePosixPath(r['target']).parents if str(p) != '.'}
        for relative in sorted(directories, key=lambda n: (n.count('/'), n)):
            self.files.directory(self.a.exact_path(self.paths['context'] / relative, True), 0o700 if relative == 'static' else 0o755)
        for target, row in sorted(self.existing_sources.items()):
            encoded = self.run(['docker', 'exec', 'synapse-content-1', 'node', '-e', self.current.source_script, target])
            need(len(encoded) < 3 * 1024 * 1024, 'BOUNDED_ORIGINAL_SOURCE_REQUIRED')
            raw = base64.b64decode(encoded, validate=True); need(sha(raw) == row['beforeSourceSha256'], 'SOURCE_BACKUP_BASE_CHANGED')
            backup = self.paths['backup'] / ('source-' + str(len(state['sourceBackups'])))
            self.files.write(backup, raw, 0o600); state['sourceBackups'].append({'target': target, 'baseSha256': row['beforeSourceSha256'], 'backup': str(backup)})
        for row in self.source_records.values():
            self.files.write(self.paths['context'] / 'app' / row['target'], self.a.read(CODE / 'payload' / row['name']), decision['sourceModes'][row['target']]['mode'])
        for target, row in sorted(self.static_records.items()):
            index = len(state['static']); prepared = self.paths['context'] / 'static' / str(index); backup = None
            raw = self.a.read(CODE / 'payload' / row['name']); self.files.write(prepared, raw, 0o600)
            if row['beforeSha256'] is not None:
                old = self.a.read(Path(target)); need(sha(old) == row['beforeSha256'], 'STATIC_BACKUP_BASE_CHANGED')
                backup = self.paths['backup'] / ('static-' + str(index)); self.files.write(backup, old, 0o600)
            state['static'].append({'target': target, 'baseSha256': row['beforeSha256'], 'sha256': row['sha256'], 'mode': decision['staticModes'][target],
                                    'backup': str(backup) if backup else None, 'prepared': str(prepared)})
        self.files.write(self.paths['context'] / 'Dockerfile', ('FROM ' + alias + '\nCOPY app/ /app/\n').encode(), 0o600)
        self.backups(state); self.update(state, 'CONTEXT_READY_NOT_BUILT', contextSha256=self.context_proof(state))
        self.baseline(); self.decision(pin); self.lease()
        self.run(['docker', 'image', 'tag', PARENT, alias]); need(self.run(['docker', 'image', 'inspect', '--format', '{{.Id}}', alias]).decode().strip() == PARENT, 'PARENT_ALIAS_CHANGED')
        self.update(state, 'BUILD_STARTED_UNKNOWN'); need(self.context_proof(state) == state['contextSha256'], 'LAST_CONTEXT_CHANGED')
        self.run(['docker', 'build', '--network=none', '--pull=false', '--tag', tag, '--iidfile', str(self.paths['context'] / 'image.id'), str(self.paths['context'])])
        child = self.a.read(self.paths['context'] / 'image.id').decode().strip()
        need(self.a.image(child) and child != PARENT and self.run(['docker', 'image', 'inspect', '--format', '{{.Id}}', tag]).decode().strip() == child, 'EXACT_CHILD_IMAGE_REQUIRED')
        child_layers = self.a.decode(self.run(['docker', 'image', 'inspect', '--format', '{{json .RootFS.Layers}}', child]))
        need(type(child_layers) is list and child_layers[:len(layers)] == layers and len(child_layers) == len(layers) + 1, 'ONE_COPY_LAYER_REQUIRED')
        need(self.context_proof(state, True) == state['contextSha256'] and self.b.photo.hashes(self.source, child) == self.source, 'FULL_CHILD_SOURCE_CHANGED')
        supplement_child_check = ";{const f=require('node:fs'),c=require('node:crypto'),p='/app/project-chat.js',s=f.lstatSync(p);if(!s.isFile()||s.isSymbolicLink()||s.nlink!==1||s.uid!==0||s.gid!==0||f.realpathSync(p)!==p||(s.mode&511)!==" + str(self.source_supplement['mode']) + "||c.createHash('sha256').update(f.readFileSync(p)).digest('hex')!==" + json.dumps(self.source[SUPPLEMENT_NAME]) + ")throw Error('EXACT_CHILD_SOURCE_SUPPLEMENT_REQUIRED');}"
        script = self.prior.CHILD_CHECK_JS + supplement_child_check + ";const {DatabaseSync}=require('node:sqlite');const r=require('/app/company-app/runtime.cjs').create({db:new DatabaseSync(':memory:')});r.close();"
        output = self.run(['docker', 'run', '--rm', '--network=none', '--read-only', '--cap-drop=ALL', '--security-opt=no-new-privileges', '--entrypoint=node', child, '-e', script, json.dumps(decision['sourceModes'])])
        need(output == b'PRECHECK_OK', 'CHILD_SYNTAX_RUNTIME_PREFLIGHT_REQUIRED')
        self.users(child)
        self.baseline(); self.decision(pin); self.backups(state)
        self.update(state, 'STATIC_STARTED_UNKNOWN', childImage=child)
        for row in sorted(state['static'], key=lambda row: (row['target'].endswith('/cabinet.html'), row['target'])):
            self.publish(row, state, pin); self.update(state, 'STATIC_STARTED_UNKNOWN')
        need(self.snapshot(changed=frozenset(state['written'])) == before, 'LAST_PARENT_WITH_PUBLISHED_STATIC_CHANGED')
        self.a.write_new(self.paths['overlay'], {'services': {'content': {'image': child}}})
        proof = {'overlaySha256': sha(self.a.read(self.paths['overlay'])), 'plannedConfigHash': self.b.plan(before, 'content', self.paths['overlay'])}
        self.update(state, 'CONTENT_UP_STARTED_UNKNOWN', **proof)
        self.decision(pin); self.lease(); self.backups(state); self.stable()
        need(self.context_proof(state, True) == state['contextSha256'] and self.b.plan(before, 'content', self.paths['overlay']) == proof['plannedConfigHash'], 'LAST_CONTEXT_OR_COMPOSE_PLAN_CHANGED')
        self.lease()
        self.backups(state)
        need(self.snapshot(changed=frozenset(state['written'])) == before, 'LAST_NATIVE_BASIS_CHANGED')
        need(private_report_db(self.report_db()), 'LAST_PRIVATE_REPORT_GROUP_REQUIRED')
        self.db.guard(state['reportDatabaseBackup'])
        self.lease()
        self.contentdb.guard(state['contentDatabaseBackup'])
        self.managed_guard.guard(); self.lease()
        self.update(state, 'CONTENT_SCHEMA_STARTED_UNKNOWN')
        state['contentMigration'] = self.contentdb.migrate(state['contentDatabaseBackup'])
        state['contentSchemaObjectsCreated'] = 6
        state['contentLegacyRowWrites'] = 0
        state['activationRowsCreated'] = 0
        self.update(state, 'CONTENT_UP_STARTED_UNKNOWN')
        need(self.snapshot(changed=frozenset(state['written'])) == before, 'POST_MIGRATION_NATIVE_BASIS_CHANGED')
        need(private_report_db(self.report_db()), 'POST_MIGRATION_PRIVATE_REPORT_GROUP_REQUIRED')
        self.db.guard(state['reportDatabaseBackup']); self.contentdb.after_guard(state['contentMigration']); self.stable(); self.lease()
        self.managed_guard.guard(); self.lease()
        self.b.up(before, 'content', self.paths['overlay'])
        self.managed_guard.guard(); self.lease()
        after = self.snapshot(child, frozenset(state['written']), proof)
        need(after['contentCid'] != before['contentCid'] and self.source_modes(True) == decision['sourceModes'], 'EXACT_NEW_CONTENT_AND_MODES_REQUIRED')
        self.contentdb.after_guard(state['contentMigration'])
        report_db = self.report_db(); need(private_report_db(report_db), 'PRIVATE_REPORT_DB_PRESERVED_REQUIRED')
        self.db.guard(state['reportDatabaseBackup'])
        self.update(state, 'APPLIED_NOT_CUSTOMER_ACCEPTANCE', after=after, reportDatabaseAfter=report_db, finishedAtUtc=self.a.stamp(time.time()))
        return {'status': 'APPLIED_NOT_CUSTOMER_ACCEPTANCE', 'receiptSha256': sha(self.a.read(self.paths['journal'])), 'contentImage': child,
                'sourceFiles': 235, 'staticFiles': 41, 'chainFiles': 39, 'workerRecreated': False, 'mainDbRowDirectWrites': 0, 'contentSchemaObjectsCreated': 6, 'activationRowsCreated': 0, 'oldJournalWrites': 0}

    def inspect(self, pin):
        need(self.inspection_pin in (None,pin), 'EXACT_OWN_INSPECTION_PIN_REQUIRED')
        state = self.a.pinned(self.paths['journal'], pin, True)
        need(state.get('phase') == 'APPLIED_NOT_CUSTOMER_ACCEPTANCE' and state.get('name') == NAME
             and state.get('inputs') == self.binding() and state.get('before') == self.base
             and state.get('workerRecreated') is False and state.get('automaticRetry') is False
             and state.get('automaticCodeRollback') is False
             and state.get('contentSchemaObjectsCreated') == 6 and state.get('contentLegacyRowWrites') == state.get('activationRowsCreated') == 0
             and state.get('mainDbRowDirectWrites') == state.get('queueEdits') == state.get('oldJournalWrites') == 0,
             'EXACT_OWN_COMPLETED_RECEIPT_REQUIRED')
        self.decision(state['decisionSha256'], fresh=False); self.backups(state)
        need(self.context_proof(state, True) == state['contextSha256'] and set(state['written']) == set(self.static_records), 'SEALED_OWN_CONTEXT_AND_STATIC_REQUIRED')
        proof = {k: state[k] for k in ('overlaySha256', 'plannedConfigHash')}
        need(self.snapshot(state['childImage'], frozenset(state['written']), proof) == state['after']
             and private_report_db(self.report_db()), 'OWN_INSTALLATION_CHANGED')
        self.db.guard(state['reportDatabaseBackup']); self.contentdb.after_guard(state['contentMigration'])
        return {'status': 'OWN_COMPLETED_READONLY_NOT_CUSTOMER_ACCEPTANCE', 'sourceFiles': 235, 'staticFiles': 41, 'chainFiles': 39, 'runtimeWrites': 0}


def main():
    p = argparse.ArgumentParser(); p.add_argument('operation', choices=['inspect-current', 'approve-current', 'apply', 'inspect']); p.add_argument('--lease-pid', required=True, type=int)
    p.add_argument('--acceptance-sha'); p.add_argument('--decision-sha'); p.add_argument('--receipt-sha'); p.add_argument('--apply', action='store_true'); args = p.parse_args()
    try:
        need(FROZEN is True and all(digest(p) and p != '0' * 64 for p in (MANIFEST_SHA,ROLLBACK_SHA,DB_HELPER_SHA,CONTENT_HELPER_SHA,CONTENT_MIGRATION_SHA,PRODUCT_REVIEW_SHA,PRODUCT_MANIFEST_SHA,MANAGED_HELPER_SHA,MANAGED_PROBE_SHA,MANAGED_PROOF_SHA,MAP_OUTCOME_SHA)) and NATIVE_CABINET_HOST is not None and NATIVE_CABINET_CSS_HOST is not None, 'DRAFT_INSTALLER_NOT_FROZEN_NO_ACTION')
        need(os.name == 'posix' and os.geteuid() == 0 and Path(__file__).resolve().parent == CODE, 'EXACT_RECEIVER_CODE_ROOT_REQUIRED')
        a, b, prior, current = load_current_r6(args.lease_pid)
        need(args.operation != 'inspect' or digest(args.receipt_sha), 'EXPLICIT_OWN_INSPECTION_RECEIPT_REQUIRED')
        release = Release(a, b, prior, current, args.lease_pid, args.receipt_sha if args.operation == 'inspect' else None)
        if args.operation == 'inspect-current': result = release.inspect_current()
        elif args.operation == 'approve-current': result = release.approve(args.acceptance_sha, args.apply)
        elif args.operation == 'apply': result = release.apply(args.decision_sha, args.apply)
        else: result = release.inspect(args.receipt_sha)
        print(json.dumps(result, separators=(',', ':'))); return 0
    except Exception as error:
        code = str(error) if type(error) is ValueError and re.fullmatch('[A-Z][A-Z0-9_]{0,100}', str(error)) else 'NATIVE_RELEASE_REFUSED'
        print(json.dumps({'status': 'REFUSED_OR_UNKNOWN_NO_AUTOMATIC_RETRY', 'code': code, 'messageSha256': sha(str(error).encode()), 'runtimeWritesNotAssumed': True})); return 2


if __name__ == '__main__':
    raise SystemExit(main())
