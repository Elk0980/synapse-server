"""UNFROZEN Root-only release29 over sealed static28/runtime27.
No old action replay. One content build/up plus the accepted customer order.js overlay.
Worker, selected flags, DB/auth/rights/prices/data and historical artifacts stay unchanged.
Final source allowlist and manifest remain empty until explicit Root review.
"""
import argparse
import base64
import copy
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import time
import types

ROOT = Path('/opt/synapse/releases/palitra-app-20261015')
NAME = 'palitra-checkout-direct-chat-r1'
CODE_NAME = 'palitra-checkout-direct-chat-code-r1'
PHASE = 'RELEASE29_CHECKOUT_APPLIED_NOT_CUSTOMER_ACCEPTANCE'
SCOPE = 'EXACT_CHECKOUT_SOURCE209_STATIC27_CHAIN27_TO_28'
UNFROZEN = '0' * 64
MANIFEST_SHA = 'af53d50c682a725b3e17f21489a37b75d663addb16d534fff08ccdc6956d2c48'
PRIOR_CODE = ROOT / 'palitra-cart-total-copy-code-r3'
PRIOR_HELPER_SHA = 'b40502447687b7c13631e5a59095207c901d80c868e2be39e00e0a55e6a5e2c6'
PRIOR_RECEIPT_SHA = 'f6e4587e5d7d697f3c126dfc7f85ed5342b4d21d6bd65a49084580d792fec7cc'
CONTENT = 'sha256:b2e778ab95e28a56d2106b0c61532fb67c55181c5b160ae5aa6127fed8ab1b06'
WORKER = 'sha256:d4d4d453ce2e3dc47d5e0962d62b95938f42c56ec73789fe76a324e0d2ff0508'
LOCK = '/opt/synapse/.palitra-app-release.lock'
# Root supplied four existing backend paths; manifest remains UNFROZEN.
SOURCE_LAYOUT = {name: name.removeprefix('source/') for name in ('source/customer-chat.js', 'source/customer-chat-native-adapter.cjs', 'source/site-orders.js', 'source/native-contact-followup.cjs')}
STATIC_LAYOUT = {'customer/order.js': 'assets/order.js'}
NAMES = set(SOURCE_LAYOUT) | set(STATIC_LAYOUT)
SOURCE_FACTS_JS = "const fs=require('fs'),p=JSON.parse(process.argv[1]);console.log(JSON.stringify(Object.fromEntries(p.map(n=>{const s=fs.lstatSync('/app/'+n);if(!s.isFile())throw Error('REGULAR_SOURCE_REQUIRED');return[n,{uid:s.uid,gid:s.gid,mode:s.mode&511}]}))));"
CHILD_CHECK_JS = "const fs=require('fs'),cp=require('child_process'),m=JSON.parse(process.argv[1]);for(const[n,e]of Object.entries(m)){const p='/app/'+n,s=fs.lstatSync(p);if(!s.isFile()||s.uid!==e.uid||s.gid!==e.gid||(s.mode&511)!==e.mode)process.exit(73);if(/[.](?:js|cjs)$/.test(n)){const r=cp.spawnSync(process.execPath,['--check',p],{stdio:'inherit'});if(r.status!==0)process.exit(74)}}process.stdout.write('PRECHECK_OK');"
USER_FORMAT = '{{json (or (index .Config "User") "")}}'
ROOT_USERS = {'', 'root', '0', '0:0', 'root:root'}
# Exact accepted cabinet modes; no chmod migration or arbitrary mode selection.
KNOWN_STATIC_MODES = {'order.js': 0o600}
ROOT_MANIFEST_SHA = 'dd82ce11f239823d005a0e05132f92b640776984f01013094d07e07e62c6d812'
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def need(value, code):
    if not value:
        raise ValueError(code)


def digest(value):
    return type(value) is str and re.fullmatch('[0-9a-f]{64}', value) is not None


def hunk_bytes(hunk):
    need(type(hunk) is dict and set(hunk) == {'before', 'after'}
         and all(type(hunk[k]) is str and 0 < len(hunk[k]) <= 3 * 1024 * 1024 for k in hunk), 'BOUNDED_BASE64_HUNK_REQUIRED')
    values = [base64.b64decode(hunk[key], validate=True) for key in ('before', 'after')]
    need(all(0 < len(raw) <= 2 * 1024 * 1024 and base64.b64encode(raw).decode('ascii') == hunk[key]
             for key, raw in zip(('before', 'after'), values)) and values[0] != values[1], 'CANONICAL_CHANGED_BYTE_HUNK_REQUIRED')
    return values


class FileOps:
    """Every new descriptor receives its exact mode despite umask077."""
    def write(self, path, raw, mode):
        flags = os.O_RDWR | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_CLOEXEC', 0) | getattr(os, 'O_BINARY', 0)
        fd = os.open(path, flags, 0o600)
        try:
            first = os.fstat(fd)
            need(stat.S_ISREG(first.st_mode), 'REGULAR_CREATED_FD_REQUIRED')
            view = memoryview(raw)
            while view:
                count = os.write(fd, view)
                need(count > 0, 'WRITE_INCOMPLETE')
                view = view[count:]
            self.set_mode(fd, mode)
            os.fsync(fd)
            last = os.fstat(fd)
            need((first.st_dev, first.st_ino, first.st_uid) == (last.st_dev, last.st_ino, last.st_uid)
                 and self.fd_mode(fd) == mode, 'CREATED_FD_MODE_READBACK_FAILED')
            return (last.st_dev, last.st_ino, last.st_uid)
        finally:
            os.close(fd)

    def set_mode(self, fd, mode):
        need(os.name == 'posix' and hasattr(os, 'fchmod'), 'POSIX_FCHMOD_REQUIRED')
        os.fchmod(fd, mode)

    def fd_mode(self, fd):
        return stat.S_IMODE(os.fstat(fd).st_mode)

    def mode(self, path):
        return stat.S_IMODE(path.stat().st_mode)

    def directory(self, path, mode):
        path.mkdir(mode=0o700)
        need(os.name == 'posix', 'POSIX_DIRECTORY_FD_REQUIRED')
        fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | getattr(os, 'O_CLOEXEC', 0))
        try:
            row = os.fstat(fd)
            need(stat.S_ISDIR(row.st_mode) and not os.listdir(fd), 'NEW_EMPTY_DIRECTORY_FD_REQUIRED')
            os.fchmod(fd, mode)
            os.fsync(fd)
            last = os.fstat(fd)
            need((last.st_dev, last.st_ino, last.st_uid) == (row.st_dev, row.st_ino, row.st_uid)
                 and stat.S_IMODE(last.st_mode) == mode, 'NEW_DIRECTORY_MODE_READBACK_FAILED')
        finally:
            os.close(fd)


class CheckoutDirectChatRelease:

    def __init__(self, a, b, current, payload, manifest_pin, lease_pid, clock=time.time, file_ops=None):
        self.a, self.b, self.current, self.photo = a, b, current, b.photo
        self.root, self.run, self.clock, self.lease_pid = b.root, b.run, clock, lease_pid
        need(type(lease_pid) is int and lease_pid > 1, 'FRESH_ROOT_LEASE_REQUIRED')
        need(file_ops is None or self.root != ROOT, 'NATIVE_DEFAULT_FILE_OPS_REQUIRED')
        self.files = file_ops or FileOps()
        self.b.lease = self.lease
        self.base = copy.deepcopy(current.base)
        self.before_source, self.before_static = dict(current.source), dict(current.static)
        need(len(self.before_source) == 209 and len(self.before_static) == 27
             and all(digest(v) for v in [*self.before_source.values(), *self.before_static.values()]), 'EXACT_SOURCE209_STATIC27_REQUIRED')
        need(self.base['containers']['content']['image'] == CONTENT and len(self.base['containers']['content']['files']) == 27
             and self.base['worker']['image'] == WORKER and self.base['selected']['content']['PALITRA_WEB_UPLOADS_ENABLED'] == 'true', 'EXACT_STATIC28_RUNTIME27_REQUIRED')
        need(digest(manifest_pin) and MANIFEST_SHA != UNFROZEN and manifest_pin == MANIFEST_SHA, 'MANIFEST_NOT_FROZEN')
        need(type(SOURCE_LAYOUT) is dict and 1 <= len(SOURCE_LAYOUT) <= 12
             and type(STATIC_LAYOUT) is dict and STATIC_LAYOUT == {'customer/order.js': 'assets/order.js'}
             and set(SOURCE_LAYOUT).isdisjoint(STATIC_LAYOUT) and NAMES == set(SOURCE_LAYOUT) | set(STATIC_LAYOUT), 'ROOT_FINAL_LAYOUT_NOT_FROZEN')
        for name, target in SOURCE_LAYOUT.items():
            need(type(name) is str and type(target) is str and name.startswith('source/')
                 and PurePosixPath(name).as_posix() == name and PurePosixPath(target).as_posix() == target
                 and not PurePosixPath(target).is_absolute() and '..' not in PurePosixPath(target).parts
                 and '\\' not in name + target and ':' not in name + target
                 and target in self.before_source and Path(target).suffix in ('.js', '.cjs')
                 and name == 'source/' + target, 'EXACT_REVIEWED_EXISTING_SOURCE_TARGET_REQUIRED')
        need(len(set(SOURCE_LAYOUT.values())) == len(SOURCE_LAYOUT), 'UNIQUE_SOURCE_TARGET_REQUIRED')
        self.managed = a.exact_path(current.managed)
        self.root_manifest_path = a.exact_path(self.root / 'bundle-root-final/manifest.json')
        need(sha(a.read(self.root_manifest_path)) == ROOT_MANIFEST_SHA, 'EXACT_SIGNED_CUSTOMER_MANIFEST_REQUIRED')
        self.parents = {str(p): self.facts(p) for p in (self.root, self.managed, self.managed / 'assets')}
        self.payload = a.exact_path(payload)
        need(self.payload.is_relative_to(self.root), 'ROOT_PAYLOAD_REQUIRED')
        self.manifest_pin = manifest_pin
        manifest = a.pinned(self.payload / 'MANIFEST.json', manifest_pin)
        need(type(manifest) is dict and set(manifest) == {'schema', 'status', 'records', 'staticModes'} and type(manifest['schema']) is int and manifest['schema'] == 1
             and manifest['status'] == SCOPE and type(manifest['records']) is list and len(manifest['records']) == len(NAMES), 'EXACT_ROOT_FINAL_PAYLOADS_REQUIRED')
        self.mode_map = manifest['staticModes']
        need(type(self.mode_map) is dict and self.mode_map == KNOWN_STATIC_MODES
             and all(type(mode) is int for mode in self.mode_map.values()), 'EXACT_PRESERVED_ORDER600_MODE_REQUIRED')
        self.helper, self.wrapper = a.exact_path(__file__), a.exact_path(Path(__file__).parent / 'checkout_direct_chat.py')
        self.pins = {str(self.helper): sha(a.read(self.helper)), str(self.wrapper): sha(a.read(self.wrapper)),
                     str(self.root_manifest_path): ROOT_MANIFEST_SHA, str(self.payload / 'MANIFEST.json'): manifest_pin}
        self.records, self.targets = {}, {}
        self.final_source, self.final_static = dict(self.before_source), dict(self.before_static)
        for row in manifest['records']: self.accept(row)
        need(set(self.records) == NAMES and len(self.static_targets()) == len(STATIC_LAYOUT)
             and set(self.final_source) == set(self.before_source) and set(self.final_static) == set(self.before_static)
             and {key for key in self.before_source if self.before_source[key] != self.final_source[key]} == set(SOURCE_LAYOUT.values())
             and {key for key in self.before_static if self.before_static[key] != self.final_static[key]} == {str(self.managed / 'assets/order.js')}, 'EXACT_FINAL_CHANGED_MAPS_REQUIRED')
        found, directories = set(), set()
        for path in self.payload.rglob('*'):
            a.exact_path(path); relative = path.relative_to(self.payload).as_posix()
            if path.is_file(): found.add(relative)
            else: need(path.is_dir(), 'REGULAR_PAYLOAD_DIRECTORY_REQUIRED'); directories.add(relative)
        expected_dirs = {str(p) for name in NAMES for p in PurePosixPath(name).parents if str(p) != '.'}
        need(found == NAMES | {'MANIFEST.json'} and directories == expected_dirs, 'CLOSED_FINAL_PAYLOAD_REQUIRED')
        self.active_decision_pin = None

    def facts(self, path):
        row = self.a.exact_path(path).stat()
        need(stat.S_ISDIR(row.st_mode), 'EXACT_DIRECTORY_PARENT_REQUIRED')
        return [row.st_dev, row.st_ino, row.st_uid, row.st_gid, stat.S_IMODE(row.st_mode)]

    def parents_guard(self):
        need({name: self.facts(Path(name)) for name in self.parents} == self.parents, 'STATIC_PARENT_IDENTITY_CHANGED')


    def target_map(self, name):
        need(name in NAMES, 'EXACT_REVIEWED_TARGET_REQUIRED')
        if name in SOURCE_LAYOUT: return [('source', SOURCE_LAYOUT[name])]
        return [('static', str(self.managed / STATIC_LAYOUT[name]))]

    def accept(self, row):
        need(type(row) is dict and set(row) == {'name', 'payload', 'beforeSha256', 'beforeBytes', 'sha256', 'bytes', 'hunks'}, 'EXACT_MANIFEST_RECORD_REQUIRED')
        name = row['name']
        need(type(name) is str and name in NAMES and name not in self.records and row['payload'] == name
             and all(digest(row[k]) for k in ('beforeSha256', 'sha256')) and row['beforeSha256'] != row['sha256']
             and all(type(row[k]) is int and 0 < row[k] <= 2 * 1024 * 1024 for k in ('beforeBytes', 'bytes'))
             and type(row['hunks']) is list and 1 <= len(row['hunks']) <= 256, 'EXACT_CHANGED_EXISTING_RECORD_REQUIRED')
        raw = self.a.read(self.payload / name)
        need(len(raw) == row['bytes'] and sha(raw) == row['sha256'], 'PAYLOAD_CHANGED')
        old = raw
        for hunk in reversed(row['hunks']):
            before, after = hunk_bytes(hunk)
            need(old.count(after) == 1, 'REVERSE_UNIQUE_HUNK_REQUIRED')
            old = old.replace(after, before, 1)
        need(len(old) == row['beforeBytes'] and sha(old) == row['beforeSha256'] and self.patch(old, row) == raw, 'EXACT_RECONSTRUCTED_BASE_REQUIRED')
        targets = self.target_map(name)
        for kind, target in targets:
            before = self.before_source if kind == 'source' else self.before_static
            final = self.final_source if kind == 'source' else self.final_static
            need(before.get(target) == row['beforeSha256'], 'EXACT_ACCEPTED_TARGET_BASE_REQUIRED')
            final[target] = row['sha256']
        self.records[name], self.targets[name] = row, targets
        self.pins[str(self.payload / name)] = row['sha256']

    def patch(self, raw, row):
        need(len(raw) == row['beforeBytes'] and sha(raw) == row['beforeSha256'], 'ACTUAL_RAW_BASE_CHANGED')
        for hunk in row['hunks']:
            before, after = hunk_bytes(hunk)
            need(raw.count(before) == 1, 'FORWARD_UNIQUE_HUNK_REQUIRED')
            raw = raw.replace(before, after, 1)
        need(len(raw) == row['bytes'] and sha(raw) == row['sha256'], 'FINAL_BYTES_CHANGED')
        return raw

    def static_targets(self):
        return [(name, Path(target)) for name in sorted(self.targets) for kind, target in self.targets[name] if kind == 'static']

    def paths(self):
        return {key: self.root / (NAME + '-' + key + ('.json' if key in ('decision', 'journal', 'overlay') else '')) for key in ('decision', 'journal', 'overlay', 'context', 'backup')}

    def lease(self):
        raw = self.run(['lslocks', '--noheadings', '--output', 'PID,PATH'])
        need(len(raw) <= 1048576, 'BOUNDED_LEASE_INVENTORY_REQUIRED')
        rows = [line.strip().split(maxsplit=1) for line in raw.decode().splitlines() if len(line.strip().split(maxsplit=1)) == 2 and line.strip().split(maxsplit=1)[1] == LOCK]
        need(rows == [[str(self.lease_pid), LOCK]], 'FRESH_EXCLUSIVE_ROOT_LEASE_REQUIRED')

    def stable(self):
        self.current.stable()
        for name, pin in self.pins.items(): need(sha(self.a.read(Path(name))) == pin, 'CHECKOUT_PINNED_INPUT_CHANGED')
        self.parents_guard()

    def absent(self, decision=False):
        for kind, path in self.paths().items():
            if kind == 'decision' and not decision: continue
            self.a.exact_path(path, True)
            need(not os.path.lexists(path) and not os.path.lexists(str(path) + '.pending'), 'ATTEMPT_EXISTS_NO_RETRY')
        for _, target in self.static_targets():
            pending = target.with_name(target.name + '.' + NAME + '.pending')
            self.a.exact_path(pending, True); need(not os.path.lexists(pending), 'OWN_STATIC_PENDING_EXISTS_NO_RETRY')


    def expected_metadata(self, service, content, proof):
        if service == 'chat': return copy.deepcopy(self.base['containers']['chat'])
        old = self.base['containers']['content']
        if content == CONTENT:
            need(proof is None, 'BASE_PROOF_MUST_BE_EMPTY'); return copy.deepcopy(old)
        need(type(proof) is dict and set(proof) == {'childImage', 'overlaySha256', 'plannedConfigHash'} and proof['childImage'] == content
             and self.a.image(content) and content != CONTENT and digest(proof['overlaySha256']) and digest(proof['plannedConfigHash']), 'OWN_SEALED_CHILD_PROOF_REQUIRED')
        overlay = self.paths()['overlay']
        need(sha(self.a.read(overlay)) == proof['overlaySha256'] and self.a.decode(self.a.read(overlay)) == {'services': {'content': {'image': content}}}, 'OWN_SEALED_OVERLAY_CHANGED')
        files = old['files'] + [str(overlay)]
        need(len(old['files']) == 27 and len(files) == len(set(files)) == 28, 'EXACT_OWN_CONTENT_CHAIN28_REQUIRED')
        return dict(old, image=content, files=files, configFiles=','.join(files), filePins={**old['filePins'], str(overlay): proof['overlaySha256']}, configHash=proof['plannedConfigHash'])

    def metadata(self, service, expected):
        if service == 'chat':
            row = self.b.metadata(service)
        else:
            row = self.a.decode(self.run(['docker', 'inspect', '--format', self.a.LABELS, 'synapse-content-1']))
            need(type(row) is dict and set(row) == {'image', 'project', 'service', 'workingDir', 'configFiles', 'configHash', 'running', 'health'}
                 and type(row['configFiles']) is str and len(row['configFiles']) <= 65536, 'EXACT_CONTENT_LABELS_REQUIRED')
            files = row['configFiles'].split(',')
            need(files == expected['files'] and len(files) == len(set(files)) and len(files) in (27, 28), 'ONLY_EXACT_RUNTIME27_OR_OWN28_REQUIRED')
            pins = {}
            for name in files:
                path = self.a.exact_path(name)
                need(path.suffix.lower() in ('.json', '.yml', '.yaml'), 'EXACT_COMPOSE_FILE_REQUIRED')
                pins[name] = sha(self.a.read(path))
            row.update(files=files, filePins=pins)
        need(row == expected, 'EXACT_METADATA_FILEPINS_CHANGED')
        return row

    def static_guard(self, changed):
        self.parents_guard()
        self.current.guide_guard()
        for name, pin in (self.final_static if changed else self.before_static).items():
            need(sha(self.a.read(Path(name))) == pin, 'FULL_STATIC27_CHANGED')
        self.modes()


    def revision_guard(self):
        if self.root != ROOT:
            need(self.current.current_managed_root == str(self.managed), 'FIXTURE_CURRENT_REVISION_CHANGED'); return
        import sqlite3
        database = '/var/lib/docker/volumes/synapse_content_data/_data/content.sqlite'
        self.a.exact_path(database)
        connection = sqlite3.connect('file:' + database + '?mode=ro', uri=True, timeout=5)
        try:
            row = connection.execute('SELECT current_revision FROM site_workspaces WHERE site_id=?', ('site-44bbe13f1bad5e005b2a',)).fetchone()
        finally: connection.close()
        need(type(row) is tuple and len(row) == 1 and digest(row[0])
             and str(self.managed) == '/var/lib/docker/volumes/synapse_content_data/_data/projects/palitra-love/sites/site-44bbe13f1bad5e005b2a/versions/' + row[0],
             'FIXED_SITE_CURRENT_REVISION_CHANGED')

    def context_directories(self):
        return {'app', 'static'} | {'app/' + str(parent) for target in SOURCE_LAYOUT.values()
                                  for parent in PurePosixPath(target).parents if str(parent) != '.'}

    def snapshot(self, content=CONTENT, changed=False, proof=None, static_changed=None):
        self.stable(); self.lease(); self.revision_guard()
        first = {s: self.metadata(s, self.expected_metadata(s, content, proof)) for s in ('content', 'chat')}
        worker = self.b.worker_facts()
        selected = {s: self.b.a.selected(s) for s in ('content', 'chat')}
        flags = self.a.decode(self.run(['docker', 'exec', 'synapse-content-1', 'node', '-e', self.a.FLAGS_JS]))
        need(worker == self.base['worker'] and selected == self.base['selected'] and flags == self.base['l12'], 'WORKER_FLAGS_OR_SELECTION_CHANGED')
        for service, row in first.items():
            text = self.run(self.b._resolve_command(row, service)).decode('ascii').strip()
            need(re.fullmatch(re.escape(service) + r'\s+' + re.escape(row['configHash']), text) is not None, 'RESOLVED_CONFIG_HASH_CHANGED')
        self.b.graph(new=True); self.b.push_guard()
        expected = self.final_source if changed else self.before_source
        need(self.photo.hashes(expected) == expected, 'FULL_SOURCE209_CHANGED')
        self.static_guard(changed if static_changed is None else static_changed)
        cid = self.photo.cid()
        last = {s: self.metadata(s, self.expected_metadata(s, content, proof)) for s in ('content', 'chat')}
        need(first == last and worker == self.b.worker_facts() and selected == {s: self.b.a.selected(s) for s in ('content', 'chat')}
             and cid == self.photo.cid(), 'CONCURRENT_RUNTIME_CHANGE')
        self.stable(); self.lease()
        return {'containers': last, 'selected': selected, 'worker': worker, 'contentCid': cid, 'l12': flags}

    def baseline(self):
        snap = self.snapshot()
        need(snap == self.base and self.b.heartbeat(snap['worker']['startedAt'], self.clock())['freshAfterWorkerStart'], 'FRESH_STATIC28_RUNTIME27_REQUIRED')
        return snap

    def users(self, child=None):
        rows = {'current': self.a.decode(self.run(['docker', 'inspect', '--format', USER_FORMAT, 'synapse-content-1'])),
                'parent': self.a.decode(self.run(['docker', 'image', 'inspect', '--format', USER_FORMAT, CONTENT]))}
        if child: rows['child'] = self.a.decode(self.run(['docker', 'image', 'inspect', '--format', USER_FORMAT, child]))
        need(all(type(v) is str and v in ROOT_USERS for v in rows.values()) and (not child or rows['parent'] == rows['child']), 'ROOT_SERVICE_READ_SCOPE_REQUIRED')
        return rows

    def modes(self):
        result = {}
        for _, path in self.static_targets():
            row = self.a.exact_path(path).stat()
            expected_uid = 0 if self.root == ROOT else (os.getuid() if hasattr(os, 'getuid') else row.st_uid)
            need(stat.S_ISREG(row.st_mode) and row.st_uid == expected_uid and row.st_gid == 0, 'ROOT_OWNED_EXISTING_STATIC_REQUIRED')
            need(self.files.mode(path) == self.mode_map[path.name], 'EXACT_ACCEPTED_STATIC_MODE_MAP_REQUIRED')
            result[str(path)] = self.mode_map[path.name]
        return result


    def binding(self):
        return {'priorReceiptSha256': PRIOR_RECEIPT_SHA, 'parentImage': CONTENT, 'workerImage': WORKER, 'manifestSha256': self.manifest_pin,
                'helperSha256': self.pins[str(self.helper)], 'wrapperSha256': self.pins[str(self.wrapper)], 'freshLeasePid': self.lease_pid,
                'managedRoot': str(self.managed), 'parents': self.parents, 'sourceLayout': SOURCE_LAYOUT, 'staticLayout': STATIC_LAYOUT,
                'beforeSource': self.before_source, 'afterSource': self.final_source, 'beforeStatic': self.before_static, 'afterStatic': self.final_static}

    def decision(self, pin):
        value = self.a.pinned(self.paths()['decision'], pin, True)
        need(type(value) is dict and set(value) == {'schema', 'name', 'scope', 'rootApproved', 'observedAtUtc', 'inputs', 'before', 'staticModes', 'serviceUsers', 'sourceModes'}
             and value['schema'] == 1 and value['name'] == NAME and value['scope'] == SCOPE and value['rootApproved'] is True
             and value['inputs'] == self.binding() and value['before'] == self.base and value['serviceUsers'] == self.users()
             and value['sourceModes'] == self.source_facts(), 'EXACT_NEW_ROOT_DECISION_REQUIRED')
        self.a.fresh(value['observedAtUtc'], self.clock())
        need(type(value['staticModes']) is dict and set(value['staticModes']) == {str(p) for _, p in self.static_targets()}
             and all(type(v) is int and v == self.mode_map[Path(name).name] for name, v in value['staticModes'].items()), 'EXACT_APPROVED_STATIC_MODES_REQUIRED')
        return value

    def inspect_current(self):
        self.baseline(); self.users()
        return {'status': 'CURRENT28_READONLY_NOT_APPROVED', 'sourceFiles': 209, 'staticFiles': 27, 'contentChainFiles': 27, 'mutations': 0, 'sourceModes': self.source_facts(), 'staticModes': self.modes()}

    def approve(self, apply=False):
        need(apply is True, 'EXPLICIT_ROOT_APPROVAL_REQUIRED')
        self.absent(True); at = self.clock(); before = self.baseline()
        modes, users = self.modes(), self.users()
        self.a.fresh(self.a.stamp(at), self.clock())
        value = {'schema': 1, 'name': NAME, 'scope': SCOPE, 'rootApproved': True, 'observedAtUtc': self.a.stamp(at), 'inputs': self.binding(),
                 'before': before, 'staticModes': modes, 'serviceUsers': users, 'sourceModes': self.source_facts()}
        self.a.write_new(self.paths()['decision'], value)
        return {'status': 'NEW_DECISION_NOT_APPLIED', 'decisionSha256': sha(self.a.read(self.paths()['decision'])), 'runtimeWrites': 0}

    def context_proof(self, state, built=False):
        paths = self.paths(); alias = 'palitra-checkout-direct-chat-base:' + NAME
        wanted = {'Dockerfile': sha(('FROM ' + alias + '\nCOPY app/ /app/\n').encode())}
        wanted.update({'app/' + target: self.records[name]['sha256'] for name in self.records for kind, target in self.targets[name] if kind == 'source'})
        wanted.update({'static/' + str(i): row['sha256'] for i, row in enumerate(state['static'])})
        actual = {}
        for path in paths['context'].rglob('*'):
            self.a.exact_path(path)
            name = path.relative_to(paths['context']).as_posix()
            if path.is_file():
                if built and name == 'image.id': continue
                actual[name] = sha(self.a.read(path))
            else: need(path.is_dir() and name in self.context_directories(), 'CLOSED_CONTEXT_DIRECTORIES_REQUIRED')
        need(actual == wanted, 'EXACT_CLOSED_CONTEXT_REQUIRED')
        self.validate_source_modes(state.get('sourceModes'))
        for target, facts in state['sourceModes'].items():
            need(self.files.mode(paths['context'] / 'app' / target) == facts['mode'], 'CONTEXT_SOURCE_MODE_CHANGED')
        return sha(json.dumps(sorted(actual.items()), separators=(',', ':')).encode())

    def update(self, state, phase, **fields):
        state.update(phase=phase, **fields); self.a.replace(self.paths()['journal'], state)

    def unused(self, tag):
        need(not self.run(['docker', 'image', 'ls', '--quiet', '--filter', 'reference=' + tag]).strip(), 'UNIQUE_NEW_IMAGE_TAG_REQUIRED')

    def backup_directory_facts(self):
        path = self.a.exact_path(self.paths()['backup']); row = path.stat()
        expected_uid = 0 if self.root == ROOT else (os.getuid() if hasattr(os, 'getuid') else row.st_uid)
        need(stat.S_ISDIR(row.st_mode) and row.st_uid == expected_uid and self.files.mode(path) == 0o700, 'PRIVATE_BACKUP_DIRECTORY_REQUIRED')
        return {'path': str(path), 'device': row.st_dev, 'inode': row.st_ino, 'uid': row.st_uid, 'mode': 0o700}

    def backup_directory_guard(self, sealed):
        self.parents_guard()
        need(type(sealed) is dict and set(sealed) == {'path', 'device', 'inode', 'uid', 'mode'}
             and sealed['path'] == str(self.paths()['backup']) and sealed['mode'] == 0o700
             and all(type(sealed[key]) is int for key in ('device', 'inode', 'uid', 'mode'))
             and self.backup_directory_facts() == sealed, 'BACKUP_DIRECTORY_IDENTITY_CHANGED')

    def backup_row_guard(self, row, directory=None):
        directory = directory if directory is not None else getattr(self, 'backup_directory', None)
        self.backup_directory_guard(directory)
        need(type(row) is dict and set(row) == {'target', 'baseSha256', 'sha256', 'mode', 'prepared', 'backup', 'written'}, 'EXACT_BACKUP_ROW_REQUIRED')
        matches = [(i, name, path) for i, (name, path) in enumerate(self.static_targets()) if row['target'] == str(path)]
        need(len(matches) == 1, 'EXACT_BACKUP_TARGET_REQUIRED')
        index, name, target = matches[0]; record = self.records[name]
        need(row['baseSha256'] == record['beforeSha256'] and row['sha256'] == record['sha256']
             and row['prepared'] == str(self.paths()['context'] / 'static' / str(index))
             and row['backup'] == str(self.paths()['backup'] / str(index))
             and type(row['mode']) is int and row['mode'] == self.mode_map[Path(name).name] and type(row['written']) is bool, 'EXACT_BACKUP_PATHS_AND_PINS_REQUIRED')
        path = self.a.exact_path(Path(row['backup']))
        flags = os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_CLOEXEC', 0) | getattr(os, 'O_BINARY', 0)
        fd = os.open(path, flags)
        try:
            first = os.fstat(fd)
            need(stat.S_ISREG(first.st_mode) and first.st_uid == directory['uid'] and self.files.fd_mode(fd) == 0o600
                 and first.st_size == record['beforeBytes'], 'PRIVATE_REGULAR_BACKUP_REQUIRED')
            raw_hash = hashlib.sha256(); total = 0
            while True:
                raw = os.read(fd, 65536)
                if not raw: break
                total += len(raw); need(total <= record['beforeBytes'], 'BACKUP_SIZE_CHANGED'); raw_hash.update(raw)
            last = os.fstat(fd); actual = self.a.exact_path(path).stat()
            identity = (first.st_dev, first.st_ino, first.st_uid)
            need(identity == (last.st_dev, last.st_ino, last.st_uid) == (actual.st_dev, actual.st_ino, actual.st_uid)
                 and stat.S_ISREG(actual.st_mode) and self.files.fd_mode(fd) == self.files.mode(path) == 0o600
                 and total == record['beforeBytes'] and raw_hash.hexdigest() == row['baseSha256'], 'BACKUP_SHA_MODE_OR_IDENTITY_CHANGED')
        finally:
            os.close(fd)
        self.backup_directory_guard(directory)

    def backup_guard(self, state):
        need(type(state.get('static')) is list and len(state['static']) == len(STATIC_LAYOUT)
             and [row.get('target') if type(row) is dict else None for row in state['static']] == [str(path) for _, path in self.static_targets()], 'EXACT_BACKUP_FIXED_TWO_MAP_REQUIRED')
        directory = state.get('backupDirectory'); self.backup_directory_guard(directory)
        need({path.name for path in self.paths()['backup'].iterdir()} == {str(i) for i in range(len(STATIC_LAYOUT))} | {'source-' + str(i) for i in range(len(SOURCE_LAYOUT))}, 'CLOSED_BACKUP_DIRECTORY_REQUIRED')
        for row in state['static']: self.backup_row_guard(row, directory)
        self.source_backup_guard(state, directory)


    def publish(self, row):
        need(digest(self.active_decision_pin), 'ACTIVE_ROOT_DECISION_REQUIRED')
        self.backup_row_guard(row); self.snapshot(); self.decision(self.active_decision_pin)
        self.parents_guard(); target = self.a.exact_path(row['target'])
        need(sha(self.a.read(target)) == row['baseSha256'] and self.files.mode(target) == row['mode'], 'STATIC_CAS_CONFLICT')
        raw = self.a.read(Path(row['prepared'])); need(sha(raw) == row['sha256'], 'PREPARED_STATIC_CHANGED')
        pending = target.with_name(target.name + '.' + NAME + '.pending')
        self.a.exact_path(pending, True)
        identity = self.files.write(pending, raw, row['mode'])
        info = self.a.exact_path(pending).stat()
        need((info.st_dev, info.st_ino, info.st_uid) == identity and self.files.mode(pending) == row['mode']
             and sha(self.a.read(pending)) == row['sha256'], 'PENDING_MODE_SHA_OR_IDENTITY_CHANGED')
        # Last complete CAS/lease/revision/TTL, after pending creation and before replacement.
        self.snapshot(); self.decision(self.active_decision_pin); self.revision_guard(); self.lease()
        need(sha(self.a.read(target)) == row['baseSha256'] and self.files.mode(target) == row['mode'], 'LATE_STATIC_CAS_CONFLICT')
        os.replace(pending, target)
        need(sha(self.a.read(target)) == row['sha256'] and self.files.mode(target) == row['mode'], 'PUBLISHED_MODE_OR_SHA_CHANGED')

    def source_records(self):
        return {target: name for name, targets in self.targets.items() for kind, target in targets if kind == 'source'}

    def validate_source_modes(self, value):
        need(type(value) is dict and set(value) == set(self.source_records())
             and all(type(row) is dict and set(row) == {'uid', 'gid', 'mode'}
                     and type(row['uid']) is int and type(row['gid']) is int and type(row['mode']) is int
                     and row['uid'] == row['gid'] == 0 and row['mode'] == 0o644 for row in value.values()),
             'EXACT_ROOT_SOURCE_MODE_MAP_REQUIRED')

    def source_facts(self):
        value = self.a.decode(self.run(['docker', 'exec', 'synapse-content-1', 'node', '-e', SOURCE_FACTS_JS,
                                       json.dumps(sorted(self.source_records()), separators=(',', ':'))]))
        self.validate_source_modes(value)
        return value

    def source_backup_guard(self, state, directory):
        rows = state.get('sourceBackups'); targets = sorted(self.source_records())
        need(type(rows) is list and len(rows) == len(SOURCE_LAYOUT), 'EXACT_SOURCE2_BACKUP_REQUIRED')
        self.validate_source_modes(state.get('sourceModes'))
        for index, row in enumerate(rows):
            record = self.records[self.source_records()[targets[index]]]
            expected = {'target': targets[index], 'baseSha256': record['beforeSha256'], 'bytes': record['beforeBytes'],
                        'backup': str(self.paths()['backup'] / ('source-' + str(index))), 'mode': 0o600}
            need(row == expected, 'EXACT_SOURCE_BACKUP_ROW_REQUIRED')
            path = self.a.exact_path(Path(row['backup']))
            flags = os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_CLOEXEC', 0) | getattr(os, 'O_BINARY', 0)
            fd = os.open(path, flags)
            try:
                first = os.fstat(fd); raw_hash = hashlib.sha256(); total = 0
                need(stat.S_ISREG(first.st_mode) and first.st_uid == directory['uid']
                     and self.files.fd_mode(fd) == 0o600 and first.st_size == row['bytes'], 'PRIVATE_SOURCE_BACKUP_REQUIRED')
                while True:
                    raw = os.read(fd, 65536)
                    if not raw: break
                    total += len(raw); need(total <= row['bytes'], 'SOURCE_BACKUP_SIZE_CHANGED'); raw_hash.update(raw)
                last = os.fstat(fd); actual = self.a.exact_path(path).stat()
                identity = (first.st_dev, first.st_ino, first.st_uid)
                need(identity == (last.st_dev, last.st_ino, last.st_uid) == (actual.st_dev, actual.st_ino, actual.st_uid)
                     and stat.S_ISREG(actual.st_mode) and self.files.fd_mode(fd) == self.files.mode(path) == 0o600
                     and total == row['bytes'] and raw_hash.hexdigest() == row['baseSha256'], 'SOURCE_BACKUP_SHA_MODE_IDENTITY_CHANGED')
            finally: os.close(fd)
        self.backup_directory_guard(directory)

    def build_preflight(self, child, source_modes):
        self.validate_source_modes(source_modes)
        need(self.a.image(child) and child != CONTENT, 'EXACT_CHILD_PREFLIGHT_REQUIRED')
        output = self.run(['docker', 'run', '--rm', '--network=none', '--read-only', '--cap-drop=ALL',
                           '--security-opt=no-new-privileges', '--entrypoint=node', child, '-e', CHILD_CHECK_JS,
                           json.dumps(source_modes, sort_keys=True, separators=(',', ':'))])
        need(output == b'PRECHECK_OK', 'CHILD_SYNTAX_MODE_PREFLIGHT_REQUIRED')

    def apply(self, pin, apply=False):
        need(apply is True, 'EXPLICIT_ROOT_APPLY_REQUIRED')
        self.absent(); decision = self.decision(pin); before = self.baseline(); self.active_decision_pin = pin
        need(self.modes() == decision['staticModes'], 'APPROVED_MODES_CHANGED')
        self.users(); paths = self.paths(); alias = 'palitra-checkout-direct-chat-base:' + NAME; tag = 'palitra-checkout-direct-chat:' + NAME
        self.unused(alias); self.unused(tag)
        need(self.run(['docker', 'image', 'inspect', '--format', '{{.Id}}', CONTENT]).decode().strip() == CONTENT, 'EXACT_LOCAL_PARENT_REQUIRED')
        layers = self.a.decode(self.run(['docker', 'image', 'inspect', '--format', '{{json .RootFS.Layers}}', CONTENT]))
        need(type(layers) is list and layers, 'PARENT_LAYER_PROOF_REQUIRED')
        state = {'schema': 1, 'name': NAME, 'phase': 'CONTEXT_STARTED_UNKNOWN', 'inputs': self.binding(), 'decisionSha256': pin, 'before': before,
                 'static': [], 'workerRecreated': False, 'uploadsEnabled': True, 'directDbWrites': 0, 'queueEdits': 0, 'automaticRetry': False,
                 'automaticCodeRollback': False, 'oldJournalWrites': 0, 'sourceModes': decision['sourceModes'], 'sourceBackups': []}
        self.a.write_new(paths['journal'], state)
        for path, mode in ((paths['context'], 0o700), (paths['backup'], 0o700)):
            self.files.directory(self.a.exact_path(path, True), mode)
        for relative in sorted(self.context_directories(), key=lambda value: (value.count('/'), value)):
            self.files.directory(self.a.exact_path(paths['context'] / relative, True), 0o700 if relative == 'static' else 0o755)
        self.backup_directory = self.backup_directory_facts(); state['backupDirectory'] = copy.deepcopy(self.backup_directory)
        source_records = self.source_records()
        for index, (target, name) in enumerate(sorted(source_records.items())):
            record = self.records[name]
            raw = self.run(['docker', 'exec', 'synapse-content-1', 'node', '-e', self.current.source_script, target])
            need(len(raw) <= 3 * 1024 * 1024, 'BOUNDED_SOURCE_BYTES_REQUIRED')
            old = base64.b64decode(raw, validate=True); patched = self.patch(old, record)
            self.files.write(paths['context'] / 'app' / target, patched, decision['sourceModes'][target]['mode'])
            backup = paths['backup'] / ('source-' + str(index))
            self.files.write(backup, old, 0o600)
            state['sourceBackups'].append({'target': target, 'baseSha256': record['beforeSha256'], 'bytes': record['beforeBytes'],
                                           'backup': str(backup), 'mode': 0o600})
        for index, (name, target) in enumerate(self.static_targets()):
            old = self.a.read(target); patched = self.patch(old, self.records[name]); mode = decision['staticModes'][str(target)]
            prepared, backup = paths['context'] / 'static' / str(index), paths['backup'] / str(index)
            self.files.write(prepared, patched, 0o600); self.files.write(backup, old, 0o600)
            state['static'].append({'target': str(target), 'baseSha256': sha(old), 'sha256': sha(patched), 'mode': mode,
                                    'prepared': str(prepared), 'backup': str(backup), 'written': False})
        self.files.write(paths['context'] / 'Dockerfile', ('FROM ' + alias + '\nCOPY app/ /app/\n').encode(), 0o600)
        self.backup_guard(state)
        self.update(state, 'CONTEXT_READY_NOT_BUILT', contextSha256=self.context_proof(state))
        self.baseline(); self.decision(pin); self.lease(); self.unused(alias); self.unused(tag)
        self.run(['docker', 'image', 'tag', CONTENT, alias])
        need(self.run(['docker', 'image', 'inspect', '--format', '{{.Id}}', alias]).decode().strip() == CONTENT, 'NEW_PARENT_ALIAS_CHANGED')
        self.update(state, 'BUILD_STARTED_UNKNOWN'); self.decision(pin); self.lease()
        need(self.context_proof(state) == state['contextSha256']
             and self.run(['docker', 'image', 'inspect', '--format', '{{.Id}}', alias]).decode().strip() == CONTENT, 'LAST_BUILD_CONTEXT_OR_PARENT_CHANGED')
        self.run(['docker', 'build', '--network=none', '--pull=false', '--tag', tag, '--iidfile', str(paths['context'] / 'image.id'), str(paths['context'])])
        child = self.a.read(paths['context'] / 'image.id').decode().strip()
        need(self.a.image(child) and child != CONTENT and self.run(['docker', 'image', 'inspect', '--format', '{{.Id}}', tag]).decode().strip() == child, 'EXACT_NEW_CHILD_REQUIRED')
        child_layers = self.a.decode(self.run(['docker', 'image', 'inspect', '--format', '{{json .RootFS.Layers}}', child]))
        need(type(child_layers) is list and child_layers[:len(layers)] == layers and len(child_layers) == len(layers) + 1, 'ONE_EXACT_COPY_LAYER_REQUIRED')
        need(self.context_proof(state, True) == state['contextSha256'] and self.photo.hashes(self.final_source, child) == self.final_source, 'BUILT_FULL_SOURCE209_CHANGED')
        self.build_preflight(child, decision['sourceModes'])
        self.users(child); self.baseline(); self.decision(pin)
        self.backup_guard(state)
        self.update(state, 'STATIC_STARTED_UNKNOWN', childImage=child)
        for row in state['static']:
            self.decision(pin); self.lease(); self.publish(row); row['written'] = True; self.a.replace(paths['journal'], state)
        self.static_guard(True); self.stable(); self.decision(pin); self.users(child)
        self.a.write_new(paths['overlay'], {'services': {'content': {'image': child}}})
        overlay_pin = sha(self.a.read(paths['overlay'])); planned = self.b.plan(before, 'content', paths['overlay'])
        self.update(state, 'CONTENT_UP_STARTED_UNKNOWN', overlay=str(paths['overlay']), overlaySha256=overlay_pin, plannedConfigHash=planned)
        # Old source is still running while the already-published static inventory is new.
        need(self.snapshot(static_changed=True) == before, 'LAST_COMPLETE_RUNTIME27_STATIC28_CHANGED')
        self.decision(pin); self.lease(); self.stable(); self.users(child)
        need(self.context_proof(state, True) == state['contextSha256'] and self.b.plan(before, 'content', paths['overlay']) == planned, 'LAST_SEALED_PLAN_OR_CONTEXT_CHANGED')
        proof = {'childImage': child, 'overlaySha256': overlay_pin, 'plannedConfigHash': planned}
        self.expected_metadata('content', child, proof)
        self.backup_guard(state); self.revision_guard(); self.lease(); self.decision(pin)
        self.b.up(before, 'content', paths['overlay'])
        after = self.snapshot(child, True, proof)
        need(self.source_facts() == decision['sourceModes'], 'CHILD_RUNTIME_SOURCE_MODES_CHANGED')
        self.users(child)
        need(after['contentCid'] != before['contentCid'] and self.b.heartbeat(after['worker']['startedAt'], self.clock())['freshAfterWorkerStart']
             and self.snapshot(child, True, proof) == after, 'FRESH_STABLE_AFTER_REQUIRED')
        self.update(state, PHASE, after=after, finishedAtUtc=self.a.stamp(self.clock()))
        return {'status': PHASE, 'journalSha256': sha(self.a.read(paths['journal'])), 'contentImage': child, 'sourceFiles': 209, 'staticFiles': 27,
                'contentChainFiles': 28, 'sourceFilesChanged': len(SOURCE_LAYOUT), 'staticFilesChanged': len(STATIC_LAYOUT), 'builds': 1, 'contentUps': 1, 'workerRecreated': False, 'uploadsEnabled': True,
                'directDbWrites': 0, 'queueEdits': 0, 'oldJournalWrites': 0, 'automaticRetry': False}

    def inspect(self, pin):
        state = self.a.pinned(self.paths()['journal'], pin, True)
        need(state.get('schema') == 1 and state.get('name') == NAME and state.get('phase') == PHASE and state.get('inputs') == self.binding()
             and state.get('before') == self.base and state.get('workerRecreated') is False and state.get('uploadsEnabled') is True
             and state.get('directDbWrites') == state.get('queueEdits') == state.get('oldJournalWrites') == 0
             and state.get('automaticRetry') is False and state.get('automaticCodeRollback') is False
             and type(state.get('static')) is list and len(state['static']) == len(STATIC_LAYOUT) and all(x.get('written') is True for x in state['static']), 'OWN_COMPLETED_RECEIPT_REQUIRED')
        sealed = self.a.pinned(self.paths()['decision'], state.get('decisionSha256'), True)
        need(type(sealed) is dict and set(sealed) == {'schema', 'name', 'scope', 'rootApproved', 'observedAtUtc', 'inputs', 'before', 'staticModes', 'serviceUsers', 'sourceModes'}
             and sealed['schema'] == 1 and sealed['name'] == NAME and sealed['scope'] == SCOPE and sealed['rootApproved'] is True
             and sealed['inputs'] == self.binding() and sealed['before'] == self.base and sealed['sourceModes'] == state.get('sourceModes')
             and sealed['staticModes'] == {str(path): self.mode_map[path.name] for _, path in self.static_targets()}
             and sealed['serviceUsers'] == self.users(), 'OWN_SEALED_DECISION_CHANGED')
        self.backup_guard(state)
        proof = {key: state[key] for key in ('childImage', 'overlaySha256', 'plannedConfigHash')}
        need(state.get('overlay') == str(self.paths()['overlay']) and self.context_proof(state, True) == state['contextSha256'], 'COMPLETED_CONTEXT_OR_OVERLAY_CHANGED')
        for row in state['static']:
            need(self.files.mode(Path(row['target'])) == row['mode'], 'COMPLETED_TARGET_MODE_CHANGED')
        need(self.snapshot(state['childImage'], True, proof) == state['after']
             and self.source_facts() == state['sourceModes'], 'COMPLETED_RUNTIME_CHANGED')
        return {'status': 'COMPLETED29_READONLY_NOT_CUSTOMER_ACCEPTANCE', 'mutations': 0, 'heartbeat': self.b.heartbeat(self.base['worker']['startedAt'], self.clock())}



def load_current28(lease_pid):
    """Read immutable static28 proof above exact runtime27; no old actions or live old JS read.

    Static28's constructor requires its old live target bytes, so it cannot be used
    after a later legitimate replacement. This loader derives its binding from
    its pinned receipt, manifest and private before/after artifacts instead.
    """
    need(type(lease_pid) is int and lease_pid > 1, 'FRESH_ROOT_LEASE_REQUIRED')
    path = PRIOR_CODE / 'cart_total_copy.py'
    for item in [*reversed(path.parents), path]: need(not item.is_symlink(), 'HISTORICAL_CODE_SYMLINK_REFUSED')
    raw = path.read_bytes(); need(sha(raw) == PRIOR_HELPER_SHA, 'EXACT_STATIC28_HELPER_REQUIRED')
    prior = types.ModuleType('sealed_static28'); prior.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), prior.__dict__)
    current27 = prior.load_current27(lease_pid)
    a, b = current27.a, current27.b
    journal = ROOT / 'palitra-cart-total-copy-r3-journal.json'
    receipt = a.pinned(journal, PRIOR_RECEIPT_SHA, True)
    manifest_path = PRIOR_CODE / 'payload/MANIFEST.json'
    manifest_pin = 'e2e8f0364c9df75d580391e6aba79ac7b227c2eb81a2b194552576336ec6bf87'
    manifest = a.pinned(manifest_path, manifest_pin)
    need(type(manifest) is dict and set(manifest) == {'schema', 'scope', 'records'} and type(manifest['schema']) is int and manifest['schema'] == 1
         and manifest['scope'] == 'PALITRA_CART_TOTAL_COPY_ONLY' and type(manifest['records']) is list and len(manifest['records']) == 2,
         'EXACT_STATIC28_FROZEN_MANIFEST_REQUIRED')
    need(prior.NAME == 'palitra-cart-total-copy-r3' and prior.CONTENT == CONTENT and prior.MANIFEST_SHA == manifest_pin
         and prior.ROOT_MANIFEST_SHA == ROOT_MANIFEST_SHA, 'EXACT_STATIC28_CODE_BINDING_REQUIRED')
    frozen_path = a.exact_path(ROOT / 'bundle-root-final/manifest.json')
    need(sha(a.read(frozen_path)) == ROOT_MANIFEST_SHA, 'EXACT_SIGNED_CUSTOMER_ROOT_MANIFEST_REQUIRED')
    frozen = b.photo.ui.r.frozen()
    managed = a.exact_path(frozen['roots']['customer'])
    if ROOT == Path('/opt/synapse/releases/palitra-app-20261015'):
        need(re.fullmatch(r'/var/lib/docker/volumes/synapse_content_data/_data/projects/palitra-love/sites/site-44bbe13f1bad5e005b2a/versions/[0-9a-f]{64}', str(managed)) is not None,
             'EXACT_MANAGED_CURRENT_ROOT_REQUIRED')
    else: need(Path(managed).is_relative_to(ROOT), 'SYNTHETIC_ROOT_REQUIRED')
    need(type(receipt) is dict and set(receipt) == {'schema', 'name', 'phase', 'inputs', 'before', 'decisionSha256', 'static', 'written',
             'automaticRetry', 'automaticCodeRollback', 'workerRecreated', 'builds', 'contentUps', 'directDbWrites', 'oldJournalWrites', 'after', 'finishedAtUtc'}
         and receipt['schema'] == 1 and receipt['name'] == prior.NAME and receipt['phase'] == prior.PHASE
         and receipt['before'] == receipt['after'] == current27.base
         and receipt['automaticRetry'] is False and receipt['automaticCodeRollback'] is False and receipt['workerRecreated'] is False
         and all(type(receipt[key]) is int and receipt[key] == 0 for key in ('builds', 'contentUps', 'directDbWrites', 'oldJournalWrites'))
         and receipt['written'] == ['assets/order.js', 'assets/storefront.js'] and digest(receipt['decisionSha256']), 'EXACT_STATIC28_COMPLETED_RECEIPT_REQUIRED')
    inputs = receipt['inputs']
    need(type(inputs) is dict and set(inputs) == {'priorReceiptSha256', 'contentImage', 'manifestSha256', 'helperSha256', 'freshLeasePid',
                'managedRoot', 'parents', 'beforeStatic', 'afterStatic', 'beforeFacts'}
         and inputs['priorReceiptSha256'] == 'b8a16849f7d45229b75369389598d66f5ac9cb69443f07257cab590c8670029f'
         and inputs['contentImage'] == CONTENT and inputs['manifestSha256'] == manifest_pin and inputs['helperSha256'] == PRIOR_HELPER_SHA
         and type(inputs['freshLeasePid']) is int and inputs['freshLeasePid'] > 1 and inputs['managedRoot'] == str(managed)
         and inputs['beforeStatic'] == current27.static and len(current27.source) == 209 and len(current27.static) == 26,
         'EXACT_STATIC28_INPUT_LINEAGE_REQUIRED')
    expected_parents = {}
    for parent in (ROOT, managed, managed / 'assets'):
        info = a.exact_path(parent).stat()
        need(stat.S_ISDIR(info.st_mode), 'STATIC28_DIRECTORY_PARENT_REQUIRED')
        expected_parents[str(parent)] = [info.st_dev, info.st_ino, info.st_uid, info.st_gid, stat.S_IMODE(info.st_mode)]
    need(inputs['parents'] == expected_parents, 'STATIC28_PARENT_IDENTITY_CHANGED')
    pins = {str(path): PRIOR_HELPER_SHA, str(journal): PRIOR_RECEIPT_SHA, str(manifest_path): manifest_pin, str(frozen_path): ROOT_MANIFEST_SHA}
    before_facts, expected_rows, after_static = {}, [], dict(current27.static)
    expected_names = {'order.js', 'storefront.js'}
    expected_before = {'order.js': '230f1c13bf7a78bb4f0c6d19455d1dcad39384ad0d3b600c48ce43d2018b6553',
                       'storefront.js': '973ee07c0565a04501390c468dc7d2f68a4ee363b4ce78ac3d6e3a15d56bcd80'}
    expected_after = {'order.js': '468e43816e3ab1787dd9fff9861af1e08ca8c09060ed8a2141568e4edbd18223',
                      'storefront.js': '7e71b415d7592e2258a88f222ef57ec539a2c6ab8478c3dddb5b1f65aff7b87c'}
    need(type(inputs['beforeFacts']) is dict and set(inputs['beforeFacts']) == {'assets/order.js', 'assets/storefront.js'}, 'EXACT_STATIC28_BEFORE_FACTS_REQUIRED')
    for kind in ('backup', 'prepared'):
        directory = a.exact_path(ROOT / (prior.NAME + '-' + kind)); info = directory.stat()
        need(stat.S_ISDIR(info.st_mode) and info.st_uid == info.st_gid == 0 and stat.S_IMODE(info.st_mode) == 0o700
             and {p.name for p in directory.iterdir()} == {'0', '1'}, 'EXACT_STATIC28_PRIVATE_ARTIFACTS_REQUIRED')
    seen = set()
    for index, row in enumerate(sorted(manifest['records'], key=lambda value: value.get('name', ''))):
        need(type(row) is dict and set(row) == {'name', 'beforeSha256', 'beforeBytes', 'sha256', 'bytes', 'hunks'}
             and row['name'] in expected_names and row['name'] not in seen
             and row['beforeSha256'] == expected_before[row['name']] and row['sha256'] == expected_after[row['name']]
             and all(type(row[key]) is int and 0 < row[key] <= 2 * 1024 * 1024 for key in ('beforeBytes', 'bytes'))
             and type(row['hunks']) is list and 1 <= len(row['hunks']) <= 8, 'EXACT_STATIC28_TWO_RECORDS_REQUIRED')
        name = row['name']; seen.add(name); target = managed / 'assets' / name
        payload_path = PRIOR_CODE / 'payload/product' / name; value = a.read(payload_path)
        need(len(value) == row['bytes'] and sha(value) == row['sha256'], 'STATIC28_SEALED_PAYLOAD_CHANGED')
        old = value
        for hunk in reversed(row['hunks']):
            need(type(hunk) is dict and set(hunk) == {'before', 'after'} and all(type(hunk[key]) is str and 0 < len(hunk[key]) <= 65536 for key in hunk),
                 'STATIC28_BOUNDED_HUNKS_REQUIRED')
            before, after = hunk['before'].encode(), hunk['after'].encode()
            need(before != after and old.count(after) == 1, 'STATIC28_REVERSE_UNIQUE_HUNK_REQUIRED'); old = old.replace(after, before, 1)
        need(len(old) == row['beforeBytes'] and sha(old) == row['beforeSha256'], 'STATIC28_RECONSTRUCTED_BEFORE_CHANGED')
        patched = old
        for hunk in row['hunks']:
            before, after = hunk['before'].encode(), hunk['after'].encode()
            need(patched.count(before) == 1, 'STATIC28_FORWARD_UNIQUE_HUNK_REQUIRED'); patched = patched.replace(before, after, 1)
        need(patched == value, 'STATIC28_EXACT_HUNK_ROUNDTRIP_REQUIRED')
        before_facts['assets/' + name] = {'sha256': row['beforeSha256'], 'bytes': row['beforeBytes'], 'mode': 0o600, 'uid': 0, 'gid': 0}
        expected_rows.append({'target': str(target), 'path': 'assets/' + name, 'backup': str(ROOT / (prior.NAME + '-backup') / str(index)),
                              'prepared': str(ROOT / (prior.NAME + '-prepared') / str(index)), 'beforeSha256': row['beforeSha256'], 'sha256': row['sha256']})
        pins[str(payload_path)] = row['sha256']
        for kind, wanted in (('backup', old), ('prepared', value)):
            artifact = a.exact_path(ROOT / (prior.NAME + '-' + kind) / str(index)); info = artifact.stat()
            need(stat.S_ISREG(info.st_mode) and info.st_uid == info.st_gid == 0 and stat.S_IMODE(info.st_mode) == 0o600
                 and a.read(artifact) == wanted, 'STATIC28_PRIVATE_ARTIFACT_SHA_MODE_CHANGED')
            pins[str(artifact)] = sha(wanted)
        if name == 'storefront.js': need(current27.static.get(str(target)) == row['beforeSha256'], 'STATIC28_STOREFRONT_BASE_CHANGED')
        else: need(str(target) not in current27.static, 'STATIC28_ORDER_MUST_BE_PRIOR_EXTENSION')
        after_static[str(target)] = row['sha256']
    need(seen == expected_names and receipt['static'] == expected_rows and inputs['beforeFacts'] == before_facts
         and inputs['afterStatic'] == after_static and len(after_static) == 27, 'EXACT_STATIC28_FULL_MAP_REQUIRED')
    decision_path = ROOT / (prior.NAME + '-decision.json'); decision = a.pinned(decision_path, receipt['decisionSha256'], True)
    need(type(decision) is dict and set(decision) == {'schema', 'name', 'scope', 'rootApproved', 'observedAtUtc', 'inputs', 'before'}
         and decision['schema'] == 1 and decision['name'] == prior.NAME and decision['scope'] == 'EXACT27_TO_STATIC28_CUSTOMER_JS2'
         and decision['rootApproved'] is True and decision['inputs'] == inputs and decision['before'] == current27.base, 'EXACT_STATIC28_SEALED_DECISION_REQUIRED')
    pins[str(decision_path)] = receipt['decisionSha256']

    def stable():
        current27.stable()
        for name, pin in pins.items(): need(sha(a.read(Path(name))) == pin, 'STATIC28_IMMUTABLE_INPUT_CHANGED')
        for name, facts in expected_parents.items():
            info = a.exact_path(name).stat()
            need(stat.S_ISDIR(info.st_mode) and [info.st_dev, info.st_ino, info.st_uid, info.st_gid, stat.S_IMODE(info.st_mode)] == facts,
                 'STATIC28_PARENT_IDENTITY_CHANGED')
        for kind in ('backup', 'prepared'):
            directory = a.exact_path(ROOT / (prior.NAME + '-' + kind)); info = directory.stat()
            need(stat.S_ISDIR(info.st_mode) and info.st_uid == info.st_gid == 0 and stat.S_IMODE(info.st_mode) == 0o700
                 and {p.name for p in directory.iterdir()} == {'0', '1'}, 'STATIC28_PRIVATE_DIRECTORY_CHANGED')
        for artifact_row in expected_rows:
            for kind in ('backup', 'prepared'):
                info = a.exact_path(artifact_row[kind]).stat()
                need(stat.S_ISREG(info.st_mode) and info.st_uid == info.st_gid == 0 and stat.S_IMODE(info.st_mode) == 0o600,
                     'STATIC28_PRIVATE_ARTIFACT_MODE_CHANGED')

    def guide_guard():
        current27.guide_guard()
        for leaf in expected_names:
            info = a.exact_path(managed / 'assets' / leaf).stat()
            need(stat.S_ISREG(info.st_mode) and info.st_uid == info.st_gid == 0 and stat.S_IMODE(info.st_mode) == 0o600,
                 'STATIC28_CUSTOMER_MODE_CHANGED')

    stable()
    current = types.SimpleNamespace(base=copy.deepcopy(current27.base), source=dict(current27.source), static=after_static,
                                    managed=managed, stable=stable, guide_guard=guide_guard,
                                    source_script=current27.accepted.current.source_script)
    return a, b, current


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=('inspect-current', 'approve-current', 'apply', 'inspect'))
    parser.add_argument('--lease-pid', required=True, type=int)
    parser.add_argument('--decision-sha'); parser.add_argument('--receipt-sha'); parser.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    try:
        need(MANIFEST_SHA != UNFROZEN, 'DRAFT_NOT_FROZEN_NO_NATIVE_ACTION')
        need(os.name == 'posix' and os.geteuid() == 0 and Path(__file__).resolve().parent == ROOT / CODE_NAME, 'EXACT_ROOT_NEW_NAMESPACE_REQUIRED')
        a, b, current = load_current28(args.lease_pid)
        release = CheckoutDirectChatRelease(a, b, current, ROOT / CODE_NAME / 'payload', MANIFEST_SHA, args.lease_pid)
        if args.operation == 'inspect-current': result = release.inspect_current()
        elif args.operation == 'approve-current': result = release.approve(args.apply)
        elif args.operation == 'apply':
            need(digest(args.decision_sha), 'EXPLICIT_NEW_DECISION_SHA_REQUIRED'); result = release.apply(args.decision_sha, args.apply)
        else:
            need(digest(args.receipt_sha), 'EXPLICIT_OWN_RECEIPT_SHA_REQUIRED'); result = release.inspect(args.receipt_sha)
        print(json.dumps(result, separators=(',', ':'))); return 0
    except Exception as error:
        code = str(error) if type(error) is ValueError and re.fullmatch('[A-Z][A-Z0-9_]{0,100}', str(error)) else 'CHECKOUT_RELEASE_ACTION_REFUSED'
        print(json.dumps({'status': 'REFUSED_OR_UNKNOWN_NO_AUTOMATIC_RETRY', 'code': code, 'messageSha256': sha(str(error).encode()),
                          'automaticRetry': False, 'automaticCodeRollback': False, 'workerRecreated': False, 'oldJournalWrites': 0})); return 2


if __name__ == '__main__': sys.exit(main())
