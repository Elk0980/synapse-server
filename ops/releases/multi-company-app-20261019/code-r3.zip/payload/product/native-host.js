/* Palitra Love Заказы — хост рабочего подключения к существующему Synapse.

   Открывается только на разрешённых адресах: кабинет https://synapse.synapsebusiness.ru (whoami cookie + CSRF)
   и магазин https://palitra-love.ru (сессия аккаунта /api/draft-account/session, portal через штатный crm-session.js,
   чат сайта /api/customer-chat/*). Новой авторизации нет: только существующие относительные маршруты моста.

   Сеть, CRM и чат включены после проверки Root. Изменение флагов требует отдельного проверенного выпуска
   (свободное окно общего сервера, origin/CSP, PALITRA_APP_ORIGIN). Адрес, роль, localStorage и данные макета флаги
   не меняют. Проверки разрешённого адреса, сессии и CSRF выполняются перед каждым запросом.
   CSRF/токены живут только в замыкании этого файла и в штатном crm-session.js; в state оболочки, URL и манифест не идут. */
'use strict';
(() => {
  const B = window.SynapseBridge;
  const FLAGS = Object.freeze({ network: true, crm: true, e1Native: true });
  const CABINET = B.ORIGINS.synapse, SHOP = B.ORIGINS.shop;
  const origin = window.location.origin;
  /* Точка входа задаётся страницей: shop.html (data-entry="shop", data-auth="site", штатный crm-session.js до этого файла)
     или cabinet.html (data-entry="cabinet", без инициализации магазина). Страница работает только на «своём» адресе. */
  const root = document.documentElement;
  const entry = root.dataset.entry === 'shop' || root.dataset.entry === 'cabinet' ? root.dataset.entry : '';
  const allowed = (entry === 'cabinet' && origin === CABINET) || (entry === 'shop' && origin === SHOP && root.dataset.auth === 'site');
  let cabinetCsrf = '', accountCsrf = '', chatCsrf = '';
  const listeners = [];
  let activeCompany = 'palitra-love';
  // Push HTTP возвращает {ok:false,code}; не переносим произвольный ответ/секреты в интерфейс.
  const PUSH_ERRORS = Object.freeze({
    PUSH_ORIGIN: 'Сервер не подтвердил адрес приложения. Подписка не подтверждена.',
    PUSH_JSON_REQUIRED: 'Сервер не принял формат запроса подписки.',
    PUSH_BODY_LIMIT: 'Сервер не принял размер запроса подписки.',
    PUSH_JSON: 'Сервер не смог прочитать данные подписки.',
    PUSH_FIELDS: 'Сервер не принял поля подписки этого браузера.',
    PUSH_SUBSCRIPTION: 'Сервер не принял данные подписки этого браузера.',
    PUSH_ENDPOINT: 'Сервер не принял адрес службы уведомлений этого браузера.',
    PUSH_PROVIDER: 'Служба уведомлений этого браузера пока не поддерживается.',
    PUSH_KEY: 'Сервер не принял ключи подписки этого браузера.',
    PUSH_EXPIRATION: 'Срок подписки истёк или не распознан сервером.',
    PUSH_ACTOR: 'Сервер не подтвердил текущую учётную запись.',
    PUSH_ACTOR_CHANGED: 'Учётная запись изменилась. Откройте приложение заново.',
    PUSH_ACTOR_REVOKED: 'Доступ учётной записи изменился. Войдите в приложение заново.',
    PUSH_FORBIDDEN: 'Для этой учётной записи нет доступа к уведомлениям.',
    PUSH_ENDPOINT_OTHER_ACTOR: 'Эта подписка связана с другой учётной записью.',
    PUSH_DEVICE_LIMIT: 'Достигнут лимит подключённых устройств для этой учётной записи.',
    PUSH_SUBSCRIPTION_NOT_FOUND: 'Подписка этой учётной записи не найдена на сервере.',
    PUSH_NOT_READY: 'Служба уведомлений ещё не готова. Попробуйте позже.',
    PUSH_NOT_CONFIGURED: 'Уведомления пока не настроены на сервере.',
    PUSH_KEYS_UNAVAILABLE: 'Служба уведомлений временно недоступна на сервере.',
    PUSH_STORE: 'Сервер не смог прочитать сохранённую подписку.',
    PUSH_STORE_LIMIT: 'Сервер не смог обработать список подписок.',
    PUSH_UNAVAILABLE: 'Служба уведомлений временно недоступна.',
    PUSH_BAD_RESPONSE: 'Сервер вернул нераспознанный ответ. Подключение не подтверждено.',
    METHOD: 'Сервер не поддерживает это действие с подпиской.',
    NOT_FOUND: 'Сервис подписки не найден на сервере.',
  });
  function pushHttpError(operation, method, status, data) {
    const safeOperation = ['capability', 'subscription', 'subscription/status'].includes(operation) ? operation : 'unknown';
    const code = data && typeof data.code === 'string' && Object.prototype.hasOwnProperty.call(PUSH_ERRORS, data.code) ? data.code : 'PUSH_REQUEST_FAILED';
    const safeStatus = Number.isInteger(status) && status >= 100 && status < 600 ? status : 0;
    const action = safeOperation === 'capability' ? 'Проверка готовности уведомлений' : safeOperation === 'subscription/status' || method === 'GET' ? 'Проверка подписки' : method === 'DELETE' ? 'Отключение уведомлений' : 'Сохранение подписки';
    const fallback = safeStatus === 401 ? 'Сессия завершилась. Войдите в приложение заново.'
      : safeStatus === 403 ? 'Сервер не подтвердил доступ к уведомлениям для текущего входа.'
        : safeStatus === 409 ? 'Состояние подписки изменилось. Подключение не подтверждено.' : 'Не удалось подтвердить подписку на сервере. Можно продолжить без уведомлений.';
    const message = safeStatus === 401 ? fallback : code === 'PUSH_UNAVAILABLE' && safeStatus === 403 ? fallback : PUSH_ERRORS[code] || fallback;
    return Object.assign(new Error(`${action}: ${message}`), { name: 'PalitraPushError', code, status: safeStatus, operation: safeOperation });
  }
  let host;
  if (!allowed) {
    // Чужой адрес (в том числе localhost/127.0.0.1) или страница другого входа: транспорта нет — «Подключение не настроено».
    host = { mode: 'blocked', reason: entry ? 'origin' : 'entry' };
  } else {
    // Штатный crm-session.js — только на входе магазина и только в режиме сайта (cookie аккаунта + CSRF, не Telegram).
    const session = entry === 'shop' && window.PalitraSession && window.PalitraSession.auth === 'site' && typeof window.PalitraSession.request === 'function' ? window.PalitraSession : null;
    const transport = B.createNativeTransport({
      // fetch внедряется только здесь, на разрешённом адресе; мост сам глобальный fetch не трогает.
      fetch: (url, init) => window.fetch(url, init),
      host: {
        origin, portalOrigin: SHOP, allowNetwork: FLAGS.network, e1Native: FLAGS.e1Native,
        cabinet: { get csrfToken() { return cabinetCsrf; } },
        account: { get csrf() { return accountCsrf; } },
        chat: { get csrf() { return chatCsrf; } },
        portal: FLAGS.crm && session ? { request: (path, options) => session.request(path, options) } : null,
      },
    });
    host = {
      mode: 'native', verified: true, origin, transport, e1Native: FLAGS.e1Native,
      selectCompany: (code) => {
        if (entry !== 'cabinet' || !window.SynapseCompanies?.profile(code)) throw new Error('Компания недоступна для этого входа');
        activeCompany = code;
        return B.forCompany(code).createNativeTransport({ fetch: (url, init) => window.fetch(url, init),
          host: { origin, portalOrigin: SHOP, allowNetwork: FLAGS.network, e1Native: code === 'palitra-love' && FLAGS.e1Native,
            cabinet: { get csrfToken() { return cabinetCsrf; } } } });
      },
      // Автоперечитывание открытого чата (5 с) — только при включённых сети и чате сайта E/R1.
      chatAutoRefresh: FLAGS.network === true && FLAGS.e1Native === true,
      // Файлы используют только разрешённую entry/origin и актуальный CSRF замыкания; server uploads.enabled проверяется UI и backend.
      attachments: B.createAttachmentTransport({ fetch: (url, init) => window.fetch(url, init),
        host: { origin, entry, allowNetwork: FLAGS.network, e1Native: FLAGS.e1Native,
          getCsrf: () => entry === 'cabinet' ? cabinetCsrf : chatCsrf } }),
      // Только наличие сессий своего адреса; роли и identity оболочка берёт из ответов whoami/bootstrap.
      getAuthContext: () => (entry === 'cabinet' ? { cabinetSession: true } : { shopSession: true, guest: true, portalAvailable: FLAGS.crm && Boolean(session) }),
      acceptCabinetCsrf: (value) => { cabinetCsrf = typeof value === 'string' ? value : ''; window.dispatchEvent(new Event('palitra:push-auth-ready')); },
      acceptAccountCsrf: (value) => { accountCsrf = typeof value === 'string' ? value : ''; },
      acceptChatSession: (value) => { chatCsrf = typeof value === 'string' ? value : ''; window.dispatchEvent(new Event('palitra:push-auth-ready')); },
      // Только кабинет, разрешённый origin, network flag и CSRF текущего whoami. Роли проверяет backend.
      customerReports: Object.freeze({ request: async (query = {}, options = {}) => {
        if (entry !== 'cabinet' || origin !== CABINET || FLAGS.network !== true || !['alvi', 'avokado'].includes(activeCompany)) throw Object.assign(new Error('Отчёты этой компании ещё не подключены.'), { status: 403 });
        for (const key of Object.keys(query)) if (!['mode', 'month', 'day', 'basis'].includes(key) || typeof query[key] !== 'string') throw new TypeError('Неизвестный фильтр отчёта');
        const path = `/content/${window.SynapseCompanies.profile(activeCompany).site}/customer-reports?${new URLSearchParams(query)}`;
        const response = await window.fetch(path, { method: 'GET', credentials: 'same-origin', cache: 'no-store', redirect: 'error', signal: options.signal, headers: { Accept: 'application/json' } });
        if (!response.ok) throw Object.assign(new Error(response.status === 403 ? 'Нет доступа к отчётам этой компании.' : response.status === 401 ? 'Войдите в приложение заново.' : 'Не удалось получить отчёт.'), { status: response.status });
        return response.json();
      } }),
      workflow: Object.freeze({ request: async (path, options = {}) => {
        const method = options.method || 'GET';
        const base = path === '/content/palitra/workflow' || path === '/content/palitra/workflow/widget-settings';
        const order = /^\/content\/palitra\/workflow\/orders\/[1-9]\d*(?:\/(confirm|advance))?$/.exec(path);
        const allowedMethod = base ? ['GET', 'PUT'].includes(method) : order ? (order[1] ? method === 'POST' : method === 'GET') : false;
        if (activeCompany !== 'palitra-love' || entry !== 'cabinet' || origin !== CABINET || FLAGS.network !== true || !cabinetCsrf || !allowedMethod) throw Object.assign(new Error('Этапы заказа не подключены для этого входа.'), { status: 403 });
        const response = await window.fetch(path, { method, credentials: 'same-origin', cache: 'no-store', redirect: 'error',
          headers: { Accept: 'application/json', ...(method !== 'GET' ? { 'Content-Type': 'application/json', 'X-CSRF-Token': cabinetCsrf } : {}) },
          ...(method !== 'GET' ? { body: JSON.stringify(options.body) } : {}) });
        const data = await response.json();
        if (!response.ok) throw Object.assign(new Error(data && data.error && typeof data.error === 'string' ? data.error : 'Не удалось выполнить действие с заказом.'), { status: response.status });
        return data;
      } }),
      push: Object.freeze({ request: async (operation, options = {}) => {
        const method = options.method || 'GET';
        const permitted = operation === 'capability' ? method === 'GET' : operation === 'subscription' ? ['GET', 'POST', 'DELETE'].includes(method) : operation === 'subscription/status' && method === 'POST';
        const csrf = entry === 'cabinet' ? cabinetCsrf : chatCsrf;
        if ((entry === 'cabinet' && activeCompany !== 'palitra-love') || !permitted || !FLAGS.network || !csrf || (entry === 'shop' && !FLAGS.e1Native)) throw Object.assign(new Error('Уведомления пока не подключены для этого входа.'), { status: 403 });
        const path = (entry === 'cabinet' ? '/content/palitra/push/' : '/api/customer-chat/push/') + operation;
        const response = await window.fetch(path, { method, credentials: 'same-origin', cache: 'no-store', redirect: 'error',
          headers: { Accept: 'application/json', [entry === 'cabinet' ? 'X-CSRF-Token' : 'X-Palitra-Chat-CSRF']: csrf, ...(method !== 'GET' ? { 'Content-Type': 'application/json' } : {}) },
          ...(method !== 'GET' ? { body: JSON.stringify(options.body) } : {}) });
        let data;
        try { data = await response.json(); }
        catch (_) { throw pushHttpError(operation, method, response.status, { code: 'PUSH_BAD_RESPONSE' }); }
        if (!response.ok) throw pushHttpError(operation, method, response.status, data);
        return data;
      } }),
      onAuthChange: (fn) => { if (typeof fn === 'function') listeners.push(fn); },
    };
    // Штатное событие завершения portal-сессии (crm-session.js) — смена identity: прежние данные и CSRF очищаются.
    window.addEventListener('palitra:session-ended', () => { cabinetCsrf = ''; accountCsrf = ''; chatCsrf = ''; for (const fn of listeners) fn(); });
  }
  Object.defineProperty(window, 'PalitraShellHost', { value: Object.freeze(host), writable: false, configurable: false });
})();
