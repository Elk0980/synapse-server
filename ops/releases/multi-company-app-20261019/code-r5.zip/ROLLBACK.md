# Ручной откат R5 к действующей R3

Это конкретная процедура для `multi-company-app-20261019-r5`, под отдельным решением Root и свежей собственной lease. Автоматического отката/повтора нет. Пакет не разрешает native-действия. Состояние UNKNOWN сначала исследуется чтением, не повторяется.

Основа R3: image `sha256:10257c64ae44718cab6f8eff7410f05fee62b4aefb89b7e10ef59aab0413045b`, receipt `1e35fab2235f9acbdda2f114da61338b9bc13deaec109a12fd7798c242222b7b`, decision `75fd71383b6a4c239ab9d5a47d07af40d917d063a9eb5c4a1efba8132bd29b0b`. После успешного R5 ожидаются227source/33static/37chain; откат на R3 с новым отдельным overlay даёт227/33/38. Старые compose-файлы не удалять и не заменять. Старые helper/journal/decision неизменны.

## Проверяемая основа

1. Получить новое отдельное решение Root на откат, зафиксировать SHA завершённого R5 journal и его decision/acceptance, свежую lease. Использовать `inspect --receipt-sha <exactR5Receipt> --lease-pid <ownFreshPid>` нового R5 helper только после допуска. Проверить текущие image/CID, полные227 source/33static/37chain, worker/auth/flags/selected и отсутствие неизвестной команды. Зафиксировать исходный R3 image через `docker image inspect` и полный source-map из R5 `inputs.beforeSource`. Нельзя восстанавливать старый host checkout.
2. Проверить приватный R5 backup каталог0700 по его journal identity: четыре `source-*` и четыре `static-*`, каждый0600 и exact before SHA; `reports.sqlite` — SQLite consistent snapshot, SHA/quick_check/логические seals. Сверить `contextSha256`, manifest, helper, DB guard и `PRODUCT_REVIEW.json`. Не менять эти файлы.

## Сохранение всех текущих данных

3. Создать **новый** приватный rollback-каталог0700 с новым именем `multi-company-app-20261019-r5-rollback-<approvedId>`; не использовать каталог старой попытки. До переключения кода выполнить тем же проверенным `ReportDatabase.backup` новый SQLite snapshot **текущего** `/var/lib/docker/volumes/synapse_content_data/_data/salon-reports.sqlite` в `reports-current.sqlite`0600. Проверить mount `/data`→`synapse_content_data`, regular/single-link/root0600 db/WAL/SHM, inode БД до/после, quick_check и hashes всех history/import строк. Не копировать живые db/WAL/SHM как независимые файлы. WAL входит в SQLite backup; SHM — индекс, а не отдельные данные.
4. Существующую live DB и её WAL/SHM **не удалять, не переименовывать, не заменять backup и не checkpoint-ить вручную**. R3 поддерживает ту же схему. Проверить минимум source revision2 обеих студий и отсутствие потери всех строк snapshot. Разрешены новые revision и новые строки; они сохраняются на месте. `content.sqlite`, чаты/вложения/черновики/согласия, очереди и подписки не трогать. Нормальная остановка SQLite может завершить checkpoint; проверять логические данные, а не требовать неизменного WAL SHA.

## Четыре статических CAS и один content restart

5. Для каждого target в cabinet-каталоге из `inputs.beforeStatic` использовать только четыре записи ниже. Свежие lease, текущий candidate SHA и исходный mode обязательны непосредственно перед pending→atomic replace. Подготовить приватные pending из соответствующего `static-*` backup0600, SHA readback и права target как в R5 decision. Публиковать `cabinet.html` последним. Любой иной текущий SHA или новая запись вне принятого partial-набора — остановка без затирания. Частичный исход сверять по отдельному rollback journal, не повторять вслепую.

| target относительно cabinet | R5 CAS SHA | восстановить R3 SHA |
|---|---|---|
|company-context.js|ce507fba3dbe665f0f82de42d47c81b9d97fda29bfc290b36d7fc7b60f3477a5|ee8d9c0ab1e72febd3df1a34ed559505056c56f526984a6ab6f1e1f4fb95df45|
|shell.js|dfb1e7e0b89fc0c25ff4366c074e808556fc06acf41daef35879d587403f39fc|ddf516a035144301a93d3d93d30768c2ef169e66a1d0f62b740714ceb8590faa|
|cabinet.html|d15189623930442674245d12418c232feed90b7dfc7c259084300d24868ebdd3|a63d26a5ffaff8eb3a4e0485dd20fe045dbca2f9c1d1237e21e2739c39aa3b63|
|workflow-ui.js|972bb6e141f8bf5dbf30a5b68b3e3d58fd19519cb9caeaf0a725b7628d5585b8|d4457efe148d0a301dcc80fae20a4e49e2d2492fc1d247703582c8439bf3765f|

6. Сформировать **новый** rollback overlay ровно `{"services":{"content":{"image":"sha256:10257c64ae44718cab6f8eff7410f05fee62b4aefb89b7e10ef59aab0413045b"}}}`. Взять project/workingDir/configFiles из проверенного актуального R5 snapshot, добавить один новый overlay; план существующим принятым compose adapter `plan(currentSnapshot,'content',newOverlay)` и exact config hash записать в новый rollback journal. Повторно проверить full source/static/chain/lease, latest DB snapshot/identity/историю и plan. Один `up(currentSnapshot,'content',newOverlay)`, только content. Не вызывать R3 apply/approve; не пересоздавать chat worker. При неизвестном результате не повторять.
7. После переключения: content image exact R3, новый CID, полный source227 из `inputs.beforeSource`, static33 из `inputs.beforeStatic`, chain38 как прежние37 плюс новый pinned overlay, неизменные worker/selected/auth/flags. Приватный live report DB inode и все логические строки snapshot сохранены; обе revision не ниже последних. Public current/old-query ресурсы, старые/новые/открытые сеансы, черновики/файл, composer-last проверить отдельно. Возврат R3 также возвращает прежние ограничения R3; это не успешная business/mobile/daily приёмка.

Если runtime не отвечает, безопасное чтение `docker inspect` и isolated image source hash без сети и томов определяют image/CID/chain. Не ослаблять healthy guard обычного installer; Root должен принять отдельный конкретный rollback plan по этим фактам и сохранённым backup.
