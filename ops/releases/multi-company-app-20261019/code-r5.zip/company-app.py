import hashlib,json,os,sys,types
from pathlib import Path
CODE=Path('/opt/synapse/releases/palitra-app-20261015/multi-company-app-20261019-r5-code')
HELPER_SHA='b9108632e8f1d1cba15a6f0749c7b31642b1e12d4dd41b8b9aa9eb830b2848bd'
def main():
 try:
  if os.name!='posix' or os.geteuid()!=0 or Path(__file__).resolve().parent!=CODE:raise ValueError('EXACT_ROOT_NEW_NAMESPACE_REQUIRED')
  p=CODE/'release-native.py'
  if any(x.is_symlink() for x in [*p.parents,p]):raise ValueError('CODE_SYMLINK_REFUSED')
  raw=p.read_bytes()
  if hashlib.sha256(raw).hexdigest()!=HELPER_SHA:raise ValueError('FROZEN_HELPER_CHANGED')
  m=types.ModuleType('frozen_company_release');m.__file__=str(p);exec(compile(raw,str(p),'exec'),m.__dict__);return m.main()
 except Exception as e:
  print(json.dumps({'status':'ENTRY_REFUSED_NO_RETRY','messageSha256':hashlib.sha256(str(e).encode()).hexdigest()}));return 2
if __name__=='__main__':sys.exit(main())
