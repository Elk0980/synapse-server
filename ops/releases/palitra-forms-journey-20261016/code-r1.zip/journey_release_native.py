"""UNFROZEN Root-only successor: exact current22 -> own sealed23.

Three existing product sources, five existing public static targets. No backend,
worker, flags, authentication, database, queues, timers or old journal writes.
"""
import argparse
import base64
import copy
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys
import time
import types

ROOT = Path('/opt/synapse/releases/palitra-app-20261015')
NAME = 'palitra-forms-consistency-r1'
CODE_NAME = 'palitra-forms-consistency-code-r1'
PHASE = 'FORMS_CONSISTENCY_APPLIED_NOT_CUSTOMER_OR_DEVICE_ACCEPTANCE'
SCOPE = 'EXACT_PRODUCT3_EDITOR2_SOURCE209_STATIC26_CHAIN22_TO_23'
UNFROZEN = '0' * 64
MANIFEST_SHA = '3c69588b06a9f9fc686d34bf383792ec8a53f576bca801d13cde266f044657b0'
PRIOR_CODE = ROOT / 'palitra-editor-chat-guide-forward-code-r1'
PRIOR_HELPER_SHA = 'fdfec3945b8317d14e2e0f004f6152d03a1121dfaf9fe9712cc940de38c6152e'
PRIOR_WRAPPER_SHA = '69595d3038cdec9eb79599834b09d55dc04d3b7b0f45776322259e13fe46be7e'
PRIOR_RECEIPT_SHA = 'f286824179a43b05ab694364f7a43bc8594785e16a28f9bfb6621aa5cbb7e103'
CONTENT = 'sha256:3348b3a24166772ac0a9802a8afe9e2d1662e9212a8ad6d8a556e199fb65b2cd'
WORKER = 'sha256:d4d4d453ce2e3dc47d5e0962d62b95938f42c56ec73789fe76a324e0d2ff0508'
LOCK = '/opt/synapse/.palitra-app-release.lock'
PRODUCT = {'shell.js', 'shell.css', 'synapse-bridge.js'}
EDITOR = {'app.js', 'style.css'}
NAMES = {'product/' + x for x in PRODUCT} | {'editor/' + x for x in EDITOR}
USER_FORMAT = '{{json (or (index .Config "User") "")}}'
ROOT_USERS = {'', 'root', '0', '0:0', 'root:root'}
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def need(value, code):
    if not value:
        raise ValueError(code)


def digest(value):
    return type(value) is str and re.fullmatch('[0-9a-f]{64}', value) is not None


class FileOps:
    """Every new descriptor receives its exact mode despite umask077."""
    def write(self, path, raw, mode):
        flags = os.O_RDWR | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_CLOEXEC', 0) | getattr(os, 'O_BINARY', 0)
        fd = os.open(path, flags, 0o600)
        try:
            first = os.fstat(fd)
            need(stat.S_ISREG(first.st_mode), 'REGULAR_CREATED_FD_REQUIRED')
            view = memoryview(raw)
            while view:
                count = os.write(fd, view)
                need(count > 0, 'WRITE_INCOMPLETE')
                view = view[count:]
            self.set_mode(fd, mode)
            os.fsync(fd)
            last = os.fstat(fd)
            need((first.st_dev, first.st_ino, first.st_uid) == (last.st_dev, last.st_ino, last.st_uid)
                 and self.fd_mode(fd) == mode, 'CREATED_FD_MODE_READBACK_FAILED')
            return (last.st_dev, last.st_ino, last.st_uid)
        finally:
            os.close(fd)

    def set_mode(self, fd, mode):
        need(os.name == 'posix' and hasattr(os, 'fchmod'), 'POSIX_FCHMOD_REQUIRED')
        os.fchmod(fd, mode)

    def fd_mode(self, fd):
        return stat.S_IMODE(os.fstat(fd).st_mode)

    def mode(self, path):
        return stat.S_IMODE(path.stat().st_mode)

    def directory(self, path, mode):
        path.mkdir(mode=0o700)
        need(os.name == 'posix', 'POSIX_DIRECTORY_FD_REQUIRED')
        fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | getattr(os, 'O_CLOEXEC', 0))
        try:
            row = os.fstat(fd)
            need(stat.S_ISDIR(row.st_mode) and not os.listdir(fd), 'NEW_EMPTY_DIRECTORY_FD_REQUIRED')
            os.fchmod(fd, mode)
            os.fsync(fd)
            last = os.fstat(fd)
            need((last.st_dev, last.st_ino, last.st_uid) == (row.st_dev, row.st_ino, row.st_uid)
                 and stat.S_IMODE(last.st_mode) == mode, 'NEW_DIRECTORY_MODE_READBACK_FAILED')
        finally:
            os.close(fd)


class JourneyRelease:
    def __init__(self, a, b, current, payload, manifest_pin, lease_pid, clock=time.time, file_ops=None):
        self.a, self.b, self.current, self.photo = a, b, current, b.photo
        self.root, self.run, self.clock, self.lease_pid = b.root, b.run, clock, lease_pid
        need(type(lease_pid) is int and lease_pid > 1, 'FRESH_ROOT_LEASE_REQUIRED')
        need(file_ops is None or self.root != ROOT, 'NATIVE_DEFAULT_FILE_OPS_REQUIRED')
        self.files = file_ops or FileOps()
        self.b.lease = self.lease
        self.base = copy.deepcopy(current.base)
        self.before_source, self.before_static = dict(current.source), dict(current.static)
        need(len(self.before_source) == 209 and len(self.before_static) == 26
             and all(digest(v) for v in [*self.before_source.values(), *self.before_static.values()]), 'EXACT_CURRENT_SOURCE209_STATIC26_REQUIRED')
        need(self.base['containers']['content']['image'] == CONTENT and len(self.base['containers']['content']['files']) == 22
             and self.base['worker']['image'] == WORKER and self.base['selected']['content']['PALITRA_WEB_UPLOADS_ENABLED'] == 'true', 'EXACT_ACCEPTED_CURRENT22_REQUIRED')
        self.cabinet, self.editor = current.cabinet, current.editor
        self.parents = {str(p): self.facts(p) for p in (self.root, self.cabinet, self.editor)}
        self.payload = a.exact_path(payload)
        need(self.payload.is_relative_to(self.root), 'ROOT_PAYLOAD_REQUIRED')
        need(digest(manifest_pin) and MANIFEST_SHA != UNFROZEN and manifest_pin == MANIFEST_SHA, 'MANIFEST_NOT_FROZEN')
        self.manifest_pin = manifest_pin
        manifest = a.pinned(self.payload / 'MANIFEST.json', manifest_pin)
        need(type(manifest) is dict and set(manifest) == {'schema', 'status', 'records'} and manifest['schema'] == 1
             and manifest['status'] == SCOPE and type(manifest['records']) is list and len(manifest['records']) == 5, 'EXACT_FIVE_PAYLOADS_REQUIRED')
        self.helper, self.wrapper = a.exact_path(__file__), a.exact_path(Path(__file__).parent / 'journey.py')
        self.pins = {str(self.helper): sha(a.read(self.helper)), str(self.wrapper): sha(a.read(self.wrapper)), str(self.payload / 'MANIFEST.json'): manifest_pin}
        self.records, self.targets = {}, {}
        self.final_source, self.final_static = dict(self.before_source), dict(self.before_static)
        for row in manifest['records']:
            self.accept(row)
        need(set(self.records) == NAMES and len(self.static_targets()) == 5, 'EXACT_PRODUCT3_EDITOR2_REQUIRED')
        found = set()
        for path in self.payload.rglob('*'):
            a.exact_path(path)
            relative = path.relative_to(self.payload).as_posix()
            if path.is_file(): found.add(relative)
            else: need(path.is_dir() and relative in {'product', 'editor'}, 'CLOSED_PAYLOAD_DIRECTORY_REQUIRED')
        need(found == NAMES | {'MANIFEST.json'}, 'CLOSED_FIVE_PAYLOADS_REQUIRED')

    def facts(self, path):
        row = self.a.exact_path(path).stat()
        need(stat.S_ISDIR(row.st_mode), 'EXACT_DIRECTORY_PARENT_REQUIRED')
        return [row.st_dev, row.st_ino, row.st_uid, stat.S_IMODE(row.st_mode)]

    def parents_guard(self):
        need({name: self.facts(Path(name)) for name in self.parents} == self.parents, 'STATIC_PARENT_IDENTITY_CHANGED')

    def target_map(self, name):
        group, leaf = name.split('/')
        return [('source', 'palitra-orders-public/' + leaf), ('static', str(self.cabinet / leaf))] if group == 'product' else [('static', str(self.editor / leaf))]

    def accept(self, row):
        need(type(row) is dict and set(row) == {'name', 'payload', 'beforeSha256', 'beforeBytes', 'sha256', 'bytes', 'hunks'}, 'EXACT_MANIFEST_RECORD_REQUIRED')
        name = row['name']
        need(type(name) is str and name in NAMES and name not in self.records and row['payload'] == name
             and all(digest(row[k]) for k in ('beforeSha256', 'sha256')) and row['beforeSha256'] != row['sha256']
             and all(type(row[k]) is int and 0 < row[k] <= 2 * 1024 * 1024 for k in ('beforeBytes', 'bytes'))
             and type(row['hunks']) is list and 1 <= len(row['hunks']) <= 256, 'EXACT_CHANGED_EXISTING_RECORD_REQUIRED')
        raw = self.a.read(self.payload / name)
        need(len(raw) == row['bytes'] and sha(raw) == row['sha256'], 'PAYLOAD_CHANGED')
        old = raw
        for hunk in reversed(row['hunks']):
            need(type(hunk) is dict and set(hunk) == {'before', 'after'} and all(type(hunk[k]) is str and hunk[k] for k in hunk)
                 and hunk['before'] != hunk['after'] and max(len(v.encode()) for v in hunk.values()) <= 2 * 1024 * 1024, 'BOUNDED_UNIQUE_HUNK_REQUIRED')
            before, after = hunk['before'].encode(), hunk['after'].encode()
            need(old.count(after) == 1, 'REVERSE_UNIQUE_HUNK_REQUIRED')
            old = old.replace(after, before, 1)
        need(len(old) == row['beforeBytes'] and sha(old) == row['beforeSha256'] and self.patch(old, row) == raw, 'EXACT_RECONSTRUCTED_BASE_REQUIRED')
        targets = self.target_map(name)
        for kind, target in targets:
            before = self.before_source if kind == 'source' else self.before_static
            final = self.final_source if kind == 'source' else self.final_static
            need(before.get(target) == row['beforeSha256'], 'EXACT_ACCEPTED_TARGET_BASE_REQUIRED')
            final[target] = row['sha256']
        self.records[name], self.targets[name] = row, targets
        self.pins[str(self.payload / name)] = row['sha256']

    def patch(self, raw, row):
        need(len(raw) == row['beforeBytes'] and sha(raw) == row['beforeSha256'], 'ACTUAL_RAW_BASE_CHANGED')
        for hunk in row['hunks']:
            before, after = hunk['before'].encode(), hunk['after'].encode()
            need(raw.count(before) == 1, 'FORWARD_UNIQUE_HUNK_REQUIRED')
            raw = raw.replace(before, after, 1)
        need(len(raw) == row['bytes'] and sha(raw) == row['sha256'], 'FINAL_BYTES_CHANGED')
        return raw

    def static_targets(self):
        return [(name, Path(target)) for name in sorted(self.targets) for kind, target in self.targets[name] if kind == 'static']

    def paths(self):
        return {key: self.root / (NAME + '-' + key + ('.json' if key in ('decision', 'journal', 'overlay') else '')) for key in ('decision', 'journal', 'overlay', 'context', 'backup')}

    def lease(self):
        raw = self.run(['lslocks', '--noheadings', '--output', 'PID,PATH'])
        need(len(raw) <= 1048576, 'BOUNDED_LEASE_INVENTORY_REQUIRED')
        rows = [line.strip().split(maxsplit=1) for line in raw.decode().splitlines() if len(line.strip().split(maxsplit=1)) == 2 and line.strip().split(maxsplit=1)[1] == LOCK]
        need(rows == [[str(self.lease_pid), LOCK]], 'FRESH_EXCLUSIVE_ROOT_LEASE_REQUIRED')

    def stable(self):
        self.current.stable()
        for name, pin in self.pins.items(): need(sha(self.a.read(Path(name))) == pin, 'JOURNEY_PINNED_INPUT_CHANGED')
        self.parents_guard()

    def absent(self, decision=False):
        for kind, path in self.paths().items():
            if kind == 'decision' and not decision: continue
            self.a.exact_path(path, True)
            need(not os.path.lexists(path) and not os.path.lexists(str(path) + '.pending'), 'ATTEMPT_EXISTS_NO_RETRY')

    def expected_metadata(self, service, content, proof):
        if service == 'chat': return copy.deepcopy(self.base['containers']['chat'])
        old = self.base['containers']['content']
        if content == CONTENT:
            need(proof is None, 'BASE_PROOF_MUST_BE_EMPTY')
            return copy.deepcopy(old)
        need(type(proof) is dict and set(proof) == {'childImage', 'overlaySha256', 'plannedConfigHash'} and proof['childImage'] == content
             and self.a.image(content) and content != CONTENT and digest(proof['overlaySha256']) and digest(proof['plannedConfigHash']), 'OWN_SEALED_CHILD_PROOF_REQUIRED')
        overlay = self.paths()['overlay']
        need(sha(self.a.read(overlay)) == proof['overlaySha256'] and self.a.decode(self.a.read(overlay)) == {'services': {'content': {'image': content}}}, 'OWN_SEALED_OVERLAY_CHANGED')
        files = old['files'] + [str(overlay)]
        need(len(old['files']) == 22 and len(files) == len(set(files)) == 23, 'EXACT_OWN_CHAIN23_REQUIRED')
        return dict(old, image=content, files=files, configFiles=','.join(files), filePins={**old['filePins'], str(overlay): proof['overlaySha256']}, configHash=proof['plannedConfigHash'])

    def metadata(self, service, expected):
        if service == 'chat':
            row = self.b.metadata(service)
        else:
            row = self.a.decode(self.run(['docker', 'inspect', '--format', self.a.LABELS, 'synapse-content-1']))
            need(type(row) is dict and set(row) == {'image', 'project', 'service', 'workingDir', 'configFiles', 'configHash', 'running', 'health'}
                 and type(row['configFiles']) is str and len(row['configFiles']) <= 65536, 'EXACT_CONTENT_LABELS_REQUIRED')
            files = row['configFiles'].split(',')
            need(files == expected['files'] and len(files) == len(set(files)) and len(files) in (22, 23), 'ONLY_EXACT_BASE22_OR_OWN23_REQUIRED')
            pins = {}
            for name in files:
                path = self.a.exact_path(name)
                need(path.suffix.lower() in ('.json', '.yml', '.yaml'), 'EXACT_COMPOSE_FILE_REQUIRED')
                pins[name] = sha(self.a.read(path))
            row.update(files=files, filePins=pins)
        need(row == expected, 'EXACT_METADATA_FILEPINS_CHANGED')
        return row

    def static_guard(self, changed):
        self.parents_guard()
        self.current.guide_guard()
        for name, pin in (self.final_static if changed else self.before_static).items():
            need(sha(self.a.read(Path(name))) == pin, 'FULL_STATIC26_CHANGED')

    def snapshot(self, content=CONTENT, changed=False, proof=None, static_changed=None):
        self.stable(); self.lease()
        first = {s: self.metadata(s, self.expected_metadata(s, content, proof)) for s in ('content', 'chat')}
        worker = self.b.worker_facts()
        selected = {s: self.b.a.selected(s) for s in ('content', 'chat')}
        flags = self.a.decode(self.run(['docker', 'exec', 'synapse-content-1', 'node', '-e', self.a.FLAGS_JS]))
        need(worker == self.base['worker'] and selected == self.base['selected'] and flags == self.base['l12'], 'WORKER_FLAGS_OR_SELECTION_CHANGED')
        for service, row in first.items():
            text = self.run(self.b._resolve_command(row, service)).decode('ascii').strip()
            need(re.fullmatch(re.escape(service) + r'\s+' + re.escape(row['configHash']), text) is not None, 'RESOLVED_CONFIG_HASH_CHANGED')
        self.b.graph(new=True); self.b.push_guard()
        expected = self.final_source if changed else self.before_source
        need(self.photo.hashes(expected) == expected, 'FULL_SOURCE209_CHANGED')
        self.static_guard(changed if static_changed is None else static_changed)
        cid = self.photo.cid()
        last = {s: self.metadata(s, self.expected_metadata(s, content, proof)) for s in ('content', 'chat')}
        need(first == last and worker == self.b.worker_facts() and selected == {s: self.b.a.selected(s) for s in ('content', 'chat')}
             and cid == self.photo.cid(), 'CONCURRENT_RUNTIME_CHANGE')
        self.stable(); self.lease()
        return {'containers': last, 'selected': selected, 'worker': worker, 'contentCid': cid, 'l12': flags}

    def baseline(self):
        snap = self.snapshot()
        need(snap == self.base and self.b.heartbeat(snap['worker']['startedAt'], self.clock())['freshAfterWorkerStart'], 'FRESH_CURRENT22_REQUIRED')
        return snap

    def users(self, child=None):
        rows = {'current': self.a.decode(self.run(['docker', 'inspect', '--format', USER_FORMAT, 'synapse-content-1'])),
                'parent': self.a.decode(self.run(['docker', 'image', 'inspect', '--format', USER_FORMAT, CONTENT]))}
        if child: rows['child'] = self.a.decode(self.run(['docker', 'image', 'inspect', '--format', USER_FORMAT, child]))
        need(all(type(v) is str and v in ROOT_USERS for v in rows.values()) and (not child or rows['parent'] == rows['child']), 'ROOT_SERVICE_READ_SCOPE_REQUIRED')
        return rows

    def modes(self):
        result = {}
        for _, path in self.static_targets():
            row = self.a.exact_path(path).stat()
            expected_uid = 0 if self.root == ROOT else (os.getuid() if hasattr(os, 'getuid') else row.st_uid)
            need(stat.S_ISREG(row.st_mode) and row.st_uid == expected_uid, 'ROOT_OWNED_EXISTING_STATIC_REQUIRED')
            result[str(path)] = self.files.mode(path)
        return result

    def binding(self):
        return {'priorReceiptSha256': PRIOR_RECEIPT_SHA, 'parentImage': CONTENT, 'workerImage': WORKER, 'manifestSha256': self.manifest_pin,
                'helperSha256': self.pins[str(self.helper)], 'wrapperSha256': self.pins[str(self.wrapper)], 'freshLeasePid': self.lease_pid, 'parents': self.parents}

    def decision(self, pin):
        value = self.a.pinned(self.paths()['decision'], pin, True)
        need(type(value) is dict and set(value) == {'schema', 'name', 'scope', 'rootApproved', 'observedAtUtc', 'inputs', 'before', 'staticModes', 'serviceUsers'}
             and value['schema'] == 1 and value['name'] == NAME and value['scope'] == SCOPE and value['rootApproved'] is True
             and value['inputs'] == self.binding() and value['before'] == self.base and value['serviceUsers'] == self.users(), 'EXACT_NEW_ROOT_DECISION_REQUIRED')
        self.a.fresh(value['observedAtUtc'], self.clock())
        need(type(value['staticModes']) is dict and set(value['staticModes']) == {str(p) for _, p in self.static_targets()}
             and all(type(v) is int and 0 < v <= 0o777 for v in value['staticModes'].values()), 'EXACT_APPROVED_STATIC_MODES_REQUIRED')
        return value

    def inspect_current(self):
        self.baseline(); self.users()
        return {'status': 'CURRENT22_READONLY_NOT_APPROVED', 'sourceFiles': 209, 'staticFiles': 26, 'contentChainFiles': 22, 'mutations': 0}

    def approve(self, apply=False):
        need(apply is True, 'EXPLICIT_ROOT_APPROVAL_REQUIRED')
        self.absent(True); at = self.clock(); before = self.baseline()
        modes, users = self.modes(), self.users()
        self.a.fresh(self.a.stamp(at), self.clock())
        value = {'schema': 1, 'name': NAME, 'scope': SCOPE, 'rootApproved': True, 'observedAtUtc': self.a.stamp(at), 'inputs': self.binding(),
                 'before': before, 'staticModes': modes, 'serviceUsers': users}
        self.a.write_new(self.paths()['decision'], value)
        return {'status': 'NEW_DECISION_NOT_APPLIED', 'decisionSha256': sha(self.a.read(self.paths()['decision'])), 'runtimeWrites': 0}

    def context_proof(self, state, built=False):
        paths = self.paths(); alias = 'palitra-forms-consistency-base:' + NAME
        wanted = {'Dockerfile': sha(('FROM ' + alias + '\nCOPY app/ /app/\n').encode())}
        wanted.update({'app/' + target: self.records[name]['sha256'] for name in self.records for kind, target in self.targets[name] if kind == 'source'})
        wanted.update({'static/' + str(i): row['sha256'] for i, row in enumerate(state['static'])})
        actual = {}
        for path in paths['context'].rglob('*'):
            self.a.exact_path(path)
            name = path.relative_to(paths['context']).as_posix()
            if path.is_file():
                if built and name == 'image.id': continue
                actual[name] = sha(self.a.read(path))
            else: need(path.is_dir() and name in {'app', 'app/palitra-orders-public', 'static'}, 'CLOSED_CONTEXT_DIRECTORIES_REQUIRED')
        need(actual == wanted, 'EXACT_CLOSED_CONTEXT_REQUIRED')
        return sha(json.dumps(sorted(actual.items()), separators=(',', ':')).encode())

    def update(self, state, phase, **fields):
        state.update(phase=phase, **fields); self.a.replace(self.paths()['journal'], state)

    def unused(self, tag):
        need(not self.run(['docker', 'image', 'ls', '--quiet', '--filter', 'reference=' + tag]).strip(), 'UNIQUE_NEW_IMAGE_TAG_REQUIRED')

    def backup_directory_facts(self):
        path = self.a.exact_path(self.paths()['backup']); row = path.stat()
        expected_uid = 0 if self.root == ROOT else (os.getuid() if hasattr(os, 'getuid') else row.st_uid)
        need(stat.S_ISDIR(row.st_mode) and row.st_uid == expected_uid and self.files.mode(path) == 0o700, 'PRIVATE_BACKUP_DIRECTORY_REQUIRED')
        return {'path': str(path), 'device': row.st_dev, 'inode': row.st_ino, 'uid': row.st_uid, 'mode': 0o700}

    def backup_directory_guard(self, sealed):
        self.parents_guard()
        need(type(sealed) is dict and set(sealed) == {'path', 'device', 'inode', 'uid', 'mode'}
             and sealed['path'] == str(self.paths()['backup']) and sealed['mode'] == 0o700
             and all(type(sealed[key]) is int for key in ('device', 'inode', 'uid', 'mode'))
             and self.backup_directory_facts() == sealed, 'BACKUP_DIRECTORY_IDENTITY_CHANGED')

    def backup_row_guard(self, row, directory=None):
        directory = directory if directory is not None else getattr(self, 'backup_directory', None)
        self.backup_directory_guard(directory)
        need(type(row) is dict and set(row) == {'target', 'baseSha256', 'sha256', 'mode', 'prepared', 'backup', 'written'}, 'EXACT_BACKUP_ROW_REQUIRED')
        matches = [(i, name, path) for i, (name, path) in enumerate(self.static_targets()) if row['target'] == str(path)]
        need(len(matches) == 1, 'EXACT_BACKUP_TARGET_REQUIRED')
        index, name, target = matches[0]; record = self.records[name]
        need(row['baseSha256'] == record['beforeSha256'] and row['sha256'] == record['sha256']
             and row['prepared'] == str(self.paths()['context'] / 'static' / str(index))
             and row['backup'] == str(self.paths()['backup'] / str(index))
             and type(row['mode']) is int and 0 < row['mode'] <= 0o777 and type(row['written']) is bool, 'EXACT_BACKUP_PATHS_AND_PINS_REQUIRED')
        path = self.a.exact_path(Path(row['backup']))
        flags = os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_CLOEXEC', 0) | getattr(os, 'O_BINARY', 0)
        fd = os.open(path, flags)
        try:
            first = os.fstat(fd)
            need(stat.S_ISREG(first.st_mode) and first.st_uid == directory['uid'] and self.files.fd_mode(fd) == 0o600
                 and first.st_size == record['beforeBytes'], 'PRIVATE_REGULAR_BACKUP_REQUIRED')
            raw_hash = hashlib.sha256(); total = 0
            while True:
                raw = os.read(fd, 65536)
                if not raw: break
                total += len(raw); need(total <= record['beforeBytes'], 'BACKUP_SIZE_CHANGED'); raw_hash.update(raw)
            last = os.fstat(fd); actual = self.a.exact_path(path).stat()
            identity = (first.st_dev, first.st_ino, first.st_uid)
            need(identity == (last.st_dev, last.st_ino, last.st_uid) == (actual.st_dev, actual.st_ino, actual.st_uid)
                 and stat.S_ISREG(actual.st_mode) and self.files.fd_mode(fd) == self.files.mode(path) == 0o600
                 and total == record['beforeBytes'] and raw_hash.hexdigest() == row['baseSha256'], 'BACKUP_SHA_MODE_OR_IDENTITY_CHANGED')
        finally:
            os.close(fd)
        self.backup_directory_guard(directory)

    def backup_guard(self, state):
        need(type(state.get('static')) is list and len(state['static']) == 5
             and [row.get('target') if type(row) is dict else None for row in state['static']] == [str(path) for _, path in self.static_targets()], 'EXACT_BACKUP_FIXED_FIVE_MAP_REQUIRED')
        directory = state.get('backupDirectory'); self.backup_directory_guard(directory)
        need({path.name for path in self.paths()['backup'].iterdir()} == {str(i) for i in range(5)}, 'CLOSED_BACKUP_DIRECTORY_REQUIRED')
        for row in state['static']: self.backup_row_guard(row, directory)

    def publish(self, row):
        self.backup_row_guard(row)
        self.parents_guard(); target = self.a.exact_path(row['target'])
        need(sha(self.a.read(target)) == row['baseSha256'] and self.files.mode(target) == row['mode'], 'STATIC_CAS_CONFLICT')
        raw = self.a.read(Path(row['prepared'])); need(sha(raw) == row['sha256'], 'PREPARED_STATIC_CHANGED')
        pending = target.with_name(target.name + '.forms-consistency-r1-pending')
        self.a.exact_path(pending, True)
        identity = self.files.write(pending, raw, row['mode'])
        info = self.a.exact_path(pending).stat()
        need((info.st_dev, info.st_ino, info.st_uid) == identity and self.files.mode(pending) == row['mode']
             and sha(self.a.read(pending)) == row['sha256'], 'PENDING_MODE_SHA_OR_IDENTITY_CHANGED')
        self.parents_guard(); self.a.exact_path(target)
        need(sha(self.a.read(target)) == row['baseSha256'] and self.files.mode(target) == row['mode'], 'LATE_STATIC_CAS_CONFLICT')
        os.replace(pending, target)
        need(sha(self.a.read(target)) == row['sha256'] and self.files.mode(target) == row['mode'], 'PUBLISHED_MODE_OR_SHA_CHANGED')

    def apply(self, pin, apply=False):
        need(apply is True, 'EXPLICIT_ROOT_APPLY_REQUIRED')
        self.absent(); decision = self.decision(pin); before = self.baseline()
        need(self.modes() == decision['staticModes'], 'APPROVED_MODES_CHANGED')
        self.users(); paths = self.paths(); alias = 'palitra-forms-consistency-base:' + NAME; tag = 'palitra-forms-consistency:' + NAME
        self.unused(alias); self.unused(tag)
        need(self.run(['docker', 'image', 'inspect', '--format', '{{.Id}}', CONTENT]).decode().strip() == CONTENT, 'EXACT_LOCAL_PARENT_REQUIRED')
        layers = self.a.decode(self.run(['docker', 'image', 'inspect', '--format', '{{json .RootFS.Layers}}', CONTENT]))
        need(type(layers) is list and layers, 'PARENT_LAYER_PROOF_REQUIRED')
        state = {'schema': 1, 'name': NAME, 'phase': 'CONTEXT_STARTED_UNKNOWN', 'inputs': self.binding(), 'decisionSha256': pin, 'before': before,
                 'static': [], 'workerRecreated': False, 'uploadsEnabled': True, 'directDbWrites': 0, 'queueEdits': 0, 'automaticRetry': False,
                 'automaticCodeRollback': False, 'oldJournalWrites': 0}
        self.a.write_new(paths['journal'], state)
        for path, mode in ((paths['context'], 0o700), (paths['backup'], 0o700), (paths['context'] / 'app', 0o755),
                           (paths['context'] / 'app/palitra-orders-public', 0o755), (paths['context'] / 'static', 0o700)):
            self.files.directory(self.a.exact_path(path, True), mode)
        self.backup_directory = self.backup_directory_facts(); state['backupDirectory'] = copy.deepcopy(self.backup_directory)
        for name in sorted(self.records):
            record = self.records[name]
            if name.startswith('product/'):
                target = 'palitra-orders-public/' + name.split('/')[1]
                raw = self.run(['docker', 'exec', 'synapse-content-1', 'node', '-e', self.current.source_script, target])
                need(len(raw) <= 3 * 1024 * 1024, 'BOUNDED_SOURCE_BYTES_REQUIRED')
                patched = self.patch(base64.b64decode(raw, validate=True), record)
                self.files.write(paths['context'] / 'app' / target, patched, 0o644)
        for index, (name, target) in enumerate(self.static_targets()):
            old = self.a.read(target); patched = self.patch(old, self.records[name]); mode = decision['staticModes'][str(target)]
            prepared, backup = paths['context'] / 'static' / str(index), paths['backup'] / str(index)
            self.files.write(prepared, patched, 0o600); self.files.write(backup, old, 0o600)
            state['static'].append({'target': str(target), 'baseSha256': sha(old), 'sha256': sha(patched), 'mode': mode,
                                    'prepared': str(prepared), 'backup': str(backup), 'written': False})
        self.files.write(paths['context'] / 'Dockerfile', ('FROM ' + alias + '\nCOPY app/ /app/\n').encode(), 0o600)
        self.update(state, 'CONTEXT_READY_NOT_BUILT', contextSha256=self.context_proof(state))
        self.baseline(); self.decision(pin); self.lease(); self.unused(alias); self.unused(tag)
        self.run(['docker', 'image', 'tag', CONTENT, alias])
        need(self.run(['docker', 'image', 'inspect', '--format', '{{.Id}}', alias]).decode().strip() == CONTENT, 'NEW_PARENT_ALIAS_CHANGED')
        self.update(state, 'BUILD_STARTED_UNKNOWN'); self.decision(pin); self.lease()
        need(self.context_proof(state) == state['contextSha256']
             and self.run(['docker', 'image', 'inspect', '--format', '{{.Id}}', alias]).decode().strip() == CONTENT, 'LAST_BUILD_CONTEXT_OR_PARENT_CHANGED')
        self.run(['docker', 'build', '--network=none', '--pull=false', '--tag', tag, '--iidfile', str(paths['context'] / 'image.id'), str(paths['context'])])
        child = self.a.read(paths['context'] / 'image.id').decode().strip()
        need(self.a.image(child) and child != CONTENT and self.run(['docker', 'image', 'inspect', '--format', '{{.Id}}', tag]).decode().strip() == child, 'EXACT_NEW_CHILD_REQUIRED')
        child_layers = self.a.decode(self.run(['docker', 'image', 'inspect', '--format', '{{json .RootFS.Layers}}', child]))
        need(type(child_layers) is list and child_layers[:len(layers)] == layers and len(child_layers) == len(layers) + 1, 'ONE_EXACT_COPY_LAYER_REQUIRED')
        need(self.context_proof(state, True) == state['contextSha256'] and self.photo.hashes(self.final_source, child) == self.final_source, 'BUILT_FULL_SOURCE209_CHANGED')
        self.users(child); self.baseline(); self.decision(pin)
        self.backup_guard(state)
        self.update(state, 'STATIC_STARTED_UNKNOWN', childImage=child)
        for row in state['static']:
            self.decision(pin); self.lease(); self.publish(row); row['written'] = True; self.a.replace(paths['journal'], state)
        self.static_guard(True); self.stable(); self.decision(pin); self.users(child)
        self.a.write_new(paths['overlay'], {'services': {'content': {'image': child}}})
        overlay_pin = sha(self.a.read(paths['overlay'])); planned = self.b.plan(before, 'content', paths['overlay'])
        self.update(state, 'CONTENT_UP_STARTED_UNKNOWN', overlay=str(paths['overlay']), overlaySha256=overlay_pin, plannedConfigHash=planned)
        # Old source is still running while the already-published static inventory is new.
        need(self.snapshot(static_changed=True) == before, 'LAST_COMPLETE_BASE22_CHANGED')
        self.decision(pin); self.lease(); self.stable(); self.users(child)
        need(self.context_proof(state, True) == state['contextSha256'] and self.b.plan(before, 'content', paths['overlay']) == planned, 'LAST_SEALED_PLAN_OR_CONTEXT_CHANGED')
        proof = {'childImage': child, 'overlaySha256': overlay_pin, 'plannedConfigHash': planned}
        self.expected_metadata('content', child, proof)
        self.backup_guard(state)
        self.b.up(before, 'content', paths['overlay'])
        after = self.snapshot(child, True, proof)
        self.users(child)
        need(after['contentCid'] != before['contentCid'] and self.b.heartbeat(after['worker']['startedAt'], self.clock())['freshAfterWorkerStart']
             and self.snapshot(child, True, proof) == after, 'FRESH_STABLE_AFTER_REQUIRED')
        self.update(state, PHASE, after=after, finishedAtUtc=self.a.stamp(self.clock()))
        return {'status': PHASE, 'journalSha256': sha(self.a.read(paths['journal'])), 'contentImage': child, 'sourceFiles': 209, 'staticFiles': 26,
                'contentChainFiles': 23, 'builds': 1, 'contentUps': 1, 'workerRecreated': False, 'uploadsEnabled': True,
                'directDbWrites': 0, 'queueEdits': 0, 'oldJournalWrites': 0, 'automaticRetry': False}

    def inspect(self, pin):
        state = self.a.pinned(self.paths()['journal'], pin, True)
        need(state.get('schema') == 1 and state.get('name') == NAME and state.get('phase') == PHASE and state.get('inputs') == self.binding()
             and state.get('before') == self.base and state.get('workerRecreated') is False and state.get('uploadsEnabled') is True
             and state.get('directDbWrites') == state.get('queueEdits') == state.get('oldJournalWrites') == 0
             and state.get('automaticRetry') is False and state.get('automaticCodeRollback') is False
             and type(state.get('static')) is list and len(state['static']) == 5 and all(x.get('written') is True for x in state['static']), 'OWN_COMPLETED_RECEIPT_REQUIRED')
        self.backup_guard(state)
        proof = {key: state[key] for key in ('childImage', 'overlaySha256', 'plannedConfigHash')}
        need(state.get('overlay') == str(self.paths()['overlay']) and self.context_proof(state, True) == state['contextSha256'], 'COMPLETED_CONTEXT_OR_OVERLAY_CHANGED')
        for row in state['static']:
            need(self.files.mode(Path(row['target'])) == row['mode'], 'COMPLETED_TARGET_MODE_CHANGED')
        need(self.snapshot(state['childImage'], True, proof) == state['after'], 'COMPLETED_RUNTIME_CHANGED')
        return {'status': 'COMPLETED23_READONLY_NOT_CUSTOMER_ACCEPTANCE', 'mutations': 0, 'heartbeat': self.b.heartbeat(self.base['worker']['startedAt'], self.clock())}


def load_current(lease_pid):
    """Pinned historical constructors only; no predecessor action or stale lease use."""
    path = PRIOR_CODE / 'forward_recovery_native.py'
    for item in [*reversed(path.parents), path, PRIOR_CODE / 'forward.py']:
        need(not item.is_symlink(), 'HISTORICAL_CODE_SYMLINK_REFUSED')
    raw = path.read_bytes(); need(sha(raw) == PRIOR_HELPER_SHA, 'EXACT_CHAIN22_READER_HELPER_REQUIRED')
    need(sha((PRIOR_CODE / 'forward.py').read_bytes()) == PRIOR_WRAPPER_SHA, 'EXACT_CHAIN22_READER_WRAPPER_REQUIRED')
    prior = types.ModuleType('historical_chain22'); prior.__file__ = str(path); exec(compile(raw, str(path), 'exec'), prior.__dict__)
    old = prior.load_old(); a, b, pwa = old.load_lineage(lease_pid)
    receipt = a.pinned(ROOT / 'palitra-editor-chat-guide-forward-r1-journal.json', PRIOR_RECEIPT_SHA, True)
    historical_pid = receipt.get('inputs', {}).get('freshLeasePid')
    need(type(historical_pid) is int and historical_pid > 1, 'HISTORICAL_RECEIPT_LEASE_BINDING_REQUIRED')
    accepted = prior.recovery_class(old)(a, b, pwa, prior.OLD_CODE / 'payload', prior.OLD_MANIFEST_SHA, historical_pid, PRIOR_CODE / 'RECOVERY_SEAL.json')
    need(receipt.get('schema') == 1 and receipt.get('phase') == prior.PHASE and receipt.get('inputs') == accepted.binding()
         and receipt.get('before') == accepted.base and receipt.get('childImage') == CONTENT and receipt.get('oldJournalWrites') == 0
         and receipt.get('workerRecreated') is False and receipt.get('uploadsEnabled') is True, 'EXACT_COMPLETED_CHAIN22_RECEIPT_REQUIRED')
    proof = {key: receipt[key] for key in ('childImage', 'overlaySha256', 'plannedConfigHash')}
    need(receipt.get('overlay') == str(accepted.paths()['overlay']) and receipt['after']['containers']['content'] == accepted.expected_metadata('content', CONTENT, proof), 'EXACT_COMPLETED22_METADATA_REQUIRED')
    accepted.transition(accepted.base, receipt['after'], accepted.paths()['overlay'], receipt['plannedConfigHash'], CONTENT)
    accepted.guide_created = receipt['guideDirectory']
    def stable():
        accepted.stable()
        need(sha(a.read(ROOT / 'palitra-editor-chat-guide-forward-r1-journal.json')) == PRIOR_RECEIPT_SHA, 'CHAIN22_COMPLETED_RECEIPT_CHANGED')
    def guide_guard():
        need(accepted.guide_facts() == accepted.guide_created, 'ACCEPTED_GUIDE_DIRECTORY_CHANGED')
        for record in accepted.failed['static']:
            info = a.exact_path(record['target']).stat()
            need(stat.S_ISREG(info.st_mode) and info.st_uid == 0 and stat.S_IMODE(info.st_mode) == record['mode'], 'ACCEPTED_STATIC_MODES_CHANGED')
    current = types.SimpleNamespace(base=receipt['after'], source=accepted.final_source, static=accepted.final_static, cabinet=accepted.cabinet, editor=accepted.editor,
                                    stable=stable, guide_guard=guide_guard, source_script=accepted.photo.ui.inc.SOURCE_JS)
    return a, b, current


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=('inspect-current', 'approve-current', 'apply', 'inspect'))
    parser.add_argument('--lease-pid', required=True, type=int)
    parser.add_argument('--decision-sha'); parser.add_argument('--receipt-sha'); parser.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    try:
        need(MANIFEST_SHA != UNFROZEN, 'DRAFT_NOT_FROZEN_NO_NATIVE_ACTION')
        need(os.name == 'posix' and os.geteuid() == 0 and Path(__file__).resolve().parent == ROOT / CODE_NAME, 'EXACT_ROOT_NEW_NAMESPACE_REQUIRED')
        a, b, current = load_current(args.lease_pid)
        release = JourneyRelease(a, b, current, ROOT / CODE_NAME / 'payload', MANIFEST_SHA, args.lease_pid)
        if args.operation == 'inspect-current': result = release.inspect_current()
        elif args.operation == 'approve-current': result = release.approve(args.apply)
        elif args.operation == 'apply':
            need(digest(args.decision_sha), 'EXPLICIT_NEW_DECISION_SHA_REQUIRED'); result = release.apply(args.decision_sha, args.apply)
        else:
            need(digest(args.receipt_sha), 'EXPLICIT_OWN_RECEIPT_SHA_REQUIRED'); result = release.inspect(args.receipt_sha)
        print(json.dumps(result, separators=(',', ':'))); return 0
    except Exception as error:
        code = str(error) if type(error) is ValueError and re.fullmatch('[A-Z][A-Z0-9_]{0,100}', str(error)) else 'NEW_RELEASE_ACTION_REFUSED'
        print(json.dumps({'status': 'REFUSED_OR_UNKNOWN_NO_AUTOMATIC_RETRY', 'code': code, 'messageSha256': sha(str(error).encode()),
                          'automaticRetry': False, 'automaticCodeRollback': False, 'workerRecreated': False, 'oldJournalWrites': 0})); return 2


if __name__ == '__main__': sys.exit(main())
